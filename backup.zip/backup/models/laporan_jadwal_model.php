<?php
/**
 * 
 */
class Laporan_jadwal_model extends Model
{

	public function pkpt($tahun)
	{
		$return =  $this->getvalue("SELECT autono, nomor_pkpt, keterangan FROM tpkpt WHERE nomor_pkpt LIKE '%$tahun' GROUP BY nomor_pkpt");

		return $return;
	}

	public function pkpt_detail($id)
    {
        $items = array();
        $provinsi = $this->execute("SELECT autono, title, id_pkpt, id_jns_audit, `start`, MONTH(`start`) AS bulan, color FROM tpkpt_detil WHERE id_pkpt = $id ORDER BY MONTH(`start`) ASC");
        while ($row = $this->fetch_assoc($provinsi)) {
            $data['id'] = $row['autono'];
            $data['bulan'] = $row['bulan'];
            $data['jenis_audit'] = $row['id_jns_audit'];
            $data['satker'] = array();

            $kota = $this->execute("SELECT a.id_pkpt, a.id_kotama, b.nm_kotama FROM tpkptsat AS a LEFT JOIN (SELECT kd_kotama, nm_kotama FROM tkotama GROUP BY kd_kotama) AS b ON a.id_kotama = b.kd_kotama WHERE a.id_pkpt = ".$data['id']." AND b.nm_kotama IS NOT NULL");
            while ($rows = $this->fetch_assoc($kota)) {
                array_push($data['satker'], $rows);
            }
            array_push($items, $data);
        }

        return $items;
    }


    public function pkpt_rev($id)
	{
		$items = array();
        $provinsi = $this->execute("SELECT a.autono, a.title, a.id_pkpt, b.id_jns_audit, MONTH(a.`start`) AS bulan, a.color FROM tpkpt_detil_rev a  LEFT JOIN (SELECT id_pkpt,  id_jns_audit,  MONTH(`start`) AS bulan FROM tpkpt_detil) AS b ON a.`id_pkpt` = b.id_pkpt AND MONTH(a.`start`) = b.bulan WHERE a.id_pkpt = $id");
        while ($row = $this->fetch_assoc($provinsi)) {
            $data['id'] = $row['autono'];
            $data['bulan'] = $row['bulan'];
            $data['jenis_audit'] = $row['id_jns_audit'];
            $data['satker'] = array();

            $kota = $this->execute("SELECT a.id_pkpt, a.id_review, b.nm_review FROM tpkptrev AS a LEFT JOIN (SELECT autono, nm_review FROM treview GROUP BY autono) AS b ON a.id_review = b.autono WHERE a.id_pkpt = ".$data['id']." ");
            while ($rows = $this->fetch_assoc($kota)) {
                array_push($data['satker'], $rows);
            }
            array_push($items, $data);
        }

        return $items;
	}

	
}