<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Uploadextract extends CI_Controller {

	public function index()
	{
		// print_r($map);
		/* start insert */
		$uo = $this->uri->segment(3);
		if (isset($_POST['submit'])){
			$config['upload_path'] = 'assets/uploads/file_pbf/'.$uo.'/';
			$config['allowed_types'] = 'DBF|dbf|zip|rar';
			$config['max_size']  = '550000'; //Kb
			$this->load->library('upload', $config);
			$this->upload->do_upload('filetni');
		}else{
			$data['title'] = "upload file extrac";
			$this->template->load('administrator/template','administrator/mod_upload_extract/view',$data);
		}
		/* end insert */
		
	}

	function f_upload()
	{
		$ret = array();
		$config['upload_path']   = 'assets/uploads/';
		$this->load->library('upload', $config);

		$error = $this->upload->display_errors('<p>', '</p>');

		if ($this->upload->do_upload('cc')) {
			$data = array('xyz'=>$this->upload->data());
			$file = $data['xyz']['file_name'];
			$ret[] = $file;
			echo json_encode($ret);
		}

	}



}

/* End of file Upload.php */
/* Location: ./application/controllers/Upload.php */