<?php



class Analisa_tj_verku_model extends Model {



	public function mget($request, $table, $primaryKey, $columns,$field = null,$key = null,$key2 = null)

	{

		 $join = 'a 
		 		  LEFT JOIN (SELECT tahun,bulan,kotama,satminkal,kategori AS belanja_pegawai FROM vt_verku_renlak_detail WHERE tahun = '.$key.' AND bulan = '.$key2.' AND kategori = 1) b ON a.`kd_kotama` = b.`kotama` AND a.`kd_satminkal` = b.`satminkal`';
		 $group = 'order by nm_satminkal';
		$result = $this->dt($request, $table, $primaryKey, $columns,$join,$field,$key,$group,$key2);


		return $result;

	}



	public function mget_detail($request, $table, $primaryKey, $columns, $join)

	{

		$result = $this->simple_detail6($request, $table, $primaryKey, $columns, $join );

		return $result;

	}

	public function mget_detail_($request, $table, $primaryKey, $columns, $join)

	{

		$result = $this->simple_detail6($request, $table, $primaryKey, $columns, $join);

		return $result;

	}



	public function get($table, $primaryKey, $id)

	{

		$result = $this->query("SELECT * FROM $table WHERE $primaryKey = '$id'");

		return $result;

	}

		public function mupdate($table, $data = array(), $primary, $id,  $primary1, $id1, $primary2, $id2, $primary3, $id3, $primary4, $id4 ,  $menu)

	{	

		// $result = $this->getvalue("SELECT * FROM $table WHERE $primaryKey1 = '$id1' AND $primaryKey2 = '$id1'");

		// if ($result['satker'] == 0)
		// {'tes';}
		// else
		// {'tes2';}

		$result = $this->sqlupdate_jnhv_tjnhv($table, $data, $primary, $id, $primary1, $id1, $primary2, $id2, $primary3, $id3, $primary4, $id4,  $menu);

		return $result;

	}




	public function msave($table, $data = array(), $title)

	{

		$result = $this->sqlinsert($table, $data, $title);

		return $result;

	}



	// public function mupdate($table, $data = array(), $primaryKey, $id, $title)

	// {

	// 	$result = $this->sqlupdate($table, $data, $primaryKey, $id, $title);

	// 	return $result;

	// }



	public function mdelete($table, $primaryKey, $id, $title)

    {

        $result = $this->sqldelete($table, $primaryKey, $id, $title);

		return $result;

    }


public function savefile($data = array())
	{
		$result = $this->sqlinsert('vt_files', $data, 'Dokumen');
		return $result;
	}

	public function get_file_attachment($id)
	{
		$result = $this->query("SELECT * FROM vt_files WHERE parent_id = '$id' AND dir = 'JNHVVERKU' ");

		return $result;
	}

	public function getfiles($request, $table, $primaryKey, $columns, $id, $y)
	{
		$result = $this->get_files($request, $table, $primaryKey, $columns, $id, $y);
		return $result;
	}

	public function get_files ( $request, $table, $primaryKey, $columns, $id, $key )

	{

		$bindings = array();

		$db = $this->connection;

		$limit = self::limit( $request, $columns );

		$order = self::order( $request, $columns );

		$where = self::filter( $request, $columns, $bindings );

		$sWhere = "WHERE `$primaryKey` = $id AND dir = 'JNHVVERKU'";

		$data = $this->query(

			"SELECT `".implode("`, `", $this->pluck($columns, 'db'))."`

			FROM `$table`

			$sWhere

			$order

			$limit"

		);

		$resFilterLength = $this->query(

			"SELECT COUNT(`{$primaryKey}`)

			FROM   `$table`

			$sWhere"

		);

		$recordsFiltered = $resFilterLength[0][0];

		$resTotalLength = $this->query(

			"SELECT COUNT(`{$primaryKey}`)

			FROM   `$table`

			$sWhere"

		);

		$recordsTotal = $resTotalLength[0][0];

		return array(

			"draw"            => isset ( $request['draw'] ) ? intval( $request['draw'] ) : 0,

			"recordsTotal"    => intval( $recordsTotal ),

			"recordsFiltered" => intval( $recordsFiltered ),

			"data"            => self::data_output( $columns, $data )

		);

	}


}