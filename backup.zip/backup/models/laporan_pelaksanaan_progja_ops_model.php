<?php
/**
 * 
 */
class Laporan_pelaksanaan_progja_ops_model extends Model
{

	public function satker()
	{
		$return =  $this->query("SELECT kd_satminkal,nm_satminkal FROM tsatminkal");

		return $return;
	}

	public function mgetsat ( $request, $table, $primaryKey, $columns,$id,$satker, $join )
	{

		$bindings = array();

		$db = $this->connection;



		$limit = self::limit( $request, $columns );

		$order = self::order( $request, $columns );

		$where = self::filter( $request, $columns, $bindings, true );

		 $sWhere = "WHERE a.kd_bidang  = '02' AND b.thang = '$id' AND c.kd_satminkal = '$satker' ";

		  $group  = "GROUP BY b.kdakun";

		 $order = "ORDER BY nm_satminkal ASC";

		$data = $this->query(

			"SELECT ".implode(",", $this->pluck($columns, 'db'))."

			 FROM $table

			 $join

			 $sWhere

			 $where

			 $group

			 $order

			 $limit"

		);



		$resFilterLength = $this->query(

			"SELECT COUNT(t2) FROM (

			SELECT COUNT({$primaryKey}) as t2

			 FROM   $table  $join  $sWhere  $where GROUP BY b.kdakun ) AS t3


			 "

		);



		$recordsFiltered = $resFilterLength[0][0];



		$resTotalLength = $this->query(

			"SELECT COUNT(t2) FROM (

			SELECT COUNT({$primaryKey}) as t2

			 FROM   $table  $join  $sWhere  $where GROUP BY b.kdakun ) AS t3
"

		);

		$recordsTotal = $resTotalLength[0][0];



		return array(

			"draw"            => isset ( $request['draw'] ) ?

				intval( $request['draw'] ) :

				0,

			"recordsTotal"    => intval( $recordsTotal ),

			"recordsFiltered" => intval( $recordsFiltered ),

			"data"            => self::data_output( $columns, $data )

		);

	}
	
	public function mget ( $request, $table, $primaryKey, $columns,$id, $join )

	{

		$bindings = array();

		$db = $this->connection;



		$limit = self::limit( $request, $columns );

		$order = self::order( $request, $columns );

		$where = self::filter( $request, $columns, $bindings, true );

		 $sWhere = "WHERE a.kd_bidang  = '02' AND b.thang = '$id'  ";

		  $group  = "GROUP BY b.kdakun";

		 $order = "ORDER BY nm_satminkal ASC";


		$data = $this->query(

			"SELECT ".implode(",", $this->pluck($columns, 'db'))."

			 FROM $table

			 $join

			 $sWhere

			 $where

			 $group

			 $order

			 $limit"

		);



		$resFilterLength = $this->query(

			"SELECT COUNT(t2) FROM (

			SELECT COUNT({$primaryKey}) as t2

			 FROM   $table  $join  $sWhere  $where GROUP BY b.kdakun ) AS t3
		 

			 "

		);



		$recordsFiltered = $resFilterLength[0][0];



		$resTotalLength = $this->query(

			"SELECT COUNT(t2) FROM (

			SELECT COUNT({$primaryKey}) as t2

			 FROM   $table  $join  $sWhere  $where GROUP BY b.kdakun ) AS t3
		"

		);

		$recordsTotal = $resTotalLength[0][0];



		return array(

			"draw"            => isset ( $request['draw'] ) ?

				intval( $request['draw'] ) :

				0,

			"recordsTotal"    => intval( $recordsTotal ),

			"recordsFiltered" => intval( $recordsFiltered ),

			"data"            => self::data_output( $columns, $data )

		);

	}
}