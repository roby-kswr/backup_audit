<?php

class Pkpt_detail_model extends Model {

	public function mget($request, $table, $primaryKey, $columns)

	{

		$result = $this->simple($request, $table, $primaryKey, $columns);

		return $result;

	}



	public function mget_detail($request, $table, $primaryKey, $columns, $id,$y)

	{	

		$result = $this->simplePkpt($request, $table, $primaryKey, $columns, $id,$y);

		return $result;

	}

	public function mget_rev($request, $table, $primaryKey, $columns, $id,$y)

	{	

		$result = $this->simpleRev($request, $table, $primaryKey, $columns, $id,$y);

		return $result;

	}

	public function mget_modRev($request, $table, $primaryKey, $columns, $id,$y)

	{	

		$result = $this->modalRev($request, $table, $primaryKey, $columns, $id,$y);

		return $result;

	}



	public function getNo($request, $table, $join, $primaryKey, $columns, $id, $y)
	{
		$result = $this->mySimple_file2($request, $table, $join, $primaryKey, $columns, $id, $y);
		return $result;
	}

	public function get($table, $primaryKey, $id)
	{
		$result = $this->query("SELECT * FROM $table WHERE $primaryKey = '$id'");
		return $result;
	}

	public function msave($table, $data = array(), $title)
	{
		$result = $this->sqlinsert($table, $data, $title);
		return $result;
	}

	public function mupdate($table, $data = array(), $primaryKey, $id, $title)
	{
		$result = $this->sqlupdate($table, $data, $primaryKey, $id, $title);
		return $result;
	}

	public function mdelete($table, $primaryKey, $id, $title)
	{
		$result = $this->sqldelete($table, $primaryKey, $id, $title);
		return $result;
	}

	public function mdel($table, $primaryKey, $id, $title)
	{
		$result = $this->sqldelete($table, $primaryKey, $id, $title);
		return $result;
	}

	// public function fetch_all_event(){
	// 	$this->order_by('autono');
	// 	return $this->get('vt_pkpt');
	// }

	Public function getpkpt_detils($id)
	{
		
		$sql = "SELECT a.autono,a.title,a.color,d.nomor_pkpt AS title,a.id_jns_audit,a.start,a.end,c.nm_kotama,b.autocode FROM tpkpt_detil AS a 
		LEFT JOIN tpkptsat AS b ON b.id_pkpt = a.autono
		LEFT JOIN tkotama AS c ON c.autono = b.id_kotama
		LEFT JOIN tpkpt AS d ON d.nomor_pkpt = a.title WHERE d.nomor_pkpt = '$id'";
		$result = $this->query($sql, array($_GET['start'], $_GET['end'])); 
		return $result;

	}

	Public function getreview_detils($id)
	{
		
		$sql = "SELECT a.autono,a.title,a.color,d.nomor_pkpt AS title,a.start,a.end,c.nm_review,b.autocode FROM tpkpt_detil_rev AS a 
		LEFT JOIN tpkptrev AS b ON b.id_pkpt = a.autono
		LEFT JOIN treview AS c ON c.autono = b.id_review
		LEFT JOIN tpkpt AS d ON d.nomor_pkpt = a.title WHERE d.nomor_pkpt = '$id'";
		$result = $this->query($sql, array($_GET['start'], $_GET['end'])); 
		return $result;

	}

	Public function getChecked($id)
	{
		$result = $this->query("SELECT a.title,a.end,a.id_kotama,b.nm_kotama 
			FROM tpkptsat AS a LEFT JOIN tkotama AS b ON b.autono = a.id_kotama WHERE a.id_pkpt = '$id'");
		return $result;
	}

	Public function dragUpdateEvent()
	{
			//$date=date('Y-m-d h:i:s',strtotime($_POST['date']));

		$sql = "UPDATE tpkpt_detil as e  SET  e.start = '".$_POST['start']."' ,e.end = '".$_POST['end']."'  WHERE autono = '".$_POST['autono']."' ";
		$this->query($sql, array($_POST['start'],$_POST['end'], $_POST['autono']));
		echo json_encode($sql);
	}

	Public function deleteEvent($id)
	{

		$sql = "DELETE tpkpt, tpkpt_detil, tpkptsat
		FROM tpkpt
		LEFT JOIN tpkpt_detil ON tpkpt_detil.title = tpkpt.autono
		LEFT JOIN tpkptsat ON tpkptsat.id_pkpt = tpkpt_detil.autono
		WHERE tpkpt.autono = '$id' ";
		$this->query($sql, array($_GET['$id']));
		return $sql;
	}

	Public function updateEvent($id)
	{

		$sql = "UPDATE tpkpt_detil SET title = '".$_POST['title']."', tahapan = '".$_POST['tahapan']."', color = '".$_POST['color']."' WHERE autono = '$id'";
		$this->query($sql, array($_POST['title'],$_POST['tahapan'], $_POST['color'], $_POST['autono']));
		echo json_encode($sql);
	}

	public function get_pkptSatker($y,$id)
	{
		$result = $this->query("SELECT autono, nm_kotama
			FROM tkotama a
			WHERE autono NOT IN (SELECT id_kotama FROM tpkptsat b LEFT JOIN tpkpt_detil c ON b.id_pkpt = c.autono WHERE b.title ='$y' AND id_jns_audit = '$id')");
		return $result;
	}

	public function getColor()
	{
		$result = $this->query("SELECT value,warna FROM warna");
		return $result;
	}


	public function simplePkpt ( $request, $table, $primaryKey, $columns, $id )

	{

		$bindings = array();

		$db = $this->connection;



		$limit = self::limit( $request, $columns );

		$order = self::order( $request, $columns );

		$where = self::filters( $request, $columns, $bindings, true );

		$sWhere = "WHERE title = '$id'";



		$data = $this->query(

			"SELECT `".implode("`, `", $this->pluck($columns, 'db'))."`

			FROM `$table`

			$sWhere

			$where

			ORDER BY start ASC"

		);



		$resFilterLength = $this->query(

			"SELECT COUNT(`{$primaryKey}`)

			FROM   `$table`

			$sWhere $where"

		);



		$recordsFiltered = $resFilterLength[0][0];



		$resTotalLength = $this->query(

			"SELECT COUNT(`{$primaryKey}`)

			FROM   `$table` $sWhere"

		);

		$recordsTotal = $resTotalLength[0][0];



		return array(

			"draw"            => isset ( $request['draw'] ) ?

			intval( $request['draw'] ) :

			0,

			"recordsTotal"    => intval( $recordsTotal ),

			"recordsFiltered" => intval( $recordsFiltered ),

			"data"            => self::data_output( $columns, $data )

		);

	}

	public function simpleRev( $request, $table, $primaryKey, $columns, $id )

	{

		$bindings = array();

		$db = $this->connection;



		$limit = self::limit( $request, $columns );

		$order = self::order( $request, $columns );

		$where = self::filters( $request, $columns, $bindings, true );

		$sWhere = "WHERE title = '$id'";

		$group = "GROUP BY autono";

		$join   = "a 
		LEFT JOIN (SELECT id_pkpt AS kd_pkpt,id_review FROM tpkptrev) c ON a.autono = c.kd_pkpt
		LEFT JOIN (SELECT autono AS kd_rev,nm_review FROM treview) b ON c.id_review = b.kd_rev";

		$data = $this->query(

			"SELECT `".implode("`, `", $this->pluck($columns, 'db'))."`

			FROM `$table`

			$join

			$sWhere

			$where

			$group

			ORDER BY start ASC"

		);



		$resFilterLength = $this->query(

			"SELECT COUNT(auto) FROM(SELECT COUNT(`{$primaryKey}`) as auto FROM `$table` $join $sWhere $where $group) as t1"

		);



		$recordsFiltered = $resFilterLength[0][0];



		$resTotalLength = $this->query(" SELECT COUNT(auto) FROM(SELECT COUNT(`{$primaryKey}`) as auto FROM `$table` $join $sWhere $where $group) as t1");

		$recordsTotal = $resTotalLength[0][0];



		return array(

			"draw"            => isset ( $request['draw'] ) ?

			intval( $request['draw'] ) :

			0,

			"recordsTotal"    => intval( $recordsTotal ),

			"recordsFiltered" => intval( $recordsFiltered ),

			"data"            => self::data_output( $columns, $data )

		);

	}

	public function loadReview ( $request, $table, $primaryKey, $columns, $id )

	{

		$bindings = array();

		$db = $this->connection;

		$val     = $this->getvalue("SELECT * FROM $table WHERE autono = '$id'");

		$limit = self::limit( $request, $columns );

		$order = self::order( $request, $columns );

		$where = self::filters( $request, $columns, $bindings, true );

		$join   = "a 
		LEFT JOIN (SELECT id_pkpt AS kd_pkpt,id_review FROM tpkptrev) c ON a.autono = c.kd_pkpt
		LEFT JOIN (SELECT autono AS kd_rev,nm_review FROM treview) b ON c.id_review = b.kd_rev";

		$group = "GROUP BY nm_review"; 

		$sWhere = "WHERE autono IS NOT NULL AND autono = '".$val['autono']."'";

		$data = $this->query(

			"SELECT ".implode(", ", $this->pluck($columns, 'db'))."

			FROM  `$table`

			$join

			$sWhere 

			$where

			$group

			$order

			$limit"

		);

		$resFilterLength = $this->query(

			"SELECT COUNT(`{$primaryKey}`) FROM (SELECT `{$primaryKey}` FROM  `$table` $join $sWhere $where  $group) AS t1" 

		);

		$recordsFiltered = $resFilterLength[0][0];

		$resTotalLength = $this->query("SELECT COUNT(`{$primaryKey}`) FROM (SELECT `{$primaryKey}` FROM `$table` $join $sWhere $group) AS t1");

		$recordsTotal = $resTotalLength[0][0];

		return array(

			"draw"            => isset ( $request['draw'] ) ?

			intval( $request['draw'] ) :

			0,

			"recordsTotal"    => intval( $recordsTotal ),

			"recordsFiltered" => intval( $recordsFiltered ),

			"data"            => self::data_output( $columns, $data )

		);

	}

	public function loadSatker ( $request, $table, $primaryKey, $columns, $id )

	{

		$bindings = array();

		$db = $this->connection;

		$val     = $this->getvalue("SELECT * FROM $table WHERE autono = '$id'");

		$limit = self::limit( $request, $columns );

		$order = self::order( $request, $columns );

		$where = self::filters( $request, $columns, $bindings, true );

		$join   = "a 
		LEFT JOIN (SELECT id_pkpt AS kd_pkpt,id_kotama FROM tpkptsat) c ON a.autono = c.kd_pkpt 
		LEFT JOIN (SELECT autono AS kd_kotama,nm_kotama FROM tkotama) b ON c.id_kotama = b.kd_kotama ";

		$group = "GROUP BY nm_kotama"; 

		$sWhere = "WHERE autono IS NOT NULL AND autono = '".$val['autono']."'";

		$data = $this->query(

			"SELECT ".implode(", ", $this->pluck($columns, 'db'))."

			FROM  `$table`

			$join

			$sWhere 

			$where

			$group

			$order

			$limit"

		);

		$resFilterLength = $this->query(

			"SELECT COUNT(`{$primaryKey}`) FROM (SELECT `{$primaryKey}` FROM  `$table` $join $sWhere $where  $group) AS t1" 

		);

		$recordsFiltered = $resFilterLength[0][0];

		$resTotalLength = $this->query("SELECT COUNT(`{$primaryKey}`) FROM (SELECT `{$primaryKey}` FROM `$table` $join $sWhere $group) AS t1");

		$recordsTotal = $resTotalLength[0][0];

		return array(

			"draw"            => isset ( $request['draw'] ) ?

			intval( $request['draw'] ) :

			0,

			"recordsTotal"    => intval( $recordsTotal ),

			"recordsFiltered" => intval( $recordsFiltered ),

			"data"            => self::data_output( $columns, $data )

		);

	}

	public function filters ( $request, $columns, &$bindings )

	{

		$globalSearch = array();

		$columnSearch = array();

		$dtColumns = $this->pluck( $columns, 'dt' );


		if ( isset($request['search']) && $request['search']['value'] != '' ) {

			$str = $request['search']['value'];



			for ( $i=0, $ien=count($request['columns']) ; $i<$ien ; $i++ ) {

				$requestColumn = $request['columns'][$i];

				$columnIdx = array_search( $requestColumn['data'], $dtColumns );

				$column = $columns[ $columnIdx ];



				if ( $requestColumn['searchable'] == 'true' ) {

					if(!empty($column['db'])){

						$binding = "'%".$str."%'";

						$globalSearch[] = "`".$column['db']."` LIKE ".$binding;

					}

				}

			}

		}

		// Individual column filtering

		if ( isset( $request['columns'] ) ) {

			for ( $i=0, $ien=count($request['columns']) ; $i<$ien ; $i++ ) {

				$requestColumn = $request['columns'][$i];

				$columnIdx = array_search( $requestColumn['data'], $dtColumns );

				$column = $columns[ $columnIdx ];



				$str = $requestColumn['search']['value'];



				if ( $requestColumn['searchable'] == 'true' &&

					$str != '' ) {

					if(!empty($column['db'])){

						$binding = "'%".$str."%'";

						$columnSearch[] = "`".$column['db']."` LIKE ".$binding;

					}

				}

			}

		}

		$where = '';

		if ( count( $globalSearch ) ) {

			$where = '('.implode(' OR ', $globalSearch).')';

		}

		if ( count( $columnSearch ) ) {

			$where = $where === '' ?

			implode(' AND ', $columnSearch) :

			$where .' AND '. implode(' AND ', $columnSearch);

		}

		if ( $where !== '' ) {

			$where = 'AND '.$where;

		}

		return $where;

	}


	public function get_review()
	
	{
		
		$result = $this->query("SELECT autono, nm_review FROM treview ORDER BY autono asc");
		
		return $result;

	}

	public function get_reviewEdit($table, $field, $id)
	{
		$result = $this->query("SELECT autono, nm_review, IF(b.id_review IS NULL, '', 'selected') AS pselect 
			FROM treview a LEFT JOIN (SELECT id_review FROM $table WHERE  $field = '$id') b ON a.autono = b.id_review");
		return $result;
	}
	

}