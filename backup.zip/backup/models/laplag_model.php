<?php

class Laplag_model extends Model {

	public function mget($request, $table, $primaryKey, $columns, $join = null)
	{
		$result = $this->simple($request, $table, $primaryKey, $columns, $join);
		return $result;
	}

	public function mgetDipa($request, $table, $primaryKey, $columns, $join)
	{
		$result = $this->loadDipa($request, $table, $primaryKey, $columns, $join);
		return $result;
	}

	public function mgetLaplag($request, $table, $primaryKey, $columns)
	{
		$result = $this->loadLaplag($request, $table, $primaryKey, $columns);
		return $result;
	}

	public function mgetdatadetail($request, $table, $primaryKey, $columns, $id)
	{
		$result = $this->simple_detail($request, $table, $primaryKey, $columns, $id);
		return $result;
	}

	public function mgetDetail($request, $table, $primaryKey, $columns, $id)
	{
		$result = $this->loadDetail($request, $table, $primaryKey, $columns, $id);
		return $result;
	}

	public function mgetRab($request, $table, $primaryKey, $columns, $id)
	{
		$result = $this->loadRab($request, $table, $primaryKey, $columns, $id);
		return $result;
	}

	public function mgetAkun($request, $table, $primaryKey, $columns, $join)
	{
		$result = $this->loadAkun($request, $table, $primaryKey, $columns, $join);
		return $result;
	}

	public function get($table, $primaryKey, $id)
	{
		$result = $this->query("SELECT * FROM $table WHERE $primaryKey = '$id'");
		return $result;
	}

	public function getfiles($request, $table, $primaryKey, $columns, $id, $y)
	{
		$result = $this->mySimple_file($request, $table, $primaryKey, $columns, $id, $y);
		return $result;
	}

	public function msave($table, $data = array(), $title)
	{
		$result = $this->sqlinsert($table, $data, $title);
		return $result;
	}

	public function mupdate($table, $data = array(), $primaryKey, $id, $title)
	{
		$result = $this->sqlupdate($table, $data, $primaryKey, $id, $title);
		return $result;
	}

	public function mdelete($table, $primaryKey, $id, $title)
    {
        $result = $this->sqldelete($table, $primaryKey, $id, $title);
		return $result;
    }

    public function savefile($data = array())
	{

		$result = $this->sqlinsert('vt_files', $data, 'HPS Dokumen');

		return $result;
	}

    public function loadDetail ( $request, $table, $primaryKey, $columns, $id )

	{

		$bindings = array();

		$db = $this->connection;

		$limit = self::limit( $request, $columns );

		$order = self::order( $request, $columns );

		$where = self::filters( $request, $columns, $bindings, true );

		$val     = $this->getvalue("SELECT * FROM $table WHERE id=$id");

		$group = "GROUP BY urskmpnen"; 

		$sWhere = "WHERE kdsatker = ".$val['kdsatker']." AND THANG = ".$val['thang']." AND urskmpnen IS NOT NULL";

		$data = $this->query(

			"SELECT ".implode(", ", $this->pluck($columns, 'db'))."

			 FROM `$table` 

			 $sWhere 

			 $where

			 $group

			 $order

			 $limit"

		);

		$resFilterLength = $this->query(

			"SELECT COUNT(*) FROM (SELECT * FROM  `$table` $sWhere $where  $group) AS t1" 

		);

		$recordsFiltered = $resFilterLength[0][0];

		$resTotalLength = $this->query("SELECT COUNT(*) FROM (SELECT * FROM  `$table` $sWhere $group) AS t1");

		$recordsTotal = $resTotalLength[0][0];

		return array(

			"draw"            => isset ( $request['draw'] ) ?

				intval( $request['draw'] ) :

				0,

			"recordsTotal"    => intval( $recordsTotal ),

			"recordsFiltered" => intval( $recordsFiltered ),

			"data"            => self::data_output( $columns, $data )

		);

	}

	public function loadLaplag ( $request, $table, $primaryKey, $columns)

	{

		$bindings = array();

		$db = $this->connection;

		//$val     = $this->getvalue("SELECT * FROM $table WHERE id=$id");

		$limit = self::limit( $request, $columns );

		$order = self::order( $request, $columns );

		$where = self::filters( $request, $columns, $bindings, true );

		$join  = "LEFT JOIN (SELECT kd_satminkal, nm_satminkal FROM tsatminkal GROUP BY kd_satminkal) AS tsatminkal ON $table.`kdsatker` = tsatminkal.kd_satminkal";

		$group = "GROUP BY kdsatker"; 

		$sWhere = "WHERE THANG = 2020";

		$data = $this->query(

			"SELECT ".implode(", ", $this->pluck($columns, 'db'))."

			 FROM  `$table`

			 $join

			 $sWhere 

			 $where

			 $group

			 $order

			 $limit"

		);

		$resFilterLength = $this->query(

			"SELECT COUNT(`{$primaryKey}`) FROM (SELECT `{$primaryKey}` FROM  `$table` $join $sWhere $where  $group) AS t1" 

		);

		$recordsFiltered = $resFilterLength[0][0];

		$resTotalLength = $this->query("SELECT COUNT(`{$primaryKey}`) FROM (SELECT `{$primaryKey}` FROM `$table` $join $sWhere $group) AS t1");

		$recordsTotal = $resTotalLength[0][0];

		return array(

			"draw"            => isset ( $request['draw'] ) ?

				intval( $request['draw'] ) :

				0,

			"recordsTotal"    => intval( $recordsTotal ),

			"recordsFiltered" => intval( $recordsFiltered ),

			"data"            => self::data_output( $columns, $data )

		);

	}

	public function loadRab ( $request, $table, $primaryKey, $columns, $id )

	{

		$bindings = array();

		$db = $this->connection;

		$val     = $this->getvalue("SELECT * FROM $table WHERE id=$id");

		$limit = self::limit( $request, $columns );

		$order = self::order( $request, $columns );

		$where = self::filters( $request, $columns, $bindings, true );

		$join  = "LEFT JOIN (SELECT kdakun AS takun, nmakun FROM dja_akun) AS dja_akun ON $table.`kdakun` = dja_akun.takun";

		$group = "GROUP BY kdakun"; 

		$sWhere = "WHERE THANG = 2020 AND urskmpnen IS NOT NULL AND urskmpnen = '".$val['urskmpnen']."' AND kdsatker = ".$val['kdsatker']."";

		$data = $this->query(

			"SELECT ".implode(", ", $this->pluck($columns, 'db'))."

			 FROM  `$table`

			 $join

			 $sWhere 

			 $where

			 $group

			 $order

			 $limit"

		);

		$resFilterLength = $this->query(

			"SELECT COUNT(`{$primaryKey}`) FROM (SELECT `{$primaryKey}` FROM  `$table` $join $sWhere $where  $group) AS t1" 

		);

		$recordsFiltered = $resFilterLength[0][0];

		$resTotalLength = $this->query("SELECT COUNT(`{$primaryKey}`) FROM (SELECT `{$primaryKey}` FROM `$table` $join $sWhere $group) AS t1");

		$recordsTotal = $resTotalLength[0][0];

		return array(

			"draw"            => isset ( $request['draw'] ) ?

				intval( $request['draw'] ) :

				0,

			"recordsTotal"    => intval( $recordsTotal ),

			"recordsFiltered" => intval( $recordsFiltered ),

			"data"            => self::data_output( $columns, $data )

		);

	}


	public function filters ( $request, $columns, &$bindings )

	{

		$globalSearch = array();

		$columnSearch = array();

		$dtColumns = $this->pluck( $columns, 'dt' );


		if ( isset($request['search']) && $request['search']['value'] != '' ) {

			$str = $request['search']['value'];



			for ( $i=0, $ien=count($request['columns']) ; $i<$ien ; $i++ ) {

				$requestColumn = $request['columns'][$i];

				$columnIdx = array_search( $requestColumn['data'], $dtColumns );

				$column = $columns[ $columnIdx ];



				if ( $requestColumn['searchable'] == 'true' ) {

					if(!empty($column['db'])){

						$binding = "'%".$str."%'";

						$globalSearch[] = "`".$column['db']."` LIKE ".$binding;

					}

				}

			}

		}

		// Individual column filtering

		if ( isset( $request['columns'] ) ) {

			for ( $i=0, $ien=count($request['columns']) ; $i<$ien ; $i++ ) {

				$requestColumn = $request['columns'][$i];

				$columnIdx = array_search( $requestColumn['data'], $dtColumns );

				$column = $columns[ $columnIdx ];



				$str = $requestColumn['search']['value'];



				if ( $requestColumn['searchable'] == 'true' &&

				 $str != '' ) {

					if(!empty($column['db'])){

						$binding = "'%".$str."%'";

						$columnSearch[] = "`".$column['db']."` LIKE ".$binding;

					}

				}

			}

		}

		$where = '';

		if ( count( $globalSearch ) ) {

			$where = '('.implode(' OR ', $globalSearch).')';

		}

		if ( count( $columnSearch ) ) {

			$where = $where === '' ?

				implode(' AND ', $columnSearch) :

				$where .' AND '. implode(' AND ', $columnSearch);

		}

		if ( $where !== '' ) {

			$where = 'AND '.$where;

		}

		return $where;

	}



}
