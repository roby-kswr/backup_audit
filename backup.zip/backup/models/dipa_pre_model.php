<?php

class Dipa_pre_model extends Model {

	public function mget($request, $table, $primaryKey, $columns)
	{
		$join = "AS t1 LEFT JOIN (SELECT kdsatker, nmsatker FROM dja_satker) AS t2 ON t1.KDSATKER = t2.kdsatker";
		$result = $this->dipa_dt($request, $table, $primaryKey, $columns,$id,  $join);
		return $result;
	}

	public function get($table, $primaryKey, $id)
	{
		$result = $this->query("SELECT * FROM $table WHERE $primaryKey = '$id'");
		return $result;
	}

	public function msave($table, $data = array(), $title)
	{
		$result = $this->sqlinsert($table, $data, $title);
		return $result;
	}

	public function mupdate($table, $data = array(), $primaryKey, $id, $title)
	{
		$result = $this->sqlupdate($table, $data, $primaryKey, $id, $title);
		return $result;
	}

	public function mdelete($table, $primaryKey, $id, $title)
    {
        $result = $this->sqldelete($table, $primaryKey, $id, $title);
		return $result;
    }

    public function savefile($data = array())
	{

		$result = $this->sqlinsert('vt_files', $data, 'Dokumen');

		return $result;

	}

	public function tempscript($id)

	{

		$result = $this->getval("app_generate", "scripts", "types", $id); 

		return $result;

	}

	public function dipa_dt ( $request, $table, $primaryKey, $columns, $id, $join )

	{

		$bindings = array();

		$db = $this->connection;

		$limit = self::limit( $request, $columns );

		$order = self::order( $request, $columns );

		$where = self::filter_dipa( $request, $columns, $bindings, true );

		$sWhere = "WHERE THANG = 2020 AND urskmpnen IS NOT NULL ";

		// $sWhere = "";



		$data = $this->query(

			"SELECT ".implode(", ", $this->pluck($columns, 'db'))."

			 FROM `$table`

			 $join

			 $sWhere

			 $where

			 $order

			 $limit"

		);



		$resFilterLength = $this->query(

			"SELECT COUNT(`{$primaryKey}`)

			 FROM   `$table` $join

			 $sWhere $where"

		);



		$recordsFiltered = $resFilterLength[0][0];



		$resTotalLength = $this->query(

			"SELECT COUNT(`{$primaryKey}`)

			 FROM   `$table` $sWhere"

		);

		$recordsTotal = $resTotalLength[0][0];



		return array(

			"draw"            => isset ( $request['draw'] ) ?

				intval( $request['draw'] ) :

				0,

			"recordsTotal"    => intval( $recordsTotal ),

			"recordsFiltered" => intval( $recordsFiltered ),

			"data"            => self::data_output( $columns, $data )

		);

	}

	public function filter_dipa ( $request, $columns, &$bindings )

	{

		$globalSearch = array();

		$columnSearch = array();

		$dtColumns = $this->pluck( $columns, 'dt' );


		if ( isset($request['search']) && $request['search']['value'] != '' ) {

			$str = $request['search']['value'];



			for ( $i=0, $ien=count($request['columns']) ; $i<$ien ; $i++ ) {

				$requestColumn = $request['columns'][$i];

				$columnIdx = array_search( $requestColumn['data'], $dtColumns );

				$column = $columns[ $columnIdx ];



				if ( $requestColumn['searchable'] == 'true' ) {

					if(!empty($column['db'])){

						$binding = "'%".$str."%'";

						$globalSearch[] = "`".$column['db']."` LIKE ".$binding;

					}

				}

			}

		}

		// Individual column filtering

		if ( isset( $request['columns'] ) ) {

			for ( $i=0, $ien=count($request['columns']) ; $i<$ien ; $i++ ) {

				$requestColumn = $request['columns'][$i];

				$columnIdx = array_search( $requestColumn['data'], $dtColumns );

				$column = $columns[ $columnIdx ];



				$str = $requestColumn['search']['value'];



				if ( $requestColumn['searchable'] == 'true' &&

				 $str != '' ) {

					if(!empty($column['db'])){

						$binding = "'%".$str."%'";

						$columnSearch[] = "".$column['db']." LIKE ".$binding;

					}

				}

			}

		}

		$where = '';

		if ( count( $globalSearch ) ) {

			$where = '('.implode(' OR ', $globalSearch).')';

		}

		if ( count( $columnSearch ) ) {

			$where = $where === '' ?

				implode(' AND ', $columnSearch) :

				$where .' AND '. implode(' AND ', $columnSearch);

		}

		if ( $where !== '' ) {

			$where = 'AND '.$where;

		}

		return $where;

	}


}
