<?php



class Komponen_model extends Model {



	public function mget($request, $table, $primaryKey, $columns)

	{

		$join = "a

				 LEFT JOIN (SELECT autocode AS autosat,nm_uo       FROM tuo )       AS b ON a.id_uo        = b.autosat

                 LEFT JOIN (SELECT autocode AS autoprog,nm_program FROM tprogram )  AS c ON a.id_program   = c.autoprog

                 LEFT JOIN (SELECT autocode AS autokeg,nm_kegiatan FROM tkegiatan ) AS d ON a.id_kegiatan  = d.autokeg

                 LEFT JOIN (SELECT autocode AS autoput,nm_output   FROM toutput )   AS e ON a.id_output    = e.autoput
                 
                 LEFT JOIN (SELECT autocode AS autosub,nm_subout   FROM tsuboutput )   AS f ON a.id_suboutput = f.autosub

                 ";

		$result = $this->simple($request, $table, $primaryKey, $columns, $join);

		return $result;

	}



	public function get($table, $primaryKey, $id)

	{

		$result = $this->query("SELECT * FROM $table WHERE $primaryKey = '$id'");

		return $result;

	}



	public function msave($table, $data = array(), $title)

	{

		$result = $this->sqlinsert($table, $data, $title);

		return $result;

	}



	public function mupdate($table, $data = array(), $primaryKey, $id, $title)

	{

		$result = $this->sqlupdate($table, $data, $primaryKey, $id, $title);

		return $result;

	}



	public function mdelete($table, $primaryKey, $id, $title)

    {

        $result = $this->sqldelete($table, $primaryKey, $id, $title);

		return $result;

    }





}

