<?php

class Lhp_model extends Model {

	public function mget($request, $table, $primaryKey, $columns, $join	= null)
	{
		$result = $this->simple($request, $table, $primaryKey, $columns, $join);
		return $result;
	}

	public function mgetdetail($request, $table, $primaryKey, $columns, $join = null, $sWhere)
	{
		$result = $this->mySimple($request, $table, $primaryKey, $columns, $join, $sWhere);
		return $result;
	}

	public function get($table, $primaryKey, $id)
	{
		$result = $this->query("SELECT *, DATE_FORMAT(tgl_lhp, '%d/%m/%Y') AS tanggal_lhp FROM $table WHERE $primaryKey = '$id'");
		return $result;
	}

	public function msave($table, $data = array(), $title)
	{
		$result = $this->sqlinsert($table, $data, $title);
		return $result;
	}

	public function mupdate($table, $data = array(), $primaryKey, $id, $title)
	{
		$result = $this->sqlupdate($table, $data, $primaryKey, $id, $title);
		return $result;
	}

	public function mdelete($table, $primaryKey, $id, $title)
    {
        $result = $this->sqldelete($table, $primaryKey, $id, $title);
		return $result;
    }

    public function getId_kka($id)
    {
        $result = $this->query("SELECT autono, no_kka, IF(b.id_kka IS NULL, '', 'selected') FROM tkka a LEFT JOIN (SELECT id_kka FROM tlhpdetil) AS b ON a.autono=b.id_kka
								WHERE id_pka = '".$id."' AND IF(b.id_kka IS NULL, '', 'selected') != 'selected' ORDER BY autono ASC");
        return $result;
    }

    public function get_sprin()
	
	{
		
		$result = $this->query("SELECT autono, no_sprin FROM tsprin");		
		
		return $result;

	}

 //    public function get_sprin()
	
	// {
		
	// 	$result = $this->query("SELECT autono, no_sprin FROM tsprin a WHERE NOT EXISTS (SELECT id_sprin FROM tpka b WHERE a.autono = b.id_sprin)");		
		
	// 	return $result;

	// }

	public function get_kka()
	
	{
		
		$result = $this->query("SELECT autono, no_kka FROM tkka ORDER BY autono asc");
		
		return $result;

	}

}