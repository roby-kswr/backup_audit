<?php require_once "includes/controller/mining_data_jadwal.class.php"; 
      $datajadwal = $rh->parsejadwal(); 
      session_start(); 
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>MONITORING DATA JADWAL</title>
<link href="includes/vt_bs3/assets/css/bootstrap.min.css" rel="stylesheet">
<link href="includes/vt_bs3/font-awesome/css/font-awesome.min.css" rel="stylesheet">
<link href="includes/vt_bs3/assets/css/AdminLTE.min.css" rel="stylesheet"> 
<link rel="stylesheet" href="lib/fullcalendar/fullcalendar.min.css">
<link rel="stylesheet" href="lib/fullcalendar/fullcalendar.print.css" media="print">
<link rel="stylesheet" type="text/css" href="./includes/assets/css/custom.arn.css"/>
<style type="text/css">
.box.box-primary{
	  border: 1px solid #a19ae6;
    border-radius: 0;
    padding: 2px;
}
.fc-unthemed .fc-today {
    background: #d5d1ff;
}
.fc-day-grid-event {
    margin: 1px 2px 0;
    padding: 0 1px;
    border-radius: 0;
    font-stretch: condensed;
    font-size: 12px;
    margin-top: 2px;
}
.table>thead>tr>th, .table>tbody>tr>th, .table>tfoot>tr>th, .table>thead>tr>td, .table>tbody>tr>td, .table>tfoot>tr>td {
    border-top: 1px solid #f4f4f4;
    font-size: 14px;
    padding: 6px;
}
.table-striped>tbody>tr:nth-of-type(odd) {
    background-color: #F3F2FD;
}
.bld{
	font-weight: bold;
}
</style>
</head>
<body>

<!-- Main content -->
        <section class="content">	
       
          <div class="row">
			<div class="col-md-8" style="text-align:center;">
				<label >KALENDER JADWAL KEGIATAN UNIVERSITAS PERTAHANAN</label>
              <div class="box box-primary">
                <div class="box-body no-padding">
                  <!-- THE CALENDAR -->
                  <div id="calendar"></div>
                </div><!-- /.box-body -->
              </div><!-- /. box -->
            </div><!-- /.col -->

            <div class="col-md-4" style="text-align:center;">
				<label >DETIL KEGIATAN</label>
              <div class="box box-primary">
                <div class="box-body no-padding">

                  <span id="result_detil">

                    <?php 
                    $idj = $_SESSION['idjadwal'];
                    $cw  = "&c_r=$_GET[c_r]&c_w=$_GET[c_w]&c_d=$_GET[c_d]&c_a=$_GET[c_a]"; 
                    $idurl = $idj.$cw;

                    if(isset($idj)){
                     $quer = mysql_query("SELECT dj.date_event,dj.event_end, dj.time_from, dj.time_to, k.nm_kegiatan, dj.judul, dj.koordinator, g.nm_gedung, r.nm_ruangan, dj.detil 
                     FROM vt_mining_data_jadwal dj, vt_kegiatan k, vt_gedung g, vt_ruangan r 
                     WHERE dj.kd_kegiatan = k.kd_kegiatan AND dj.kd_gedung = g.kd_gedung AND dj.kd_ruangan = r.kd_ruangan AND dj.autono = '$idj' ");
                     $q = mysql_fetch_array($quer);
                     $nm_kegiatan = $q['nm_kegiatan'];
                     $judul       = $q['judul'];
                     $koordinator = $q['koordinator'];
                     $nm_gedung   = $q['nm_gedung'];
                     $nm_ruangan  = $q['nm_ruangan'];
                     $date_event  = date("d-m-Y",strtotime($q['date_event'] ));
                     $event_end  = date("d-m-Y",strtotime($q['event_end'] ));
                     $time_fromto = "$q[time_from]"." - "."$q[time_to]";
                     $ket         = $q['detil'];
                     $dis_ro      = "";
                    }else{
                     $nm_kegiatan = $judul = $koordinator = $nm_gedung = $nm_ruangan = $date_event = $event_end = $time_fromto = $ket = "-";
                     $dis_ro      = "disabled readonly";
                    } ?>
                	<table class="table table-striped">
                      <tbody>
                      <tr>
                              <td style="width: 26%;" class="bld">Jenis Keg.</td>
                              <td style="width: 2px;"> : </td>
                              <td><?php echo $nm_kegiatan ?></td>
                      </tr>
                      <tr>
                              <td class="bld">Judul Keg.</td>
                              <td> : </td>
                              <td><?php echo $judul ?></td>
                      </tr>
                      <tr>
                              <td class="bld">Koordinator</td>
                              <td> : </td>
                              <td><?php echo $koordinator
                               ?></td>
                      </tr>
                      <tr>
                              <td class="bld">Gedung</td>
                              <td> : </td>
                              <td><?php echo $nm_gedung ?></td>
                      </tr>
                      <tr>
                              <td class="bld">Ruang</td>
                              <td> : </td>
                              <td><?php echo $nm_ruangan ?></td>
                      </tr>
                      <tr>
                              <td class="bld">Tanggal Mulai</td>
                              <td> : </td>
                              <td><?php echo $date_event ?></td>
                      </tr>
                      <tr>
                              <td class="bld">Tanggal Selesai</td>
                              <td> : </td>
                              <td><?php echo $event_end ?></td>
                      </tr>
                      <tr>
                              <td class="bld">Jam</td>
                              <td> : </td>
                              <td><?php echo $time_fromto ?></td>
                      </tr>
                      
                      <tr>
                              <td class="bld">Keterangan</td>
                              <td> : </td>
                              <td><?php echo $ket ?></td>
                      </tr>
                      <tr>
                              <td></td>
                              <td colspan="2">
                                  <button type="button" onclick='window.location.href="script.php?show=script&script=jadwal/mining_data_jadwal/edit.php&id=<?=$idurl?>"; ' class="btn btn-primary btn-flat btn-ex" <?php echo $dis_ro ?> ><i class="glyphicon glyphicon-edit"></i> Edit</button>
                                  <button type="button" onclick="unsetsession()" class="btn btn-success btn-flat btn-ex"><i class="glyphicon glyphicon-refresh"></i> Refresh</button>
                            </td>
                      </tr>
                      </tbody>
                </table>

                </span>

                </div><!-- /.box-body -->
              </div><!-- /. box -->


            </div><!-- /.col 4-->

          </div><!-- /row -->

         </section>




  <!-- jQuery -->
  <script src="includes/vt_bs3/js/jquery-1.7.2.min.js"></script>
  <!-- transition / effect library -->
  <script src="includes/vt_bs3/assets/js/bootstrap.min.js"></script>

  <script src="lib/fullcalendar/moment.min.js"></script>
  <script src="lib/fullcalendar/fullcalendar.min.js"></script>

  <script>

      $(function () {

        /* initialize the calendar
         -----------------------------------------------------------------*/
        //Date for the calendar events (dummy data)
        var date = new Date();
        var d = date.getDate(),
                m = date.getMonth(),
                y = date.getFullYear();
        $('#calendar').fullCalendar({
          header: {
            left: 'prev,next today',
            center: 'title',
            right: 'month,agendaWeek'
            // right: ''
          },
          buttonText: {
            today: 'Hari ini',
            month: 'Lihat Bulanan',
            week: 'Lihat Mingguan & Jam',
            // day: 'day'
          },
          //Random default events
          events: <?=$datajadwal?>,
          
          editable: false,
          droppable: false, // this allows things to be dropped onto the calendar !!!
    
        });


      });

      var siteUrl = "http://localhost/inventaris_unhan/";
      function showDetil(id){
        $.ajax({
            type    : 'POST',
            url     : siteUrl+'script/jadwal/monitoring_jadwal/detiljadwal.php',
            data    : {'id':id},
            dataType: 'html',
            success: function(response) {
            $('#result_detil').html(response);
          }
        });
      };

      function unsetsession(){
        $.get(siteUrl+'script/jadwal/monitoring_jadwal/unset_idjadwal.php');
        window.location.reload();
      }
    </script>

</body>
</html>



        