<?php

class Progja_model extends Model {

	public function mget($request, $table, $primaryKey, $columns, $join = null)
	{
		$result = $this->simple($request, $table, $primaryKey, $columns, $join);
		return $result;
	}

	public function mgetDipa($request, $table, $primaryKey, $columns, $join)
	{
		$result = $this->loadDipa($request, $table, $primaryKey, $columns, $join);
		return $result;
	}

	public function mgetProgja($request, $table, $primaryKey, $columns)
	{
		$result = $this->loadProgja($request, $table, $primaryKey, $columns);
		return $result;
	}

	public function mgetDetail($request, $table, $primaryKey, $columns, $id)
	{
		$result = $this->loadDetail($request, $table, $primaryKey, $columns, $id);
		return $result;
	}

	public function mgetRab($request, $table, $primaryKey, $columns, $id)
	{
		$result = $this->loadRab($request, $table, $primaryKey, $columns, $id);
		return $result;
	}

	public function mgetAkun($request, $table, $primaryKey, $columns, $join)
	{
		$result = $this->loadAkun($request, $table, $primaryKey, $columns, $join);
		return $result;
	}

	public function get($table, $primaryKey, $id)
	{
		$result = $this->query("SELECT * FROM $table WHERE $primaryKey = '$id'");
		return $result;
	}

	public function getfiles($request, $table, $primaryKey, $columns, $id, $y)
	{
		$result = $this->mySimple_file($request, $table, $primaryKey, $columns, $id, $y);
		return $result;
	}

	public function msave($table, $data = array(), $title)
	{
		$result = $this->sqlinsert($table, $data, $title);
		return $result;
	}

	public function mupdate($table, $data = array(), $primaryKey, $id, $title)
	{
		$result = $this->sqlupdate($table, $data, $primaryKey, $id, $title);
		return $result;
	}

	public function mdelete($table, $primaryKey, $id, $title)
    {
        $result = $this->sqldelete($table, $primaryKey, $id, $title);
		return $result;
    }

    public function loadProgja ( $request, $table, $primaryKey, $columns )

	{

		$bindings = array();

		$db = $this->connection;

		$limit = self::limit( $request, $columns );

		$order = self::order( $request, $columns );

		$where = self::filters( $request, $columns, $bindings, true );

		$group = "GROUP BY urskmpnen"; 

		$sWhere = "WHERE THANG = 2020 AND urskmpnen IS NOT NULL";

		$data = $this->query(

			"SELECT ".implode(", ", $this->pluck($columns, 'db'))."

			 FROM `$table`

			 $sWhere 

			 $where

			 $group

			 $order

			 $limit"

		);

		$resFilterLength = $this->query(

			"SELECT COUNT(*) FROM (SELECT * FROM  `$table` $sWhere $where  $group) AS t1" 

		);

		$recordsFiltered = $resFilterLength[0][0];

		$resTotalLength = $this->query("SELECT COUNT(*) FROM (SELECT * FROM  `$table` $sWhere $group) AS t1");

		$recordsTotal = $resTotalLength[0][0];

		return array(

			"draw"            => isset ( $request['draw'] ) ?

				intval( $request['draw'] ) :

				0,

			"recordsTotal"    => intval( $recordsTotal ),

			"recordsFiltered" => intval( $recordsFiltered ),

			"data"            => self::data_output( $columns, $data )

		);

	}

	public function loadDetail ( $request, $table, $primaryKey, $columns, $id )

	{

		$bindings = array();

		$db = $this->connection;

		$val     = $this->getvalue("SELECT * FROM $table WHERE id=$id");

		$limit = self::limit( $request, $columns );

		$order = self::order( $request, $columns );

		$where = self::filters( $request, $columns, $bindings, true );

		$join  = "LEFT JOIN tsatminkal ON $table.`kdsatker` = tsatminkal.kd_satminkal";

		$group = "GROUP BY kdsatker"; 

		$sWhere = "WHERE THANG = 2020 AND urskmpnen IS NOT NULL AND urskmpnen = '".$val['urskmpnen']."' AND kdgiat = ".$val['kdgiat']."";

		$data = $this->query(

			"SELECT ".implode(", ", $this->pluck($columns, 'db'))."

			 FROM  `$table`

			 $join

			 $sWhere 

			 $where

			 $group

			 $order

			 $limit"

		);

		$resFilterLength = $this->query(

			"SELECT COUNT(`{$primaryKey}`) FROM (SELECT `{$primaryKey}` FROM  `$table` $join $sWhere $where  $group) AS t1" 

		);

		$recordsFiltered = $resFilterLength[0][0];

		$resTotalLength = $this->query("SELECT COUNT(`{$primaryKey}`) FROM (SELECT `{$primaryKey}` FROM `$table` $join $sWhere $group) AS t1");

		$recordsTotal = $resTotalLength[0][0];

		return array(

			"draw"            => isset ( $request['draw'] ) ?

				intval( $request['draw'] ) :

				0,

			"recordsTotal"    => intval( $recordsTotal ),

			"recordsFiltered" => intval( $recordsFiltered ),

			"data"            => self::data_output( $columns, $data )

		);

	}

	public function loadRab ( $request, $table, $primaryKey, $columns, $id )

	{

		$bindings = array();

		$db = $this->connection;

		$val     = $this->getvalue("SELECT * FROM $table WHERE id=$id");

		$limit = self::limit( $request, $columns );

		$order = self::order( $request, $columns );

		$where = self::filters( $request, $columns, $bindings, true );

		$join  = "LEFT JOIN (SELECT kdakun AS takun, nmakun FROM dja_akun) AS dja_akun ON $table.`kdakun` = dja_akun.takun";

		$group = "GROUP BY kdakun"; 

		$sWhere = "WHERE THANG = 2020 AND urskmpnen IS NOT NULL AND urskmpnen = '".$val['urskmpnen']."' AND kdsatker = ".$val['kdsatker']."";

		$data = $this->query(

			"SELECT ".implode(", ", $this->pluck($columns, 'db'))."

			 FROM  `$table`

			 $join

			 $sWhere 

			 $where

			 $group

			 $order

			 $limit"

		);

		$resFilterLength = $this->query(

			"SELECT COUNT(`{$primaryKey}`) FROM (SELECT `{$primaryKey}` FROM  `$table` $join $sWhere $where  $group) AS t1" 

		);

		$recordsFiltered = $resFilterLength[0][0];

		$resTotalLength = $this->query("SELECT COUNT(`{$primaryKey}`) FROM (SELECT `{$primaryKey}` FROM `$table` $join $sWhere $group) AS t1");

		$recordsTotal = $resTotalLength[0][0];

		return array(

			"draw"            => isset ( $request['draw'] ) ?

				intval( $request['draw'] ) :

				0,

			"recordsTotal"    => intval( $recordsTotal ),

			"recordsFiltered" => intval( $recordsFiltered ),

			"data"            => self::data_output( $columns, $data )

		);

	}

    public function loadDipa ( $request, $table, $primaryKey, $columns, $join )

	{

		$bindings = array();

		$db = $this->connection;

		$limit = self::limit( $request, $columns );

		$order = self::order( $request, $columns );

		$where = self::filters( $request, $columns, $bindings, true );

		$sWhere = "THANG = 2020 AND urskmpnen IS NOT NULL";

		$data = $this->query(

			"SELECT `id`, `nmsatker`, `wasgiat`, `urskmpnen`, SUM(jml_pagu) AS `jml_pagu`

			 FROM `$table`

			 $join

			 WHERE $sWhere

			 $where

			 GROUP BY thang, t1.KDSATKER, `kdoutput`, `kdlokasi`, `kdkabkota`, `kddekon`, `kdsoutput`, `kdkmpnen`, `kdskmpnen`, `kdkppn`, `kdjenbel`

			 $order

			 $limit"

		);

		$resFilterLength = $this->query(

			"SELECT COUNT(`{$primaryKey}`)

			 FROM `$table`

			 WHERE $sWhere $where"

		);

		$recordsFiltered = $resFilterLength[0][0];

		$resTotalLength = $this->query(

			"SELECT COUNT(`{$primaryKey}`)

			 FROM   `$table` WHERE $sWhere"

		);

		$recordsTotal = $resTotalLength[0][0];

		return array(

			"draw"            => isset ( $request['draw'] ) ?

				intval( $request['draw'] ) :

				0,

			"recordsTotal"    => intval( $recordsTotal ),

			"recordsFiltered" => intval( $recordsFiltered ),

			"data"            => self::data_output( $columns, $data )

		);

	}

	public function loadAkun ( $request, $table, $primaryKey, $columns, $join )

	{

		$bindings = array();

		$db = $this->connection;

		$limit = self::limit( $request, $columns );

		$order = self::order( $request, $columns );

		$where = self::filter( $request, $columns, $bindings, true );

		$sWhere = "thang = '2020' AND 
				   `kdsatker` = '685742' AND
	 			   `kdfungsi` = '02' AND
				   `kdsfung` = '02' AND
	 			   `kdprogram` = '14' AND
				   `kdgiat` = '1444' AND
	 			   `kdoutput` = '001' AND
				   `kdlokasi` = '11' AND
				   `kdkabkota` = '00' AND
	 			   `kddekon` = '2' AND
				   `kdsoutput` = '001' AND
	 			   `kdkmpnen` = '003' AND
				   `kdskmpnen` = 'B' AND
	 			   `kdkppn` = '014' AND
	 			   `kdjenbel` = '52'";

		$data = $this->query(

			"SELECT `id`, `kdakun`, `nmakun`, `jml_pagu`

			 FROM `$table`

			 $join

			 WHERE $sWhere

			 $where

			 GROUP BY `thang`, `kdsatker`, `kdfungsi`, `kdsfung`, `kdprogram`, `kdgiat`, `kdoutput`, `kdlokasi`, `kdkabkota`, `kddekon`, `kdsoutput`, `kdkmpnen`, `kdskmpnen`, `kdkppn`, `kdjenbel`

			 $order

			 $limit"

		);

		$resFilterLength = $this->query(

			"SELECT COUNT(`{$primaryKey}`)

			 FROM `$table`

			 WHERE $sWhere $where"

		);

		$recordsFiltered = $resFilterLength[0][0];

		$resTotalLength = $this->query(

			"SELECT COUNT(`{$primaryKey}`)

			 FROM   `$table` WHERE $sWhere"

		);

		$recordsTotal = $resTotalLength[0][0];

		return array(

			"draw"            => isset ( $request['draw'] ) ?

				intval( $request['draw'] ) :

				0,

			"recordsTotal"    => intval( $recordsTotal ),

			"recordsFiltered" => intval( $recordsFiltered ),

			"data"            => self::data_output( $columns, $data )

		);

	}

	public function filters ( $request, $columns, &$bindings )

	{

		$globalSearch = array();

		$columnSearch = array();

		$dtColumns = $this->pluck( $columns, 'dt' );


		if ( isset($request['search']) && $request['search']['value'] != '' ) {

			$str = $request['search']['value'];



			for ( $i=0, $ien=count($request['columns']) ; $i<$ien ; $i++ ) {

				$requestColumn = $request['columns'][$i];

				$columnIdx = array_search( $requestColumn['data'], $dtColumns );

				$column = $columns[ $columnIdx ];



				if ( $requestColumn['searchable'] == 'true' ) {

					if(!empty($column['db'])){

						$binding = "'%".$str."%'";

						$globalSearch[] = "`".$column['db']."` LIKE ".$binding;

					}

				}

			}

		}

		// Individual column filtering

		if ( isset( $request['columns'] ) ) {

			for ( $i=0, $ien=count($request['columns']) ; $i<$ien ; $i++ ) {

				$requestColumn = $request['columns'][$i];

				$columnIdx = array_search( $requestColumn['data'], $dtColumns );

				$column = $columns[ $columnIdx ];



				$str = $requestColumn['search']['value'];



				if ( $requestColumn['searchable'] == 'true' &&

				 $str != '' ) {

					if(!empty($column['db'])){

						$binding = "'%".$str."%'";

						$columnSearch[] = "`".$column['db']."` LIKE ".$binding;

					}

				}

			}

		}

		$where = '';

		if ( count( $globalSearch ) ) {

			$where = '('.implode(' OR ', $globalSearch).')';

		}

		if ( count( $columnSearch ) ) {

			$where = $where === '' ?

				implode(' AND ', $columnSearch) :

				$where .' AND '. implode(' AND ', $columnSearch);

		}

		if ( $where !== '' ) {

			$where = 'AND '.$where;

		}

		return $where;

	}

 //    public function mget_thang()

	// {
	// 	$result = $this->query("SELECT 'id', `thang` FROM dja_pagu GROUP BY `thang`");
	// 	return $result;
	// }

 //    public function mget_progja()

	// {
	// 	$result = $this->query("SELECT `id`, `nmsatker`, `urskmpnen`, `wasgiat`
	// 							FROM dja_pagu AS t1 LEFT JOIN (SELECT `kdsatker`, `nmsatker` FROM dja_satker) AS t2 ON t1.KDSATKER = t2.kdsatker 
	// 							GROUP BY t1.KDSATKER");
	// 	return $result;
	// }

	// public function load_progja($id)

	// {
	// 	$result = $this->query("SELECT `id`, `nmsatker`, `urskmpnen`, `wasgiat`, `thang`, t1.kdsatker, `kdfungsi`, `kdsfung`, `kdprogram`, `kdgiat`, `kdoutput`, `kdlokasi`, `kdkabkota`, `kddekon`, `kdsoutput`, `kdkmpnen`, `kdskmpnen`, `kdkppn`, `kdjenbel`
	// 							FROM dja_pagu AS t1 LEFT JOIN (SELECT `kdsatker`, `nmsatker` FROM dja_satker) AS t2 ON t1.KDSATKER = t2.kdsatker 
	// 							WHERE id = $id 
	// 							GROUP BY t1.KDSATKER");
	// 	return $result;
	// }

	// public function load_TotalPagu($thang,$kdsatker,$kdfungsi,$kdsfung,$kdprogram,$kdgiat,$kdoutput,$kdlokasi,$kdkabkota,$kddekon,$kdsoutput,$kdkmpnen,$kdskmpnen,$kdkppn,$kdjenbel)

	// {
	// 	$result = $this->query("SELECT `id`, SUM(`jml_pagu`) AS `pagu`
	// 							FROM dja_pagu
	// 							WHERE `thang` = '$thang' AND
	// 								  `kdsatker` = '$kdsatker' AND
	// 								  `kdfungsi` = '$kdfungsi' AND
	// 								  `kdsfung` = '$kdsfung' AND
	// 								  `kdprogram` = '$kdprogram' AND
	// 								  `kdgiat` = '$kdgiat' AND
	// 								  `kdoutput` = '$kdoutput' AND
	// 								  `kdlokasi` = '$kdlokasi' AND
	// 								  `kdkabkota` = '$kdkabkota' AND
	// 								  `kddekon` = '$kddekon' AND
	// 								  `kdsoutput` = '$kdsoutput' AND
	// 								  `kdkmpnen` = '$kdkmpnen' AND
	// 								  `kdskmpnen` = '$kdskmpnen' AND
	// 								  `kdkppn` = '$kdkppn' AND
	// 								  `kdjenbel` = '$kdjenbel'
	// 							GROUP BY `thang`, `kdsatker`, `kdfungsi`, `kdsfung`, `kdprogram`, `kdgiat`, `kdoutput`, `kdlokasi`, `kdkabkota`, `kddekon`, `kdsoutput`, `kdkmpnen`, `kdskmpnen`, `kdkppn`, `kdjenbel`
	// 							");
	// 	return $result;
	// }

}
