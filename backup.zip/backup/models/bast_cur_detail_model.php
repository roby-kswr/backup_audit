<?php

class Bast_cur_detail_model extends Model {

	public function mget($request, $table, $primaryKey, $columns)
	{
		$join = "";
		$result = $this->simple($request, $table, $primaryKey, $columns, $join);
		return $result;
	}

	public function mget_detail($request, $table, $primaryKey,$primaryKey2, $columns, $id)
	{	
		$join = "a
				 LEFT JOIN (SELECT kd_satker AS autosat , nm_satker AS namasat FROM tsatker ) AS b ON a.satker = b.autosat
				 LEFT JOIN (SELECT autocode AS autobast FROM bast_cur ) AS c ON a.autocode = c.autobast";
		$result = $this->simple_detailBast($request, $table, $primaryKey,$primaryKey2, $columns, $id,$join);
		return $result;
	}

	public function get($table, $primaryKey, $id)
	{
		$result = $this->query("SELECT * FROM $table WHERE $primaryKey = '$id'");
		return $result;
	}

	public function msave($table, $data = array(), $title)
	{
		$result = $this->sqlinsert($table, $data, $title);
		return $result;
	}

	public function mupdate($table, $data = array(), $primaryKey, $id, $title)
	{
		$result = $this->sqlupdate($table, $data, $primaryKey, $id, $title);
		return $result;
	}

	public function mdelete($table, $primaryKey, $id, $title)
    {
        $result = $this->sqldelete($table, $primaryKey, $id, $title);
		return $result;
    }


}