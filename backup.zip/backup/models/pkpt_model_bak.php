<?php

class Pkpt_model extends Model {

	public function mget($request, $table, $primaryKey, $columns,$field = null,$key = null,$key2 = null)

	{
		$result = $this->dt($request, $table, $primaryKey, $columns,$join,$field,$key,$group,$key2);


		return $result;

	}

	public function mget_detail($request, $table, $primaryKey, $columns, $id)
	{
		$result = $this->simple_detail7($request, $table, $primaryKey, $columns, $id);
		return $result;
	}

	public function getNo($request, $table, $join, $primaryKey, $columns, $id, $y)
	{
		$result = $this->mySimple_file2($request, $table, $join, $primaryKey, $columns, $id, $y);
		return $result;
	}

	public function get($table, $primaryKey, $id)
	{
		$result = $this->query("SELECT * FROM $table WHERE $primaryKey = '$id'");
		return $result;
	}

	public function msave($table, $data = array(), $title)
	{
		$result = $this->sqlinsert($table, $data, $title);
		return $result;
	}

	public function mupdate($table, $data = array(), $primaryKey, $id, $title)
	{
		$result = $this->sqlupdate($table, $data, $primaryKey, $id, $title);
		return $result;
	}

	public function mdelete($table, $primaryKey, $id, $title)
	{
		$result = $this->sqldelete($table, $primaryKey, $id, $title);
		return $result;
	}

	public function mdel($table, $primaryKey, $id, $title)
	{
		$result = $this->sqldelete($table, $primaryKey, $id, $title);
		return $result;
	}

	// public function fetch_all_event(){
	// 	$this->order_by('autono');
	// 	return $this->get('vt_pkpt');
	// }

	// Public function getpkpt_detils()
	// {
		
	// 	$sql = "SELECT a.autono,a.title,a.color,d.nomor_pkpt AS title,a.id_jns_audit,a.start,a.end,c.nm_kotama,b.autocode FROM tpkpt_detil AS a 
	// 	LEFT JOIN tpkptsat AS b ON b.id_pkpt = a.autono
	// 	LEFT JOIN tkotama AS c ON c.autono = b.id_kotama
	// 	LEFT JOIN tpkpt AS d ON d.autono = a.title ";
	// 	$result = $this->query($sql, array($_GET['start'], $_GET['end'])); 
	// 	return $result;

	// }

	// Public function getChecked($id)
	// {
	// 	$result = $this->query("SELECT MONTHNAME(a.start) as bulan,a.color,a.title,a.id_jns_audit,a.end,b.id_kotama,b.autocode FROM tpkpt_detil AS a LEFT JOIN tpkptsat AS b ON b.id_pkpt = a.autono WHERE b.id_pkpt = '$id'");
	// 	return $result;
	// }

	// Public function dragUpdateEvent()
	// {
	// 		//$date=date('Y-m-d h:i:s',strtotime($_POST['date']));

	// 	$sql = "UPDATE tpkpt_detil as e  SET  e.start = '".$_POST['start']."' ,e.end = '".$_POST['end']."'  WHERE autono = '".$_POST['autono']."' ";
	// 	$this->query($sql, array($_POST['start'],$_POST['end'], $_POST['autono']));
	// 	echo json_encode($sql);
	// }

	Public function deleteEvent($id)
	{

		$sql = "DELETE tpkpt, tpkpt_detil, tpkptsat
		FROM tpkpt
		LEFT JOIN tpkpt_detil ON tpkpt_detil.title = tpkpt.nomor_pkpt
		LEFT JOIN tpkptsat ON tpkptsat.id_pkpt = tpkpt_detil.autono
		WHERE tpkpt.autono = '$id' ";
		$this->query($sql, array($_GET['$id']));
		return $sql;
	}

	// Public function updateEvent($id)
	// {

	// 	$sql = "UPDATE tpkpt_detil SET title = '".$_POST['title']."', tahapan = '".$_POST['tahapan']."', color = '".$_POST['color']."' WHERE autono = '$id'";
	// 	$this->query($sql, array($_POST['title'],$_POST['tahapan'], $_POST['color'], $_POST['autono']));
	// 	echo json_encode($sql);
	// }

}