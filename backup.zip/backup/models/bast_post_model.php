<?php

class Bast_post_model extends Model {

	public function mget($request, $table, $primaryKey, $columns)
	{
		$join = "a
				 LEFT JOIN (SELECT autono AS autosat ,autocode AS id , satminkal AS kode_satminkal, SUM(totalbast) AS sum_score FROM vt_upload_bast_post GROUP BY autocode ) AS b ON a.autocode = b.id
				  LEFT JOIN (SELECT autono AS autosat ,kd_satminkal AS id , nm_satminkal FROM tsatminkal) AS c ON a.satminkal = c.autosat
				  ";

				 // $join = "a
				 // LEFT JOIN (SELECT autono AS autotor ,autocode AS id , tor AS kode_tor, SUM(total) AS sum_score FROM vt_upload_rab_post GROUP BY autocode ) AS b ON a.autocode = b.id";
		$result = $this->simpleBast($request, $table, $primaryKey, $columns, $join);
		return $result;
	}

	public function get($table, $primaryKey, $id)
	{
		$result = $this->query("SELECT * FROM $table WHERE $primaryKey = '$id'");
		return $result;
	}

	public function mget_detail($request, $table, $primaryKey, $columns,$join = null, $id)
	{
		$result = $this->simple_detailBast($request, $table, $primaryKey, $primaryKey2, $columns, $id);
		return $result;
	}

	public function msave($table, $data = array(), $title)
	{
		$result = $this->sqlinsert($table, $data, $title);
		return $result;
	}

	public function mupdate($table, $data = array(), $primaryKey, $id, $title)
	{
		$result = $this->sqlupdate($table, $data, $primaryKey, $id, $title);
		return $result;
	}

	public function mdelete($table, $primaryKey, $id, $title)
    {
        $result = $this->sqldelete($table, $primaryKey, $id, $title);
		return $result;
    }


        public function get_file_attachment($id)
    {
        $result = $this->query("SELECT * FROM vt_files WHERE parent_id = $id ");

        return $result;
    }


	public function savefile($data = array())
	{
		$result = $this->sqlinsert('vt_files', $data, 'Dokumen');
		return $result;
	}

	public function getfiles($request, $table, $primaryKey, $columns, $id, $y)
	{
		$result = $this->mySimple_file($request, $table, $primaryKey, $columns, $id, $y);
		return $result;
	}


	public function deletes_file($id)
    {
        $result = $this->sqldeletefiles('vt_files', $id, 'Bast');
		return $result;
    }


 	public function sqldeletefiles($table, $id, $label)

	{

		$data = $this->getvalue("SELECT kode_parent FROM vt_files WHERE autono = $id");
		
		$i    = $this->count("SELECT COUNT(*) as jml FROM vt_files WHERE kode_parent = '$data[0]'");

		$result = $this->sqldelete("vt_files", "autono", $id, $label);

		return $result;

	}

	public function uploadBastpos($filename, $satminkal,$tahun,$autocode)
    {
        $dir         = './static/files/POST_Bast/'.$satminkal.'/'.$tahun.'/';
        $file_name   = $filename;
        $storagename = $dir."/".$autocode.".xlsx";
        $storagefile = $dir;
                
        if(!empty($file_name["name"])){
            if(!file_exists($storagename)){
                mkdir($storagefile, 0777, true);
                $result = move_uploaded_file($file_name["tmp_name"],  $storagename);
            }
            $file_name = $file_name["name"];

            return $file_name;
        } 
        return $file_name["name"]; 
        
    }

    public function import_bast_post($satminkal, $tahun,$autono, $autocode, $last_id)
    {
    	error_reporting(1);
    	// IF(file_exists(ROOT_DIR.'static/PHPExcel/PHPExcel.php'))
    	// {echo 'ada';}
    	// else
    	// 	{echo 'tidak ada';}
    	// exit;
    		include ROOT_DIR.'static/PHPExcel/PHPExcel.php';
    
    $excelreader		= new PHPExcel_Reader_Excel2007();
	$loadexcel 			= $excelreader->load(ROOT_DIR.'static/files/POST_Bast/'.$satminkal.'/'.$tahun.'/'.$autocode.".xlsx"); 
	$sheet 				= $loadexcel->getActiveSheet()->toArray(null, true, true ,true);

	$numrow = 1;
	// var_dump($sheet);
	foreach($sheet as $row){

		$no_urut 			= $row['A']; 
		$keterangan 		= $row['B']; 
		$vol 		        = $row['C']; 
		$satuan 		    = $row['D']; 
		$harga 		        = $row['E'];		
		$jumlah 		    = $row['F'];
		$ppn 		        = $row['G'];
		$subtotal 		    = $row['H']; 
 

 


		if($no_urut == "" && $keterangan == "" && $vol == "" && $satuan == "" && $harga == ""  && $jumlah == "" && $ppn == "" && $subtotal == "")
			continue;
		
					if($numrow > 2){

						// merubah ke huruf kapital
						// $namaconvert = 	$act->ucw(str_replace("'","\'", $nama));  
 
						// insert ke database
						$this->execute("INSERT INTO vt_upload_bast_post
							(parent_id,
							autocode,
							satminkal, 
							tahun,
							no_urut, 
							keterangan,
							vol,
							satuan,
							harga,						
							jumlah,
							ppn,
							totalbast
							
							) 
							VALUES 
							('$last_id',
							'$autocode',
							'$satminkal',
							'$tahun',
							'$no_urut',
							'$keterangan',
							'$vol',
							'$satuan',
							'$harga',							
							'$jumlah',
							'$ppn',
							'$subtotal'
							
						) ");
						

 
						// update untuk mendapatkan kode pass
						// s$act->execute("UPDATE t_peserta SET pass = '$kode' WHERE id_kegiatan = '$id_kegiatan' AND id = $lastid ");

						// Hapus data duplikat
						// $act->execute("DELETE n1 FROM t_peserta n1, t_peserta n2 WHERE n1.id < n2.id AND n1.nomor = n2.nomor AND n1.id_kegiatan = n2.id_kegiatan"); 

						// $act->execute("UPDATE t_kegiatan SET status_import = 1 WHERE id = '$id_kegiatan' ");

						 
					}
			 
		$numrow++; 
	}

		unlink(ROOT_DIR.'static/files/POST_Bast/'.$satminkal.'/'.$tahun.'/'.$autocode.".xlsx");
        
        return $numrow;
    }



}
