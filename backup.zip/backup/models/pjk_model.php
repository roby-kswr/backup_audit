<?php

class Pjk_model extends Model {

	public function satker()
	{
		$return =  $this->query("SELECT kd_satminkal,nm_satminkal FROM tsatminkal");

		return $return;
	}

	public function bidang()
	{
		$return =  $this->query("SELECT kd_bidang,nm_bidang FROM tbidang");

		return $return;
	}

	public function mget($request, $table, $primaryKey, $columns, $join = null)
	{
		$result = $this->simple($request, $table, $primaryKey, $columns, $join);
		return $result;
	}

	public function mgetsat ( $request, $table, $primaryKey, $columns,$satker, $join = null )
	{

		$bindings = array();

		$db = $this->connection;



		$limit = self::limit( $request, $columns );

		$order = self::order( $request, $columns );

		$where = self::filter( $request, $columns, $bindings );

		$sWhere = "WHERE t2.kode = '$satker'";



		$data = $this->query(

			"SELECT ".implode(",", $this->pluck($columns, 'db'))."

			FROM `$table`

			$join

			$sWhere

			$where

			$order

			$limit"

		);



		$resFilterLength = $this->query(

			"SELECT COUNT(`{$primaryKey}`)

			FROM   `$table`
			$join

			$sWhere 

			$where


			"

		);



		$recordsFiltered = $resFilterLength[0][0];



		$resTotalLength = $this->query(

			"SELECT COUNT(`{$primaryKey}`)

			FROM   `$table`  $join  $sWhere  $where  "

		);

		$recordsTotal = $resTotalLength[0][0];



		return array(

			"draw"            => isset ( $request['draw'] ) ?

			intval( $request['draw'] ) :

			0,

			"recordsTotal"    => intval( $recordsTotal ),

			"recordsFiltered" => intval( $recordsFiltered ),

			"data"            => self::data_output( $columns, $data )

		);

	}
	public function mgetdetail($request, $table, $primaryKey, $columns, $join, $sWhere)
	{
		$result = $this->mySimplex($request, $table, $primaryKey, $columns, $join, $sWhere);
		return $result;
	}

	public function get($table, $primaryKey, $id)
	{
		$result = $this->query("SELECT * FROM $table WHERE $primaryKey = '$id'");
		return $result;
	}


	public function simple ( $request, $table, $primaryKey, $columns, $join = null )

	{

		$bindings = array();

		$db = $this->connection;

		$limit = self::limit( $request, $columns );

		$order = self::order( $request, $columns );

		$where = self::filter( $request, $columns, $bindings );


		$data = $this->query(

			"SELECT `".implode("`, `", $this->pluck($columns, 'db'))."`

			FROM `$table`

			$join

			$where

			$order

			$limit"

		);

		$resFilterLength = $this->query(

			"SELECT COUNT(`{$primaryKey}`)

			FROM   `$table`

			$where"

		);



		$recordsFiltered = $resFilterLength[0][0];



		$resTotalLength = $this->query(

			"SELECT COUNT(`{$primaryKey}`)

			FROM   `$table`"

		);

		$recordsTotal = $resTotalLength[0][0];



		return array(

			"draw"            => isset ( $request['draw'] ) ?

			intval( $request['draw'] ) :

			0,

			"recordsTotal"    => intval( $recordsTotal ),

			"recordsFiltered" => intval( $recordsFiltered ),

			"data"            => self::data_output( $columns, $data )

		);

	}

}
