<?php



class Analisa_laporan_pelaksanaan_kegiatan_vermat_model extends Model {



	public function mget($request, $table, $primaryKey, $columns,$field = null,$key = null,$key2 = null)

	{

		 $join = 'a 
		 		  
		 		  LEFT JOIN (SELECT tahun,bulan,kotama,satminkal,kategori AS belanja_barang FROM vt_vermat_laplak_detail WHERE tahun = '.$key.' AND bulan = '.$key2.' AND kategori = 2) b ON a.`kd_kotama` = b.`kotama` AND a.`kd_satminkal` = b.`satminkal`
		 		  LEFT JOIN (SELECT tahun,bulan,kotama,satminkal,kategori AS belanja_modal FROM vt_vermat_laplak_detail WHERE tahun = '.$key.' AND bulan = '.$key2.' AND kategori = 3) c ON a.`kd_kotama` = c.`kotama` AND a.`kd_satminkal` = c.`satminkal`';
		 		  
		 $group = 'order by nm_satminkal';
		$result = $this->dt($request, $table, $primaryKey, $columns,$join,$field,$key,$group,$key2);


		return $result;

	}



	public function mget_detail($request, $table, $primaryKey, $columns, $id)

	{

		$result = $this->simple_detail($request, $table, $primaryKey, $columns, $id);

		return $result;

	}



	public function get($table, $primaryKey, $id)

	{

		$result = $this->query("SELECT * FROM $table WHERE $primaryKey = '$id'");

		return $result;

	}



	public function msave($table, $data = array(), $title)

	{

		$result = $this->sqlinsert($table, $data, $title);

		return $result;

	}



	public function mupdate($table, $data = array(), $primaryKey, $id, $title)

	{

		$result = $this->sqlupdate($table, $data, $primaryKey, $id, $title);

		return $result;

	}



	public function mdelete($table, $primaryKey, $id, $title)

    {

        $result = $this->sqldelete($table, $primaryKey, $id, $title);

		return $result;

    }





}