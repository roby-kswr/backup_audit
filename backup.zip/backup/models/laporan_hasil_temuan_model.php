<?php



class Laporan_hasil_temuan_model extends Model 
{

	public function getkotama()
	{
		$return = $this->query("SELECT * FROM tkotama");
		return $return;
	}

	public function getSatminkal($kdsatminkal)
	{
		$return = $this->query("SELECT * FROM tsatminkal WHERE kd_kotama = '$kdsatminkal'");

		return $return;
	}

	public function getData($table , $kotama,$satminkal ,$bulan, $tahun )
	{
		$result = $this->query("SELECT * FROM $table WHERE kotama = '$kotama' AND satminkal = '$satminkal' AND bulan = '$bulan' AND tahun = '$tahun'");

		return $result;
	}


	public function mget ( $request, $table, $primaryKey, $columns, $tahun, $bulan )

	{

		$bindings = array();

		$db = $this->connection;



		$limit = self::limit( $request, $columns );

		$order = self::order( $request, $columns );

		$where = self::filter( $request, $columns, $bindings, true );

		$join = "LEFT JOIN (SELECT kd_kotama,kd_satminkal,nm_satminkal FROM tsatminkal) AS tsatminkal ON 
				 $table.satminkal = tsatminkal.kd_satminkal";

		$sWhere = "WHERE tahun = '$tahun' AND bulan = '$bulan'";

		$group  = "GROUP BY satminkal";

		$order  = "ORDER BY nm_satminkal";



		$data = $this->query(

			"SELECT `".implode("`, `", $this->pluck($columns, 'db'))."`

			 FROM `$table`

			 $join

			 $sWhere

			 $where

			 $group

			 $order

			 $limit"

		);



		$resFilterLength = $this->query(

			"SELECT COUNT(`{$primaryKey}`)

			 FROM   `$table`

			 $join $sWhere $where $group"

		);



		$recordsFiltered = $resFilterLength[0][0];



		$resTotalLength = $this->query(

			"SELECT COUNT(`{$primaryKey}`)

			 FROM   `$table` $join $sWhere $where $group "

		);

		$recordsTotal = $resTotalLength[0][0];



		return array(

			"draw"            => isset ( $request['draw'] ) ?

				intval( $request['draw'] ) :

				0,

			"recordsTotal"    => intval( $recordsTotal ),

			"recordsFiltered" => intval( $recordsFiltered ),

			"data"            => self::data_output( $columns, $data )

		);

	}

}

