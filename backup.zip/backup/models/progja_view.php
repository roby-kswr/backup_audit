<?php include('header.php'); ?>
<!-- Page header -->
<div class="page-header">
	<div class="page-header-content">
		<div class="page-title">
			<h4><i class="icon-arrow-left52 position-left"></i> <span class="text-semibold"><?php echo $data['breadcrumb1']; ?></span> - <?php echo $data['title']; ?></h4>
		</div>
	</div>
	<div class="breadcrumb-line">
		<ul class="breadcrumb">
			<li><a href="<?php echo BASE_URL ?>"><i class="icon-home2 position-left"></i> Home</a></li>
			<li><a href="<?php echo $data['curl'] ?>"><?php echo $data['breadcrumb1']; ?></a></li>
			<li class="active"><?php echo $data['title']; ?> Detail</li>
		</ul>
	</div>
</div>
<!-- /page header -->

<!-- Content area -->
<div class="content">

	<div class="panel panel-flat">
		<div class="panel-heading">
			<h5 class="panel-title"><i class="icon-display4 position-left"></i><span class="text-bold">SATKER</span>  <span class="text-teal"> &nbsp; <?php echo $data['nmsatker'] ?></span></h5>
			<div class="heading-elements">
				<ul class="icons-list">
					<li><a data-action="collapse"></a></li>
					<li><a data-action="reload"></a></li>
					<li><a data-action="close"></a></li>
				</ul>
			</div>
		</div>
		<div class="panel-body">
			<a href="<?php echo $data['curl'] ?>" class="btn btn-danger btn-ladda btn-ladda-progress btn-sx" data-style="zoom-out"><span class="ladda-label"><i class="icon-arrow-left52 position-left"></i></span> Back</a>
		</div>
		<table class="table datatable table-striped table-bordered">
			<thead>
				<tr>
					<th class="text-center">URAIAN</th>
					<th class="text-center">WASGIAT</th>
					<th class="text-center">NILAI</th>
					<th class="text-center">DATA</th>
					<th class="text-center">AKUN</th>
		<!-- 			<th class="text-center">TOR</th>
					<th class="text-center">RAB</th>
					<th class="text-center">SPH</th>
					<th class="text-center">KONTRAK</th>
					<th class="text-center">BAST</th>
					<th class="text-center">SP2D</th>
					<th class="text-center">KU17</th> -->
					
				</tr>
			</thead>
		</table>
	</div>
<!-- /basic datatable --> 

<!-- AKUN modal -->
<div id="modal_form" class="modal fade">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header bg-info">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h6 class="modal-title"><i class="icon-windows8" title="Dokumen"></i>&nbsp; Dokumen Media</h6>
			</div>

			<div class="modal-body">
				<table class="table" id="datafile1">
					<thead>
						<tr>
							<th class="text-center">Kode Akun</th>
							<th class="text-center">Nama Akun</th>
							<th class="text-center">Pagu</th>
						</tr>
					</thead>
				</table>
			</div>
		</div>
	</div>
</div>
<!-- /AKUN modal -->  

<!-- HPS modal -->
<div id="modal_akun" class="modal fade">
<div class="modal-dialog modal-lg">
  <div class="modal-content">
	    <div class="modal-header bg-teal">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h6 class="modal-title"><i class="icon-file-spreadsheet2" title="Dokumen"></i>&nbsp; Akun</h6>
	    </div>

	    <div class="modal-body">
	      <table class="table table-striped table-bordered" id="dthps">
	          <thead>
	            <tr>
	              <th class="text-center">KDAKUN</th>
	              <th class="text-center">NAMA AKUN</th>
	              <th class="text-center">NILAI</th><!-- 
	              <th class="text-center">DOKUMEN</th>
	              <th class="text-center">HPS</th>
	              <th class="text-center">Actions</th> -->
	            </tr>
	          </thead>
	        </table>
	  </div>
	</div>
</div>
</div>
<!-- /HPS modal -->   

<!-- Info modal -->
<div id="modal_datas" class="modal fade">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header bg-teal">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h6 class="modal-title"><i class="icon-file-text2" title="Dokumen"></i>&nbsp; Dokumen</h6>
			</div>

			<div class="modal-body">

				<div class="tabbable"> <!-- tab -->
					<ul class="nav nav-tabs nav-tabs-highlight nav-justified">
						<li class="active"><a href="#highlighted-tab1" class="text-bold text-grey-300" data-toggle="tab">HPS</a></li>
						<li><a href="#highlighted-tab2" class="text-bold text-grey-300" onclick="gettor(false)" data-toggle="tab">TOR</a></li>
						<li><a href="#highlighted-tab3" class="text-bold text-grey-300" onclick="getrab(false)" data-toggle="tab">RAB</a></li>
						<li><a href="#highlighted-tab4" class="text-bold text-grey-300" onclick="getsph(false)" data-toggle="tab">SPH</a></li>
						<li><a href="#highlighted-tab5" class="text-bold text-grey-300" onclick="getkontrak(false)" data-toggle="tab">KONTRAK</a></li>
						<li><a href="#highlighted-tab6" class="text-bold text-grey-300" onclick="getbast(false)" data-toggle="tab">BAST</a></li>
						<li><a href="#highlighted-tab7" class="text-bold text-grey-300" onclick="getku17(false)" data-toggle="tab">KU17</a></li>
						<li><a href="#highlighted-tab8" class="text-bold text-grey-300" onclick="getsp2d(false)" data-toggle="tab">SP2D</a></li>
					</ul>

					<div class="tab-content">
						<div class="tab-pane active" id="highlighted-tab1">
							<div class="row">
							<form class="form-horizontal" id="hps-form" action="<?php echo $data['curl']."/savehps/".$data['encode']; ?>" method="post" enctype="multipart/form-data">
								<fieldset class="content-group">
								  <div class="form-group">
								    <label class="control-label col-lg-2">Tanggal HPS</label>
								    <div class="col-lg-6">
								      <div class="input-group">
								        <span class="input-group-addon"><i class="icon-calendar"></i></span>
								        <input type="date" class="form-control" name="tanggal_hps" value="" >
								        <input type="hidden" class="form-control" name="hpsval" id="hpsval" readonly="true">
								      </div>
								    </div>
								  </div>
								  <div class="form-group">
								    <label class="control-label col-lg-2">Nilai HPS</label>
								    <div class="col-lg-6">		      
								        <input type="number" class="form-control" name="nilai_hps">
								    </div>
								  </div>
								  <div class="form-group">
								    <label class="control-label col-lg-2">Dok. HPS</label>
								    <div class="col-lg-10">
								      <input type="file" class="file-input" multiple="multiple" name="file_hps[]" data-show-upload="false" data-show-caption="true" data-show-preview="false" accept="application/pdf">
								      <span class="text-size-mini text-danger">* Hanya menerima file <code>.pdf</code></span>
								    </div>
								  </div>
								  <div class="form-group">
								    <label class="control-label col-lg-2">File HPS</label>
								    <div class="col-lg-10">
								      <input type="file" class="file-input" multiple="multiple" name="file_excelhps[]" data-show-upload="false" data-show-caption="true" data-show-preview="false" accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel">
								      <span class="text-size-mini text-danger">* Hanya menerima file <code>.xls, .xlsx</code></span>
								    </div>
								  </div>
								</fieldset>
								<div class="text-right">		  
								  <button type="button" id="post-hps" class="btn btn-success">Submit <i class="icon-circle-right2 position-right"></i></button>
								</div>
								<div class="form-group">
								    <label class="control-label col-lg-2"></label>
								    <div class="col-lg-10"></div>
								  </div>
							</form>
							</div>
							<fieldset class="content-group">
								<table class="table table-striped table-bordered" id="datatable-hps">
						          <thead>
						            <tr>
						              <th class="text-center bg-slate-600">Tanggal HPS</th>
						              <th class="text-center bg-slate-600">Nilai HPS</th>
						              <th class="text-center bg-slate-600">Dok.</th>
						              <th class="text-center bg-slate-600">HPS</th>
						            </tr>
						          </thead>
						        </table>
							</fieldset>
						</div> <!-- tab hps -->

						<div class="tab-pane" id="highlighted-tab2"> <!-- tab tor -->
							<div class="row">
							<form class="form-horizontal" id="tor-form" action="<?php echo $data['curl']."/savertor/".$data['encode']; ?>" method="post" enctype="multipart/form-data">
								<fieldset class="content-group">
								  <div class="form-group">
								    <label class="control-label col-lg-2">Tanggal TOR</label>
								    <div class="col-lg-6">
								      <div class="input-group">
								        <span class="input-group-addon"><i class="icon-calendar"></i></span>
								        <input type="date" class="form-control" name="tanggal_tor" value="" >
								        <input type="hidden" class="form-control" name="torval" id="torval" readonly="true">
								      </div>
								    </div>
								  </div>
								  <div class="form-group">
								    <label class="control-label col-lg-2">Dok. TOR</label>
								    <div class="col-lg-10">
								      <input type="file" class="file-input" multiple="multiple" name="file_tor[]" data-show-upload="false" data-show-caption="true" data-show-preview="false" accept="application/pdf">
								      <span class="text-size-mini text-danger">* Hanya menerima file <code>.pdf</code></span>
								    </div>
								  </div>
								  <div class="form-group">
								    <label class="control-label col-lg-2">File TOR</label>
								    <div class="col-lg-10">
								      <input type="file" class="file-input" multiple="multiple" name="file_exceltor[]" data-show-upload="false" data-show-caption="true" data-show-preview="false" accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel">
								      <span class="text-size-mini text-danger">* Hanya menerima file <code>.xls, .xlsx</code></span>
								    </div>
								  </div>
								</fieldset>
								<div class="text-right">		  
								  <button type="button" id="post-tor" class="btn btn-success">Submit <i class="icon-circle-right2 position-right"></i></button>
								</div>
								<div class="form-group">
								    <label class="control-label col-lg-2"></label>
								    <div class="col-lg-10"></div>
								  </div>
							</form>
							</div>
							<fieldset class="content-group">
								<table class="table table-striped table-bordered" id="datatable-tor">
						          <thead>
						            <tr>
						              <th class="text-center bg-slate-600">Tanggal TOR</th>
						              <th class="text-center bg-slate-600">Dok.</th>
						              <th class="text-center bg-slate-600">TOR</th>
						            </tr>
						          </thead>
						        </table>
							</fieldset>
						</div> <!-- tab tor -->

						<div class="tab-pane" id="highlighted-tab3">
							<div class="row">
							<form class="form-horizontal" id="rab-form" action="<?php echo $data['curl']."/savehrab/".$data['encode']; ?>" method="post" enctype="multipart/form-data">
								<fieldset class="content-group">
								  <div class="form-group">
								    <label class="control-label col-lg-2">Tanggal RAB</label>
								    <div class="col-lg-6">
								      <div class="input-group">
								        <span class="input-group-addon"><i class="icon-calendar"></i></span>
								        <input type="date" class="form-control" name="tanggal_rab" value="" >
								        <input type="hidden" class="form-control" name="rabval" id="rabval" readonly="true">
								      </div>
								    </div>
								  </div>
								  <div class="form-group">
								    <label class="control-label col-lg-2">Nilai RAB</label>
								    <div class="col-lg-6">		      
								        <input type="number" class="form-control" name="nilai_rab">
								    </div>
								  </div>
								  <div class="form-group">
								    <label class="control-label col-lg-2">Dok. RAB</label>
								    <div class="col-lg-10">
								      <input type="file" class="file-input" multiple="multiple" name="file_rab[]" data-show-upload="false" data-show-caption="true" data-show-preview="false" accept="application/pdf">
								      <span class="text-size-mini text-danger">* Hanya menerima file <code>.pdf</code></span>
								    </div>
								  </div>
								  <div class="form-group">
								    <label class="control-label col-lg-2">File RAB</label>
								    <div class="col-lg-10">
								      <input type="file" class="file-input" multiple="multiple" name="file_excelrab[]" data-show-upload="false" data-show-caption="true" data-show-preview="false" accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel">
								      <span class="text-size-mini text-danger">* Hanya menerima file <code>.xls, .xlsx</code></span>
								    </div>
								  </div>
								</fieldset>
								<div class="text-right">		  
								  <button type="button" id="post-rab" class="btn btn-success">Submit <i class="icon-circle-right2 position-right"></i></button>
								</div>
								<div class="form-group">
								    <label class="control-label col-lg-2"></label>
								    <div class="col-lg-10"></div>
								  </div>
							</form>
							</div>
							<fieldset class="content-group">
								<table class="table table-striped table-bordered" id="datatable-rab">
						          <thead>
						            <tr>
						              <th class="text-center bg-slate-600">Tanggal RAB</th>
						              <th class="text-center bg-slate-600">Nilai RAB</th>
						              <th class="text-center bg-slate-600">Dok.</th>
						              <th class="text-center bg-slate-600">RAB</th>
						            </tr>
						          </thead>
						        </table>
							</fieldset>
						</div> <!-- tab rab -->

						<div class="tab-pane" id="highlighted-tab4"><!-- tab sph -->
							<div class="row">
							<form class="form-horizontal" id="sph-form" action="<?php echo $data['curl']."/savehsph/".$data['encode']; ?>" method="post" enctype="multipart/form-data">
								<fieldset class="content-group">
								  <div class="form-group">
								    <label class="control-label col-lg-2">Tanggal SPH</label>
								    <div class="col-lg-6">
								      <div class="input-group">
								        <span class="input-group-addon"><i class="icon-calendar"></i></span>
								        <input type="date" class="form-control" name="tanggal_sph" value="" >
								        <input type="hidden" class="form-control" name="sphval" id="sphval" readonly="true">
								      </div>
								    </div>
								  </div>
								  <div class="form-group">
								    <label class="control-label col-lg-2">Nilai SPH</label>
								    <div class="col-lg-6">		      
								        <input type="number" class="form-control" name="nilai_sph">
								    </div>
								  </div>
								  <div class="form-group">
								    <label class="control-label col-lg-2">Dok. SPH</label>
								    <div class="col-lg-10">
								      <input type="file" class="file-input" multiple="multiple" name="file_sph[]" data-show-upload="false" data-show-caption="true" data-show-preview="false" accept="application/pdf">
								      <span class="text-size-mini text-danger">* Hanya menerima file <code>.pdf</code></span>
								    </div>
								  </div>
								  <div class="form-group">
								    <label class="control-label col-lg-2">File SPH</label>
								    <div class="col-lg-10">
								      <input type="file" class="file-input" multiple="multiple" name="file_excelsph[]" data-show-upload="false" data-show-caption="true" data-show-preview="false" accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel">
								      <span class="text-size-mini text-danger">* Hanya menerima file <code>.xls, .xlsx</code></span>
								    </div>
								  </div>
								</fieldset>
								<div class="text-right">		  
								  <button type="button" id="post-sph" class="btn btn-success">Submit <i class="icon-circle-right2 position-right"></i></button>
								</div>
								<div class="form-group">
								    <label class="control-label col-lg-2"></label>
								    <div class="col-lg-10"></div>
								  </div>
							</form>
							</div>
							<fieldset class="content-group">
								<table class="table table-striped table-bordered" id="datatable-sph">
						          <thead>
						            <tr>
						              <th class="text-center bg-slate-600">Tanggal SPH</th>
						              <th class="text-center bg-slate-600">Nilai SPH</th>
						              <th class="text-center bg-slate-600">Dok.</th>
						              <th class="text-center bg-slate-600">SPH</th>
						            </tr>
						          </thead>
						        </table>
							</fieldset>
						</div> <!-- tab sph -->

						<div class="tab-pane" id="highlighted-tab5"><!-- tab kontrak -->
							<div class="row">
							<form class="form-horizontal" id="kontrak-form" action="<?php echo $data['curl']."/savehkontrak/".$data['encode']; ?>" method="post" enctype="multipart/form-data">
								<fieldset class="content-group">
								  <div class="form-group">
								    <label class="control-label col-lg-2">Tanggal Kontrak</label>
								    <div class="col-lg-6">
								      <div class="input-group">
								        <span class="input-group-addon"><i class="icon-calendar"></i></span>
								        <input type="date" class="form-control" name="tanggal_kontrak" value="" >
								        <input type="hidden" class="form-control" name="kontrakval" id="kontrakval" readonly="true">
								      </div>
								    </div>
								  </div>
								  <div class="form-group">
								    <label class="control-label col-lg-2">Termin Pembayaran</label>
								    <div class="col-lg-6">		      
								        <input type="number" class="form-control" name="termin" min="1" max="5">
								    </div>
								  </div>
								  <div class="form-group">
								    <label class="control-label col-lg-2">Nilai Kontrak</label>
								    <div class="col-lg-6">		      
								        <input type="number" class="form-control" name="nilai_kontrak">
								    </div>
								  </div>
								  <div class="form-group">
								    <label class="control-label col-lg-2">Dok. Kontrak</label>
								    <div class="col-lg-10">
								      <input type="file" class="file-input" multiple="multiple" name="file_kontrak[]" data-show-upload="false" data-show-caption="true" data-show-preview="false" accept="application/pdf">
								      <span class="text-size-mini text-danger">* Hanya menerima file <code>.pdf</code></span>
								    </div>
								  </div>
								  <div class="form-group">
								    <label class="control-label col-lg-2">File Kontrak</label>
								    <div class="col-lg-10">
								      <input type="file" class="file-input" multiple="multiple" name="file_excelkontrak[]" data-show-upload="false" data-show-caption="true" data-show-preview="false" accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel">
								      <span class="text-size-mini text-danger">* Hanya menerima file <code>.xls, .xlsx</code></span>
								    </div>
								  </div>
								</fieldset>
								<div class="text-right">		  
								  <button type="button" id="post-kontrak" class="btn btn-success">Submit <i class="icon-circle-right2 position-right"></i></button>
								</div>
								<div class="form-group">
								    <label class="control-label col-lg-2"></label>
								    <div class="col-lg-10"></div>
								  </div>
							</form>
							</div>
							<fieldset class="content-group">
								<table class="table table-striped table-bordered" id="datatable-kontrak">
						          <thead>
						            <tr>
						              <th class="text-center bg-slate-600">Tanggal Kontrak</th>
						              <th class="text-center bg-slate-600">Nilai Kontrak</th>
						              <th class="text-center bg-slate-600">Termin Ke</th>
						              <th class="text-center bg-slate-600">Dok.</th>
						              <th class="text-center bg-slate-600">Kontrak</th>
						            </tr>
						          </thead>
						        </table>
							</fieldset>
						</div> <!-- tab kontrak -->

						<div class="tab-pane" id="highlighted-tab6"><!-- tab bast -->
							<div class="row">
							<form class="form-horizontal" id="bast-form" action="<?php echo $data['curl']."/savehbast/".$data['encode']; ?>" method="post" enctype="multipart/form-data">
								<fieldset class="content-group">
								  <div class="form-group">
								    <label class="control-label col-lg-2">Tanggal BAST</label>
								    <div class="col-lg-6">
								      <div class="input-group">
								        <span class="input-group-addon"><i class="icon-calendar"></i></span>
								        <input type="date" class="form-control" name="tanggal_bast" value="" >
								        <input type="hidden" class="form-control" name="bastval" id="bastval" readonly="true">
								      </div>
								    </div>
								  </div>
								  <div class="form-group">
								    <label class="control-label col-lg-2">Nilai BAST</label>
								    <div class="col-lg-6">		      
								        <input type="number" class="form-control" name="nilai_bast">
								    </div>
								  </div>
								  <div class="form-group">
								    <label class="control-label col-lg-2">Dok. BAST</label>
								    <div class="col-lg-10">
								      <input type="file" class="file-input" multiple="multiple" name="file_bast[]" data-show-upload="false" data-show-caption="true" data-show-preview="false" accept="application/pdf">
								      <span class="text-size-mini text-danger">* Hanya menerima file <code>.pdf</code></span>
								    </div>
								  </div>
								  <div class="form-group">
								    <label class="control-label col-lg-2">File BAST</label>
								    <div class="col-lg-10">
								      <input type="file" class="file-input" multiple="multiple" name="file_excelbast[]" data-show-upload="false" data-show-caption="true" data-show-preview="false" accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel">
								      <span class="text-size-mini text-danger">* Hanya menerima file <code>.xls, .xlsx</code></span>
								    </div>
								  </div>
								</fieldset>
								<div class="text-right">		  
								  <button type="button" id="post-bast" class="btn btn-success">Submit <i class="icon-circle-right2 position-right"></i></button>
								</div>
								<div class="form-group">
								    <label class="control-label col-lg-2"></label>
								    <div class="col-lg-10"></div>
								  </div>
							</form>
							</div>
							<fieldset class="content-group">
								<table class="table table-striped table-bordered" id="datatable-bast">
						          <thead>
						            <tr>
						              <th class="text-center bg-slate-600">Tanggal BAST</th>
						              <th class="text-center bg-slate-600">Nilai BAST</th>
						              <th class="text-center bg-slate-600">Dok.</th>
						              <th class="text-center bg-slate-600">BAST</th>
						            </tr>
						          </thead>
						        </table>
							</fieldset>
						</div> <!-- tab bast -->

						<div class="tab-pane" id="highlighted-tab7"><!-- tab ku17 -->
							<div class="row">
							<form class="form-horizontal" id="ku17-form" action="<?php echo $data['curl']."/savehku17/".$data['encode']; ?>" method="post" enctype="multipart/form-data">
								<fieldset class="content-group">
								  <div class="form-group">
								    <label class="control-label col-lg-2">Tanggal KU17</label>
								    <div class="col-lg-6">
								      <div class="input-group">
								        <span class="input-group-addon"><i class="icon-calendar"></i></span>
								        <input type="date" class="form-control" name="tanggal_ku17" value="" >
								        <input type="hidden" class="form-control" name="ku17val" id="ku17val" readonly="true">
								      </div>
								    </div>
								  </div>
								  <div class="form-group">
								    <label class="control-label col-lg-2">Nilai KU17</label>
								    <div class="col-lg-6">		      
								        <input type="number" class="form-control" name="nilai_ku17">
								    </div>
								  </div>
								  <div class="form-group">
								    <label class="control-label col-lg-2">Dok. KU17</label>
								    <div class="col-lg-10">
								      <input type="file" class="file-input" multiple="multiple" name="file_ku17[]" data-show-upload="false" data-show-caption="true" data-show-preview="false" accept="application/pdf">
								      <span class="text-size-mini text-danger">* Hanya menerima file <code>.pdf</code></span>
								    </div>
								  </div>
								  <div class="form-group">
								    <label class="control-label col-lg-2">File KU17</label>
								    <div class="col-lg-10">
								      <input type="file" class="file-input" multiple="multiple" name="file_excelku17[]" data-show-upload="false" data-show-caption="true" data-show-preview="false" accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel">
								      <span class="text-size-mini text-danger">* Hanya menerima file <code>.xls, .xlsx</code></span>
								    </div>
								  </div>
								</fieldset>
								<div class="text-right">		  
								  <button type="button" id="post-ku17" class="btn btn-success">Submit <i class="icon-circle-right2 position-right"></i></button>
								</div>
								<div class="form-group">
								    <label class="control-label col-lg-2"></label>
								    <div class="col-lg-10"></div>
								  </div>
							</form>
							</div>
							<fieldset class="content-group">
								<table class="table table-striped table-bordered" id="datatable-ku17">
						          <thead>
						            <tr>
						              <th class="text-center bg-slate-600">Tanggal KU17</th>
						              <th class="text-center bg-slate-600">Nilai KU17</th>
						              <th class="text-center bg-slate-600">Dok.</th>
						              <th class="text-center bg-slate-600">KU17</th>
						            </tr>
						          </thead>
						        </table>
							</fieldset>
						</div> <!-- tab ku17 -->

						<div class="tab-pane" id="highlighted-tab8"><!-- tab sp2d -->
							<div class="row">
							<form class="form-horizontal" id="sp2d-form" action="<?php echo $data['curl']."/savehsp2d/".$data['encode']; ?>" method="post" enctype="multipart/form-data">
								<fieldset class="content-group">
								  <div class="form-group">
								    <label class="control-label col-lg-2">Tanggal SP2D</label>
								    <div class="col-lg-6">
								      <div class="input-group">
								        <span class="input-group-addon"><i class="icon-calendar"></i></span>
								        <input type="date" class="form-control" name="tanggal_sp2d" value="" >
								        <input type="hidden" class="form-control" name="sp2dval" id="sp2dval" readonly="true">
								      </div>
								    </div>
								  </div>
								  <div class="form-group">
								    <label class="control-label col-lg-2">Nilai SP2D</label>
								    <div class="col-lg-6">		      
								        <input type="number" class="form-control" name="nilai_sp2d">
								    </div>
								  </div>
								  <div class="form-group">
								    <label class="control-label col-lg-2">Dok. SP2D</label>
								    <div class="col-lg-10">
								      <input type="file" class="file-input" multiple="multiple" name="file_sp2d[]" data-show-upload="false" data-show-caption="true" data-show-preview="false" accept="application/pdf">
								      <span class="text-size-mini text-danger">* Hanya menerima file <code>.pdf</code></span>
								    </div>
								  </div>
								  <div class="form-group">
								    <label class="control-label col-lg-2">File SP2D</label>
								    <div class="col-lg-10">
								      <input type="file" class="file-input" multiple="multiple" name="file_excelsp2d[]" data-show-upload="false" data-show-caption="true" data-show-preview="false" accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel">
								      <span class="text-size-mini text-danger">* Hanya menerima file <code>.xls, .xlsx</code></span>
								    </div>
								  </div>
								</fieldset>
								<div class="text-right">		  
								  <button type="button" id="post-sp2d" class="btn btn-success">Submit <i class="icon-circle-right2 position-right"></i></button>
								</div>
								<div class="form-group">
								    <label class="control-label col-lg-2"></label>
								    <div class="col-lg-10"></div>
								  </div>
							</form>
							</div>
							<fieldset class="content-group">
								<table class="table table-striped table-bordered" id="datatable-sp2d">
						          <thead>
						            <tr>
						              <th class="text-center bg-slate-600">Tanggal SP2D</th>
						              <th class="text-center bg-slate-600">Nilai SP2D</th>
						              <th class="text-center bg-slate-600">Dok.</th>
						              <th class="text-center bg-slate-600">SP2D</th>
						            </tr>
						          </thead>
						        </table>
							</fieldset>
						</div> <!-- tab sp2d -->
					</div>
				</div> <!-- tab -->


			</div>
		</div>
	</div>
</div>
<!-- /info modal -->

   

<script type="text/javascript">
  	var url = '<?php echo $data['curl'] ?>';
  	

  	// #HPS
	$('#post-hps').on('click', function() {
	  let data = new FormData($("#hps-form")[0]);
	  var hps = $("#hpsval").val();
	  $.ajax({
	    url: url+'savehps/'+hps,
	    type: 'POST',
	    data: data,
	    processData: false,
	    contentType: false,
	    success: function(r) {
	      gethps(hps);
	      $('#hps-form')[0].reset();
			new PNotify({
	            title: 'sukses',
	            text: 'Data HPS berhasil disimpan.',
	            addclass: 'bg-primary alert-styled-left'
	        });

         
	    },
	    error: function(r) {
	      console.log('error', r);
	    }
	  });
	});

	function gethps(a){
     	$('#hpsval').val(a);
	    $('#datatable-hps').DataTable({
          	"destroy": true,
          	"processing": true,
          	"serverSide": true, 
          	"paging": false,
          	"searching": false,
          	"info": false,
          	"order": [0],
          	"ajax": {
	              "url": url+'getdatahps/'+a,
	              "type": "POST"
	        },
	        "columns": [
              	{"data": 1,width:'auto', orderable: false, searchable:true, className:'text-center'},
              	{"data": 2,width:'auto', orderable: false, searchable:true, className: 'text-right text-bold'},
              	{
	                "data": null,
	                "width": 50,
	                "sortable": false,
	                "className": "center",
	                "render": function ( data, type, row, meta ) {
	                     return "<a href=\""+url+'downloadpdf/'+row[0]+"\"  class=\"btn-sx text-danger\" data-toggle=\"modal\" data-target=\"#modal_hps_dokumen\" title=\"Dokumen HPS\"><i class=\"icon-file-pdf\"></i></a> ";
	                 }
	            },
              	{
	                "data": null,
	                "width": 50,
	                "sortable": false,
	                "className": "center",
	                "render": function ( data, type, row, meta ) {
	                     return "<a href=\""+url+'downloadexcel/'+row[0]+"\"  class=\"btn-sx text-teal\" data-toggle=\"modal\" data-target=\"#modal_hps_dokumen\" title=\"File HPS\"><i class=\"icon-file-excel\"></i></a> ";
	                 }
	            }
          	]
     	});
	}

	// #TOR
	$('#post-tor').on('click', function() {
	  let data = new FormData($("#tor-form")[0]);
	  //var tor = $("#torval").val();
	  var tor = $("#hpsval").val();
	  $.ajax({
	    url: url+'savetor/'+tor,
	    type: 'POST',
	    data: data,
	    processData: false,
	    contentType: false,
	    success: function(r) {
	      gettor(tor);
	      $('#tor-form')[0].reset();
			new PNotify({
	            title: 'sukses',
	            text: 'Data berhasil disimpan.',
	            addclass: 'bg-primary alert-styled-left'
	        });

         
	    },
	    error: function(r) {
	      console.log('error', r);
	    }
	  });
	});

	function gettor(b){
		if(!b){
			var b = $("#hpsval").val();
		}
     	$('#torval').val(b);
     	
	    $('#datatable-tor').DataTable({
          	"destroy": true,
          	"processing": true,
          	"serverSide": true, 
          	"paging": false,
          	"searching": false,
          	"info": false,
          	"order": [0],
          	"ajax": {
	              "url": url+'getdatator/'+b,
	              "type": "POST"
	        },
	        "columns": [
              	{"data": 1,width:'auto', orderable: false, searchable:true, className:'text-center'},
              	{
	                "data": null,
	                "width": 50,
	                "sortable": false,
	                "className": "center",
	                "render": function ( data, type, row, meta ) {
	                     return "<a href=\""+url+'downloadpdf/'+row[0]+"\"  class=\"btn-sx text-danger\" data-toggle=\"modal\" data-target=\"#modal_tor_dokumen\" title=\"Dokumen TOR\"><i class=\"icon-file-pdf\"></i></a> ";
	                 }
	            },
              	{
	                "data": null,
	                "width": 50,
	                "sortable": false,
	                "className": "center",
	                "render": function ( data, type, row, meta ) {
	                     return "<a href=\""+url+'downloadexcel/'+row[0]+"\"  class=\"btn-sx text-teal\" data-toggle=\"modal\" data-target=\"#modal_tor_dokumen\" title=\"File TOR\"><i class=\"icon-file-excel\"></i></a> ";
	                 }
	            }
          	]
     	});
	}

	// #RAB
	$('#post-rab').on('click', function() {
	  let data = new FormData($("#rab-form")[0]);
	  var rab = $("#hpsval").val();
	  //var rab = $("#rabval").val();
	  $.ajax({
	    url: url+'saverab/'+rab,
	    type: 'POST',
	    data: data,
	    processData: false,
	    contentType: false,
	    success: function(r) {
	      getrab(rab);
	      $('#rab-form')[0].reset();
			new PNotify({
	            title: 'sukses',
	            text: 'Data berhasil disimpan.',
	            addclass: 'bg-primary alert-styled-left'
	        });

         
	    },
	    error: function(r) {
	      console.log('error', r);
	    }
	  });
	});

	function getrab(c){
		if(!c){
			var c = $("#hpsval").val();
		}
     	$('#rabval').val(c);
	    $('#datatable-rab').DataTable({
          	"destroy": true,
          	"processing": true,
          	"serverSide": true, 
          	"paging": false,
          	"searching": false,
          	"info": false,
          	"order": [0],
          	"ajax": {
	              "url": url+'getdatarab/'+c,
	              "type": "POST"
	        },
	        "columns": [
              	{"data": 1,width:'auto', orderable: false, searchable:true, className:'text-center'},
              	{"data": 2,width:'auto', orderable: false, searchable:true, className: 'text-right text-bold'},
              	{
	                "data": null,
	                "width": 50,
	                "sortable": false,
	                "className": "center",
	                "render": function ( data, type, row, meta ) {
	                     return "<a href=\""+url+'downloadpdf/'+row[0]+"\"  class=\"btn-sx text-danger\" data-toggle=\"modal\" data-target=\"#modal_rab_dokumen\" title=\"Dokumen TOR\"><i class=\"icon-file-pdf\"></i></a> ";
	                 }
	            },
              	{
	                "data": null,
	                "width": 50,
	                "sortable": false,
	                "className": "center",
	                "render": function ( data, type, row, meta ) {
	                     return "<a href=\""+url+'downloadexcel/'+row[0]+"\"  class=\"btn-sx text-teal\" data-toggle=\"modal\" data-target=\"#modal_rab_dokumen\" title=\"File TOR\"><i class=\"icon-file-excel\"></i></a> ";
	                 }
	            }
          	]
     	});
	}


	// #SPH
	$('#post-sph').on('click', function() {
	  let data = new FormData($("#sph-form")[0]);
	  var sph = $("#hpsval").val();
	  // var sph = $("#sphval").val();
	  $.ajax({
	    url: url+'savesph/'+sph,
	    type: 'POST',
	    data: data,
	    processData: false,
	    contentType: false,
	    success: function(r) {
	      getsph(sph);
	      $('#sph-form')[0].reset();
			new PNotify({
	            title: 'sukses',
	            text: 'Data berhasil disimpan.',
	            addclass: 'bg-primary alert-styled-left'
	        });

         
	    },
	    error: function(r) {
	      console.log('error', r);
	    }
	  });
	});

	function getsph(d){
		if(!d){
			var d = $("#hpsval").val();
		}
     	$('#sphval').val(d);
	    $('#datatable-sph').DataTable({
          	"destroy": true,
          	"processing": true,
          	"serverSide": true, 
          	"paging": false,
          	"searching": false,
          	"info": false,
          	"order": [0],
          	"ajax": {
	              "url": url+'getdatasph/'+d,
	              "type": "POST"
	        },
	        "columns": [
              	{"data": 1,width:'auto', orderable: false, searchable:true, className:'text-center'},
              	{"data": 2,width:'auto', orderable: false, searchable:true, className: 'text-right text-bold'},
              	{
	                "data": null,
	                "width": 50,
	                "sortable": false,
	                "className": "center",
	                "render": function ( data, type, row, meta ) {
	                     return "<a href=\""+url+'downloadpdf/'+row[0]+"\"  class=\"btn-sx text-danger\" data-toggle=\"modal\" data-target=\"#modal_sph_dokumen\" title=\"Dokumen TOR\"><i class=\"icon-file-pdf\"></i></a> ";
	                 }
	            },
              	{
	                "data": null,
	                "width": 50,
	                "sortable": false,
	                "className": "center",
	                "render": function ( data, type, row, meta ) {
	                     return "<a href=\""+url+'downloadexcel/'+row[0]+"\"  class=\"btn-sx text-teal\" data-toggle=\"modal\" data-target=\"#modal_sph_dokumen\" title=\"File TOR\"><i class=\"icon-file-excel\"></i></a> ";
	                 }
	            }
          	]
     	});
	}


	// #KONTRAK
	$('#post-kontrak').on('click', function() {
	  let data = new FormData($("#kontrak-form")[0]);
	  var kontrak = $("#hpsval").val();
	  //var kontrak = $("#kontrakval").val();
	  $.ajax({
	    url: url+'savekontrak/'+kontrak,
	    type: 'POST',
	    data: data,
	    processData: false,
	    contentType: false,
	    success: function(r) {
	      getkontrak(kontrak);
	      $('#kontrak-form')[0].reset();
			new PNotify({
	            title: 'sukses',
	            text: 'Data berhasil disimpan.',
	            addclass: 'bg-primary alert-styled-left'
	        });

         
	    },
	    error: function(r) {
	      console.log('error', r);
	    }
	  });
	});

	function getkontrak(e){
		if(!e){
			var e = $("#hpsval").val();
		}
     	$('#kontrakval').val(e);
	    $('#datatable-kontrak').DataTable({
          	"destroy": true,
          	"processing": true,
          	"serverSide": true, 
          	"paging": false,
          	"searching": false,
          	"info": false,
          	"order": [0],
          	"ajax": {
	              "url": url+'getdatakontrak/'+e,
	              "type": "POST"
	        },
	        "columns": [
              	{"data": 1,width:'auto', orderable: false, searchable:true, className:'text-center'},
              	{"data": 2,width:'auto', orderable: false, searchable:true, className: 'text-right text-bold'},
              	{"data": 3,width:'auto', orderable: false, searchable:true, className: 'text-center text-bold'},
              	{
	                "data": null,
	                "width": 50,
	                "sortable": false,
	                "className": "center",
	                "render": function ( data, type, row, meta ) {
	                     return "<a href=\""+url+'downloadpdf/'+row[0]+"\"  class=\"btn-sx text-danger\" data-toggle=\"modal\" data-target=\"#modal_kontrak_dokumen\" title=\"Dokumen TOR\"><i class=\"icon-file-pdf\"></i></a> ";
	                 }
	            },
              	{
	                "data": null,
	                "width": 50,
	                "sortable": false,
	                "className": "center",
	                "render": function ( data, type, row, meta ) {
	                     return "<a href=\""+url+'downloadexcel/'+row[0]+"\"  class=\"btn-sx text-teal\" data-toggle=\"modal\" data-target=\"#modal_kontrak_dokumen\" title=\"File TOR\"><i class=\"icon-file-excel\"></i></a> ";
	                 }
	            }
          	]
     	});
	}

	// #BAST
	$('#post-bast').on('click', function() {
	  let data = new FormData($("#bast-form")[0]);
	  var bast = $("#hpsval").val();
	  //var bast = $("#bastval").val();
	  $.ajax({
	    url: url+'savebast/'+bast,
	    type: 'POST',
	    data: data,
	    processData: false,
	    contentType: false,
	    success: function(r) {
	      getbast(bast);
	      $('#bast-form')[0].reset();
			new PNotify({
	            title: 'sukses',
	            text: 'Data berhasil disimpan.',
	            addclass: 'bg-primary alert-styled-left'
	        });

         
	    },
	    error: function(r) {
	      console.log('error', r);
	    }
	  });
	});

	function getbast(f){
		if(!f){
			var f = $("#hpsval").val();
		}
     	$('#bastval').val(f);
	    $('#datatable-bast').DataTable({
          	"destroy": true,
          	"processing": true,
          	"serverSide": true, 
          	"paging": false,
          	"searching": false,
          	"info": false,
          	"order": [0],
          	"ajax": {
	              "url": url+'getdatabast/'+f,
	              "type": "POST"
	        },
	        "columns": [
              	{"data": 1,width:'auto', orderable: false, searchable:true, className:'text-center'},
              	{"data": 2,width:'auto', orderable: false, searchable:true, className: 'text-right text-bold'},
              	{
	                "data": null,
	                "width": 50,
	                "sortable": false,
	                "className": "center",
	                "render": function ( data, type, row, meta ) {
	                     return "<a href=\""+url+'downloadpdf/'+row[0]+"\"  class=\"btn-sx text-danger\" data-toggle=\"modal\" data-target=\"#modal_bast_dokumen\" title=\"Dokumen TOR\"><i class=\"icon-file-pdf\"></i></a> ";
	                 }
	            },
              	{
	                "data": null,
	                "width": 50,
	                "sortable": false,
	                "className": "center",
	                "render": function ( data, type, row, meta ) {
	                     return "<a href=\""+url+'downloadexcel/'+row[0]+"\"  class=\"btn-sx text-teal\" data-toggle=\"modal\" data-target=\"#modal_bast_dokumen\" title=\"File TOR\"><i class=\"icon-file-excel\"></i></a> ";
	                 }
	            }
          	]
     	});
	}

	// #KU17
	$('#post-ku17').on('click', function() {
	  let data = new FormData($("#ku17-form")[0]);
	  var ku17 = $("#hpsval").val();
	  //var ku17 = $("#ku17val").val();
	  $.ajax({
	    url: url+'saveku17/'+ku17,
	    type: 'POST',
	    data: data,
	    processData: false,
	    contentType: false,
	    success: function(r) {
	      getku17(ku17);
	      $('#ku17-form')[0].reset();
			new PNotify({
	            title: 'sukses',
	            text: 'Data berhasil disimpan.',
	            addclass: 'bg-primary alert-styled-left'
	        });

         
	    },
	    error: function(r) {
	      console.log('error', r);
	    }
	  });
	});

	function getku17(g){
		if(!g){
			var g = $("#hpsval").val();
		}
     	$('#ku17val').val(g);
	    $('#datatable-ku17').DataTable({
          	"destroy": true,
          	"processing": true,
          	"serverSide": true, 
          	"paging": false,
          	"searching": false,
          	"info": false,
          	"order": [0],
          	"ajax": {
	              "url": url+'getdataku17/'+g,
	              "type": "POST"
	        },
	        "columns": [
              	{"data": 1,width:'auto', orderable: false, searchable:true, className:'text-center'},
              	{"data": 2,width:'auto', orderable: false, searchable:true, className: 'text-right text-bold'},
              	{
	                "data": null,
	                "width": 50,
	                "sortable": false,
	                "className": "center",
	                "render": function ( data, type, row, meta ) {
	                     return "<a href=\""+url+'downloadpdf/'+row[0]+"\"  class=\"btn-sx text-danger\" data-toggle=\"modal\" data-target=\"#modal_ku17_dokumen\" title=\"Dokumen TOR\"><i class=\"icon-file-pdf\"></i></a> ";
	                 }
	            },
              	{
	                "data": null,
	                "width": 50,
	                "sortable": false,
	                "className": "center",
	                "render": function ( data, type, row, meta ) {
	                     return "<a href=\""+url+'downloadexcel/'+row[0]+"\"  class=\"btn-sx text-teal\" data-toggle=\"modal\" data-target=\"#modal_ku17_dokumen\" title=\"File TOR\"><i class=\"icon-file-excel\"></i></a> ";
	                 }
	            }
          	]
     	});
	}


	// #SP2D
	$('#post-sp2d').on('click', function() {
	  let data = new FormData($("#sp2d-form")[0]);
	  var sp2d = $("#hpsval").val();
	  //var sp2d = $("#sp2dval").val();
	  $.ajax({
	    url: url+'savesp2d/'+sp2d,
	    type: 'POST',
	    data: data,
	    processData: false,
	    contentType: false,
	    success: function(r) {
	      getsp2d(sp2d);
	      $('#sp2d-form')[0].reset();
			new PNotify({
	            title: 'sukses',
	            text: 'Data berhasil disimpan.',
	            addclass: 'bg-primary alert-styled-left'
	        });

         
	    },
	    error: function(r) {
	      console.log('error', r);
	    }
	  });
	});

	function getsp2d(h){
		if(!h){
			var h = $("#hpsval").val();
		}
     	$('#sp2dval').val(h);
	    $('#datatable-sp2d').DataTable({
          	"destroy": true,
          	"processing": true,
          	"serverSide": true, 
          	"paging": false,
          	"searching": false,
          	"info": false,
          	"order": [0],
          	"ajax": {
	              "url": url+'getdatasp2d/'+h,
	              "type": "POST"
	        },
	        "columns": [
              	{"data": 1,width:'auto', orderable: false, searchable:true, className:'text-center'},
              	{"data": 2,width:'auto', orderable: false, searchable:true, className: 'text-right text-bold'},
              	{
	                "data": null,
	                "width": 50,
	                "sortable": false,
	                "className": "center",
	                "render": function ( data, type, row, meta ) {
	                     return "<a href=\""+url+'downloadpdf/'+row[0]+"\"  class=\"btn-sx text-danger\" data-toggle=\"modal\" data-target=\"#modal_sp2d_dokumen\" title=\"Dokumen TOR\"><i class=\"icon-file-pdf\"></i></a> ";
	                 }
	            },
              	{
	                "data": null,
	                "width": 50,
	                "sortable": false,
	                "className": "center",
	                "render": function ( data, type, row, meta ) {
	                     return "<a href=\""+url+'downloadexcel/'+row[0]+"\"  class=\"btn-sx text-teal\" data-toggle=\"modal\" data-target=\"#modal_sp2d_dokumen\" title=\"File TOR\"><i class=\"icon-file-excel\"></i></a> ";
	                 }
	            }
          	]
     	});
	}










  	$(function() {
	 	$('.datatable').DataTable({
	        "processing": true,
	        "serverSide": true, 
	        "order": [0],
	        "ajax": {
	            "url": url+'getdetail/<?php echo $data['encode'] ?>',
	            "type": "POST"
	        },
	        "columns": [
				{"data": 1,width:'auto', className:'text-left text-nowrap', orderable: false, searchable:false},
	            {"data": 8,width:'auto', className:'text-left  text-nowrap'},
	            {"data": 7,width:'auto', className:'text-right', searchable:false},
	            {
	                "data": null,
	                "width": 50,
	                "sortable": false,
	                "className": "center",
	                "render": function ( data, type, row, meta ) {
	                     return "<a href=\"#\" onclick=\"gethps('"+row[0]+"')\"   class=\"btn-sx\" data-toggle=\"modal\" data-target=\"#modal_datas\" title=\"Lihat data dokumen\"><i class=\"icon-zoomin3 text-slate-300\"></i></a> ";
	                 }
	            },
	            {
	                "data": null,
	                "width": 50,
	                "sortable": false,
	                "className": "center",
	                "render": function ( data, type, row, meta ) {
	                     return "<a href=\"#\" onclick=\"showakun('"+row[0]+"')\"  class=\"btn-sx\" data-toggle=\"modal\" data-target=\"#modal_akun\" title=\"Lihat Akun\"><i class=\"icon-file-spreadsheet2 text-teal-600\"></i></a> ";
	                 }
	            },
	            // {
	            //     "data": null,
	            //     "width": 50,
	            //     "sortable": false,
	            //     "className": "center",
	            //     "render": function ( data, type, row, meta ) {
	            //          return "<a href=\"#\" onclick=\"showhps('"+row[0]+"')\"  class=\"btn-sx\" data-toggle=\"modal\" data-target=\"#modal_hps\" title=\"View HPS\"><i class=\"icon-file-upload2 text-grey-600\"></i></a> ";
	            //      }
	            // },
	            // {
	            //     "data": null,
	            //     "width": 50,
	            //     "sortable": false,
	            //     "className": "center",
	            //     "render": function ( data, type, row, meta ) {
	            //          return "<a href=\"#\" onclick=\"showhps('"+row[0]+"')\"  class=\"btn-sx\" data-toggle=\"modal\" data-target=\"#modal_hps\" title=\"View HPS\"><i class=\"icon-file-upload2 text-grey-600\"></i></a> ";
	            //      }
	            // },
	            // {
	            //     "data": null,
	            //     "width": 50,
	            //     "sortable": false,
	            //     "className": "center",
	            //     "render": function ( data, type, row, meta ) {
	            //          return "<a href=\"#\" onclick=\"showhps('"+row[0]+"')\"  class=\"btn-sx\" data-toggle=\"modal\" data-target=\"#modal_hps\" title=\"View HPS\"><i class=\"icon-file-upload2 text-grey-600\"></i></a> ";
	            //      }
	            // },
	            // {
	            //     "data": null,
	            //     "width": 50,
	            //     "sortable": false,
	            //     "className": "center",
	            //     "render": function ( data, type, row, meta ) {
	            //          return "<a href=\"#\" onclick=\"showhps('"+row[0]+"')\"  class=\"btn-sx\" data-toggle=\"modal\" data-target=\"#modal_hps\" title=\"View HPS\"><i class=\"icon-file-upload2 text-grey-600\"></i></a> ";
	            //      }
	            // },
	            // {
	            //     "data": null,
	            //     "width": 50,
	            //     "sortable": false,
	            //     "className": "center",
	            //     "render": function ( data, type, row, meta ) {
	            //          return "<a href=\"#\" onclick=\"showhps('"+row[0]+"')\"  class=\"btn-sx\" data-toggle=\"modal\" data-target=\"#modal_hps\" title=\"View HPS\"><i class=\"icon-file-upload2 text-grey-600\"></i></a> ";
	            //      }
	            // },
	            // {
	            //     "data": null,
	            //     "width": 50,
	            //     "sortable": false,
	            //     "className": "center",
	            //     "render": function ( data, type, row, meta ) {
	            //          return "<a href=\"#\" onclick=\"showhps('"+row[0]+"')\"  class=\"btn-sx\" data-toggle=\"modal\" data-target=\"#modal_hps\" title=\"View HPS\"><i class=\"icon-file-upload2 text-grey-600\"></i></a> ";
	            //      }
	            // },
	            // {
	            //     "data": null,
	            //     "width": 50,
	            //     "sortable": false,
	            //     "className": "center",
	            //     "render": function ( data, type, row, meta ) {
	            //          return "<a href=\"#\" onclick=\"showhps('"+row[0]+"')\"  class=\"btn-sx\" data-toggle=\"modal\" data-target=\"#modal_hps\" title=\"View HPS\"><i class=\"icon-file-upload2 text-grey-600\"></i></a> ";
	            //      }
	            // }
	        ]
    	});
  	});
  	function showakun(a){
     	// Show file
	    $('#dthps').DataTable({
          	"destroy": true,
          	"processing": true,
          	"serverSide": true, 
          	"paging": false,
          	"searching": true,
          	"info": false,
          	"order": [0],
          	"ajax": {
	              "url": url+'getrab/'+a,
	              "type": "POST"
	        },
	        "columns": [
              	{"data": 1,width:'auto', orderable: false, searchable:true},
              	{"data": 2,width:'auto', orderable: false, searchable:true},
              	{"data": 3,width:'auto', orderable: false, searchable:false, className:'text-right'}
             //  	,
             //  	{
	            //     "data": null,
	            //     "width": 50,
	            //     "sortable": false,
	            //     "className": "center",
	            //     "render": function ( data, type, row, meta ) {
	            //          //return '<a href="javascript:void()" onclick="dokumenhps()" class="btn-sx text-teal" data-popup="tooltip" title="Upload dokumen HPS"><i class=" icon-stack"></i></a> ';
	            //          return "<a href=\"#\" onclick=\"dokumenhps('"+row[0]+"')\"  class=\"btn-sx text-teal\" data-toggle=\"modal\" data-target=\"#modal_hps_dokumen\" title=\"Upload dokumen HPS\"><i class=\"icon-stack\"></i></a> ";
	            //      }
	            // },
             //  	{
	            //     "data": null,
	            //     "width": 50,
	            //     "sortable": false,
	            //     "className": "center",
	            //     "render": function ( data, type, row, meta ) {
	            //          return '<a href="#" class="btn-sx text-teal" data-toggle="modal" data-target="#modal_hps_dokumen" title="Upload dokumen HPS" title="Data HPS"><i class=" icon-file-spreadsheet"></i></a> ';
	            //      }
	            // },
	            // {
	            //     "data": null,
	            //     "width": 50,
	            //     "sortable": false,
	            //     "className": "center",
	            //     "render": function ( data, type, row, meta ) {
	            //          return '<a href="#" onclick="dokumenhps("'+row[0]+'")" class="btn-sx text-warning" data-popup="tooltip" data-toggle="modal" data-target="#modal_hps_dokumen"  title="Upload dokumen HPS"><i class="icon-file-upload2"></i></a>&nbsp; <a href="javascript:void()" onclick="importrab()" class="btn-sx text-success" data-popup="tooltip" title="Import HPS"><i class="icon-download7"></i></a> ';
	            //      }
	            // }
          	]
     	});
	}
</script>