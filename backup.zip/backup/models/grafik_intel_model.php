<?php

class Grafik_intel_model extends Model {

	public function mget($request, $table, $primaryKey, $columns, $join = null)
	{
		$result = $this->simple($request, $table, $primaryKey, $columns, $join);
		return $result;
	}

	public function mgetdetail($request, $table, $primaryKey, $columns, $join, $sWhere)
	{
		$result = $this->mySimple($request, $table, $primaryKey, $columns, $join, $sWhere);
		return $result;
	}

	public function msave($table, $data = array(), $title)
	{
		$result = $this->sqlinsert($table, $data, $title);
		return $result;
	}

	public function savefile($data = array())
	{
		$result = $this->sqlinsert('vt_files', $data, 'Dokumen');
		return $result;
	}

	public function mupdate($table, $data = array(), $primaryKey, $id, $title)
	{
		$result = $this->sqlupdate($table, $data, $primaryKey, $id, $title);
		return $result;
	}

	public function mdelete($table, $primaryKey, $id, $title)
	{
		$result = $this->sqldelete($table, $primaryKey, $id, $title);
		return $result;
	}

	// public function load_progja(){
	// 	$result = $this->query("SELECT urskmpnen ,COUNT(*) AS progja, wasgiat FROM dja_pagu WHERE wasgiat = 'SRENAD' GROUP BY urskmpnen ");
	// 	return $result;
	// }

	public function load_progja ( $request, $table, $primaryKey, $columns, $join, $sWhere )

	{

		$bindings = array();

		$db = $this->connection;

		$limit = self::limit( $request, $columns );

		$order = self::order( $request, $columns );

		$where = self::filter( $request, $columns, $bindings, true );

		// $sWhere = "WHERE $sWhere";

		$data = $this->query("SELECT kd_bidang,nm_bidang,urskmpnen,jml_pagu, thang FROM tbidang a 
			LEFT JOIN(SELECT wasgiat, urskmpnen,jml_pagu,thang FROM dja_pagu) AS b ON a.wasgiat = b.wasgiat
			WHERE a.kd_bidang NOT BETWEEN 09 AND 11 AND kd_bidang = '01' 

			ORDER BY urskmpnen ASC

			$limit"

		);

		$resFilterLength = $this->query(

			"SELECT COUNT(`{$primaryKey}`)

			FROM `$table`

			WHERE wasgiat = 'SPAMAD'"

		);

		$recordsFiltered = $resFilterLength[0][0];

		$resTotalLength = $this->query(

			"SELECT COUNT(`{$primaryKey}`)

			FROM   `$table`

			WHERE wasgiat = 'SPAMAD'"

		);

		$recordsTotal = $resTotalLength[0][0];

		return array(

			"draw"            => isset ( $request['draw'] ) ?

			intval( $request['draw'] ) :

			0,

			"recordsTotal"    => intval( $recordsTotal ),

			"recordsFiltered" => intval( $recordsFiltered ),

			"data"            => self::data_output( $columns, $data )

		);

	}

	public function load_pagu ( $request, $table, $primaryKey, $columns, $join, $sWhere )

	{

		$bindings = array();

		$db = $this->connection;

		$limit = self::limit( $request, $columns );

		$order = self::order( $request, $columns );

		$where = self::filter( $request, $columns, $bindings, true );

		// $sWhere = "WHERE $sWhere";

		$data = $this->query("SELECT kd_bidang,nm_bidang,urskmpnen,jml_pagu FROM tbidang a 
			LEFT JOIN(SELECT wasgiat, urskmpnen,jml_pagu FROM dja_pagu) AS b ON a.wasgiat = b.wasgiat
			WHERE a.kd_bidang NOT BETWEEN 09 AND 11 AND kd_bidang = '06'

			ORDER BY urskmpnen ASC

			$limit"

		);

		$resFilterLength = $this->query(

			"SELECT COUNT(`{$primaryKey}`)

			FROM `$table`

			WHERE wasgiat = 'SPAMAD'"

		);

		$recordsFiltered = $resFilterLength[0][0];

		$resTotalLength = $this->query(

			"SELECT COUNT(`{$primaryKey}`)

			FROM   `$table`

			WHERE wasgiat = 'SPAMAD'"

		);

		$recordsTotal = $resTotalLength[0][0];

		return array(

			"draw"            => isset ( $request['draw'] ) ?

			intval( $request['draw'] ) :

			0,

			"recordsTotal"    => intval( $recordsTotal ),

			"recordsFiltered" => intval( $recordsFiltered ),

			"data"            => self::data_output( $columns, $data )

		);

	}

	function belanja_personel() {
		$sql = $this->query("SELECT kd_bidang,nm_bidang,b.wasgiat,IF(total IS NULL,0,total) AS total FROM tbidang a 
			LEFT JOIN(SELECT  COUNT(*) AS total, kdakun, wasgiat FROM dja_pagu WHERE wasgiat = 'SPAMAD' AND kdakun LIKE '51%') AS b ON a.wasgiat = b.wasgiat
			WHERE a.kd_bidang NOT BETWEEN 09 AND 11 AND kd_bidang = '01'");
		return $sql;
	}

	function belanja_barang() {
		$sql = $this->query("SELECT kd_bidang,nm_bidang,b.wasgiat,IF(total IS NULL,0,total) AS total FROM tbidang a 
			LEFT JOIN(SELECT  COUNT(*) AS total, kdakun, wasgiat FROM dja_pagu WHERE wasgiat = 'SPAMAD' AND kdakun LIKE '52%') AS b ON a.wasgiat = b.wasgiat
			WHERE a.kd_bidang NOT BETWEEN 09 AND 11 AND kd_bidang = '01'");
		return $sql;
	}

	function belanja_modal() {
		$sql = $this->query("SELECT kd_bidang,nm_bidang,b.wasgiat,IF(total IS NULL,0,total) AS total FROM tbidang a 
			LEFT JOIN(SELECT  COUNT(*) AS total, kdakun, wasgiat FROM dja_pagu WHERE wasgiat = 'SPAMAD' AND kdakun LIKE '53%') AS b ON a.wasgiat = b.wasgiat
			WHERE a.kd_bidang NOT BETWEEN 09 AND 11 AND kd_bidang = '01'");
		return $sql;
	}



	// function hasil_pagu() {
	// 	$sql = $this->query("SELECT nm_bidang AS name,IF(total IS NULL,0,total) AS y FROM tbidang a 
	// 		LEFT JOIN(SELECT COUNT(wasgiat) AS total, wasgiat FROM dja_pagu GROUP BY wasgiat) AS b ON a.wasgiat = b.wasgiat
	// 		WHERE a.kd_bidang NOT BETWEEN 09 AND 11 AND kd_bidang = '05' ");
	// 	return $sql;
	// }

	// function tot_pagu(){
	// 	$sql = $this->query("SELECT nm_bidang AS name,urskmpnen AS y,jml_pagu FROM tbidang a 
	// 		LEFT JOIN(SELECT wasgiat, urskmpnen,jml_pagu FROM dja_pagu) AS b ON a.wasgiat = b.wasgiat
	// 		WHERE a.kd_bidang NOT BETWEEN 09 AND 11 AND kd_bidang = '07'");
	// 	return $sql;
	// }

	// function tot_kontrak(){
	// 	$sql = $this->query("SELECT kd_bidang,nm_bidang,urskmpnen,jml_pagu FROM tbidang a 
	// 		LEFT JOIN(SELECT wasgiat, urskmpnen,jml_pagu FROM dja_pagu GROUP BY wasgiat) AS b ON a.wasgiat = b.wasgiat
	// 		WHERE a.kd_bidang NOT BETWEEN 09 AND 11 AND kd_bidang = '05' ");
	// 	return $sql;
	// }

	// function hasil_survey() {
	// 	$sql = $this->query("SELECT urskmpnen ,COUNT(*) AS progja, wasgiat FROM dja_pagu WHERE wasgiat = 'SOPSAD' GROUP BY wasgiat");
	// 	return $sql;
	// }

}
