<?php



class Analisa_hasil_temuan_model extends Model {



	public function mget($request, $table, $primaryKey, $columns,$field = null,$key = null,$key2 = null)

	{

		 $join = 'LEFT JOIN (SELECT kd_kotama,kd_satminkal,nm_satminkal from tsatminkal group by kd_satminkal) as tsatminkal ON dja_pagu.`kdsatker` = tsatminkal.kd_satminkal
		 		  LEFT JOIN (SELECT tahun,bulan,kotama,satminkal,kategori AS belanja_pegawai FROM vt_verku_temuan WHERE tahun = '.$key.' AND bulan = '.$key2.' AND kategori = 1) b ON dja_pagu.`kdsatker` = b.`kotama` AND dja_pagu.`kdsatker` = b.`satminkal`
		 		  LEFT JOIN (SELECT tahun,bulan,kotama,satminkal,kategori AS belanja_barang FROM vt_verku_temuan WHERE tahun = '.$key.' AND bulan = '.$key2.' AND kategori = 4) c ON dja_pagu.`kdsatker` = c.`kotama` AND dja_pagu.`kdsatker` = c.`satminkal`
		 		  LEFT JOIN (SELECT tahun,bulan,kotama,satminkal,kategori AS belanja_modal FROM vt_verku_temuan WHERE tahun = '.$key.' AND bulan = '.$key2.' AND kategori = 5) d ON dja_pagu.`kdsatker` = d.`kotama` AND dja_pagu.`kdsatker` = d.`satminkal`
		 		  LEFT JOIN (SELECT satker AS satker_hps,COUNT(satker) AS total_hps FROM tbl_hps GROUP BY satker) AS e ON kdsatker = e.satker_hps
				  LEFT JOIN (SELECT satker AS satker_tor,COUNT(satker) AS total_tor FROM tbl_tor GROUP BY satker) AS f ON kdsatker = f.satker_tor
				  LEFT JOIN (SELECT satker AS satker_rab,COUNT(satker) AS total_rab FROM tbl_rab GROUP BY satker) AS g ON kdsatker = g.satker_rab	
		 		  LEFT JOIN (SELECT satker AS satker_sph,COUNT(satker) AS total_sph FROM tbl_sph GROUP BY satker) AS h ON kdsatker = h.satker_sph
		 		  LEFT JOIN (SELECT satker AS satker_kontrak,COUNT(satker) AS total_kontrak FROM tbl_kontrak GROUP BY satker) AS i ON kdsatker = i.satker_kontrak
				  LEFT JOIN (SELECT satker AS satker_bast,COUNT(satker) AS total_bast FROM tbl_bast GROUP BY satker) AS j ON kdsatker = j.satker_bast
				  LEFT JOIN (SELECT satker AS satker_ku17,COUNT(satker) AS total_ku17 FROM tbl_ku17 GROUP BY satker) AS k ON kdsatker = k.satker_ku17
				  LEFT JOIN (SELECT satker AS satker_sp2d,COUNT(satker) AS total_sp2d FROM tbl_sp2d GROUP BY satker) AS l ON kdsatker = l.satker_sp2d
				 ';
		 $group = 'group by kd_satminkal order by nm_satminkal';
		 $where = 'WHERE (total_hps != "" or total_tor != "" or total_rab != "" or total_sph != "" or total_kontrak != "" or total_bast != "" or total_ku17 != "" or total_sp2d != "") ';
		$result = $this->dt2($request, $table, $primaryKey, $columns,$join,$field,$key,$group,$key2,$where);


		return $result;

	}

	public function dt2 ( $request, $table, $primaryKey, $columns,$join = null, $field = null, $key = null,$group = null,$key2 = null,$where2 = null )

	{

		$bindings = array();

		$db = $this->connection;



		$limit = self::limit( $request, $columns );

		$order = self::order( $request, $columns );

		$where = self::filters( $request, $columns, $bindings, true );

		$sWhere = $where2;

		 // $sWhere = "WHERE ". $field." = '".$key."' AND bulan = '".$key2."'";
		// $sWhere = "";
		//$join = "";


		$data = $this->query(

			"SELECT `".implode("`, `", $this->pluck($columns, 'db'))."`

			 FROM `$table`

			 $join

			 $sWhere

			 $where

			 $group

			 $order

			 $limit"

		);



		$resFilterLength = $this->query(

			"
			SELECT COUNT(total) FROM (
			SELECT COUNT(`{$primaryKey}`) as total

			 FROM   `$table`
			 $join

			 $sWhere $where
			 $group) as t
			 "

		);



		$recordsFiltered = $resFilterLength[0][0];



		$resTotalLength = $this->query(

			"
			SELECT COUNT(total) FROM (
			SELECT COUNT(`{$primaryKey}`) as total

			 FROM   `$table` $join $sWhere $where $group ) as t"

		);

		$recordsTotal = $resTotalLength[0][0];



		return array(

			"draw"            => isset ( $request['draw'] ) ?

				intval( $request['draw'] ) :

				0,

			"recordsTotal"    => intval( $recordsTotal ),

			"recordsFiltered" => intval( $recordsFiltered ),

			"data"            => self::data_output( $columns, $data )

		);

	}

public function filters ( $request, $columns, &$bindings )

	{

		$globalSearch = array();

		$columnSearch = array();

		$dtColumns = $this->pluck( $columns, 'dt' );


		if ( isset($request['search']) && $request['search']['value'] != '' ) {

			$str = $request['search']['value'];



			for ( $i=0, $ien=count($request['columns']) ; $i<$ien ; $i++ ) {

				$requestColumn = $request['columns'][$i];

				$columnIdx = array_search( $requestColumn['data'], $dtColumns );

				$column = $columns[ $columnIdx ];



				if ( $requestColumn['searchable'] == 'true' ) {

					if(!empty($column['db'])){

						$binding = "'%".$str."%'";

						$globalSearch[] = "`".$column['db']."` LIKE ".$binding;

					}

				}

			}

		}

		// Individual column filtering

		if ( isset( $request['columns'] ) ) {

			for ( $i=0, $ien=count($request['columns']) ; $i<$ien ; $i++ ) {

				$requestColumn = $request['columns'][$i];

				$columnIdx = array_search( $requestColumn['data'], $dtColumns );

				$column = $columns[ $columnIdx ];



				$str = $requestColumn['search']['value'];



				if ( $requestColumn['searchable'] == 'true' &&

				 $str != '' ) {

					if(!empty($column['db'])){

						$binding = "'%".$str."%'";

						$columnSearch[] = "`".$column['db']."` LIKE ".$binding;

					}

				}

			}

		}

		$where = '';

		if ( count( $globalSearch ) ) {

			$where = '('.implode(' OR ', $globalSearch).')';

		}

		if ( count( $columnSearch ) ) {

			$where = $where === '' ?

				implode(' AND ', $columnSearch) :

				$where .' AND '. implode(' AND ', $columnSearch);

		}

		if ( $where !== '' ) {

			$where = 'AND '.$where;

		}

		return $where;

	}



	public function mget_detail($request, $table, $primaryKey, $columns, $id)

	{

		$result = $this->simple_detail($request, $table, $primaryKey, $columns, $id);

		return $result;

	}



	public function get($table, $primaryKey, $id)

	{

		$result = $this->query("SELECT * FROM $table WHERE $primaryKey = '$id'");

		return $result;

	}



	public function msave($table, $data = array(), $title)

	{

		$result = $this->sqlinsert($table, $data, $title);

		return $result;

	}



	public function mupdate($table, $data = array(), $primaryKey, $id, $title)

	{

		$result = $this->sqlupdate($table, $data, $primaryKey, $id, $title);

		return $result;

	}



	public function mdelete($table, $primaryKey, $id, $title)

    {

        $result = $this->sqldelete($table, $primaryKey, $id, $title);

		return $result;

    }





}