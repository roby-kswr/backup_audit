<?php

class Pencarian_model extends Model {

	public function mget($request, $table, $primaryKey, $columns)
	{
		$join = "";
		$result = $this->simple($request, $table, $primaryKey, $columns, $join);
		return $result;
	}

	public function mget_detail($request, $table, $primaryKey, $columns, $id)
	{
		$result = $this->simple_detail($request, $table, $primaryKey, $columns, $id);
		return $result;
	}

	public function get($table, $primaryKey, $id)
	{
		$result = $this->query("SELECT * FROM $table WHERE $primaryKey = '$id'");
		return $result;
	}

	public function msave($table, $data = array(), $title)
	{
		$result = $this->sqlinsert($table, $data, $title);
		return $result;
	}

	public function mupdate($table, $data = array(), $primaryKey, $id, $title)
	{
		$result = $this->sqlupdate($table, $data, $primaryKey, $id, $title);
		return $result;
	}

	public function mdelete($table, $primaryKey, $id, $title)
    {
        $result = $this->sqldelete($table, $primaryKey, $id, $title);
		return $result;
    }

    public function get_dokumen($q = '', $page, $limit)
	{
		$start = ($page-1) * $limit; 
		$result = array();
		$result['total'] = $this->getvalue("SELECT COUNT(*) as total FROM tbl_dokumen WHERE nama_kegiatan LIKE '%$q%' OR narasi LIKE '%$q%'");
		$result['aadata'] = $this->query("SELECT autono, autocode, nama_kegiatan, lokasi, no_card, narasi, tanggal, fotografer, kamera, total FROM tbl_dokumen  LEFT JOIN (SELECT parent_id,COUNT(views) AS total FROM ref_views GROUP BY parent_id) AS ref_views ON tbl_dokumen.`autono` = ref_views.`parent_id` WHERE nama_kegiatan LIKE '%$q%' OR narasi LIKE '%$q%'  LIMIT $start, $limit");
		return $result;
	}

	public function get_history()
	{
		$result = $this->query("SELECT autono, keywords FROM ref_keywords GROUP BY keywords ORDER BY autono DESC LIMIT 12");
		return $result;
	}

    public function get_kategori()

	{
		$result = $this->query("SELECT autono, nama_kategori FROM ref_kategori ORDER BY nama_kategori ASC");
		return $result;
	}


}