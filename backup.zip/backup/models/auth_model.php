<?php

class Auth_model extends Model {
	
	public function check($username, $password, $security_key)
	{
		$pass = $this->passencrpyt($password,$security_key);
		$result = $this->query("SELECT * FROM tuser WHERE user_id = '". $username ."' AND user_password = '$pass'");
		return $result;
	}

	public function passencrpyt($pass, $key)
	{
		$pass = sha1(md5($pass.$key));

		return $pass;
	}

	public function sign($id)
	{
		echo "Sign in";
	}

	public function mupdate($table, $data = array(), $primaryKey, $id, $title)
	{
		$result = $this->sqlupdate($table, $data, $primaryKey, $id, $title);
		return $result;
	}

}

