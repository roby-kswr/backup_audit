<?php

class Sprin_model extends Model {

	public function mget($request, $table, $primaryKey, $columns, $join = null)
	{
		
		$result = $this->simple($request, $table, $primaryKey, $columns, $join);
		
		return $result;

	}

	public function mgetdetail($request, $table, $primaryKey, $columns, $join, $sWhere)
	{
		
		$result = $this->mySimplex($request, $table, $primaryKey, $columns, $join, $sWhere);
		
		return $result;

	}

	public function get($table, $primaryKey, $id)
	{
		
		$result = $this->query("SELECT *, DATE_FORMAT(tgl_sprin, '%d/%m/%Y') AS tgl_sp, DATE_FORMAT(tgl_mulai, '%d/%m/%Y') AS tgl_start, DATE_FORMAT(tgl_selesai, '%d/%m/%Y') AS tgl_end FROM $table WHERE $primaryKey = '$id'");
		
		return $result;

	}

	public function msave($table, $data = array(), $title)
	{
		
		$result = $this->sqlinsert($table, $data, $title);
		
		return $result;

	}

	public function mupdate($table, $data = array(), $primaryKey, $id, $title)
	{
		
		$result = $this->sqlupdate($table, $data, $primaryKey, $id, $title);
		
		return $result;

	}

	public function mdelete($table, $primaryKey, $id, $title)
    {
        
        $result = $this->sqldelete($table, $primaryKey, $id, $title);
		
		return $result;

    }

    public function mget_bulan($id)

	{
		
		$result = $this->query("SELECT autono, MONTH(START) AS bln, id_jns_audit AS nm_jns_audit FROM tpkpt_detil WHERE id_pkpt = '$id'");
		
		return $result;

	}

	public function mget_kotama($id)

	{
		
		$result = $this->query("SELECT autono, kd_kotama, nm_kotama FROM tpkptsat a LEFT JOIN (SELECT autono AS kd_kotama, nm_kotama FROM tkotama) AS b ON a.id_kotama=b.kd_kotama WHERE id_pkpt = '$id'");
		
		return $result;

	}

	public function mget_personel()

	{

		$result = $this->query("SELECT `nrp`, LOWER(nama) AS `nama` FROM tpers a WHERE NOT EXISTS (SELECT nrp FROM tsprinpers b WHERE a.nrp = b.nrp AND b.id_sprin = '$id')");

		return $result;

	}

	public function get_PKPT()

	{
		
		$result = $this->query("SELECT autono, nomor_pkpt FROM tpkpt ORDER BY autono asc");
		
		return $result;

	}

	public function get_PKPTEdit($table, $field, $id)
	
	{
		
		$result = $this->query("SELECT autono, nomor_pkpt, IF(b.id_pkpt IS NULL, '', 'selected') AS pselect FROM tpkpt a LEFT JOIN (SELECT id_pkpt FROM $table WHERE `$field` = '$id') b ON a.autono = b.id_pkpt ORDER BY autono ASC");
		
		return $result;
	
	}

	public function get_sprinEdit($table, $field, $id)
	{
		
		$result = $this->query("SELECT a.autono, nomor_pkpt,  id_pkpt_detil, bulan, id_jns_audit, IF(b.id_pkpt IS NULL, '', 'selected') AS pselect FROM tpkpt a 
								LEFT JOIN (SELECT id_pkpt, id_pkpt_detil FROM $table WHERE `$field` = '$id') b ON a.autono = b.id_pkpt 
								LEFT JOIN (SELECT autono, id_pkpt, MONTH(`start`) AS bulan, id_jns_audit FROM tpkpt_detil) AS c ON b.id_pkpt = c.id_pkpt AND b.id_pkpt_detil = c.autono
								ORDER BY a.autono ASC");

		return $result;

	}

	public function load_sprin($id)
	{
		
		$result = $this->getvalue("SELECT autono, id_jns_audit, no_sprin, menimbang, dasar, kepada, untuk, MONTH(tgl_sprin) AS bulan, YEAR(tgl_sprin) AS tahun FROM tpkpt_detil a LEFT JOIN (SELECT id_pkpt, id_pkpt_detil, no_sprin, menimbang, dasar, kepada, untuk, tgl_sprin FROM tsprin WHERE autono = '$id') b ON a.autono = b.id_pkpt_detil WHERE IF(b.id_pkpt IS NULL, '', 'selected') = 'selected' ORDER BY autono ASC");
		return $result;

	}

	public function load_kotama($id)
	{
		
		$result = $this->query("SELECT DISTINCT nm_kotama FROM tkotama a LEFT JOIN (SELECT id_kotama FROM tsprinpers WHERE id_sprin = '$id') b ON a.autono = b.id_kotama WHERE IF(b.id_kotama IS NULL, '', 'selected') != ''");
		
		return $result;

	}

	public function load_personel($id, $sWhere)
	{
		
		$result = $this->query("SELECT `nama`, `nm_pangkat`, `nm_korps`, `nrp`, `jabatan`, `nm_jabatan_wasrik`, GROUP_CONCAT(nm_kotama) AS `nm_kotama`, 						 DAY(tgl_mulai) AS d_start, MONTH(tgl_mulai) AS m_start, YEAR(tgl_mulai) AS y_start, DAY(tgl_selesai) AS d_end, MONTH(						 tgl_selesai) AS m_end, YEAR(tgl_selesai) AS y_end 
								FROM tsprinpers a 
			 						LEFT JOIN (SELECT autono AS kd_pers, nrp as id_personel, nama, id_korps, id_pangkat, jabatan FROM tpers) b ON a.nrp = b.id_personel
		 	   						LEFT JOIN (SELECT autono as kd_pangkat, nm_pangkat FROM tpangkat) c ON b.id_pangkat = c.kd_pangkat
		 	   						LEFT JOIN (SELECT autono as kd_korps, nm_korps FROM tkorps) d ON b.id_korps = d.kd_korps
		 	  						LEFT JOIN (SELECT autono as kd_jabwas, nm_jabatan_wasrik, status FROM tjabatanwasrik) e ON a.id_jabatanwasrik = e.kd_jabwas
		 	   						LEFT JOIN (SELECT autono as kd_kotama, nm_kotama FROM tkotama) f ON FIND_IN_SET (f.kd_kotama, a.id_kotama)
		 	   						LEFT JOIN (SELECT autono as kd_sprin, tgl_mulai, tgl_selesai FROM tsprin) g ON a.id_sprin = g.kd_sprin
			 	   				WHERE `id_sprin` = '$id' $sWhere GROUP BY autono");
		
		return $result;

	}

	public function load_tembusan($id)
	{
		
		$result = $this->query("SELECT `nm_tembusan` FROM tsprintemb a LEFT JOIN (SELECT autono AS kd_tembusan, nm_tembusan FROM ttembusan) AS b ON a.id_tembusan = b.kd_tembusan WHERE id_sprin = '$id'");
		
		return $result;

	}

	public function mySimplex ( $request, $table, $primaryKey, $columns, $join, $sWhere )

	{

		$bindings = array();

		$db = $this->connection;

		$limit = self::limit( $request, $columns );

		$order = self::order( $request, $columns );

		$where = self::filter( $request, $columns, $bindings, true );

		// $sWhere = "WHERE $sWhere";

		$data = $this->query(

			"SELECT `autono`, `nama`, `nm_pangkat`, `nm_korps`, `nrp`, `jabatan`, `nm_jabatan_wasrik`, GROUP_CONCAT(nm_kotama) AS nm_kotama

			 FROM `$table` a

			 $join

			 WHERE $sWhere

			 $where

			 GROUP BY autono

			 ORDER BY id_jabatanwasrik ASC

			 $limit"

		);

		$resFilterLength = $this->query(

			"SELECT COUNT(`{$primaryKey}`)

			 FROM `$table`

			 WHERE $sWhere $where"

		);

		$recordsFiltered = $resFilterLength[0][0];

		$resTotalLength = $this->query(

			"SELECT COUNT(`{$primaryKey}`)

			 FROM   `$table` WHERE $sWhere"

		);

		$recordsTotal = $resTotalLength[0][0];

		return array(

			"draw"            => isset ( $request['draw'] ) ?

				intval( $request['draw'] ) :

				0,

			"recordsTotal"    => intval( $recordsTotal ),

			"recordsFiltered" => intval( $recordsFiltered ),

			"data"            => self::data_output( $columns, $data )

		);

	}

}
