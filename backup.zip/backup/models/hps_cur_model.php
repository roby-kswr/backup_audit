<?php

class Hps_cur_model extends Model {

	public function mget($request, $table, $primaryKey, $columns)
	{
		$join = "a
				 LEFT JOIN (SELECT autono AS autosat ,autocode AS id , satminkal AS kode_satminkal, SUM(totalhps) AS sum_score FROM vt_upload_hps_cur GROUP BY autocode ) AS b ON a.autocode = b.id
				 LEFT JOIN (SELECT autono AS autosat ,kd_satminkal AS id , nm_satminkal FROM tsatminkal) AS c ON a.satminkal = c.autosat
				 ";

				 // $join = "a
				 // LEFT JOIN (SELECT autono AS autotor ,autocode AS id , tor AS kode_tor, SUM(total) AS sum_score FROM vt_upload_rab_post GROUP BY autocode ) AS b ON a.autocode = b.id";
		$result = $this->simpleHps($request, $table, $primaryKey, $columns, $join);
		return $result;
	}

	public function get($table, $primaryKey, $id)
	{
		$result = $this->query("SELECT * FROM $table WHERE $primaryKey = '$id'");
		return $result;
	}

	public function mget_detail($request, $table, $primaryKey, $columns,$join = null, $id)
	{
		$result = $this->simple_detailHps2($request, $table, $primaryKey, $primaryKey2, $columns, $id);
		return $result;
	}


	public function msave($table, $data = array(), $title)
	{
		$result = $this->sqlinsert($table, $data, $title);
		return $result;
	}

	public function mupdate($table, $data = array(), $primaryKey, $id, $title)
	{
		$result = $this->sqlupdate($table, $data, $primaryKey, $id, $title);
		return $result;
	}

	public function mdelete($table, $primaryKey, $id, $title)
    {
        $result = $this->sqldelete($table, $primaryKey, $id, $title);
		return $result;
    }

    public function hps_cur()

	{
		
		$result = $this->query("SELECT a.autono, no_hps , a.satminkal , b.nm_satminkal FROM hps_cur a LEFT JOIN tsatminkal b ON a.satminkal = b.kd_satminkal GROUP BY a.autono");
		
		return $result;

	}

     function uploadHpscur($filename, $satminkal,$tahun,$autocode)
    {
        $dir         = './static/files/CUR_HPS/'.$satminkal.'/'.$tahun.'/';
        $file_name   = $filename;
        $storagename = $dir."/".$autocode.".xlsx";
        $storagefile = $dir;
                
        if(!empty($file_name["name"])){
            if(!file_exists($storagename)){
                mkdir($storagefile, 0777, true);
                $result = move_uploaded_file($file_name["tmp_name"],  $storagename);
            }
            $file_name = $file_name["name"];
            return $file_name;
        } 
        return $file_name["name"]; 
        
    }

    public function import_hps_cur($satminkal, $tahun,$autono, $autocode, $last_id)
    {
    	error_reporting(1);
    	// IF(file_exists(ROOT_DIR.'static/PHPExcel/PHPExcel.php'))
    	// {echo 'ada';}
    	// else
    	// 	{echo 'tidak ada';}
    	// exit;
    		include ROOT_DIR.'static/PHPExcel/PHPExcel.php';
    
    $excelreader		= new PHPExcel_Reader_Excel2007();
	$loadexcel 			= $excelreader->load(ROOT_DIR.'static/files/CUR_HPS/'.$satminkal.'/'.$tahun.'/'.$autocode.".xlsx"); 
	$sheet 				= $loadexcel->getActiveSheet()->toArray(null, true, true ,true);

	$numrow = 1;
	// var_dump($sheet);
	foreach($sheet as $row){

		$no_urut 			= $row['A']; 
		$keterangan 		= $row['B']; 
		$vol 		        = $row['C']; 
		$satuan 		    = $row['D']; 
		$harga 		        = $row['E'];
		$total 		        = $row['F'];
		$keuntungan 		= $row['G'];
		$jumlah 		    = $row['H'];
		$ppn 		        = $row['I'];
		$totalhps 		    = $row['J']; 
 

 


		if($no_urut == "" && $keterangan == "" && $vol == "" && $satuan == "" && $harga == "" && $total == "" && $keuntungan == "" && $jumlah == "" && $ppn == "" && $totalhps == "")
			continue;
		
					if($numrow > 2){

						// merubah ke huruf kapital
						// $namaconvert = 	$act->ucw(str_replace("'","\'", $nama));  
 
						// insert ke database
						$this->execute("INSERT INTO vt_upload_hps_cur
							(parent_id,
							autocode,
							satminkal, 
							tahun,
							no_urut, 
							keterangan,
							vol,
							satuan,
							harga,							
							total,
							keuntungan,
							jumlah,
							ppn,
							totalhps
							
							) 
							VALUES 
							('$last_id',
							'$autocode',
							'$satminkal',
							'$tahun',
							'$no_urut',
							'$keterangan',
							'$vol',
							'$satuan',
							'$harga',							
							'$total',
							'$keuntungan',
							'$jumlah',
							'$ppn',
							'$totalhps'
							
						) ");
						

 
						// update untuk mendapatkan kode pass
						// s$act->execute("UPDATE t_peserta SET pass = '$kode' WHERE id_kegiatan = '$id_kegiatan' AND id = $lastid ");

						// Hapus data duplikat
						// $act->execute("DELETE n1 FROM t_peserta n1, t_peserta n2 WHERE n1.id < n2.id AND n1.nomor = n2.nomor AND n1.id_kegiatan = n2.id_kegiatan"); 

						// $act->execute("UPDATE t_kegiatan SET status_import = 1 WHERE id = '$id_kegiatan' ");

						 
					}
			 
		$numrow++; 
	}

		unlink(ROOT_DIR.'static/files/CUR_HPS/'.$satminkal.'/'.$tahun.'/'.$autocode.".xlsx");
        
        return $numrow;
    }


}
