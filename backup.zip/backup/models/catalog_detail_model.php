<?php

class Catalog_detail_model extends Model {

	public function mget($request, $table, $primaryKey, $columns)
	{
		$join = "";
		$result = $this->simple($request, $table, $primaryKey, $columns, $join);
		return $result;
	}

	public function mget_detail($request, $table, $primaryKey,$primaryKey2, $columns, $id)
	{	
		$join = "";
		$result = $this->simple_detailCatalog1($request, $table, $primaryKey,$primaryKey2, $columns, $id,$join);
		return $result;
	}

	public function get($table, $primaryKey, $id)
	{
		$result = $this->query("SELECT * FROM $table WHERE $primaryKey = '$id'");
		return $result;
	}

	public function msave($table, $data = array(), $title)
	{
		$result = $this->sqlinsert($table, $data, $title);
		return $result;
	}

	public function mupdate($table, $data = array(), $primaryKey, $id, $title)
	{
		$result = $this->sqlupdate($table, $data, $primaryKey, $id, $title);
		return $result;
	}

	public function mdelete($table, $primaryKey, $id, $title)
    {
        $result = $this->sqldelete($table, $primaryKey, $id, $title);
		return $result;
    }

    public function simple_detailCatalog1 ( $request, $table, $primaryKey2,$primaryKey3, $columns )

	{

		$bindings = array();

		$db = $this->connection;



		$limit = self::limit( $request, $columns );

		$order = self::order( $request, $columns );

		$where = self::filter( $request, $columns, $bindings, true );

		$sWhere = "WHERE tahun = '$primaryKey2' AND autocode = '$primaryKey3'";

		$order1 = "ORDER BY no_urut";

		$data = $this->query(

			"SELECT `".implode("`, `", $this->pluck($columns, 'db'))."`

			 FROM `$table`

			 $where

			 $sWhere

			 $order1

			 $limit"

		);



		$resFilterLength = $this->query(

			"SELECT COUNT(*)

			 FROM   `$table`

			 $sWhere $where"

		);



		$recordsFiltered = $resFilterLength[0][0];



		$resTotalLength = $this->query(

			"SELECT COUNT(*)

			 FROM   `$table` $sWhere"

		);

		$recordsTotal = $resTotalLength[0][0];



		return array(

			"draw"            => isset ( $request['draw'] ) ?

				intval( $request['draw'] ) :

				0,

			"recordsTotal"    => intval( $recordsTotal ),

			"recordsFiltered" => intval( $recordsFiltered ),

			"data"            => self::data_output( $columns, $data )

		);

	}


}