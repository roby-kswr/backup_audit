<?php

class Takhir_model extends Model {

	public function mget($request, $table, $primaryKey, $columns, $join = null)
	{
		$result = $this->simpleTakwal($request, $table, $primaryKey, $columns, $join);
		return $result;
	}

	public function mgetdetail($request, $table, $primaryKey, $columns, $join, $sWhere)
	{
		$result = $this->mySimple($request, $table, $primaryKey, $columns, $join, $sWhere);
		return $result;
	}

	public function get_file_attachment($id)
	{
		$result = $this->query("SELECT * FROM vt_files WHERE parent_id = $id AND dir = 'Takhir' ");

		return $result;
	}

	public function get($table, $primaryKey, $id)
	{
		$result = $this->query("SELECT *  FROM $table WHERE $primaryKey = '$id'");
		return $result;
	}

	public function getfiles($request, $table, $primaryKey, $columns, $id, $y)
	{
		$result = $this->get_files($request, $table, $primaryKey, $columns, $id, $y);
		return $result;
	}

	public function msave($table, $data = array(), $title)
	{
		$result = $this->sqlinsert($table, $data, $title);
		return $result;
	}

	public function savefile($data = array())
	{
		$result = $this->sqlinsert('vt_files', $data, 'Dokumen');
		return $result;
	}

	public function mupdate($table, $data = array(), $primaryKey, $id, $title)
	{
		$result = $this->sqlupdate($table, $data, $primaryKey, $id, $title);
		return $result;
	}

	public function mdelete($table, $primaryKey, $id, $title)
	{
		$result = $this->sqldelete($table, $primaryKey, $id, $title);
		return $result;
	}

	public function deletes_file($id)
	{
		$result = $this->sqldeletefiles('vt_files', $id, 'Takhir');
		return $result;
	}

	public function sqldeletefiles($table, $id, $label)

	{
		$data = $this->getvalue("SELECT kode_parent FROM vt_files WHERE autono = $id");
		$i    = $this->count("SELECT COUNT(*) as jml FROM vt_files WHERE kode_parent = '$data[0]'");
		$result = $this->sqldelete("vt_files", "autono", $id, $label);
		return $result;
	}

	public function simpleTakwal( $request, $table, $primaryKey, $columns, $join = null )

	{

		$bindings = array();

		$db = $this->connection;

		$limit = self::limit( $request, $columns );

		$order = self::order( $request, $columns );

		$where = self::filter( $request, $columns, $bindings );

		$data = $this->query(

			"SELECT `".implode("`, `", $this->pluck($columns, 'db'))."`

			FROM `$table`

			$join

			$where

			GROUP BY autono

			$order

			$limit"

		);

		$resFilterLength = $this->query(

			"SELECT COUNT(`{$primaryKey}`)

			FROM   `$table`

			$where"

		);



		$recordsFiltered = $resFilterLength[0][0];



		$resTotalLength = $this->query(

			"SELECT COUNT(`{$primaryKey}`)

			FROM   `$table`"

		);

		$recordsTotal = $resTotalLength[0][0];



		return array(

			"draw"            => isset ( $request['draw'] ) ?

			intval( $request['draw'] ) :

			0,

			"recordsTotal"    => intval( $recordsTotal ),

			"recordsFiltered" => intval( $recordsFiltered ),

			"data"            => self::data_output( $columns, $data )

		);

	}
	public function get_files ( $request, $table, $primaryKey, $columns, $id, $key )

	{

		$bindings = array();

		$db = $this->connection;

		$limit = self::limit( $request, $columns );

		$order = self::order( $request, $columns );

		$where = self::filter( $request, $columns, $bindings );

		$sWhere = "WHERE `$primaryKey` = $id AND dir = 'Takhir'";

		$data = $this->query(

			"SELECT `".implode("`, `", $this->pluck($columns, 'db'))."`

			FROM `$table`

			$where

			$sWhere

			$order

			$limit"

		);

		$resFilterLength = $this->query(

			"SELECT COUNT(`{$primaryKey}`)

			FROM   `$table`
			$where

			$sWhere"

		);

		$recordsFiltered = $resFilterLength[0][0];

		$resTotalLength = $this->query(

			"SELECT COUNT(`{$primaryKey}`)

			FROM   `$table`

			$where

			$sWhere"

		);

		$recordsTotal = $resTotalLength[0][0];

		return array(

			"draw"            => isset ( $request['draw'] ) ? intval( $request['draw'] ) : 0,

			"recordsTotal"    => intval( $recordsTotal ),

			"recordsFiltered" => intval( $recordsFiltered ),

			"data"            => self::data_output( $columns, $data )

		);

	}

}
