<?php



class Dasar_tup_verku_model extends Model {



	public function mget($request, $table, $primaryKey, $columns)

	{

		$result = $this->simple($request, $table, $primaryKey, $columns);

		return $result;

	}



	public function mget_detail($request, $table, $primaryKey, $columns,$x = NULL,$y = NULL,$z = NULL,$za = NULL)

	{	
		$join   = "a LEFT JOIN (SELECT autono AS auto_det,keterangan AS ket2 FROM vt_verku_tup_dasar) AS c ON a.`parent_id` = c.auto_det
";
		$result = $this->simple_detail55($request, $table, $primaryKey, $columns,$x,$y,$z,$za,$join);

		return $result;

	}

	public function get($table, $primaryKey, $id)

	{

		$result = $this->query("SELECT * FROM $table WHERE $primaryKey = '$id'");

		return $result;

	}

	// public function get($table, $primaryKey, $id, $primaryKey2, $id2, $primaryKey3, $id3, $primaryKey4, $id4)

	// {

	// 	$result = $this->query("SELECT * FROM $table WHERE $primaryKey = '$id' AND $primaryKey2 = '$id2' AND $primaryKey3 = '$id3' AND $primaryKey4 = '$id4'");

	// 	return $result;

	// }


	public function msave($table, $data = array(), $title)

	{

		$result = $this->sqlinsert($table, $data, $title);

		return $result;

	}


	public function mupdate($table,$data,$primaryKey,$id,$menu)
	{
		$result = $this->sqlupdate($table,$data, $primaryKey,$id,$menu);

		return $result;
	}

	// public function mupdate($table, $data = array(), $primaryKey5, $id5,$primaryKey6, $id6,$primaryKey2, $id2,$primaryKey3, $id3,$primaryKey4, $id4, $title)

	// {	

	// 	// $result = $this->getvalue("SELECT * FROM $table WHERE $primaryKey1 = '$id1' AND $primaryKey2 = '$id1'");

	// 	// if ($result['satker'] == 0)
	// 	// {'tes';}
	// 	// else
	// 	// {'tes2';}

	// 	$result = $this->sqlupdate($table, $data, $primaryKey5, $id5,$primaryKey6, $id6, $primaryKey2, $id2, $primaryKey3, $id3, $primaryKey4, $id4, $title);

	// 	return $result;

	// }



	public function mdelete($table, $primaryKey, $id, $title)

    {

        $result = $this->sqldelete($table, $primaryKey, $id, $title);

		return $result;

    }





}