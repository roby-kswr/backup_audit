<?php



class Analisa_tj_vermat2_model extends Model {



	public function mget($request, $table, $primaryKey, $columns,$field = null,$key = null,$key2 = null)

	{

		 $join = 'a 
		 		  LEFT JOIN (SELECT tahun,bulan,kotama,satminkal,kategori AS belanja_pegawai FROM vt_vermat_renlak_detail WHERE tahun = '.$key.' AND bulan = '.$key2.' AND kategori = 1) b ON a.`kd_kotama` = b.`kotama` AND a.`kd_satminkal` = b.`satminkal`';
		 $group = 'order by nm_satminkal';
		$result = $this->dt($request, $table, $primaryKey, $columns,$join,$field,$key,$group,$key2);


		return $result;

	}



	public function mget_detail($request, $table, $primaryKey, $columns, $join)

	{

		$result = $this->simple_detail6($request, $table, $primaryKey, $columns, $join );

		return $result;

	}

	public function mget_detail_($request, $table, $primaryKey, $columns, $join)

	{

		$result = $this->simple_detail6($request, $table, $primaryKey, $columns, $join);

		return $result;

	}



	public function get($table, $primaryKey, $id)

	{

		$result = $this->query("SELECT * FROM $table WHERE $primaryKey = '$id'");

		return $result;

	}

		public function mupdate($table, $data = array(), $primary, $id,  $primary1, $id1, $primary2, $id2, $primary3, $id3, $primary4, $id4 ,  $menu)

	{	

		// $result = $this->getvalue("SELECT * FROM $table WHERE $primaryKey1 = '$id1' AND $primaryKey2 = '$id1'");

		// if ($result['satker'] == 0)
		// {'tes';}
		// else
		// {'tes2';}

		$result = $this->sqlupdate_jnhv_tjnhv($table, $data, $primary, $id, $primary1, $id1, $primary2, $id2, $primary3, $id3, $primary4, $id4,  $menu);

		return $result;

	}




	public function msave($table, $data = array(), $title)

	{

		$result = $this->sqlinsert($table, $data, $title);

		return $result;

	}

public function get_file_attachment($id)
	{
		$result = $this->query("SELECT * FROM vt_files WHERE parent_id = '$id' AND dir = 'JNHVVERMAT' ");

		return $result;
	}

	// public function mupdate($table, $data = array(), $primaryKey, $id, $title)

	// {

	// 	$result = $this->sqlupdate($table, $data, $primaryKey, $id, $title);

	// 	return $result;

	// }



	public function mdelete($table, $primaryKey, $id, $title)

    {

        $result = $this->sqldelete($table, $primaryKey, $id, $title);

		return $result;

    }





}