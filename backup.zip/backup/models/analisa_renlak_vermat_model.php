<?php



class Analisa_renlak_vermat_model extends Model {



	public function mget($request, $table, $primaryKey, $columns,$field = null,$key = null,$key2 = null)

	{

		 $join = 'a 
		 		  LEFT JOIN (SELECT tahun,bulan,parent_id,kategori AS belanja_pegawai FROM vt_vermat_renlak_detail WHERE tahun = '.$key.' AND bulan = '.$key2.' AND kategori = 1) b ON a.`autono` = b.`parent_id`
		 		  LEFT JOIN (SELECT tahun,bulan,parent_id,kategori AS belanja_barang FROM vt_vermat_renlak_detail WHERE tahun = '.$key.' AND bulan = '.$key2.' AND kategori = 2) c ON a.`autono` = c.`parent_id`
		 		  LEFT JOIN (SELECT tahun,bulan,parent_id,kategori AS belanja_modal FROM vt_vermat_renlak_detail WHERE tahun = '.$key.' AND bulan = '.$key2.' AND kategori = 3) d ON a.`autono` = d.`parent_id`';
		 $group = 'GROUP BY a.autono';
		$result = $this->dt($request, $table, $primaryKey, $columns,$join,$field,$key,$group,$key2);


		return $result;

	}



	public function mget_detail($request, $table, $primaryKey, $columns, $id)

	{

		$result = $this->simple_detail($request, $table, $primaryKey, $columns, $id);

		return $result;

	}



	public function get($table, $primaryKey, $id)

	{

		$result = $this->query("SELECT * FROM $table WHERE $primaryKey = '$id'");

		return $result;

	}



	public function msave($table, $data = array(), $title)

	{

		$result = $this->sqlinsert($table, $data, $title);

		return $result;

	}



	public function mupdate($table, $data = array(), $primaryKey, $id, $title)

	{

		$result = $this->sqlupdate($table, $data, $primaryKey, $id, $title);

		return $result;

	}



	public function mdelete($table, $primaryKey, $id, $title)

    {

        $result = $this->sqldelete($table, $primaryKey, $id, $title);

		return $result;

    }





}