<?php

class Laporan_hasil_temuan_wasrik_intel_model extends Model {

	public function mget($request, $table, $primaryKey, $audit,$columns )
	{

		$join = "AS a 
		LEFT JOIN (SELECT id_kotama, id_sprin FROM tsprinpers) b ON a.autono = b.id_kotama 
		LEFT JOIN (SELECT autono, DATE_FORMAT(tgl_mulai,'%d-%m-%Y') AS tgl_mulai, DATE_FORMAT(tgl_selesai,'%d-%m-%Y') AS tgl_selesai, id_pkpt_detil FROM tsprin) AS c ON b.id_sprin = c.autono
		LEFT JOIN (SELECT autono, id_sprin FROM tpka) AS d ON d.id_sprin = c.autono
		LEFT JOIN (SELECT id_pka, nm_audit, jml_fakta FROM tkka) AS e ON e.id_pka = d. autono
		LEFT JOIN (SELECT autono,id_jns_audit FROM tpkpt_detil) AS f ON c.id_pkpt_detil = f.autono
		
		";

		$result = $this->getDat($request, $table, $primaryKey, $columns,$audit, $join);
		return $result;
	}

	public function mget_detail($request, $table, $primaryKey, $columns, $id)
	{
		$result = $this->simple_detail($request, $table, $primaryKey, $columns, $id);
		return $result;
	}

	public function get($table, $primaryKey, $id)
	{
		$result = $this->query("SELECT * FROM $table WHERE $primaryKey = '$id'");
		return $result;
	}

	public function msave($table, $data = array(), $title)
	{
		$result = $this->sqlinsert($table, $data, $title);
		return $result;
	}

	public function mupdate($table, $data = array(), $primaryKey, $id, $title)
	{
		$result = $this->sqlupdate($table, $data, $primaryKey, $id, $title);
		return $result;
	}

	public function mdelete($table, $primaryKey, $id, $title)
	{
		$result = $this->sqldelete($table, $primaryKey, $id, $title);
		return $result;
	}


	public function getDat ( $request, $table, $primaryKey, $columns,$audit, $join  )

	{

		$bindings = array();

		$db = $this->connection;

		$limit = self::limit( $request, $columns );

		$order = self::order( $request, $columns );

		$where = self::filter( $request, $columns, $bindings );

		$wheres = "WHERE id_jns_audit = '$audit' AND IF(b.id_kotama IS NULL, '', 'selected') != ''";

		$group  = "GROUP BY nm_audit";

		$data = $this->query(

			"SELECT DISTINCT  nm_kotama, tgl_mulai, tgl_selesai, jml_fakta

			FROM `$table`

			$join

			$wheres

			$where

			$group 

			$order

			$limit"

		);

		$resFilterLength = $this->query(

			"SELECT COUNT(`{$primaryKey}`)

			FROM   tkka 

			$where"

		);



		$recordsFiltered = $resFilterLength[0][0];



		$resTotalLength = $this->query(

			"SELECT COUNT(`{$primaryKey}`)

			FROM   tkka $where "

		);

		$recordsTotal = $resTotalLength[0][0];



		return array(

			"draw"            => isset ( $request['draw'] ) ?

			intval( $request['draw'] ) :

			0,

			"recordsTotal"    => intval( $recordsTotal ),

			"recordsFiltered" => intval( $recordsFiltered ),

			"data"            => self::data_output( $columns, $data )

		);

	}



}