<?php

class Sprin_anev_model extends Model {

	public function mget($request, $table, $primaryKey, $columns, $join = null)
	{
		$result = $this->simple($request, $table, $primaryKey, $columns, $join);
		return $result;
	}

	public function mgetdetail($request, $table, $primaryKey, $columns, $join, $sWhere)
	{
		$result = $this->mySimplex($request, $table, $primaryKey, $columns, $join, $sWhere);
		return $result;
	}

	public function get($table, $primaryKey, $id)
	{
		$result = $this->query("SELECT *, DATE_FORMAT(tgl_sprin, '%d/%m/%Y') AS tgl_sp FROM $table WHERE $primaryKey = '$id'");
		return $result;
	}


    public function mget_bulan($id)

	{
		$result = $this->query("SELECT autono, MONTH(START) AS bln, id_jns_audit AS nm_jns_audit FROM tpkpt_detil WHERE id_pkpt = '$id'");
		return $result;
	}

	public function mget_kotama($id)

	{
		$result = $this->query("SELECT autono, kd_kotama, nm_kotama FROM tpkptsat a LEFT JOIN (SELECT autono AS kd_kotama, nm_kotama FROM tkotama) AS b ON a.id_kotama=b.kd_kotama WHERE id_pkpt = '$id'");
		return $result;
	}

	public function mySimplex ( $request, $table, $primaryKey, $columns, $join, $sWhere )

	{

		$bindings = array();

		$db = $this->connection;

		$limit = self::limit( $request, $columns );

		$order = self::order( $request, $columns );

		$where = self::filter( $request, $columns, $bindings, true );

		// $sWhere = "WHERE $sWhere";

		$data = $this->query(

			"SELECT `autono`, `nama`, `nm_pangkat`, `nm_korps`, `nrp`, `jabatan`, `nm_jabatan_wasrik`, GROUP_CONCAT(nm_kotama) AS nm_kotama

			 FROM `$table` a

			 $join

			 WHERE $sWhere

			 $where

			 GROUP BY autono

			 $order

			 $limit"

		);

		$resFilterLength = $this->query(

			"SELECT COUNT(`{$primaryKey}`)

			 FROM `$table`

			 WHERE $sWhere $where"

		);

		$recordsFiltered = $resFilterLength[0][0];

		$resTotalLength = $this->query(

			"SELECT COUNT(`{$primaryKey}`)

			 FROM   `$table` WHERE $sWhere"

		);

		$recordsTotal = $resTotalLength[0][0];

		return array(

			"draw"            => isset ( $request['draw'] ) ?

				intval( $request['draw'] ) :

				0,

			"recordsTotal"    => intval( $recordsTotal ),

			"recordsFiltered" => intval( $recordsFiltered ),

			"data"            => self::data_output( $columns, $data )

		);

	}

}
