<?php

class Sub_satker_model extends Model {

	public function mget($request, $table, $primaryKey, $columns, $join = null)
	{
		$result = $this->simple($request, $table, $primaryKey, $columns, $join);
		return $result;
	}

	public function get($table, $primaryKey, $id)
	{
		$result = $this->query("SELECT * FROM $table WHERE $primaryKey = '$id'");
		return $result;
	}

	public function msave($table, $data = array(), $title)
	{
		$result = $this->sqlinsert($table, $data, $title);
		return $result;
	}

	public function mupdate($table, $data = array(), $primaryKey, $id, $title)
	{
		$result = $this->sqlupdate($table, $data, $primaryKey, $id, $title);
		return $result;
	}

	public function mdelete($table, $primaryKey, $id, $title)
    {
        $result = $this->sqldelete($table, $primaryKey, $id, $title);
		return $result;
    }
	
	public function get_kotama($param)
    {
        return $this->query("SELECT autocode, nm_kotama, id_uo FROM tkotama WHERE id_uo = '".$param."' ORDER BY autono ASC");
    }
	
	public function get_satker($param, $param2)
    {
        return $this->query("SELECT autocode, nm_satker, id_uo, id_kotama FROM tsatker WHERE id_uo = '".$param."' AND id_kotama = '".$param2."' ORDER BY autono ASC");
    }

}
