<?php
/**
 * 
 */
class Laporan_pertanggung_jawaban_current_ops_model extends Model
{

	public function satker()
	{
		$return =  $this->query("SELECT kd_satminkal,nm_satminkal FROM tsatminkal");

		return $return;
	}

	public function getTahun()
	{
		$return =  $this->query("SELECT thang FROM dja_pagu GROUP BY thang");

		return $return;
	}

	public function loadProgja ( $request, $table, $primaryKey,$thang, $columns)

	{

		$bindings = array();

		$db = $this->connection;

		//$val     = $this->getvalue("SELECT * FROM $table WHERE id=$id");

		$limit = self::limit( $request, $columns );

		$order = self::order( $request, $columns );

		$where = self::filter( $request, $columns, $bindings, true );

		$join  = "LEFT JOIN tsatminkal ON $table.`kdsatker` = tsatminkal.kd_satminkal LEFT JOIN tbidang  ON $table.wasgiat = tbidang.wasgiat ";

		$group = "GROUP BY kdsatker"; 

		$sWhere = "WHERE THANG = $thang AND kd_bidang = 02 ";

		$data = $this->query(

			"SELECT ".implode(", ", $this->pluck($columns, 'db'))."

			 FROM  `$table`

			 $join

			 $sWhere 

			 $where

			 $group

			 $order

			 $limit"

		);

		$resFilterLength = $this->query(

			"SELECT COUNT(`{$primaryKey}`) FROM (SELECT `{$primaryKey}` FROM  `$table` $join $sWhere $where  $group) AS t1" 

		);

		$recordsFiltered = $resFilterLength[0][0];

		$resTotalLength = $this->query("SELECT COUNT(`{$primaryKey}`) FROM (SELECT `{$primaryKey}` FROM `$table` $join $sWhere $group) AS t1");

		$recordsTotal = $resTotalLength[0][0];

		return array(

			"draw"            => isset ( $request['draw'] ) ?

				intval( $request['draw'] ) :

				0,

			"recordsTotal"    => intval( $recordsTotal ),

			"recordsFiltered" => intval( $recordsFiltered ),

			"data"            => self::data_output( $columns, $data )

		);

	}

public function mgetsat ( $request, $table, $primaryKey, $columns,$satker, $join = null )
	{

		$bindings = array();

		$db = $this->connection;



		$limit = self::limit( $request, $columns );

		$order = self::order( $request, $columns );

		$where = self::filter( $request, $columns, $bindings );

		$sWhere = "WHERE t2.kode = '$satker' AND t3.kode_bid = 02";

		$group  = "GROUP BY urskmpnen";

		$data = $this->query(

			"SELECT ".implode(",", $this->pluck($columns, 'db'))."

			FROM `$table`

			$join

			$sWhere

			$where

			$group

			$order

			$limit"

		);



		$resFilterLength = $this->query(

			"SELECT COUNT(t2) FROM(
			SELECT COUNT(`{$primaryKey}`) AS t2

			FROM   `$table`
			$join

			$sWhere 

			$where $group) AS t3


			"

		);



		$recordsFiltered = $resFilterLength[0][0];



		$resTotalLength = $this->query(

			"SELECT COUNT(t2) FROM(
			SELECT COUNT(`{$primaryKey}`) AS t2

			FROM   `$table`
			$join

			$sWhere 

			$where $group) AS t3  "

		);


		$recordsTotal = $resTotalLength[0][0];



		return array(

			"draw"            => isset ( $request['draw'] ) ?

			intval( $request['draw'] ) :

			0,

			"recordsTotal"    => intval( $recordsTotal ),

			"recordsFiltered" => intval( $recordsFiltered ),

			"data"            => self::data_output( $columns, $data )

		);

	}

	
	// public function mget ( $request, $table, $primaryKey, $columns,$id, $join )

	// {

	// 	$bindings = array();

	// 	$db = $this->connection;



	// 	$limit = self::limit( $request, $columns );

	// 	$order = self::order( $request, $columns );

	// 	$where = self::filter( $request, $columns, $bindings, true );

	// 	 $sWhere = "WHERE  AND b.thang = '2020'  ";

	// 	 $group = "GROUP BY b.kd_satker";



	// 	$data = $this->query(

	// 		"SELECT ".implode(",", $this->pluck($columns, 'db'))."

	// 		 FROM $table

	// 		 $join

	// 		 $sWhere

	// 		 $where

	// 		 $group

	// 		 $order

	// 		 $limit"

	// 	);



	// 	$resFilterLength = $this->query(

	// 		"SELECT COUNT({$primaryKey})

	// 		 FROM   $table
	// 		 $join

	// 		 $where  

	// 		  $sWhere

	// 		  $group
	// 		 "

	// 	);



	// 	$recordsFiltered = $resFilterLength[0][0];



	// 	$resTotalLength = $this->query(

	// 		"SELECT COUNT({$primaryKey})

	// 		 FROM   $table $join  $where  $sWhere $group"

	// 	);

	// 	$recordsTotal = $resTotalLength[0][0];



	// 	return array(

	// 		"draw"            => isset ( $request['draw'] ) ?

	// 			intval( $request['draw'] ) :

	// 			0,

	// 		"recordsTotal"    => intval( $recordsTotal ),

	// 		"recordsFiltered" => intval( $recordsFiltered ),

	// 		"data"            => self::data_output( $columns, $data )

	// 	);

	// }
}