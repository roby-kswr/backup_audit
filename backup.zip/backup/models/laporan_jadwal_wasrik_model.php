<?php
/**
 * 
 */
class Laporan_jadwal_wasrik_model extends Model
{

	function getTahun()
	{
		$result = $this->query("SELECT title FROM tpkptsat GROUP BY title ");
		return $result;
	}

	function ttd()
	{
		$result = $this->query("SELECT * FROM ttandatangan ORDER BY autono ASC");
		return $result;
	}
	
	public function mget ( $request, $table, $primaryKey, $columns,$id,$wheres,  $join )

	{

		$bindings = array();

		$db = $this->connection;



		$limit = self::limit( $request, $columns );

		 // $order = self::order( $request, $columns );

		$where = self::filters( $request, $columns, $bindings, true );

		 $sWhere = "WHERE  a.title = '$id' AND b.id_jns_audit = '$wheres' ";



		$data = $this->query(

			"SELECT ".implode(",", $this->pluck($columns, 'db'))."

			 FROM $table

			 $join

			 $sWhere

			 $where

			 order by MONTH(start) asc 

			 $limit"

		);



		$resFilterLength = $this->query(

			"SELECT COUNT({$primaryKey})

			 FROM   $table
			 $join

			 $sWhere

			 $where"

		);



		$recordsFiltered = $resFilterLength[0][0];



		$resTotalLength = $this->query(

			"SELECT COUNT({$primaryKey})

			 FROM   $table $join   $sWhere $where"

		);

		$recordsTotal = $resTotalLength[0][0];



		return array(

			"draw"            => isset ( $request['draw'] ) ?

				intval( $request['draw'] ) :

				0,

			"recordsTotal"    => intval( $recordsTotal ),

			"recordsFiltered" => intval( $recordsFiltered ),

			"data"            => self::data_output( $columns, $data )

		);

	}

	public function filters ( $request, $columns, &$bindings )

	{

		$globalSearch = array();

		$columnSearch = array();

		$dtColumns = $this->pluck( $columns, 'dt' );


		if ( isset($request['search']) && $request['search']['value'] != '' ) {

			$str = $request['search']['value'];



			for ( $i=0, $ien=count($request['columns']) ; $i<$ien ; $i++ ) {

				$requestColumn = $request['columns'][$i];

				$columnIdx = array_search( $requestColumn['data'], $dtColumns );

				$column = $columns[ $columnIdx ];



				if ( $requestColumn['searchable'] == 'true' ) {

					if(!empty($column['db'])){

						$binding = "'%".$str."%'";

						$globalSearch[] = "`".$column['db']."` LIKE ".$binding;

					}

				}

			}

		}

		// Individual column filtering

		if ( isset( $request['columns'] ) ) {

			for ( $i=0, $ien=count($request['columns']) ; $i<$ien ; $i++ ) {

				$requestColumn = $request['columns'][$i];

				$columnIdx = array_search( $requestColumn['data'], $dtColumns );

				$column = $columns[ $columnIdx ];



				$str = $requestColumn['search']['value'];



				if ( $requestColumn['searchable'] == 'true' &&

					$str != '' ) {

					if(!empty($column['db'])){

						$binding = "'%".$str."%'";

						$columnSearch[] = "`".$column['db']."` LIKE ".$binding;

					}

				}

			}

		}

		$where = '';

		if ( count( $globalSearch ) ) {

			$where = '('.implode(' OR ', $globalSearch).')';

		}

		if ( count( $columnSearch ) ) {

			$where = $where === '' ?

			implode(' AND ', $columnSearch) :

			$where .' AND '. implode(' AND ', $columnSearch);

		}

		if ( $where !== '' ) {

			$where = 'AND'.$where;

		}

		return $where;

	}
}