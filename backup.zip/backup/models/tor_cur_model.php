<?php

class Tor_cur_model extends Model {

	public function mget($request, $table, $primaryKey, $columns, $join = null)
	{
		$result = $this->simple($request, $table, $primaryKey, $columns, $join);
		return $result;
	}

	public function get($table, $primaryKey, $id)
	{
		$result = $this->query("SELECT *, DATE_FORMAT(tgl_tor, '%d/%m/%Y') AS tanggal_tor FROM $table WHERE $primaryKey = '$id'");
		return $result;
	}

	public function get_file_attachment($id)
    {
        $result = $this->query("SELECT * FROM vt_files WHERE parent_id = $id ");

        return $result;
    }

	public function msave($table, $data = array(), $title)
	{
		$result = $this->sqlinsert($table, $data, $title);
		return $result;
	}

	public function savefile($data = array())
	{
		$result = $this->sqlinsert('vt_files', $data, 'Dokumen');
		return $result;
	}

	public function getfiles($request, $table, $primaryKey, $columns, $id, $y)
	{
		$result = $this->mySimple_file($request, $table, $primaryKey, $columns, $id, $y);
		return $result;
	}

	public function mupdate($table, $data = array(), $primaryKey, $id, $title)
	{
		$result = $this->sqlupdate($table, $data, $primaryKey, $id, $title);
		return $result;
	}

	public function mdelete($table, $primaryKey, $id, $title)
    {
        $result = $this->sqldelete($table, $primaryKey, $id, $title);
		return $result;
    }

    public function deletes_file($id)
    {
        $result = $this->sqldeletefiles('vt_files', $id, 'TOR');
		return $result;
    }

    public function sqldeletefiles($table, $id, $label)

	{

		$data = $this->getvalue("SELECT kode_parent FROM vt_files WHERE autono = $id");
		
		$i    = $this->count("SELECT COUNT(*) as jml FROM vt_files WHERE kode_parent = '$data[0]'");

		$result = $this->sqldelete("vt_files", "autono", $id, $label);

		return $result;

	}

}