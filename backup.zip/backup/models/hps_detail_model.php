<?php



class Hps_detail_model extends Model {



	public function mget($request, $table, $primaryKey, $columns)

	{

		$result = $this->simple($request, $table, $primaryKey, $columns);

		return $result;

	}



	public function mget_detail($request, $table, $primaryKey, $columns, $id,$y = NULL,$join = NULL)

	{	
		$join   = "";
		$result = $this->simple_detail22($request, $table, $id,$y, $columns);

		return $result;

	}

	public function simple_detail22 ( $request, $table, $primaryKey,$primaryKey2, $columns )

	{

		$bindings = array();

		$db = $this->connection;



		$limit = self::limit( $request, $columns );

		$order = self::order( $request, $columns );

		$where = self::filter( $request, $columns, $bindings, true );

		$sWhere = "WHERE parent_id = '$primaryKey' AND tahun = '$primaryKey2'";



		$data = $this->query(

			"SELECT `".implode("`, `", $this->pluck($columns, 'db'))."`

			 FROM `$table`

			 $sWhere

			 $where

			 $order

			 $limit"

		);



		$resFilterLength = $this->query(

			"SELECT COUNT(*)

			 FROM   `$table`

			 $sWhere $where"

		);



		$recordsFiltered = $resFilterLength[0][0];



		$resTotalLength = $this->query(

			"SELECT COUNT(*)

			 FROM   `$table` $sWhere"

		);

		$recordsTotal = $resTotalLength[0][0];



		return array(

			"draw"            => isset ( $request['draw'] ) ?

				intval( $request['draw'] ) :

				0,

			"recordsTotal"    => intval( $recordsTotal ),

			"recordsFiltered" => intval( $recordsFiltered ),

			"data"            => self::data_output( $columns, $data )

		);

	}

	public function get($table, $primaryKey, $id)

	{

		$result = $this->query("SELECT * FROM $table WHERE $primaryKey = '$id'");

		return $result;

	}

	// public function get($table, $primaryKey, $id, $primaryKey2, $id2, $primaryKey3, $id3, $primaryKey4, $id4)

	// {

	// 	$result = $this->query("SELECT * FROM $table WHERE $primaryKey = '$id' AND $primaryKey2 = '$id2' AND $primaryKey3 = '$id3' AND $primaryKey4 = '$id4'");

	// 	return $result;

	// }


	public function msave($table, $data = array(), $title)

	{

		$result = $this->sqlinsert($table, $data, $title);

		return $result;

	}


	public function mupdate($table,$data,$primaryKey,$id,$menu)
	{
		$result = $this->sqlupdate($table,$data, $primaryKey,$id,$menu);

		return $result;
	}

	// public function mupdate($table, $data = array(), $primaryKey5, $id5,$primaryKey6, $id6,$primaryKey2, $id2,$primaryKey3, $id3,$primaryKey4, $id4, $title)

	// {	

	// 	// $result = $this->getvalue("SELECT * FROM $table WHERE $primaryKey1 = '$id1' AND $primaryKey2 = '$id1'");

	// 	// if ($result['satker'] == 0)
	// 	// {'tes';}
	// 	// else
	// 	// {'tes2';}

	// 	$result = $this->sqlupdate($table, $data, $primaryKey5, $id5,$primaryKey6, $id6, $primaryKey2, $id2, $primaryKey3, $id3, $primaryKey4, $id4, $title);

	// 	return $result;

	// }



	public function mdelete($table, $primaryKey, $id, $title)

    {

        $result = $this->sqldelete($table, $primaryKey, $id, $title);

		return $result;

    }


public function import_hps ($encode,$tahun, $nama_files)
    {
    	error_reporting(1);
    	// $urll = ROOT_DIR.'static/files/dokumen/excelhps/'.$nama_files;
    	// IF(file_exists(ROOT_DIR.'static/files/dokumen/excelhps/'.$nama_files))
    	// {echo 'ada';echo $urll;}
    	// else
    	// 	{echo $urll;}
    	// exit;

    	// echo $encode;exit;
    		include ROOT_DIR.'static/PHPExcel/PHPExcel.php';
    
    $excelreader		= new PHPExcel_Reader_Excel2007();
	$loadexcel 			= $excelreader->load(ROOT_DIR.'static/files/dokumen/excelhps/'.$nama_files); 
	$sheet 				= $loadexcel->getActiveSheet()->toArray(null, true, true ,true);

	$numrow = 1;
	// var_dump($sheet);
	foreach($sheet as $row){

		$no_urut 			= $row['A']; 
		$keterangan 		= $row['B']; 
		$satuan 		    = $row['C']; 
		$harga 		        = $row['D'];
		
 

 


		if($no_urut == "" && $keterangan == "" && $satuan == "" && $harga == "")
			continue;
		
					if($numrow > 2){

						// merubah ke huruf kapital
						// $namaconvert = 	$act->ucw(str_replace("'","\'", $nama));  
 
						// insert ke database
						$this->execute("INSERT INTO tbl_hps_detail
							(parent_id,						 
							tahun,
							no_urut, 
							keterangan,							
							satuan,
							harga							
							
							
							) 
							VALUES 
							('$encode',					
							'$tahun',
							'$no_urut',
							'$keterangan',							
							'$satuan',
							'$harga'							
							
							
						) ");
						

 
						// update untuk mendapatkan kode pass
						// s$act->execute("UPDATE t_peserta SET pass = '$kode' WHERE id_kegiatan = '$id_kegiatan' AND id = $lastid ");

						// Hapus data duplikat
						// $act->execute("DELETE n1 FROM t_peserta n1, t_peserta n2 WHERE n1.id < n2.id AND n1.nomor = n2.nomor AND n1.id_kegiatan = n2.id_kegiatan"); 

						// $act->execute("UPDATE t_kegiatan SET status_import = 1 WHERE id = '$id_kegiatan' ");

						 
					}
			 
		$numrow++; 
	}

		// unlink(ROOT_DIR.'static/files/CATALOG/'.$tahun.'/'.$autocode.".xlsx");
        
        return $numrow;
    }


}