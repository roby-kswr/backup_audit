<?php

class Dashboard_model extends Model {

	private $table = "vt_akun";
	
	
    public function stock($value)
    {
    	$data = $this->query("SELECT c.`id`, c.`kategori` FROM tbl_jumlah a
								LEFT JOIN tbl_jumlah_detail b ON a.`id` = b.`parent_kode`
								LEFT JOIN vt_kategori c ON b.`id_kategori` = c.`id`
								WHERE c.`jenis` = $value AND c.`tampilkan` = 'on'
								GROUP BY c.`id`
								ORDER BY c.`ordering` ASC");

    	return $data;
    }

    public function stock_child($value)
    {
    	$data = $this->query("SELECT b.`nama_rs`, SUM(jumlah) AS stock, c.min_stock, d.`kategori` FROM tbl_jumlah_detail a  
								LEFT JOIN tbl_jumlah b ON a.`parent_kode` = b.`id`
								LEFT JOIN tbl_stock_rule c ON a.`id_kategori` = c.id_kategori
								LEFT JOIN vt_kategori d ON a.`id_kategori` = d.`id`
								WHERE a.id_kategori = '$value' AND d.`jenis` = 1 GROUP BY b.`kode_rs`");

    	return $data;
    }


     public function total($id)
    {
    	$data = $this->query("SELECT a.id_kategori, b.kategori,sum(a.jumlah) as jumlah, b.tampilkan, b.ordering, b.warna FROM tbl_jumlah_detail a LEFT JOIN vt_kategori b ON a.id_kategori = b.id WHERE b.tampilkan = 'on' AND b.jenis = $id GROUP BY a.id_kategori ORDER BY  b.ordering ASC ");

    	return $data;
    }



    public function min_stock($value)
    {
    	$data = $this->query("SELECT a.`nama_rs`, a.`min_stock`, c.jumlah AS stock FROM  tbl_stock_rule a LEFT JOIN tbl_jumlah b ON a.`kode_rs` = b.`kode_rs` LEFT JOIN ( SELECT parent_kode, jumlah, id_kategori FROM tbl_jumlah_detail WHERE id_kategori = '$value') c ON b.`id` = c.`parent_kode` WHERE a.`id_kategori` = '$value'");

    	return $data;
    }

}
