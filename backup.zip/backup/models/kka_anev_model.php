<?php

class Kka_anev_model extends Model {

	public function mget($request, $table, $primaryKey, $columns, $join	= null)
	{
		
		$result = $this->simple($request, $table, $primaryKey, $columns, $join);
		
		return $result;

	}

	public function get($table, $primaryKey, $id)
	{
		
		$result = $this->query("SELECT *, DATE_FORMAT(tgl_kka, '%d/%m/%Y') AS tanggal_kka FROM $table WHERE $primaryKey = '$id'");
		
		return $result;

	}

	public function msave($table, $data = array(), $title)
	{
		
		$result = $this->sqlinsert($table, $data, $title);
		
		return $result;

	}

	public function mupdate($table, $data = array(), $primaryKey, $id, $title)
	{
		
		$result = $this->sqlupdate($table, $data, $primaryKey, $id, $title);
		
		return $result;

	}

	public function mdelete($table, $primaryKey, $id, $title)
    {
       
        $result = $this->sqldelete($table, $primaryKey, $id, $title);
		
		return $result;

    }

    public function getvalues($qry)

	{

		$result = $this->execute($qry);

		$data   = $this->fetch_assoc($result);

		return $data;

	}

    public function mget_pka($id)
	
	{
		
		$result = $this->query("SELECT autono, no_pka, id_sprin FROM tpka WHERE autono = '$id' ORDER BY autono asc");
		
		return $result;

	}

	public function mget_personel($id)
	{
		
		$result = $this->query("SELECT `nama`, `nm_pangkat`, `nm_korps`, `nrp`, `jabatan` 
								   FROM tsprinpers a 
									LEFT JOIN (SELECT autono AS kd_pers, nrp AS id_personel, nama, id_korps, id_pangkat, jabatan FROM tpers) b ON a.nrp = b.id_personel
									LEFT JOIN (SELECT autono as kd_pangkat, nm_pangkat FROM tpangkat) c ON b.id_pangkat = c.kd_pangkat
									LEFT JOIN (SELECT autono as kd_korps, nm_korps FROM tkorps) d ON b.id_korps = d.kd_korps
								   WHERE id_sprin = '$id'
								   GROUP BY autono");
		
		return $result;

	}

	public function mget_personelEdit($table, $sField, $field, $id)
	
	{
		
		$result = $this->query("SELECT nrp, LOWER(nama) AS nama, IF(b.$sField IS NULL, '', 'selected') AS pselect FROM tpers a LEFT JOIN (SELECT $sField FROM $table WHERE `$field` = '$id') b ON a.nrp = b.$sField ORDER BY nrp ASC");		
		
		return $result;

	}

    public function get_pka()
	
	{
		
		$result = $this->query("SELECT autono, no_pka FROM tpka a WHERE NOT EXISTS (SELECT id_pka FROM tkka b WHERE a.autono = b.id_pka)");
		
		return $result;

	}

	public function get_kkaEdit($table, $field, $id)
	{
		
		$result = $this->query("SELECT autono, no_kka, IF(b.id_kka IS NULL, '', 'selected') AS pselect FROM tpka a LEFT JOIN ( SELECT id_kka FROM $table WHERE $field = '$id') b ON a.autono = b.id_kka ORDER BY no_kka ASC");
		
		return $result;

	}

    public function gets_himpunan()
	{
		
		$result = $this->getvalues("SELECT GROUP_CONCAT('\'',tentang, '\'') AS tentang FROM thimpunanperaturan ORDER BY autono ASC");
		
		return $result;

	}

	public function load_kka($id)
	{
		
		$result = $this->getValue("SELECT *, nm_audit, no_kka, sasaran_audit, periode, potensi, akibat, catatan, sumber, DAY(tgl_kka) AS `day`, MONTH(tgl_kka) AS `month`, YEAR(tgl_kka) AS `year` FROM tkka WHERE autono = $id");
		
		return $result;

	}

	public function load_personel($table, $field, $id)
	{
		
		$result = $this->getValue("SELECT `nama`, `nm_pangkat`, `nm_korps`, `nrp`, `jabatan` 
								   FROM $table a 
			 						LEFT JOIN (SELECT autono AS kd_pers, nrp, nama, id_korps, id_pangkat, jabatan FROM tpers) b ON a.disusun_oleh = b.kd_pers
		 	   						LEFT JOIN (SELECT autono as kd_pangkat, nm_pangkat FROM tpangkat) c ON b.id_pangkat = c.kd_pangkat
		 	   						LEFT JOIN (SELECT autono as kd_korps, nm_korps FROM tkorps) d ON b.id_korps = d.kd_korps
			 	   				   WHERE $field = '$id'
			 	   				   GROUP BY autono");
		
		return $result;

	}
}