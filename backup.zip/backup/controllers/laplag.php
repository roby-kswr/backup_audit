<?php

class Laplag extends Controller {

	private $table       = "dja_pagu";
	private $tbl_hps     = "tbl_hps";
	private $tbl_tor     = "tbl_tor";
	private $tbl_rab     = "tbl_rab";
	private $tbl_sph     = "tbl_sph";
	private $tbl_kontrak = "tbl_kontrak";
	private $tbl_bast    = "tbl_bast";
	private $tbl_ku17    = "tbl_ku17";
	private $tbl_sp2d    = "tbl_sp2d";
	private $primaryKey  = "id";
	private $model       = "Laplag_model"; # please write with no space
	private $menu        = "Transaksi";
	private $title       = "Laplakgiat Post";
	private $curl        = BASE_URL."laplag/";
	

	public function __construct()
    {
        $session = $this->loadHelper('Session_helper');
        if(!$session->get('username')){
        	$this->redirect('auth/login');
        }
    }
	
	function index()
	{

		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['curl']        = $this->curl;
		$template            = $this->loadView('laplag_index');
		$template->set('data', $data);
		$template->render();


	}

	function detail($x)
	{
		$model               = $this->loadModel($this->model);
		$id                  = $this->base64url_decode($x);
		$get                 = $model->getvalue("SELECT * FROM $this->table WHERE id = $id");
		$sat                 = $model->getvalue("SELECT * FROM tsatminkal WHERE kd_satminkal = ".$get['kdsatker']."");
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['curl']        = $this->curl;
		$data['nmsatker']    = $sat['nm_satminkal'];
		$data['encode']      = $x;
		$template            = $this->loadView('laplag_view');
		$template->set('data', $data);
		$template->render();
	}

	function get()
	{
		$request = $_REQUEST;
		$columns = array(
			array( 'db' => 'id', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'thang',  'dt' => 1 ),
			array( 'db' => 'wasgiat',  'dt' => 2 ),
			array( 'db' => 'urskmpnen',  'dt' => 3 ),
			array( 'db' => 'jml_pagu',   'dt' => 4 )
		);
		
		$join   = "AS t1 LEFT JOIN (SELECT `kdsatker`, `nmsatker` FROM dja_satker) AS t2 ON t1.KDSATKER = t2.kdsatker";
		$model  = $this->loadModel($this->model);
		$result = $model->mgetDipa($request, $this->table, $this->primaryKey, $columns, $join);

		return json_encode($result);
	}

	function getLaplag()
	{
		$request = $_REQUEST;
		$columns = array(
			array( 'db' => 'id', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'thang',  'dt' => 1 ),
			array( 'db' => 'kdsatker',  'dt' => 2 ),
			array( 'db' => 'kdprogram',   'dt' => 3 ),
			array( 'db' => 'kdgiat',   'dt' => 4 ),
			array( 'db' => 'kdoutput',   'dt' => 5 ),
			array( 'db' => 'kdsoutput',   'dt' => 6 ),
			array( 'db' => 'SUM(jml_pagu)',   'dt' => 7 , 'formatter' => function( $d, $row ) { return number_format($d); } ),
			array( 'db' => 'nm_satminkal',   'dt' => 8 ),
			array( 'db' => 'wasgiat',   'dt' => 9 )
		);
		
		$model  = $this->loadModel($this->model);
		$result = $model->mgetLaplag($request, $this->table, $this->primaryKey, $columns);

		return json_encode($result);
	}

	function getdetail($x)
	{
		$request = $_REQUEST;
		$id      = $this->base64url_decode($x);
		$model   = $this->loadModel($this->model);
		$columns = array(
			array( 'db' => 'id', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'urskmpnen',  'dt' => 1 ),
			array( 'db' => 'kdsatker',  'dt' => 2 ),
			array( 'db' => 'kdprogram',   'dt' => 3 ),
			array( 'db' => 'kdgiat',   'dt' => 4 ),
			array( 'db' => 'kdoutput',   'dt' => 5 ),
			array( 'db' => 'kdsoutput',   'dt' => 6 ),
			array( 'db' => 'SUM(jml_pagu)',   'dt' => 7 , 'formatter' => function( $d, $row ) { return number_format($d); } ),
			array( 'db' => 'wasgiat',   'dt' => 8 )
		);
		
		
		$result = $model->mgetDetail($request, $this->table, $this->primaryKey, $columns, $id);

		return json_encode($result);
	}

	function getrab($x)
	{
		$request = $_REQUEST;
		$id      = $this->base64url_decode($x);
		$model   = $this->loadModel($this->model);
		$columns = array(
			array( 'db' => 'id', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'kdakun',  'dt' => 1 ),
			array( 'db' => 'nmakun',  'dt' => 2 ),
			array( 'db' => 'SUM(jml_pagu)',   'dt' => 3 , 'formatter' => function( $d, $row ) { return number_format($d); } )
		);
		
		
		$result = $model->mgetRab($request, $this->table, $this->primaryKey, $columns, $id);

		return json_encode($result);
	}


	function getAkun($x, $y)
	{
		$id         = $this->base64url_decode($x);
		$request    = $_REQUEST;
		$primaryKey = "id";
		$sTable     = "dja_pagu";
		$columns = array(
			array( 'db' => 'kdakun', 'dt' => 1 ),
			array( 'db' => 'nmakun',  'dt' => 2 ),
			array( 'db' => 'jml_pagu',  'dt' => 3 )
		);

		$join   = "AS t1 LEFT JOIN (SELECT kdakun AS `kodeakun`, `nmakun` FROM dja_akun) AS t2 ON t1.kdakun = t2.kodeakun";
		$model  = $this->loadModel('laplag_model');
		$result = $model->mgetAkun($request, $sTable, $primaryKey, $columns, $join, $id, $y);

		$row = json_encode($result);

		return $row;
	}

	function getdatahps($x)
	{
		$id         = $this->base64url_decode($x);
		$request    = $_REQUEST;
		$primaryKey = "autono";
		$sTable     = $this->tbl_hps;
		$columns = array(
			array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'tanggal_hps', 'dt' => 1 ),
			array( 'db' => 'nilai_hps',  'dt' => 2 , 'formatter' => function( $d, $row ) { return number_format($d); } ),
			array( 'db' => 'file_hps',  'dt' => 3 )
		);

		$model  = $this->loadModel('laplag_model');
		$result = $model->mgetdatadetail($request, $sTable, $primaryKey, $columns, $id);

		$row = json_encode($result);

		return $row;
	}

	function getdatator($x)
	{
		$id         = $this->base64url_decode($x);
		$request    = $_REQUEST;
		$primaryKey = "autono";
		$sTable     = $this->tbl_tor;
		$columns = array(
			array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'tanggal_tor', 'dt' => 1 ),
			array( 'db' => 'nilai_tor',  'dt' => 2 , 'formatter' => function( $d, $row ) { return number_format($d); } ),
			array( 'db' => 'file_tor',  'dt' => 3 )
		);

		$model  = $this->loadModel('laplag_model');
		$result = $model->mgetdatadetail($request, $sTable, $primaryKey, $columns, $id);

		$row = json_encode($result);

		return $row;
	}

	function getdatarab($x)
	{
		$id         = $this->base64url_decode($x);
		$request    = $_REQUEST;
		$primaryKey = "autono";
		$sTable     = $this->tbl_rab;
		$columns = array(
			array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'tanggal_rab', 'dt' => 1 ),
			array( 'db' => 'nilai_rab',  'dt' => 2 , 'formatter' => function( $d, $row ) { return number_format($d); } ),
			array( 'db' => 'file_rab',  'dt' => 3 )
		);

		$model  = $this->loadModel('laplag_model');
		$result = $model->mgetdatadetail($request, $sTable, $primaryKey, $columns, $id);

		$row = json_encode($result);

		return $row;
	}

	function getdatasph($x)
	{
		$id         = $this->base64url_decode($x);
		$request    = $_REQUEST;
		$primaryKey = "autono";
		$sTable     = $this->tbl_sph;
		$columns = array(
			array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'tanggal_sph', 'dt' => 1 ),
			array( 'db' => 'nilai_sph',  'dt' => 2 , 'formatter' => function( $d, $row ) { return number_format($d); } ),
			array( 'db' => 'file_sph',  'dt' => 3 )
		);

		$model  = $this->loadModel('laplag_model');
		$result = $model->mgetdatadetail($request, $sTable, $primaryKey, $columns, $id);

		$row = json_encode($result);

		return $row;
	}

	function getdatakontrak($x)
	{
		$id         = $this->base64url_decode($x);
		$request    = $_REQUEST;
		$primaryKey = "autono";
		$sTable     = $this->tbl_kontrak;
		$columns = array(
			array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'tanggal_kontrak', 'dt' => 1 ),
			array( 'db' => 'nilai_kontrak',  'dt' => 2 , 'formatter' => function( $d, $row ) { return number_format($d); } ),
			array( 'db' => 'file_kontrak',  'dt' => 3 ),
			array( 'db' => 'termin',  'dt' => 4 )
		);

		$model  = $this->loadModel('laplag_model');
		$result = $model->mgetdatadetail($request, $sTable, $primaryKey, $columns, $id);

		$row = json_encode($result);

		return $row;
	}

	function getdatabast($x)
	{
		$id         = $this->base64url_decode($x);
		$request    = $_REQUEST;
		$primaryKey = "autono";
		$sTable     = $this->tbl_bast;
		$columns = array(
			array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'tanggal_bast', 'dt' => 1 ),
			array( 'db' => 'nilai_bast',  'dt' => 2 , 'formatter' => function( $d, $row ) { return number_format($d); } ),
			array( 'db' => 'file_bast',  'dt' => 3 )
		);

		$model  = $this->loadModel('laplag_model');
		$result = $model->mgetdatadetail($request, $sTable, $primaryKey, $columns, $id);

		$row = json_encode($result);

		return $row;
	}

	function getdataku17($x)
	{
		$id         = $this->base64url_decode($x);
		$request    = $_REQUEST;
		$primaryKey = "autono";
		$sTable     = $this->tbl_ku17;
		$columns = array(
			array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'tanggal_ku17', 'dt' => 1 ),
			array( 'db' => 'nilai_ku17',  'dt' => 2 , 'formatter' => function( $d, $row ) { return number_format($d); } ),
			array( 'db' => 'file_ku17',  'dt' => 3 )
		);

		$model  = $this->loadModel('laplag_model');
		$result = $model->mgetdatadetail($request, $sTable, $primaryKey, $columns, $id);

		$row = json_encode($result);

		return $row;
	}

	function getdatasp2d($x)
	{
		$id         = $this->base64url_decode($x);
		$request    = $_REQUEST;
		$primaryKey = "autono";
		$sTable     = $this->tbl_sp2d;
		$columns = array(
			array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'tanggal_sp2d', 'dt' => 1 ),
			array( 'db' => 'nilai_sp2d',  'dt' => 2 , 'formatter' => function( $d, $row ) { return number_format($d); } ),
			array( 'db' => 'file_sp2d',  'dt' => 3 ),
			array( 'db' => 'termin',  'dt' => 4 )
		);

		$model  = $this->loadModel('laplag_model');
		$result = $model->mgetdatadetail($request, $sTable, $primaryKey, $columns, $id);

		$row = json_encode($result);

		return $row;
	}

	public function add()
	{
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Add';
		$data['curl']        = $this->curl;
		$data['thang']       = $model->mget_thang();
		$data['laplag']      = $model->mget_laplag();
		$template            = $this->loadView('laplag_add');
		$template->set('data', $data);
		$template->render();
	}

	public function edit($x)
	{
		$id                  = $this->base64url_decode($x);
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Edit';
		$data['encode']      = $x;
		$data['curl']        = $this->curl;
		$data['id_jenbel']   = $model->get_jenBelEdit($this->table, $this->primaryKey, $id);
		$data['aadata']      = $model->get($this->table, $this->primaryKey, $id);
		$template            = $this->loadView('laplag_edit');
		$template->set('data', $data);
		$template->render();
	}

	public function save()
	{
		$data               = array();
		$model              = $this->loadModel($this->model);
		$data['id_jenbel']  = ucwords(htmlspecialchars($_REQUEST['id_jenbel'])) ;
		$data['kd_akun']    = ucwords(htmlspecialchars($_REQUEST['kd_akun'])) ;
		$data['nm_akun']    = ucwords(htmlspecialchars($_REQUEST['nm_akun'])) ;
		$data['keterangan'] = ucwords(htmlspecialchars($_REQUEST['keterangan'])) ;
		$data['autocode']   = $model->autocode($this->table, "AKN_");	
		$result             = $model->msave($this->table, $data, $this->title);
		$this->redirect('laplag');
	}

	public function savehps($x)

	{		
		$data                  = array();	
		$model                 = $this->loadModel($this->model);
		$data['parent_id']     = $this->base64url_decode($x) ;
		$data['tanggal_hps']   = $model->escapeString($_REQUEST['tanggal_hps']) ;
		$data['nilai_hps']     = $model->escapeString($_REQUEST['nilai_hps']) ;		
		$data['file_hps']      = !empty($_FILES['file_hps']['name'][0]) ?  1 : 0;
		$data['file_excelhps'] = !empty($_FILES['file_excelhps']['name'][0]) ?  1 : 0;
		$data['autocode']      = $model->autocode($this->tbl_hps, "HPS-");	
		
		$result                = $model->msave($this->tbl_hps, $data, $this->title);
		$lastid                = $result['id'];
		
		# Insert files
		$files1              = array();
		$files1['dir']       = "dochps";
		$files1['subdir']    = "";
		if(!empty($_FILES['file_hps']['name'][0])) {
		    $file_ary1 = $model->reArrayFiles($_FILES['file_hps']);
		    foreach ($file_ary1 as $file1) {
				$files1['kode_parent'] = $data['autocode'];
				$files1['parent_id']   = $lastid;
				$files1['nama_file']   = $this->randName($file1['name']);
				$files1['tipe_file']   = $file1['type'];
				$files1['ukuran']      = $file1['size'];
				$files1['ftable']      = $this->tbl_hps;

				if(!empty($file1['name'])){ $model->savefile($files1); } 
		    }
		}

		$files2              = array();
		$files2['dir']       = "excelhps";
		$files2['subdir']    = "";
		if(!empty($_FILES['file_excelhps']['name'][0])) {
		    $file_ary2 = $model->reArrayFiles($_FILES['file_excelhps']);
		    foreach ($file_ary2 as $file2) {
				$files2['kode_parent'] = $data['autocode'];
				$files2['parent_id']   = $lastid;
				$files2['nama_file']   = $this->randName($file2['name']);
				$files2['tipe_file']   = $file2['type'];
				$files2['ukuran']      = $file2['size'];
				$files2['ftable']      = $this->tbl_hps;

				if(!empty($file2['name'])){ $model->savefile($files2); } 
		    }
		}
		# Upload file
		if(isset($_FILES['file_hps'])){ $model->uploads('dokumen', $_FILES['file_hps'], $files1['dir'], $files1['subdir']); }
		if(isset($_FILES['file_excelhps'])){ $model->uploads('dokumen', $_FILES['file_excelhps'], $files2['dir'], $files2['subdir']); }


		return true;

	}

	public function savetor($x)

	{		
		$data                  = array();	
		$model                 = $this->loadModel($this->model);
		$data['parent_id']     = $this->base64url_decode($x) ;
		$data['tanggal_tor']   = $model->escapeString($_REQUEST['tanggal_tor']) ;
		$data['nilai_tor']     = $model->escapeString($_REQUEST['nilai_tor']) ;		
		$data['file_tor']      = !empty($_FILES['file_tor']['name'][0]) ?  1 : 0;
		$data['file_exceltor'] = !empty($_FILES['file_exceltor']['name'][0]) ?  1 : 0;
		$data['autocode']      = $model->autocode($this->tbl_tor, "TOR-");	
		
		$result                = $model->msave($this->tbl_tor, $data, $this->title);
		$lastid                = $result['id'];
		
		# Insert files
		$files1              = array();
		$files1['dir']       = "doctor";
		$files1['subdir']    = "";
		if(!empty($_FILES['file_tor']['name'][0])) {
		    $file_ary1 = $model->reArrayFiles($_FILES['file_tor']);
		    foreach ($file_ary1 as $file1) {
				$files1['kode_parent'] = $data['autocode'];
				$files1['parent_id']   = $lastid;
				$files1['nama_file']   = $this->randName($file1['name']);
				$files1['tipe_file']   = $file1['type'];
				$files1['ukuran']      = $file1['size'];
				$files1['ftable']      = $this->tbl_tor;

				if(!empty($file1['name'])){ $model->savefile($files1); } 
		    }
		}

		$files2              = array();
		$files2['dir']       = "exceltor";
		$files2['subdir']    = "";
		if(!empty($_FILES['file_exceltor']['name'][0])) {
		    $file_ary2 = $model->reArrayFiles($_FILES['file_exceltor']);
		    foreach ($file_ary2 as $file2) {
				$files2['kode_parent'] = $data['autocode'];
				$files2['parent_id']   = $lastid;
				$files2['nama_file']   = $this->randName($file2['name']);
				$files2['tipe_file']   = $file2['type'];
				$files2['ukuran']      = $file2['size'];
				$files2['ftable']      = $this->tbl_tor;

				if(!empty($file2['name'])){ $model->savefile($files2); } 
		    }
		}
		# Upload file
		if(isset($_FILES['file_tor'])){ $model->uploads('dokumen', $_FILES['file_tor'], $files1['dir'], $files1['subdir']); }
		if(isset($_FILES['file_exceltor'])){ $model->uploads('dokumen', $_FILES['file_exceltor'], $files2['dir'], $files2['subdir']); }


		return true;

	}

	public function saverab($x)

	{		
		$data                  = array();	
		$model                 = $this->loadModel($this->model);
		$data['parent_id']     = $this->base64url_decode($x) ;
		$data['tanggal_rab']   = $model->escapeString($_REQUEST['tanggal_rab']) ;
		$data['nilai_rab']     = $model->escapeString($_REQUEST['nilai_rab']) ;		
		$data['file_rab']      = !empty($_FILES['file_rab']['name'][0]) ?  1 : 0;
		$data['file_excelrab'] = !empty($_FILES['file_excelrab']['name'][0]) ?  1 : 0;
		$data['autocode']      = $model->autocode($this->tbl_rab, "RAB-");	
		
		$result                = $model->msave($this->tbl_rab, $data, $this->title);
		$lastid                = $result['id'];
		
		# Insert files
		$files1              = array();
		$files1['dir']       = "docrab";
		$files1['subdir']    = "";
		if(!empty($_FILES['file_rab']['name'][0])) {
		    $file_ary1 = $model->reArrayFiles($_FILES['file_rab']);
		    foreach ($file_ary1 as $file1) {
				$files1['kode_parent'] = $data['autocode'];
				$files1['parent_id']   = $lastid;
				$files1['nama_file']   = $this->randName($file1['name']);
				$files1['tipe_file']   = $file1['type'];
				$files1['ukuran']      = $file1['size'];
				$files1['ftable']      = $this->tbl_rab;

				if(!empty($file1['name'])){ $model->savefile($files1); } 
		    }
		}

		$files2              = array();
		$files2['dir']       = "excelrab";
		$files2['subdir']    = "";
		if(!empty($_FILES['file_excelrab']['name'][0])) {
		    $file_ary2 = $model->reArrayFiles($_FILES['file_excelrab']);
		    foreach ($file_ary2 as $file2) {
				$files2['kode_parent'] = $data['autocode'];
				$files2['parent_id']   = $lastid;
				$files2['nama_file']   = $this->randName($file2['name']);
				$files2['tipe_file']   = $file2['type'];
				$files2['ukuran']      = $file2['size'];
				$files2['ftable']      = $this->tbl_rab;

				if(!empty($file2['name'])){ $model->savefile($files2); } 
		    }
		}
		# Upload file
		if(isset($_FILES['file_rab'])){ $model->uploads('dokumen', $_FILES['file_rab'], $files1['dir'], $files1['subdir']); }
		if(isset($_FILES['file_excelrab'])){ $model->uploads('dokumen', $_FILES['file_excelrab'], $files2['dir'], $files2['subdir']); }


		return true;

	}

	public function savesph($x)

	{		
		$data                  = array();	
		$model                 = $this->loadModel($this->model);
		$data['parent_id']     = $this->base64url_decode($x) ;
		$data['tanggal_sph']   = $model->escapeString($_REQUEST['tanggal_sph']) ;
		$data['nilai_sph']     = $model->escapeString($_REQUEST['nilai_sph']) ;		
		$data['file_sph']      = !empty($_FILES['file_sph']['name'][0]) ?  1 : 0;
		$data['file_excelsph'] = !empty($_FILES['file_excelsph']['name'][0]) ?  1 : 0;
		$data['autocode']      = $model->autocode($this->tbl_sph, "SPH-");	
		
		$result                = $model->msave($this->tbl_sph, $data, $this->title);
		$lastid                = $result['id'];
		
		# Insert files
		$files1              = array();
		$files1['dir']       = "docsph";
		$files1['subdir']    = "";
		if(!empty($_FILES['file_sph']['name'][0])) {
		    $file_ary1 = $model->reArrayFiles($_FILES['file_sph']);
		    foreach ($file_ary1 as $file1) {
				$files1['kode_parent'] = $data['autocode'];
				$files1['parent_id']   = $lastid;
				$files1['nama_file']   = $this->randName($file1['name']);
				$files1['tipe_file']   = $file1['type'];
				$files1['ukuran']      = $file1['size'];
				$files1['ftable']      = $this->tbl_sph;

				if(!empty($file1['name'])){ $model->savefile($files1); } 
		    }
		}

		$files2              = array();
		$files2['dir']       = "excelsph";
		$files2['subdir']    = "";
		if(!empty($_FILES['file_excelsph']['name'][0])) {
		    $file_ary2 = $model->reArrayFiles($_FILES['file_excelsph']);
		    foreach ($file_ary2 as $file2) {
				$files2['kode_parent'] = $data['autocode'];
				$files2['parent_id']   = $lastid;
				$files2['nama_file']   = $this->randName($file2['name']);
				$files2['tipe_file']   = $file2['type'];
				$files2['ukuran']      = $file2['size'];
				$files2['ftable']      = $this->tbl_sph;

				if(!empty($file2['name'])){ $model->savefile($files2); } 
		    }
		}
		# Upload file
		if(isset($_FILES['file_sph'])){ $model->uploads('dokumen', $_FILES['file_sph'], $files1['dir'], $files1['subdir']); }
		if(isset($_FILES['file_excelsph'])){ $model->uploads('dokumen', $_FILES['file_excelsph'], $files2['dir'], $files2['subdir']); }


		return true;

	}

	public function savekontrak($x)

	{		
		$data                      = array();	
		$model                     = $this->loadModel($this->model);
		$data['parent_id']         = $this->base64url_decode($x) ;
		$data['tanggal_kontrak']   = $model->escapeString($_REQUEST['tanggal_kontrak']) ;
		$data['nilai_kontrak']     = $model->escapeString($_REQUEST['nilai_kontrak']) ;		
		$data['termin']            = $model->escapeString($_REQUEST['termin']) ;		
		$data['file_kontrak']      = !empty($_FILES['file_kontrak']['name'][0]) ?  1 : 0;
		$data['file_excelkontrak'] = !empty($_FILES['file_excelkontrak']['name'][0]) ?  1 : 0;
		$data['autocode']          = $model->autocode($this->tbl_kontrak, "KNT-");	
		
		$result                    = $model->msave($this->tbl_kontrak, $data, $this->title);
		$lastid                    = $result['id'];
		
		# Insert files
		$files1              = array();
		$files1['dir']       = "dockontrak";
		$files1['subdir']    = "";
		if(!empty($_FILES['file_kontrak']['name'][0])) {
		    $file_ary1 = $model->reArrayFiles($_FILES['file_kontrak']);
		    foreach ($file_ary1 as $file1) {
				$files1['kode_parent'] = $data['autocode'];
				$files1['parent_id']   = $lastid;
				$files1['nama_file']   = $this->randName($file1['name']);
				$files1['tipe_file']   = $file1['type'];
				$files1['ukuran']      = $file1['size'];
				$files1['ftable']      = $this->tbl_kontrak;

				if(!empty($file1['name'])){ $model->savefile($files1); } 
		    }
		}

		$files2              = array();
		$files2['dir']       = "excelkontrak";
		$files2['subdir']    = "";
		if(!empty($_FILES['file_excelkontrak']['name'][0])) {
		    $file_ary2 = $model->reArrayFiles($_FILES['file_excelkontrak']);
		    foreach ($file_ary2 as $file2) {
				$files2['kode_parent'] = $data['autocode'];
				$files2['parent_id']   = $lastid;
				$files2['nama_file']   = $this->randName($file2['name']);
				$files2['tipe_file']   = $file2['type'];
				$files2['ukuran']      = $file2['size'];
				$files2['ftable']      = $this->tbl_kontrak;

				if(!empty($file2['name'])){ $model->savefile($files2); } 
		    }
		}
		# Upload file
		if(isset($_FILES['file_kontrak'])){ $model->uploads('dokumen', $_FILES['file_kontrak'], $files1['dir'], $files1['subdir']); }
		if(isset($_FILES['file_excelkontrak'])){ $model->uploads('dokumen', $_FILES['file_excelkontrak'], $files2['dir'], $files2['subdir']); }


		return true;

	}

	public function savebast($x)

	{		
		$data                  = array();	
		$model                 = $this->loadModel($this->model);
		$data['parent_id']     = $this->base64url_decode($x) ;
		$data['tanggal_bast']   = $model->escapeString($_REQUEST['tanggal_bast']) ;
		$data['nilai_bast']     = $model->escapeString($_REQUEST['nilai_bast']) ;		
		$data['file_bast']      = !empty($_FILES['file_bast']['name'][0]) ?  1 : 0;
		$data['file_excelbast'] = !empty($_FILES['file_excelbast']['name'][0]) ?  1 : 0;
		$data['autocode']      = $model->autocode($this->tbl_bast, "BAST-");	
		
		$result                = $model->msave($this->tbl_bast, $data, $this->title);
		$lastid                = $result['id'];
		
		# Insert files
		$files1              = array();
		$files1['dir']       = "docbast";
		$files1['subdir']    = "";
		if(!empty($_FILES['file_bast']['name'][0])) {
		    $file_ary1 = $model->reArrayFiles($_FILES['file_bast']);
		    foreach ($file_ary1 as $file1) {
				$files1['kode_parent'] = $data['autocode'];
				$files1['parent_id']   = $lastid;
				$files1['nama_file']   = $this->randName($file1['name']);
				$files1['tipe_file']   = $file1['type'];
				$files1['ukuran']      = $file1['size'];
				$files1['ftable']      = $this->tbl_bast;

				if(!empty($file1['name'])){ $model->savefile($files1); } 
		    }
		}

		$files2              = array();
		$files2['dir']       = "excelbast";
		$files2['subdir']    = "";
		if(!empty($_FILES['file_excelbast']['name'][0])) {
		    $file_ary2 = $model->reArrayFiles($_FILES['file_excelbast']);
		    foreach ($file_ary2 as $file2) {
				$files2['kode_parent'] = $data['autocode'];
				$files2['parent_id']   = $lastid;
				$files2['nama_file']   = $this->randName($file2['name']);
				$files2['tipe_file']   = $file2['type'];
				$files2['ukuran']      = $file2['size'];
				$files2['ftable']      = $this->tbl_bast;

				if(!empty($file2['name'])){ $model->savefile($files2); } 
		    }
		}
		# Upload file
		if(isset($_FILES['file_bast'])){ $model->uploads('dokumen', $_FILES['file_bast'], $files1['dir'], $files1['subdir']); }
		if(isset($_FILES['file_excelbast'])){ $model->uploads('dokumen', $_FILES['file_excelbast'], $files2['dir'], $files2['subdir']); }


		return true;

	}

	public function saveku17($x)

	{		
		$data                  = array();	
		$model                 = $this->loadModel($this->model);
		$data['parent_id']     = $this->base64url_decode($x) ;
		$data['tanggal_ku17']   = $model->escapeString($_REQUEST['tanggal_ku17']) ;
		$data['nilai_ku17']     = $model->escapeString($_REQUEST['nilai_ku17']) ;		
		$data['file_ku17']      = !empty($_FILES['file_ku17']['name'][0]) ?  1 : 0;
		$data['file_excelku17'] = !empty($_FILES['file_excelku17']['name'][0]) ?  1 : 0;
		$data['autocode']      = $model->autocode($this->tbl_ku17, "SPH-");	
		
		$result                = $model->msave($this->tbl_ku17, $data, $this->title);
		$lastid                = $result['id'];
		
		# Insert files
		$files1              = array();
		$files1['dir']       = "docku17";
		$files1['subdir']    = "";
		if(!empty($_FILES['file_ku17']['name'][0])) {
		    $file_ary1 = $model->reArrayFiles($_FILES['file_ku17']);
		    foreach ($file_ary1 as $file1) {
				$files1['kode_parent'] = $data['autocode'];
				$files1['parent_id']   = $lastid;
				$files1['nama_file']   = $this->randName($file1['name']);
				$files1['tipe_file']   = $file1['type'];
				$files1['ukuran']      = $file1['size'];
				$files1['ftable']      = $this->tbl_ku17;

				if(!empty($file1['name'])){ $model->savefile($files1); } 
		    }
		}

		$files2              = array();
		$files2['dir']       = "excelku17";
		$files2['subdir']    = "";
		if(!empty($_FILES['file_excelku17']['name'][0])) {
		    $file_ary2 = $model->reArrayFiles($_FILES['file_excelku17']);
		    foreach ($file_ary2 as $file2) {
				$files2['kode_parent'] = $data['autocode'];
				$files2['parent_id']   = $lastid;
				$files2['nama_file']   = $this->randName($file2['name']);
				$files2['tipe_file']   = $file2['type'];
				$files2['ukuran']      = $file2['size'];
				$files2['ftable']      = $this->tbl_ku17;

				if(!empty($file2['name'])){ $model->savefile($files2); } 
		    }
		}
		# Upload file
		if(isset($_FILES['file_ku17'])){ $model->uploads('dokumen', $_FILES['file_ku17'], $files1['dir'], $files1['subdir']); }
		if(isset($_FILES['file_excelku17'])){ $model->uploads('dokumen', $_FILES['file_excelku17'], $files2['dir'], $files2['subdir']); }


		return true;

	}

	public function savesp2d($x)

	{		
		$data                  	= array();	
		$model                 	= $this->loadModel($this->model);
		$data['parent_id']     	= $this->base64url_decode($x) ;
		$data['tanggal_sp2d']   = $model->escapeString($_REQUEST['tanggal_sp2d']) ;
		$data['nilai_sp2d']     = $model->escapeString($_REQUEST['nilai_sp2d']) ;
		$data['termin']         = $model->escapeString($_REQUEST['termin']) ;			
		$data['file_sp2d']      = !empty($_FILES['file_sp2d']['name'][0]) ?  1 : 0;
		$data['file_excelsp2d'] = !empty($_FILES['file_excelsp2d']['name'][0]) ?  1 : 0;
		$data['autocode']      	= $model->autocode($this->tbl_sp2d, "SPH-");	
		
		$result                	= $model->msave($this->tbl_sp2d, $data, $this->title);
		$lastid                	= $result['id'];
		
		# Insert files
		$files1              = array();
		$files1['dir']       = "docsp2d";
		$files1['subdir']    = "";
		if(!empty($_FILES['file_sp2d']['name'][0])) {
		    $file_ary1 = $model->reArrayFiles($_FILES['file_sp2d']);
		    foreach ($file_ary1 as $file1) {
				$files1['kode_parent'] = $data['autocode'];
				$files1['parent_id']   = $lastid;
				$files1['nama_file']   = $this->randName($file1['name']);
				$files1['tipe_file']   = $file1['type'];
				$files1['ukuran']      = $file1['size'];
				$files1['ftable']      = $this->tbl_sp2d;

				if(!empty($file1['name'])){ $model->savefile($files1); } 
		    }
		}

		$files2              = array();
		$files2['dir']       = "excelsp2d";
		$files2['subdir']    = "";
		if(!empty($_FILES['file_excelsp2d']['name'][0])) {
		    $file_ary2 = $model->reArrayFiles($_FILES['file_excelsp2d']);
		    foreach ($file_ary2 as $file2) {
				$files2['kode_parent'] = $data['autocode'];
				$files2['parent_id']   = $lastid;
				$files2['nama_file']   = $this->randName($file2['name']);
				$files2['tipe_file']   = $file2['type'];
				$files2['ukuran']      = $file2['size'];
				$files2['ftable']      = $this->tbl_sp2d;

				if(!empty($file2['name'])){ $model->savefile($files2); } 
		    }
		}
		# Upload file
		if(isset($_FILES['file_sp2d'])){ $model->uploads('dokumen', $_FILES['file_sp2d'], $files1['dir'], $files1['subdir']); }
		if(isset($_FILES['file_excelsp2d'])){ $model->uploads('dokumen', $_FILES['file_excelsp2d'], $files2['dir'], $files2['subdir']); }


		return true;

	}

	public function update($x)
	{
		$data               = array();
		$id                 = $this->base64url_decode($x);
		$model              = $this->loadModel($this->model);
		$data['id_jenbel']  = ucwords(htmlspecialchars($_REQUEST['id_jenbel'])) ;
		$data['kd_akun']    = ucwords(htmlspecialchars($_REQUEST['kd_akun'])) ;
		$data['nm_akun']    = ucwords(htmlspecialchars($_REQUEST['nm_akun'])) ;
		$data['keterangan'] = ucwords(htmlspecialchars($_REQUEST['keterangan'])) ;
		$result             = $model->mupdate($this->table, $data, $this->primaryKey, $id, $this->title);
		$this->redirect('laplag');
	}

	public function delete($x)
	{
		$id     = $this->base64url_decode($x);
		$model  = $this->loadModel($this->model);
		$result = $model->mdelete($this->table, $this->primaryKey, $id, $this->title);
		return $result;
	}

	public function downloadpdf($key = null)
	{
		if($key){
			$id     = $this->base64url_decode($key);
			$model  = $this->loadModel($this->model);
			$data   = $model->getvalue("SELECT dir, kode_parent, subdir, nama_file FROM vt_files WHERE parent_id = $id AND dir = 'dochps'");
			$path   = $data[0]."/".$data[1]."/";
			//$result = $this->download_file($data[3], $path);
			echo $path.$data[3];
			return $result;
		} else {
			echo $path;
		}

	}

	public function downloadexcel($key = null)
	{
		if($key){
			$id     = $this->base64url_decode($key);
			$model  = $this->loadModel($this->model);
			$data   = $model->getvalue("SELECT dir, kode_parent, subdir, nama_file FROM vt_files WHERE parent_id = $id AND dir = 'excelhps'");
			$path   = $data[0]."/".$data[1]."/";
			$result = $this->download_file($data[3], $path);
			//echo $path.$data[3];
			return $result;
		} else {
			echo $path;
		}

	}

    
}