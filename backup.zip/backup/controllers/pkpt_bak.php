<?php

class Pkpt extends Controller {

	private $table      = "tpkpt_detil";
	private $tablePk    = "tpkpt";
	private $tableSat   = "tpkptsat";
	private $primaryKey = "autono";
	private $model      = "Pkpt_model";
	private $menu       = "Transaksi";
	private $title      = "PKPT";
	private $curl       = BASE_URL."pkpt";

	public function __construct()
	{
		$session = $this->loadHelper('Session_helper');
		if(!$session->get('username')){
			$this->redirect('auth/login');
		}
	}

	public function index()
	{
		$id                  = $this->base64url_decode($x);
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['curl']	     = $this->curl;
		$template            = $this->loadView('pkpt_view');
		$template->set('data', $data);
		$template->render();
	}

	public function detail()
	{
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['curl']	     = $this->curl;
		// $data['encode']      = $x;
		$template            = $this->loadView('pkpt_view');
		$template->set('data', $data);
		$template->render();
	}

	function get($x = null)
	{
		$request    = $_REQUEST;
		$uri        = $this->loadHelper('Url_helper');
		$pkpt       = $uri->segment(5);
		$id         = $this->base64url_decode($x);
		$columns = array(
			array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'nomor_pkpt',  'dt' => 1 ),
			array( 'db' => 'keterangan',  'dt' => 2 ),
			array( 'db' => 'flag',  'dt' => 3 ),
		);
		$model   = $this->loadModel($this->model);
		// $result  = $model->mget($request, $this->tablePk, $this->primaryKey, $columns);
		if($x){

			$result  = $model->mget_detail($request, $this->tablePk, $this->primaryKey, $columns, $id);

		} else {

			$result  = $model->mget($request, $this->tablePk, $this->primaryKey, $columns, 'autono', $pkpt);
			

		}
		return json_encode($result);
	}


	public function add()
	{
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Add';
		$data['curl']	     = $this->curl;
		// $data['encode']	     = $x;
		$data['id_kotama']	 = $model->get_satker($this->tableSat);
		$template            = $this->loadView('pkpt_add');
		$template->set('data', $data);
		$template->render();
	}

	public function jdwl()

	{
		$id                  = $this->base64url_decode($x);
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Jadwal';
		$data['curl']	     = $this->curl;
		// $id 			     = $_POST['autono'];
		// $data['encode']	     = $x;
		$data['id_jns_audit']= $model->get_jenisAudit();
		$data['pkpt']        = $model->get_PKPT();
		$data['id_kotama'] 	 = $model->get_kotamaEdit($this->tableSat, 'id_pkpt', $id);
		$data['aadata']      = $model->get($this->tablePk, $this->primaryKey, $id);
		$template            = $this->loadView('index_jadwal');
		$template->set('data', $data);
		$template->render();

	}

	// public function jdwlGet($x)

	// {
	// 	$id                  = $this->base64url_decode($x);
	// 	$model               = $this->loadModel($this->model);
	// 	$data                = array();
	// 	$data['breadcrumb1'] = $this->menu;
	// 	$data['title']       = $this->title;
	// 	$data['action']      = 'Jadwal';
	// 	$data['encode']      = $x;
	// 	$data['curl']	     = $this->curl;
	// 	// $id 			     = $_POST['autono'];
	// 	// $data['encode']	     = $x;
	// 	$data['id_jns_audit']= $model->get_jenisAudit();
	// 	$data['pkpt']        = $model->get_PKPT();
	// 	$data['id_kotama'] 	 = $model->get_kotamaEdit($this->tableSat, 'id_pkpt', $id);
	// 	$template            = $this->loadView('jadwal_readonly');
	// 	$template->set('data', $data);
	// 	$template->render();

	// }

	public function edit($x)
	{
		$id                  = $this->base64url_decode($x);
		$model               = $this->loadModel($this->model);
		// $uri                 = $this->loadHelper('Url_helper');
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Edit';
		$data['encode']      = $x;
		$data['curl']	     = $this->curl;
		// // $data['child']       = $uri->segment(5);
		
		$data['id_jns_audit']= $model->get_jenisAudit();
		$data['id_kotama'] 	 = $model->get_kotamaEdit($this->tableSat, 'id_pkpt', $id);
		$data['aadata']      = $model->get($this->table, $this->primaryKey, $id);
		$template            = $this->loadView('pkpt_edit');
		$template->set('data', $data);
		$template->render();
	}

	public function editPkpt($x)
	{
		$id                  = $this->base64url_decode($x);
		$model               = $this->loadModel($this->model);
		// $uri                 = $this->loadHelper('Url_helper');
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Edit';
		$data['encode']      = $x;
		$data['curl']	     = $this->curl;
		// // $data['child']       = $uri->segment(5);
		$data['aadata']      = $model->get($this->tablePk, $this->primaryKey, $id);
		$template            = $this->loadView('index_edit');
		$template->set('data', $data);
		$template->render();
	}

	public function approvePkpt($x)
	{
		$id                  = $this->base64url_decode($x);
		$model               = $this->loadModel($this->model);
		// $uri                 = $this->loadHelper('Url_helper');
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Approve';
		$data['encode']      = $x;
		$data['curl']	     = $this->curl;
		// // $data['child']       = $uri->segment(5);
		$data['aadata']      = $model->get($this->tablePk, $this->primaryKey, $id);
		$template            = $this->loadView('index_approve');
		$template->set('data', $data);
		$template->render();
	}

	public function save()
	{
		$data                 = array();
		$model                = $this->loadModel($this->model);
		$data['parent_id']    = $this->base64url_decode($x) ;
		$data['title']   	= htmlspecialchars($_REQUEST['title']) ;
		// $data['satker']       = htmlspecialchars($_REQUEST['satker']) ;
		$data['id_jns_audit']      = htmlspecialchars($_REQUEST['id_jns_audit']) ;
		$data['color']      = htmlspecialchars($_REQUEST['color']) ;
		$data['start'] = date("Y-m-d",strtotime($_REQUEST['start']));
		$data['end'] = date("Y-m-d",strtotime($_REQUEST['end'])) ;
		$data['autocode']     = $model->autocode($this->table, "#autocode#");	
		$result               = $model->msave($this->table, $data, $this->title);
		$lastid               = $result['id'];
		$jmlsat 		      = count($_REQUEST['satker']);

		for ($i=0; $i < $jmlsat ; $i++){
			$satker['autocode']  = $model->autocode($this->tableSat, "SPSAT_");
			$satker['id_pkpt']  = $lastid;
			$satker['id_kotama'] = htmlspecialchars($_REQUEST['satker'][$i]);
			$satker['title']   	= htmlspecialchars($_REQUEST['title']) ;
			$satker['start'] = date("Y-m-d",strtotime($_REQUEST['start']));
			$satker['end'] = date("Y-m-d",strtotime($_REQUEST['end'])) ;
			$satresult 			 = $model->msave($this->tableSat, $satker, $this->title);
		}

		$this->redirect('pkpt');

	}

	public function saveTo()
	{
		$data                 = array();
		$model                = $this->loadModel($this->model);
		$data['parent_id']    = $this->base64url_decode($x) ;
		$data['nomor_pkpt']   = htmlspecialchars($_REQUEST['nomor_pkpt']) ;
		// $data['satker']    = htmlspecialchars($_REQUEST['satker']) ;
		$data['keterangan']   = htmlspecialchars($_REQUEST['keterangan']) ;
		$data['flag']         = htmlspecialchars($_REQUEST['flag']) ;
		$data['autocode']     = $model->autocode($this->tablePk, "#autocode#");	
		$result               = $model->msave($this->tablePk, $data, $this->title);

		$this->redirect('pkpt');

	}

	public function update($x)
	{
		$data               = array();
		$sat 				= array();
		$id                 = $this->base64url_decode($x);
		$model              = $this->loadModel($this->model);
		$data['parent_id']  = $this->base64url_decode($x) ;
		// $uri                = $this->loadHelper('Url_helper');
		// $child              = $uri->segment(5);
		$data['title']	   	= htmlspecialchars($_REQUEST['title']) ;
		$data['id_jns_audit']	= htmlspecialchars($_REQUEST['id_jns_audit']);
		$data['start']  	= date("Y-m-d",strtotime($_REQUEST['start'])) ;
		$data['end']  		= date("Y-m-d",strtotime($_REQUEST['end'])) ;
		$data['color']		= htmlspecialchars($_REQUEST['color']) ;
		$result         	= $model->mupdate($this->table, $data, $this->primaryKey, $id, $this->title);

		$jmlsat               = count($_REQUEST['satker']);
		$hapusSatker 		  = $model->mdel($this->tableSat, 'id_pkpt', $id, $this->title);

		for ($j=0; $j < $jmlsat ; $j++) { 
			$satker['autocode']  = $model->autocode($this->tableSat, "SPSAT_");
			$satker['id_pkpt']   = $id;
			$satker['id_kotama'] = htmlspecialchars($_REQUEST['satker'][$j]);
			$satker['title']	   	= htmlspecialchars($_REQUEST['title']) ;
			$satker['start']  	= date("Y-m-d",strtotime($_REQUEST['start'])) ;
			$satker['end']  		= date("Y-m-d",strtotime($_REQUEST['end'])) ;
			$satresult           = $model->msave($this->tableSat, $satker, $this->title);
		}

		$this->redirect('pkpt/jdwlGet');

	}

	public function updatePkpt($x)
	{
		$data               = array();
		$sat 				= array();
		$id                 = $this->base64url_decode($x);
		$model              = $this->loadModel($this->model);
		$data['parent_id']  = $this->base64url_decode($x) ;
		// $uri                = $this->loadHelper('Url_helper');
		// $child              = $uri->segment(5);
		$data['nomor_pkpt']	   	= htmlspecialchars($_REQUEST['nomor_pkpt']) ;
		$data['keterangan']	= htmlspecialchars($_REQUEST['keterangan']);
		$data['flag']	= htmlspecialchars($_REQUEST['flag']);
		$result         	= $model->mupdate($this->tablePk, $data, $this->primaryKey, $id, $this->title);

		$this->redirect('pkpt');

	}

	Public function dragUpdateEvent()
	{	
		$model              = $this->loadModel($this->model);
		$result  			= $model->dragUpdateEvent();
		echo $result;
	}

	public function delete($x)
	{
		$id                 = $this->base64url_decode($x);
		$model              = $this->loadModel($this->model);
		$result 	        = $model->deleteEvent($id);
		// $resultSat          = $model->mdelete($this->tableSat, 'id_pkpt', $id,  $this->title);
		return $result;
	}

	// public function delete($x)
	// {
	// 	$id                 = $this->base64url_decode($x);
	// 	$model              = $this->loadModel($this->model);
	// 	$result             = $model->mdelete($this->table, $this->primaryKey, $id, $this->title);
	// 	$resultSat          = $model->mdelete($this->tableSat, 'id_pkpt', $id,  $this->title);

	// 	$this->redirect('pkpt');
	// }

	Public function getEvents()
	{
		$id 				= $_POST['autono'];
		$model              = $this->loadModel($this->model);
		$result             = $model->getpkpt_detils();
		echo json_encode($result);
	}

	Public function getChecked($id)
	{	
		$id 				= $_POST['autono'];
		$data 				= array();
		$model              = $this->loadModel($this->model);

		$result=$model->getChecked($id);
		echo json_encode($result);
	}

	/*Delete Event*/
	Public function deleteEvent()
	{
		$id  		= $_POST['autono'];
		$model   	= $this->loadModel($this->model);
		$result 	= $model->deleteEvent($id);
		return $result;
	}

	Public function updateEvent(){
		$id 		= $_POST['autono'];
		$model 		= $this->loadModel($this->model);
		$result 	= $model->updateEvent($id);

		$jmlsat               = count($_REQUEST['satker']);
		$hapusSatker 		  = $model->mdel($this->tableSat, 'id_pkpt', $id, $this->title);

		for ($j=0; $j < $jmlsat ; $j++) { 
			$satker['autocode']  	 = $model->autocode($this->tableSat, "SPSAT_");
			$satker['id_pkpt']    = $id;
			$satker['id_kotama'] = htmlspecialchars($_REQUEST['satker'][$j]);
			$satresult          = $model->msave($this->tableSat, $satker, $this->title);
		}
		echo $result; 
	}


}

