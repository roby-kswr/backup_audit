<?php

class Bast_post extends Controller {

	private $table      = "bast_post";
	private $tableSat   = "vt_upload_bast_post";
	private $primaryKey = "autono";
	private $primaryKey2 = "autocode";
	private $model      = "Bast_post_model"; # please write with no space
	private $menu       = "Ekstrak Data";
	private $title      = "BAST - Post ";
	private $curl       = BASE_URL."bast_post/";
	private $curl2      = BASE_URL."bast_post";
	

	public function __construct()
    {
        $session = $this->loadHelper('Session_helper');
        if(!$session->get('username')){
        	$this->redirect('auth/login');
        }
    }

	function index()
	{
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['curl']		 = $this->curl;
		$data['curl2']		 = $this->curl2;
		$template            = $this->loadView('bast_post_view');
		$template->set('data', $data);
		$template->render();
	}

	function get($x = null)
	{
		$request = $_REQUEST;
		$columns = array(
			array( 'db' => 'autono',      'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'no_bast',    'dt' => 1  ),
			array( 'db' => 'tahun',       'dt' => 2 ),
			array( 'db' => 'file_name',   'dt' => 3 ),
			array( 'db' => 'nm_satminkal','dt' => 4 ),
			array( 'db' => 'autocode',    'dt' => 5 ),
			array( 'db' => 'program',     'dt' => 6 ),
			array( 'db' => 'giat',        'dt' => 7 ),
			array( 'db' => 'output',      'dt' => 8 ),
			array( 'db' => 'suboutput',   'dt' => 9 ),
			array( 'db' => 'komponen',    'dt' => 10 ),
			array( 'db' => 'subkomponen', 'dt' => 11 ),
			array( 'db' => 'akun',        'dt' => 12 ),
			array( 'db' => 'sum_score',   'dt' => 13 )
			
			
		);

		// $join = "a
		// 		 LEFT JOIN (SELECT nm_satminkal,kd_satminkal AS kode_satminkal FROM tsatminkal ) AS b ON a.satminkal = b.kode_satminkal";

		$model   = $this->loadModel($this->model);
		if($x){
			$result  = $model->mget_detail($request, $this->table, $this->primaryKey, $columns,$join, $id);
		} else {
			$result  = $model->mget($request, $this->table, $this->primaryKey, $columns);
		}

		return json_encode($result);
	}

	public function add()
	{
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Add';
		$data['curl']		 = $this->curl;

		$data['id_kontrak']	 = $model->get_kontrak1();
        $data['satminkal']	 = $model->get_satmin();
        $data['program']	 = $model->get_program();
        $data['giat']		 = $model->get_kegiatan();
        $data['output']		 = $model->output();
        $data['suboutput']   = $model->suboutput();
        $data['komponen']    = $model->get_komponen();
        $data['subkomponen'] = $model->get_subkomponen();
        $data['akun'] 		 = $model->get_akun();

		$template            = $this->loadView('bast_post_add');
		$template->set('data', $data);
		$template->render();
	}

	public function edit($x)
	{
		$id                  = $this->base64url_decode($x);
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Edit';
		$data['encode']      = $x;
		$data['curl']		 = $this->curl;
		$data['aadata']      = $model->get($this->table, $this->primaryKey, $id);

		$data['satminkal']	 = $model->get_satmin();
        $data['program']	 = $model->get_program();
        $data['giat']		 = $model->get_kegiatan();
        $data['output']		 = $model->output();
        $data['suboutput']   = $model->suboutput();
        $data['komponen']    = $model->get_komponen();
        $data['subkomponen'] = $model->get_subkomponen();
        $data['akun'] 		 = $model->get_akun();

		$template            = $this->loadView('bast_post_edit');
		$template->set('data', $data);
		$template->render();
	}

	public function save()

	{


		$data                 = array();

		$model                = $this->loadModel($this->model);
		$data['parent_id']    = $this->base64url_decode($x) ;

		$data['id_kontrak']   = htmlspecialchars($_REQUEST['id_kontrak']) ;
		$data['satminkal']    = htmlspecialchars($_REQUEST['satminkal']) ;
		$data['program']      = htmlspecialchars($_REQUEST['program']) ;
		$data['giat']         = htmlspecialchars($_REQUEST['giat']) ;
		$data['output']       = htmlspecialchars($_REQUEST['output']) ;
		$data['suboutput']    = htmlspecialchars($_REQUEST['suboutput']) ;
		$data['komponen']     = htmlspecialchars($_REQUEST['komponen']) ;
		$data['subkomponen']  = htmlspecialchars($_REQUEST['subkomponen']) ;
		$data['akun']         = htmlspecialchars($_REQUEST['akun']) ;

		$data['no_bast']   	  = htmlspecialchars($_REQUEST['no_bast']) ;		
		$data['tahun']        = htmlspecialchars($_REQUEST['tahun']) ;
		$data['file_name']    = $_FILES['file_name']['name'] ;
		$data['autocode']     = $model->autocode($this->table, "ekbast_");
		// $s	  				  = $model->aut();
		
		$result               = $model->msave($this->table, $data, $this->title);
		$last_id              = $result['id'];

		// # Insert files
		// $files1        = array();
		// $files1['dir'] = "TOR_POST";
		// if(!empty($_FILES['file_dokumen']['name'][0])) {
		//     $file_ary1 = $model->reArrayFiles($_FILES['file_dokumen']);
		//     foreach ($file_ary1 as $file1) {
		// 		$files1['kode_parent'] = $data['autocode'];
		// 		$files1['parent_id']   = $lastid;
		// 		$files1['nama_file']   = $this->randName($file1['name']);
		// 		$files1['tipe_file']   = $file1['type'];
		// 		$files1['ukuran']      = $file1['size'];
		// 		$files1['ftable']      = $this->table;

		// 		if(!empty($file1['name'])){ $model->savefile($files1); } 
		//     }
		// }

		// # Upload file
		// if(isset($_FILES['file_dokumen'])){ $model->uploads('TOR_POST', $_FILES['file_dokumen'], $data['autocode']); }

		$uploadDyn			  = $model->uploadBastpos($_FILES['file_name'],$data['satminkal'],$data['tahun'],$data['autocode']);

		$import_bast		  = $model->import_bast_post($data['satminkal'],$data['tahun'], $s, $data['autocode'], $last_id);
        
        $this->redirect('bast_post_detail/detail/'.$data['satminkal'].'/'.$data['autocode']);
        // $this->redirect('ekstrakbast');
	}

	public function update($x)
	{
		$data           	= array();
		$id             	= $this->base64url_decode($x);
		$model          	= $this->loadModel($this->model);
		$data['satker']     = htmlspecialchars($_REQUEST['satker']) ;
		$data['tahun']      = htmlspecialchars($_REQUEST['tahun']) ;
		$data['file_name']	= htmlspecialchars($_REQUEST['file_name']) ;
		$result         	= $model->mupdate($this->table, $data, $this->primaryKey, $id, $this->title);
		$this->redirect('bast_post');
	}

	public function delete($x)
	{
		$id        = $this->base64url_decode($x);
		$model     = $this->loadModel($this->model);
		$resultSat = $model->mdelete($this->tableSat,'parent_id', $id, $this->title);
		$result    = $model->mdelete($this->table, $this->primaryKey,$id, $this->title);
		
		
		return $result;
	}

}