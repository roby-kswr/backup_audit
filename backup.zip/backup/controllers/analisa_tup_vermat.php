<?php



class Analisa_tup_vermat extends Controller {



	// private $table      = "vt_vermat_renlak";
	private $table      = "tsatminkal";

	private $table2		= "vt_jnhv_vermat";

	private $table3		= "vt_vermat_tup";

	private $tableTemb   = "ttuptemb_vermat";

	private $primaryKey = "autono";

	// private $primaryKey2 = "kategori";

	private $primaryKey3 = "tahun";

	private $primaryKey4 = "bulan";

	private $primaryKey5 = "kotama";

	private $primaryKey6 = "satminkal";

	private $model      = "Analisa_tup_vermat_model";

	private $menu       = "Analisa";

	private $title      = "TUP Nota Hasil Verifikasi";

	private $curl       = BASE_URL."analisa_tup_vermat";

	private $curl2      = BASE_URL."laporan_hasil_temuan/vermat_1";

	private $curl3      = BASE_URL."dasar_tup_vermat";






	public function __construct()

    {

        $session = $this->loadHelper('Session_helper');

        if(!$session->get('username')){

        	$this->redirect('auth/login');

        }

    }

	// J NHV

	function index()

	{

		$data                = array();

		$data['breadcrumb1'] = $this->menu;

		$data['title']       = $this->title;

		$data['curl']	     = $this->curl;

		$data['curl2']	     = $this->curl2;

		$data['curl3']	     = $this->curl3;

		$template            = $this->loadView('analisa_tup_vermat_view');

		$template->set('data', $data);

		$template->render();

	}

		public function detail($x)

	{

		$id                  = $this->base64url_decode($x);

		$model               = $this->loadModel($this->model);

		$uri                 = $this->loadHelper('Url_helper');

		$data                = array();

		$data['breadcrumb1'] = $this->menu;

		$data['title']       = "Tanggapan Jawaban Nota hasil Verifikasi";

		// $data['action']      = 'Edit';

		$data['encode']      = $x;

		$data['curl']	     = $this->curl;

		$data['autono']		 = $uri->segment(4);

		$data['tahun']		 = $uri->segment(5);

		$data['bulan']		 = $uri->segment(6);

		$data['kotama']		 = $uri->segment(7);

		$data['satminkal']	 = $uri->segment(8);

		// $data['child']       = $uri->segment(5);

		$data['aadata']      = $model->get($this->table, $this->primaryKey, $id);

		$template            = $this->loadView('analisa_tup_vermat_detail');

		$data['aadata']      = $model->getvalue("SELECT * FROM vt_jnhv_vermat WHERE autono = '$data[autono]' AND kotama = '$data[kotama]' AND satminkal = '$data[satminkal]'  AND tahun = '$data[tahun]' AND bulan = '$data[bulan]'");

		// $data['stat']		 = $model->query("SELECT * FROM t_nhv_status ORDER BY autono DESC"); 

		$template->set('data', $data);

		$template->render();

	}


	function get($tahun , $bulan)

	{

		$request    = $_REQUEST;

		// $uri        = $this->loadHelper('Url_helper');

		// $id         = $this->base64url_decode($x);


		// $tahun = $uri->segment(5);

		// $bulan = $uri->segment(6);

		$columns = array(

			array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),

			array('db'=>'autono_j', 'dt'=> 1),
			array( 'db' => 'kd_satminkal',  'dt' => 2 ),
			array( 'db' => 'nm_satminkal',  'dt' => 3 ),
			array( 'db' => 'jawaban',  'dt' => 4 ),
			array('db'=>'kd_kotama', 'dt'=> 5 ),
			array('db'=> 'status_jawaban','dt'=>6),
			array('db' =>'tanggapan_jawaban', 'dt'=> 7)
		);



		$model   = $this->loadModel($this->model);

			$join   = " AS t2
						LEFT JOIN (SELECT a.autono AS autono_j, a.kotama AS kotama, a.satminkal AS satminkal , a.jawaban AS jawaban, a.status_jawaban AS status_jawaban, a.tanggapan_jawaban AS tanggapan_jawaban  FROM vt_jnhv_vermat a 
						LEFT JOIN (SELECT MAX(autono) AS autono FROM vt_jnhv_vermat WHERE tahun='".$tahun."' AND bulan='".$bulan."' GROUP BY kotama, satminkal) AS t1 ON a.autono = t1.autono
						WHERE t1.autono IS NOT NULL) t3 ON t2.kd_kotama = t3.kotama AND t2.kd_satminkal = t3.satminkal 
						WHERE kd_satminkal IN (SELECT satminkal FROM vt_vermat_temuan WHERE tahun='".$tahun."' AND bulan='".$bulan."' GROUP BY satminkal)
						order by nm_satminkal asc
						";
		// if($x){

			$result  = $model->mget_detail($request, $this->table, $this->primaryKey, $columns, $join);

		// } else {

		// 	$result  = $model->mget($request, $this->table, $this->primaryKey, $columns);

		// }

		return json_encode($result);
	}



	public function add()

	{
		$uri 				 = $this->loadHelper('Url_helper');

		$model               = $this->loadModel($this->model);

		$data                = array();

		$data['breadcrumb1'] = $this->menu;

		$data['title']       = $this->title;

		$data['action']      = 'Add';

		$data['curl']	     = $this->curl;

		// $data['encode']	     = $x;

		$data['tahun']		 = $uri->segment(4);

		$data['bulan']		 = $uri->segment(5);

		$data['kotama']		 = $uri->segment(6);

		$data['satminkal']	 = $uri->segment(7);



		$template            = $this->loadView('analisa_tup_vermat_add');

		$template->set('data', $data);

		$template->render();

	}



	public function edit($x)

	{

		$id                  = $this->base64url_decode($x);

		$model               = $this->loadModel($this->model);

		$uri                 = $this->loadHelper('Url_helper');

		$data                = array();

		$data['breadcrumb1'] = $this->menu;

		$data['title']       = $this->title;

		$data['action']      = 'Edit';

		$data['encode']      = $x;

		$data['curl']	     = $this->curl;

		$data['kotama']		 = $uri->segment(4);

		$data['satminkal']	 = $uri->segment(5);

		$data['tahun']		 = $uri->segment(6);

		$data['bulan']		 = $uri->segment(7);

		// echo $data['kotama'];exit;
		// $data['id_tembusan']      = $model->get_tembusan();

		// $data['aadata']      = $model->get($this->table, $this->primaryKey, $id);

		$template            = $this->loadView('analisa_tup_vermat_edit');

		$data['aadata']      = $model->getvalue("SELECT * FROM vt_vermat_tup WHERE kotama = '$data[kotama]' AND satminkal = '$data[satminkal]'  AND tahun = '$data[tahun]' AND bulan = '$data[bulan]'");

		$data['tanda_tangan']		 = $model->query("SELECT nrp,nm_personel FROM ttandatangan ORDER BY nm_personel asc"); 

		$data['id_tembusan']      = $model->get_tuptembusanEdit($this->tableTemb, 'tahun', $data['tahun'], 'bulan', $data['bulan'], 'kotama', $data['kotama'], 'satminkal', $data['satminkal']);
		

		$template->set('data', $data);

		$template->render();

	}



	public function save($x = null)

	{

		$data                 	= array();

		$uri 					= $this->loadHelper('Url_helper');

		$model                	= $this->loadModel($this->model);

		// $data['parent_id']    	= $this->base64url_decode($x) ;

		$data['tahun']		 	= $uri->segment(4);

		$data['bulan']		 	= $uri->segment(5);

		$data['kotama']		 	= $uri->segment(6);

		$data['satminkal']	 	= $uri->segment(7);

		$data['jawaban'] 		= htmlspecialchars($_REQUEST['jawaban']) ;

		$data['upload']        = $_FILES['upload']['name'];

		$data['status_jawaban'] = htmlspecialchars($_REQUEST['status']) ;
	
		$uploadDyn			 = $model->uploadRenlak($_FILES['upload'],$data['kotama'],$data['satminkal'],$data['tahun'],$data['bulan'],'jnhv');

		$data['autocode']     = $model->autocode($this->table, "#autocode#");	

		$result               = $model->msave($this->table2, $data, $this->title);
		if ($result) {
			echo "<script>alert('berhasil')</script>". $this->redirect('analisa_tup_vermat');
		}else{
			echo "<script>alert('gagal')</script>". $this->redirect('analisa_tup_vermat');
		}


	}



	public function update($x)

	{
		$temb               = array();
		$data               = array();

		$id                 = $this->base64url_decode($x);

		$model              = $this->loadModel($this->model);

		$uri                = $this->loadHelper('Url_helper');

		// $child              = $uri->segment(5);

        // $autono  			 = $uri->segment(4);
       
		$tahun				 = $uri->segment(4);

		$bulan 				 = $uri->segment(5);

		$kotama 			 = $uri->segment(6);

		$satminkal 			 = $uri->segment(7);

		$data['tahun'] = $uri->segment(4);

		$data['bulan'] = $uri->segment(5);

		$data['kotama']		 = $uri->segment(6);

		$data['satminkal']	 = $uri->segment(7);

		$data['nomor_nhv']  = htmlspecialchars($_REQUEST['nomor_nhv']) ;

		$data['tanggal'] = htmlspecialchars($_REQUEST['tanggal']) ;

		$data['tanda_tangan'] 		= htmlspecialchars($_REQUEST['tanda_tangan']) ;

		$jmlCmbTemb           = count($_REQUEST['temb']);
		
		$result = $model->getvalue("SELECT * FROM vt_vermat_tup WHERE kotama = '$data[kotama]' AND satminkal = '$data[satminkal]' AND tahun = '$data[tahun]' AND bulan = '$data[bulan]'");

		// echo $result['autono'];exit;
		if($result['autono']!='')
		{
		$result             = $model->mupdate($this->table3, $data, $this->primaryKey5, $kotama, $this->primaryKey6, $satminkal, $this->primaryKey3, $tahun, $this->primaryKey4, $bulan, $this->title);
		$resultdTemb          = $model->mdelete2($this->tableTemb, 'tahun', $data['tahun'], 'bulan', $data['bulan'], 'kotama', $data['kotama'], 'satminkal', $data['satminkal'], $this->title);
		for ($i=0; $i < $jmlCmbTemb ; $i++) { 
			$temb['autocode']    = $model->autocode($this->tableTemb, "SPTEMB_");

			$temb['tahun'] = $uri->segment(4);

			$temb['bulan'] = $uri->segment(5);

			$temb['kotama']		 = $uri->segment(6);

			$temb['satminkal']	 = $uri->segment(7);

			$temb['id_tembusan'] = htmlspecialchars($_REQUEST['temb'][$i]);

			$tembresult          = $model->msave($this->tableTemb, $temb, $this->title);
		}
		}
		else
		{
		$result               = $model->msave($this->table3, $data, $this->title);	

		for ($i=0; $i < $jmlCmbTemb ; $i++) { 
			$temb['autocode']    = $model->autocode($this->tableTemb, "SPTEMB_");

			$temb['tahun'] = $uri->segment(4);

			$temb['bulan'] = $uri->segment(5);

			$temb['kotama']		 = $uri->segment(6);

			$temb['satminkal']	 = $uri->segment(7);

			$temb['id_tembusan'] = htmlspecialchars($_REQUEST['temb'][$i]);

			$tembresult          = $model->msave($this->tableTemb, $temb, $this->title);
		}
		}
	
		
		// $result  = $model->mupdate($this->table2, $data,  $this->primaryKey, $autono, $this->primaryKey1, $tahun, $this->primaryKey2, $bulan,$this->primaryKey3, $kotama,$this->primaryKey4, $satminkal,  $this->title);


		$this->redirect('analisa_tup_vermat');

	}


	


    

}