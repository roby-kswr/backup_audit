<?php
/**
 * 
 */
class Laporan_hasil_temuan extends Controller
{
    private $table      = "vt_verku_temuan";

    private $primaryKey = "autono";

    private $model      = "Laporan_hasil_temuan_model";

    private $title      = "Laporan hasil temuan";

    private $menu       = "Laporan";

    private $curl       = BASE_URL."laporan_hasil_temuan";
   
   function __construct()
   {
      
      $session = $this->loadHelper('Session_helper');

        if(!$session->get('username')){

         $this->redirect('auth/login');


        }
   }
   
   function index()
   {
      $model = $this->loadModel($this->model);

      $data                = array();
      $data['breadcrumb1'] = $this->menu;
      $data['curl']        = $this->curl;
      $data['title']       = $this->title;
      $data['kotama']      = $model->getkotama();
      $template            = $this->loadView('laporan_hasil_temuan_view');
      $template->set('data', $data);
      $template->render();
   }

     function get_satminkal()
     {
       $model       = $this->loadModel($this->model);
       $kdkotama    = $_REQUEST['kd_kotama'];
       $data      = $model->getSatminkal($kdkotama);
       echo json_encode($data);
     } 

  function get($tahun,$bulan)
  {

    $request    = $_REQUEST;

   
    $columns = array(

      array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
      array( 'db' => 'bulan',  'dt' => 1 ),
      array( 'db' => 'tahun',  'dt' => 2 ),
      array( 'db' => 'nm_satminkal',  'dt' => 3 ),
      array( 'db' => 'satminkal',  'dt' => 4 ),
      array( 'db' => 'kategori',  'dt' =>  5),


    );
    $model   = $this->loadModel($this->model);
    
    $result  = $model->mget($request,$this->table, $this->primaryKey, $columns,$tahun,$bulan);



    return json_encode($result);

  }
   
       function verku_1()
    {

         $model = $this->loadModel($this->model);
       

         $help  = $this->loadHelper('Url_helper');

         $tahun      = $help->segment(4);

         $bulan      = $help->segment(5);

         $satminkal  = $help->segment(6);

         $v     = $model->getvalue("SELECT * FROM vt_verku_temuan a LEFT JOIN tsatminkal b ON 
                                    a.satminkal = b.kd_satminkal WHERE  a.satminkal = '$satminkal' AND bulan = '$bulan' AND tahun = '$tahun' GROUP BY satminkal"); 

         $var   = $model->getvalue("SELECT * FROM vt_verku_temuan a LEFT JOIN tsatminkal b ON 
                                    a.satminkal = b.kd_satminkal WHERE a.kategori = '1' AND a.status_temuan = '1' AND  a.satminkal = '$satminkal' AND bulan = '$bulan' AND tahun = '$tahun' ");

         $kat   = $var['kategori'];

         $temuan = $model->query("SELECT * FROM vt_verku_temuan_detail WHERE  satminkal = '$satminkal' AND tahun = '$tahun' AND bulan = '$bulan' AND kategori = '$kat' AND parent_id = 0 ORDER BY `order` ASC ");


         $dasar = $model->query("SELECT * FROM vt_verku_nhv_dasar WHERE  satminkal = '$satminkal' AND tahun = '$tahun' AND bulan = '$bulan'  ORDER BY `order` ASC");

         $tembusan  = $model->query("SELECT b.nm_tembusan FROM nhv_temb_verku a LEFT JOIN  ttembusan b ON a.id_tembusan = b.autono 
                                      WHERE  a.satminkal = '$satminkal' AND a.tahun = '$tahun' AND a.bulan = '$bulan'  ORDER BY a.id_tembusan ASC");

         $ttd  = $model->getvalue("SELECT b.nrp,b.nama,a.klasifikasi,a.lampiran,a.perihal,b.jabatan,nm_pangkat FROM vt_verku_nhv a     
                                    LEFT JOIN tpers b ON b.nrp = a.tanda_tangan
                                    LEFT JOIN tpangkat c ON b.id_pangkat =  c.kd_pangkat WHERE a.satminkal = '$satminkal' AND a.tahun = '$tahun' AND 
                                    a.bulan = '$bulan'");

         $nomor  = $model->getvalue("SELECT nomor_nhv FROM vt_verku_tup WHERE satminkal = '$satminkal' AND tahun = '$tahun' AND bulan = '$bulan'  ");


         $pdf = $this->loadLibrary('fpdf');
        
         $pdf->setAutoPageBreak(true,27);   
         $pdf->SetMargins(25.4,20.3,15.2,12.7); // Format A4
         $pdf->AddPage('P','A4');
        
         // Header

         $pdf->SetFont('Arial', '', 10);  

         $pdf->header();
         $pdf->Cell(65, -6, 'MARKAS BESAR ANGKATAN DARAT', 0, 1, 'C');
         $pdf->Cell(64, 15, 'INSPEKTORAT JENDERAL', 0, 1, 'C');
         $pdf->Cell(2);
         $pdf->Cell(62,-5,'','B',1);
         $pdf->Cell(220, 10, 'Bandung,              '.$help->getBulan($v['bulan']).' '. $v['tahun'], 0, 1, 'C');
         $pdf->Ln(5);

         // Kop
     
         $pdf->Cell(25, 5, 'Nomor', 0, 'LTR', 'L');
         $pdf->Cell(-2, 5, ':', 0, 'LTR','C');
         $pdf->Cell(2);
         $pdf->MultiCell(110, 5, $nomor['nomor_nhv'].'/NHV-Verku.'.$help->getRomawi($v['bulan']).'/'.$v['tahun'], 'J');
         $pdf->Cell(28, 5, 'Klasifikasi', 0, 'LTR', 'L');
         $pdf->Cell(-8, 5, ':', 0, 'LTR','C');
         $pdf->Cell(5);
         $pdf->MultiCell(110, 5, $ttd['klasifikasi'], 'J');
         $pdf->Cell(28, 5, 'Lampiran', 0, 'LTR', 'L');
         $pdf->Cell(-8, 5, ':', 0, 'LTR','C');
         $pdf->Cell(5);
         $pdf->MultiCell(110, 5,$ttd['lampiran'], 'J');
         $pdf->Cell(28, 5, 'Perihal', 0, 'LTR', 'L');
         $pdf->Cell(-8, 5, ': ', 0, 'LTR','C');
         $pdf->Cell(5);
         $pdf->MultiCell(60, 5,$ttd['perihal'], 'J');
         $pdf->Cell(26);
         $pdf->Cell(58,0,'','B',1);
         $pdf->Ln(5);

         $pdf->Cell(240, 5, 'Kepada', 0, 1, 'C');
         $pdf->Ln(2);
         $pdf->Cell(103);
         $pdf->Cell(10, 4, 'Yth.', 0, 0);
         $pdf->MultiCell(33, 4, strtolower(ucfirst($v['nm_satminkal'])), 0,'J');
         $pdf->Ln(2);
         $pdf->Cell(232, 7, 'di', 0, 1, 'C');
         $pdf->Cell(243, 7, 'Bandung', 0, 1, 'C');
         $pdf->Ln(5);


         // Content

         $pdf->Cell(25, 5, 'U.p.Sekertaris', 0, 'LTR', 'L');
         $pdf->Ln(5);
         $pdf->Cell(10,5,'1.',0,0);
         $pdf->MultiCell(25,5,'Dasar :',0,'J');
         // $pdf->Ln(3);
         $pdf->Cell(15);

         $no = 'a';
         foreach ($dasar as $v) {
        $pdf->Cell(10,5,$no++.'.',0,0);
         $pdf->MultiCell(125,5,strip_tags($v['keterangan']),0,'J');
         $pdf->Ln(2);
         $pdf->Cell(15);
         }

         $pdf->Cell(10,1,'',0,1);
         // $pdf->Cell(5);
         $pdf->Cell(10,5,'2. ',0,0);
         $pdf->MultiCell(140,5,'Sesuai dasar tersebut diatas, disampaikan Nota Hasil Verifikasi (NHV) pertanggungjawaban keuangan '.strtolower(ucfirst($v['nm_satminkal'])).' bulan '.$help->getBulan($v['bulan']).' '. $v['tahun']. ' sebagai berikut : ',0,'J');
         $pdf->Ln(4);
         $pdf->Cell(15);

         $pdf->Cell(10,5,'a.',0,0);
         $pdf->Cell(110,5,'Pertanggungjawaban keuangan yang tidak sesuai peruntukannya',0,1);
         $pdf->Ln(5);       

          
         if ($var['kategori'] == 1 && $var['status_temuan'] == 1 ) {

         $pdf->Cell(25);
         $pdf->Cell(10,5,'1) ',0,0);
         $pdf->Cell(40,5,'Belanja Perosonel',0,1);
         $pdf->Ln(4);

         $abj = 'a';
         foreach ($temuan as $val) {
         $pdf->Cell(35);
         $pdf->Cell(10,5,$abj++.') ',0,0);
         $pdf->MultiCell(108,5,strip_tags($val['keterangan']),0,'J');
         $pdf->Ln(4);
         $pars = $val['autono'];
         $parent = $model->getvalue("SELECT parent_id FROM vt_verku_temuan_detail WHERE  autono = '$pars'");
         $no = 1;


         if ($val['autono'] == $parent['parent_id']) {
    
         // $parent_id = $parent['parent_id'];

         // var_dump($parent_id);
         $dtil = $model->query("SELECT * FROM vt_verku_temuan_detail WHERE parent_id = '$parent[parent]' ORDER BY `order` ASC ");
         foreach ($dtil as $key ) {
         $pdf->Cell(45);
         $pdf->Cell(10,5,'('.$no++.')',0,0);
         $pdf->MultiCell(99,5,strip_tags($key['keterangan']),0,'J');   
         $pdf->Ln(3);
         }
         

            }
         }
        }else{
         $pdf->Cell(25);
         $pdf->Cell(10,5,'1) ',0,0);
         $pdf->Cell(40,5,'Belanja Perosonel Nihil',0,1);
        }
      
         $var1   = $model->getvalue("SELECT * FROM vt_verku_temuan a LEFT JOIN tsatminkal b ON a.satminkal = b.kd_satminkal  WHERE a.kategori = '4' AND a.status_temuan = '1'AND  a.satminkal = '$satminkal' AND bulan = '$bulan' AND tahun = '$tahun' ");

         $kat1   = $var1['kategori'];

     
         $temuan1 = $model->query("SELECT * FROM vt_verku_temuan_detail WHERE  satminkal = '$satminkal' AND tahun = '$tahun' AND bulan = '$bulan' AND kategori = '$kat1' AND parent_id = 0 ORDER BY `order` ASC ");


         if ($var1['kategori'] == 4 && $var1['status_temuan']  == 1 ) {

         $pdf->Cell(25);
         $pdf->Cell(10,5,'2) ',0,0);
         $pdf->Cell(40,5,'Belanja Barang',0,1);
         $pdf->Ln(4);

         $abj = 'a';
         foreach ($temuan1 as $val1) {
         $pdf->Cell(35);
         $pdf->Cell(10,5,$abj++.') ',0,0);
         $pdf->MultiCell(108,5,strip_tags($val1['keterangan']),0,'J');
         $pdf->Ln(4);
         $pars = $val1['autono'];
         $parent1 = $model->getvalue("SELECT parent_id FROM vt_verku_temuan_detail WHERE  autono = '$pars'");
         $no = 1;


         if ($val1['autono'] == $parent1['parent_id']) {
    
         // $parent_id = $parent['parent_id'];

         // var_dump($parent_id);
         $dtil = $model->query("SELECT * FROM vt_verku_temuan_detail WHERE parent_id = '$parent1[parent]' ORDER BY `order` ASC ");
         foreach ($dtil as $key ) {
         $pdf->Cell(45);
         $pdf->Cell(10,5,'('.$no++.')',0,0);
         $pdf->MultiCell(99,5,strip_tags($key['keterangan']),0,'J');   
         $pdf->Ln(3);
         }
         

            }
         }
        }else{
         $pdf->Cell(25);
         $pdf->Cell(10,5,'2) ',0,0);
         $pdf->Cell(40,5,'Belanja Barang Nihil',0,1);
        }




         $var2   = $model->getvalue("SELECT * FROM vt_verku_temuan a LEFT JOIN tsatminkal b ON a.satminkal = b.kd_satminkal WHERE a.kategori = '5' AND a.status_temuan = '1' AND a.satminkal = '$satminkal' AND a.tahun = '$tahun' AND a.bulan = '$bulan' ");

         $kat2   = $var2['kategori'];

     
         $temuan2 = $model->query("SELECT * FROM vt_verku_temuan_detail WHERE  satminkal = '$satminkal' AND tahun = '$tahun' AND bulan = '$bulan' AND kategori = '$kat2' AND parent_id = 0 ORDER BY `order` ASC ");


         if ($var2['kategori'] == 5 && $var2['status_temuan']  == 1 ) {

         $pdf->Cell(25);
         $pdf->Cell(10,5,'3) ',0,0);
         $pdf->Cell(40,5,'Belanja Modal',0,1);
         $pdf->Ln(4);

         $abj = 'a';
         foreach ($temuan2 as $val2) {
         $pdf->Cell(35);
         $pdf->Cell(10,5,$abj++.') ',0,0);
         $pdf->MultiCell(108,5,strip_tags($val1['keterangan']),0,'J');
         $pdf->Ln(4);
         $pars = $val2['autono'];
         $parent2 = $model->getvalue("SELECT parent_id FROM vt_verku_temuan_detail WHERE  parent_id = '$pars'");
         $no = 1;


         if ($val2['autono'] == $parent2['parent_id']) {
    
         // $parent_id = $parent['parent_id'];

         // var_dump($parent_id);
         $dtil = $model->query("SELECT * FROM vt_verku_temuan_detail WHERE parent_id = '$parent2[parent]'  ORDER BY `order` ASC");
         foreach ($dtil as $key ) {
         $pdf->Cell(45);
         $pdf->Cell(10,5,'('.$no++.')',0,0);
         $pdf->MultiCell(99,5,strip_tags($key['keterangan']),0,'J');   
         $pdf->Ln(3);
         }
         

            }
         }
        }else{
         $pdf->Cell(25);
         $pdf->Cell(10,5,'3) ',0,0);
         $pdf->Cell(40,5,'Belanja Modal Nihil',0,1);
        }

         $pdf->Cell(15);
         $pdf->Cell(10,5,'b.',0,0);
         $pdf->Cell(110,5,'Pertanggungjawaban keuangan yang diragukan kebenarannya  ',0,1);
         $pdf->Ln(5);



         $get   =$model->getvalue("SELECT * FROM vt_verku_temuan a LEFT JOIN tsatminkal b ON a.satminkal = b.kd_satminkal WHERE a.kategori = '1' AND a.status_temuan = '2'  AND a.satminkal = '$satminkal' AND a.tahun = '$tahun' AND a.bulan = '$bulan' ");

         $kat   = $get['kategori'];

        
         $tem = $model->query("SELECT * FROM vt_verku_temuan_detail WHERE  satminkal = '$satminkal' AND tahun = '$tahun' AND bulan = '$bulan' AND kategori = '$kat' AND parent_id = 0 ORDER BY `order` ASC ");


         if ($get['kategori'] == 1 && $get['status_temuan']  == 2 ) {

         $pdf->Cell(25);
         $pdf->Cell(10,5,'1) ',0,0);
         $pdf->Cell(40,5,'Belanja Personel',0,1);
         $pdf->Ln(4);

         $abj = 'a';
         foreach ($tem as $va) {
         $pdf->Cell(35);
         $pdf->Cell(10,5,$abj++.') ',0,0);
         $pdf->MultiCell(108,5,strip_tags($va['keterangan']),0,'J');
         $pdf->Ln(4);
         $pars = $va['autono'];
         $paren = $model->getvalue("SELECT parent_id FROM vt_verku_temuan_detail WHERE  parent_id = '$pars'");
         $no = 1;
         if ($va['autono'] == $paren['parent_id']) {
    
         // $parent_id = $parent['parent_id'];

         // var_dump($parent_id);
         $dtil = $model->query("SELECT * FROM vt_verku_temuan_detail WHERE parent_id = '$paren[parent]' ORDER BY `order` ASC");
         foreach ($dtil as $key ) {
         $pdf->Cell(45);
         $pdf->Cell(10,5,'('.$no++.')',0,0);
         $pdf->MultiCell(99,5,strip_tags($key['keterangan']),0,'J');   
         $pdf->Ln(3);
         }
         

            }
         }
        }else{
         $pdf->Cell(25);
         $pdf->Cell(10,5,'1) ',0,0);
         $pdf->Cell(40,5,'Belanja Personel Nihil',0,1);
        }


         $get1   = $model->getvalue("SELECT * FROM vt_verku_temuan a LEFT JOIN tsatminkal b ON a.satminkal = b.kd_satminkal WHERE a.kategori = '4' AND a.status_temuan = '2'  AND a.satminkal = '$satminkal' AND a.tahun = '$tahun' AND a.bulan = '$bulan' ");

         $kat1   = $get1['kategori'];

     
         $tem1 = $model->query("SELECT * FROM vt_verku_temuan_detail WHERE  satminkal = '$satminkal' AND tahun = '$tahun' AND bulan = '$bulan' AND kategori = '$kat1' AND parent_id = 0  ORDER BY `order` ASC");


         if ($get1['kategori'] == 4 && $get1['status_temuan']  == 2 ) {

         $pdf->Cell(25);
         $pdf->Cell(10,5,'2) ',0,0);
         $pdf->Cell(40,5,'Belanja barang',0,1);
         $pdf->Ln(4);

         $abj = 'a';
         foreach ($tem1 as $va1) {
         $pdf->Cell(35);
         $pdf->Cell(10,5,$abj++.') ',0,0);
         $pdf->MultiCell(108,5,strip_tags($va1['keterangan']),0,'J');
         $pdf->Ln(4);
         $pars = $va1['autono'];
         $paren1 = $model->getvalue("SELECT parent_id FROM vt_verku_temuan_detail WHERE  parent_id = '$pars'");
         $no = 1;


         if ($va1['autono'] == $paren1['parent_id']) {
    
         // $parent_id = $parent['parent_id'];

         // var_dump($parent_id);
         $dtil = $model->query("SELECT * FROM vt_verku_temuan_detail WHERE parent_id = '$paren1[parent]' ORDER BY `order` ASC");
         foreach ($dtil as $key ) {
         $pdf->Cell(45);
         $pdf->Cell(10,5,'('.$no++.')',0,0);
         $pdf->MultiCell(99,5,strip_tags($key['keterangan']),0,'J');   
         $pdf->Ln(3);
         }
         

            }
         }
        }else{
         $pdf->Cell(25);
         $pdf->Cell(10,5,'2) ',0,0);
         $pdf->Cell(40,5,'Belanja Barang Nihil',0,1);
        }


         $get2   = $model->getvalue("SELECT * FROM vt_verku_temuan a LEFT JOIN tsatminkal b ON a.satminkal = b.kd_satminkal WHERE a.kategori = '5' AND a.status_temuan = '2'  AND a.satminkal = '$satminkal' AND a.tahun = '$tahun' AND a.bulan = '$bulan' ");

         $kat2   = $get2['kategori'];

     
         $tem2 = $model->query("SELECT * FROM vt_verku_temuan_detail WHERE  satminkal = '$satminkal' AND tahun = '$tahun' AND bulan = '$bulan' AND kategori = '$kat2' AND parent_id = 0 ORDER BY `order` ASC");


         if ($get2['kategori'] == 5 && $get2['status_temuan']  == 2 ) {

         $pdf->Cell(25);
         $pdf->Cell(10,5,'3) ',0,0);
         $pdf->Cell(40,5,'Belanja Modal',0,1);
         $pdf->Ln(4);

         $abj = 'a';
         foreach ($tem2 as $va2) {
         $pdf->Cell(35);
         $pdf->Cell(10,5,$abj++.') ',0,0);
         $pdf->MultiCell(108,5,strip_tags($va2['keterangan']),0,'J');
         $pdf->Ln(4);
         $pars = $va2['autono'];
         $paren2 = $model->getvalue("SELECT parent_id FROM vt_verku_temuan_detail WHERE  parent_id = '$pars'");
         $no = 1;


         if ($va2['autono'] == $paren2['parent_id']) {
    
         // $parent_id = $parent['parent_id'];

         // var_dump($parent_id);
         $dtil = $model->query("SELECT * FROM vt_verku_temuan_detail WHERE parent_id = '$paren2[parent]' ORDER BY `order` ASC");
         foreach ($dtil as $key ) {
         $pdf->Cell(45);
         $pdf->Cell(10,5,'('.$no++.')',0,0);
         $pdf->MultiCell(99,5,strip_tags($key['keterangan']),0,'J');   
         $pdf->Ln(3);
         }
         

            }
         }
        }else{
         $pdf->Cell(25);
         $pdf->Cell(10,5,'3) ',0,0);
         $pdf->Cell(40,5,'Belanja Modal Nihil',0,1);
        }

         $pdf->Cell(15);
         $pdf->Cell(10,5,'c.',0,0);
         $pdf->MultiCell(130,5,'Pertanggungjawaban keuangan yang tidak dapat dipertanggung jawaban  ',0,1);
         $pdf->Ln(5);



         $gets   = $model->getvalue("SELECT * FROM vt_verku_temuan a LEFT JOIN tsatminkal b ON a.satminkal = b.kd_satminkal WHERE a.kategori = '1' AND  a.status_temuan = '3'  AND a.satminkal = '$satminkal' AND a.tahun = '$tahun' AND a.bulan = '$bulan' ");

         $kats   = $gets['kategori'];

     
         $temp = $model->query("SELECT * FROM vt_verku_temuan_detail WHERE  satminkal = '$satminkal' AND tahun = '$tahun' AND bulan = '$bulan' AND kategori = '$kats' AND parent_id = 0 ORDER BY `order` ASC");


         if ($gets['kategori'] == 1 && $gets['status_temuan']  == 3 ) {

         $pdf->Cell(25);
         $pdf->Cell(10,5,'1) ',0,0);
         $pdf->Cell(40,5,'Belanja Personel',0,1);
         $pdf->Ln(4);

         $abj = 'a';
         foreach ($temp as $v) {
         $pdf->Cell(35);
         $pdf->Cell(10,5,$abj++.') ',0,0);
         $pdf->MultiCell(108,5,strip_tags($v['keterangan']),0,'J');
         $pdf->Ln(4);
         $pars = $v['autono'];
         $parents = $model->getvalue("SELECT parent_id FROM vt_verku_temuan_detail WHERE  parent_id = '$pars'");
         $no = 1;


         if ($v['autono'] == $parents['parent_id']) {
    
         // $parent_id = $parent['parent_id'];

         // var_dump($parent_id);
         $dtil = $model->query("SELECT * FROM vt_verku_temuan_detail WHERE parent_id = '$parents[parent]' ORDER BY `order` ASC");
         foreach ($dtil as $key ) {
         $pdf->Cell(45);
         $pdf->Cell(10,5,'('.$no++.')',0,0);
         $pdf->MultiCell(99,5,strip_tags($key['keterangan']),0,'J');   
         $pdf->Ln(3);
         }
         

            }
         }
        }else{
         $pdf->Cell(25);
         $pdf->Cell(10,5,'1) ',0,0);
         $pdf->Cell(40,5,'Belanja Personel Nihil',0,1);
        }
        




        $gets1   = $model->getvalue("SELECT * FROM vt_verku_temuan a LEFT JOIN tsatminkal b ON a.satminkal = b.kd_satminkal WHERE a.kategori = '4' AND a.status_temuan = '3'  AND a.satminkal = '$satminkal' AND a.tahun = '$tahun' AND a.bulan = '$bulan' ");

        $kats1   = $gets1['kategori'];

        // var_dump($kotama);
     
         $temp1 = $model->query("SELECT * FROM vt_verku_temuan_detail WHERE  satminkal = '$satminkal' AND tahun = '$tahun' AND bulan = '$bulan' AND kategori = '$kats1' AND parent_id = 0  ORDER BY `order` ASC");


         if ($gets1['kategori'] == 4 && $gets1['status_temuan']  == 3 ) {

         $pdf->Cell(25);
         $pdf->Cell(10,5,'2) ',0,0);
         $pdf->Cell(40,5,'Belanja Barang ',0,1);
         $pdf->Ln(4);

         $abj = 'a';
         foreach ($temp1 as $v1) {
         $pdf->Cell(35);
         $pdf->Cell(10,5,$abj++.') ',0,0);
         $pdf->MultiCell(108,5,strip_tags($v1['keterangan']),0,'J');
         $pdf->Ln(4);
         $pars = $v1['autono'];
         $parents1 = $model->getvalue("SELECT parent_id FROM vt_verku_temuan_detail WHERE  parent_id = '$pars'");
         $no = 1;


         if ($v1['autono'] == $parents1['parent_id']) {
    
         // $parent_id = $parent['parent_id'];

         // var_dump($parent_id);
         $dtil = $model->query("SELECT * FROM vt_verku_temuan_detail WHERE parent_id = '$parents1[parent]' ORDER BY `order` ASC");
         foreach ($dtil as $key ) {
         $pdf->Cell(45);
         $pdf->Cell(10,5,'('.$no++.')',0,0);
         $pdf->MultiCell(99,5,strip_tags($key['keterangan']),0,'J');   
         $pdf->Ln(3);
         }
         

            }
         }
        }else{
         $pdf->Cell(25);
         $pdf->Cell(10,5,'2) ',0,0);
         $pdf->Cell(40,5,'Belanja Barang Nihil',0,1);
        }
        




        $gets2   = $model->getvalue("SELECT * FROM vt_verku_temuan a LEFT JOIN tsatminkal b ON a.satminkal = b.kd_satminkal WHERE a.kategori = '5' AND  a.status_temuan = '3'  AND a.satminkal = '$satminkal' AND a.tahun = '$tahun' AND a.bulan = '$bulan' ");

         $kats2   = $gets2['kategori'];

     
         $temp2 = $model->query("SELECT * FROM vt_verku_temuan_detail WHERE  satminkal = '$satminkal' AND tahun = '$tahun' AND bulan = '$bulan' AND kategori = '$kats2' AND parent_id = 0  ORDER BY `order` ASC");


         if ($gets2['kategori'] == 5 && $gets2['status_temuan']  == 3 ) {

         $pdf->Cell(25);
         $pdf->Cell(10,5,'3) ',0,0);
         $pdf->Cell(40,5,'Belanja Modal',0,1);
         $pdf->Ln(4);

         $abj = 'a';
         foreach ($temp2 as $v2) {
         $pdf->Cell(35);
         $pdf->Cell(10,5,$abj++.') ',0,0);
         $pdf->MultiCell(108,5,str_replace('&nbsp;','',strip_tags($v2['keterangan'])),0,'J');
         $pdf->Ln(4);
         $pars = $v2['autono'];
         $parents2 = $model->getvalue("SELECT parent_id FROM vt_verku_temuan_detail WHERE  parent_id = '$pars'");
         $no = 1;


         if ($v2['autono'] == $parents2['parent_id']) {
    
         // $parent_id = $parent['parent_id'];

         // var_dump($parent_id);
         $dtil = $model->query("SELECT * FROM vt_verku_temuan_detail WHERE parent_id = '$parents2[parent]' ORDER BY `order` ASC");
         foreach ($dtil as $key ) {
         $pdf->Cell(45);
         $pdf->Cell(10,5,'('.$no++.')',0,0);
         $pdf->MultiCell(99,5,strip_tags($key['keterangan']),0,'J');   
         $pdf->Ln(3);
         }
         

            }
         }
        }else{
         $pdf->Cell(25);
         $pdf->Cell(10,5,'3) ',0,0);
         $pdf->Cell(40,5,'Belanja Modal Nihil',0,1);
        }

         $pdf->Cell(10,1,'',0,1);
         // $pdf->Cell(5);
         $pdf->Cell(10,5,'3.',0,0);
         $pdf->MultiCell(145,5,'Jawaban Nota Hasil Verifikasi (NHV) beserta kelengkapan admnistrasi dikirim ke verku itsus Itjenad Jl. Manado No. 8 Bandung Jawa Barat ,Kode Pos 4013 Telpon/Fak 022-4204248 Email Verkubdg@gmail.com. paling lambat 15 hari setelah NHV ini diterima',0,'J');
         $pdf->Ln(3);
          $pdf->CheckPageBreak(60);
         // $var = "";
         // if ($var == "Demikian untuk dimaklumi.") {
         //    $pdf->AddPage('P','A4');
         // }
         // $pdf->Cell(5);
         $pdf->Cell(10,5,'4.',0,0);
         $pdf->MultiCell(145,5,'Demikian untuk dimaklumi.',0,'J');
         $pdf->Ln(3);
          
         // Footer
         $pdf->Cell(50);
         $pdf->Cell(140,5,"a.n Inspektur Jendral Angkatan Darat",0,1,'C');
         $pdf->Cell(60);
         $pdf->Cell(126,5,"Inspektur Khusus",0,1,'C');
         $pdf->Cell(67);
         $pdf->Cell(116,5,"u.b",0,1,'C');
         $pdf->Cell(60);
         $pdf->Cell(120,5,strtolower(ucfirst($ttd['jabatan'])),0,1,'C');
         $pdf->Cell(100 ,10,'',0,1);//end of line
         $pdf->Ln(30);

         $pdf->Cell(120,5,'Tembusan :',0,0);
         $pdf->Cell(8,5,$ttd['nama'],0,1,'C');
         $pdf->Cell(55);
         $pdf->Cell(140,5,$ttd['nm_pangkat'].' '.$ttd['nm_korps']." NRP ".$ttd['nrp'],0,1,'C');
         $pdf->Ln(1);

         $no = 1;
         foreach ($tembusan as $vals) {
          $pdf->Cell(10,5,$no++.'.',0,0);
         $pdf->MultiCell(45,5,$vals['nm_tembusan'],0,1);
        
         }
        $pdf->Cell(55,0,'','B',1);
         $pdf->Output();

    } 

     function verku_2()
    {
         $pdf = $this->loadLibrary('fpdf');
        
         $pdf->setAutoPageBreak(true,27);   
         $pdf->SetMargins(25.4,20.3,15.2,12.7); // Format A4
         $pdf->AddPage('P','A4');
        
         // Kop Surat
         $pdf->SetFont('Arial', '', 10);    
         $pdf->header();
         $pdf->Cell(65, -6, 'MARKAS BESAR ANGKATAN DARAT', 0, 1, 'C');
         $pdf->Cell(64, 15, 'PUSAT ZENI', 0, 1, 'C');
         $pdf->Cell(2);
         $pdf->Cell(62,-5,'','B',1);
         $pdf->Cell(253, 10, 'Jakarta,          Mei 2019', 0, 1, 'C');
         $pdf->Ln(5);

         // Content
         $pdf->Cell(25, 5, 'Nomor', 0, 'LTR', 'L');
         $pdf->Cell(-2, 5, ':', 0, 'LTR','C');
         $pdf->Cell(2);
         $pdf->MultiCell(110, 5, 'B/ 2445 /V/2020', 'J');
         $pdf->Cell(28, 5, 'Klasifikasi', 0, 'LTR', 'L');
         $pdf->Cell(-8, 5, ':', 0, 'LTR','C');
         $pdf->Cell(5);
         $pdf->MultiCell(110, 5, 'Biasa', 'J');
         $pdf->Cell(28, 5, 'Lampiran', 0, 'LTR', 'L');
         $pdf->Cell(-8, 5, ':', 0, 'LTR','C');
         $pdf->Cell(5);
         $pdf->MultiCell(110, 5,'Satu Bundel', 'J');
         $pdf->Cell(28, 5, 'Perihal', 0, 'LTR', 'L');
         $pdf->Cell(-8, 5, ':', 0, 'LTR','C');
         $pdf->Cell(5);
         $pdf->MultiCell(60, 5, 'Jawaban Nota Hasil Verifikasi', 'J');
         $pdf->Cell(26);
         $pdf->Cell(47,0,'','B',1);
         // $pdf->Line(127, 73, 68, 73);
         $pdf->Ln(5);

         $pdf->Cell(240, 8, 'Kepada', 0, 1, 'C');
         $pdf->Cell(103);
         $pdf->Cell(10, 4, 'Yth.', 0, 0);
         $pdf->MultiCell(36, 4, 'Kepala Unit Verifikasi Keuangan Itsus Itjenad', 0,'J');
         $pdf->Cell(232, 7, 'di', 0, 1, 'C');
         $pdf->Cell(243, 7, 'Bandung', 0, 1, 'C');
         $pdf->Ln(5);

         // $pdf->Cell(25, 5, 'U.p.Sekertaris', 0, 'LTR', 'L');
         // $pdf->Ln(5);
         $pdf->Cell(10,5,'1.',0,0);
         $pdf->MultiCell(140,5,'Berdasarkan Surat Inspektorat Jendral Angkatan Darat Nomor B/656/V/NHV-Verku.IV/2020 tanggal 20 mei 2020, tentang Nota Hasil Verifikasi Wabku bulan Oktober 2019.Belanja Personel nomor BK 2835/X-2019 Pembayaran Uang Makan anggota PNS Ditziad bulan November 2019,atas nama Penata Tk.I-III/c Siti Rohayati NIP 196204051982022001 jabatan Penata Cang Sicang bangkon Balakada Ditziad dan kawan-kawan 4 orang uang seharusnya Masa Persiapan Pensiun(MPP) namun uang makan tetap di bayarkan. ',0,'J');
         $pdf->Ln(3);
         $pdf->Cell(15);

         $pdf->Cell(10,1,'',0,1);
         // $pdf->Cell(5);
         $pdf->Cell(10,5,'2. ',0,0);
         $pdf->MultiCell(140,5,'SSehubungan dasar tersebut di atas, dikirimkan jawaban Nota Hasil Verifikasi (NHV) Anggota PNS Ditziad data terlampir atas nama : ',0,'J');
         $pdf->Ln(4);
         $pdf->Cell(15);

         $pdf->Cell(10,5,'a.',0,0);
         $pdf->MultiCell(125,5,'Penata Tk.I-III/c Siti Rohayati NIP 19620451982022001 abatan Penata Cang Si Cang Bangkon Balada Ditziad, sesuai Surat Perintah Ditziad Nomor Sprin/915/II/2019 tanggal 27 Febuari 2019 ',0,'J');
         $pdf->Ln(2);
         $pdf->Cell(15);

         $pdf->Cell(10,5,'b.',0,0);
         $pdf->MultiCell(125,5,'Penata Muda Tk.I-III/b Sri Sunaryati NIP 19620451982022002 jabatan Tur Was Spektek Bagwas Balakada Ditziad, sesuai Surat Perintah Ditziad Nomor Sprin/VII/2019 tanggal 30 Juli 2019 ',0,'J');
         $pdf->Ln(5);
         $pdf->Cell(15);

         $pdf->Cell(10,5,'c.',0,0);
         $pdf->MultiCell(125,5,'Pengatur Tk.I-III/d Agus Sahri NIP 19620451982022001 jabatan Tur Air dan listrik Tuud Balakada Ditziad, sesuai Surat Perintah Dirziad  Nomor Sprin/3278/VIII/2019 tanggal 13 Agustus 2019',0,'J');
         $pdf->Ln(5);
         $pdf->Cell(15);

         $pdf->Cell(10,5,'d.',0,0);
         $pdf->MultiCell(125,5,'Penata Tk.I-III/d Sulisyana NIP 19620451982022001 jabatan Tur Air dan listrik Tuud Balakada Ditziad, sesuai Surat Perintah Dirziad  Nomor Sprin/3278/VIII/2019 tanggal 13 Agustus 2019',0,'J');
         $pdf->Ln(5);
         $pdf->Cell(15);

         $pdf->Cell(10,5,'e.',0,0);
         $pdf->MultiCell(125,5,'Pengatur Tk.I-III/d Herti NIP 19620451982022001 jabatan Tur Air dan listrik Tuud Balakada Ditziad, sesuai Surat Perintah Dirziad  Nomor Sprin/3278/VIII/2019 tanggal 13 Agustus 2019',0,'J');
         $pdf->Ln(5);
         // $pdf->Cell(20);

         $var = "Demikian untuk dimaklumi.";
         if ($var == "Demikian untuk dimaklumi.") {
            $pdf->AddPage('P','A4');
         }

        // $pdf->Cell(5);
         $pdf->Cell(10,5,'3.',0,0);
         $pdf->MultiCell(145,5,$var,0,'J');
         $pdf->Ln(3);
      
          

         $pdf->Cell(140,5,"a.n Kepala Pusat Zeni TNI Angkatan Darat",0,1,'R');
         $pdf->Cell(114,5,"Dirum",0,1,'R');
         // $pdf->Cell(116,5,"u.b",0,1,'R');
         // $pdf->Cell(120,5,"Kaverku",0,1,'R');
         $pdf->Cell(100 ,10,'',0,1);//end of line
         $pdf->Ln(10);

         $pdf->Cell(105,5,'Tembusan :',0,0);
         $pdf->Cell(5,5,"Jamallulael S.Sos.,M.Si.",0,1,'C');
         $pdf->Cell(1);
         $pdf->Cell(135,5,"Kolonel Czi NRP 1910049280968",0,1,'R');
         $pdf->Ln(1);

         $pdf->Cell(10,5,'1.',0,0);
         $pdf->Cell(40,5,'Irjenad sebagai laporan',0,1);
         $pdf->Cell(10,5,'2.',0,0);
         $pdf->Cell(40,5,'kapusziad',0,1);
         $pdf->Cell(10,5,'3.',0,0);
         $pdf->Cell(40,5,'Irsus Itjenad',0,1);
         $pdf->Cell(10,5,'4.',0,0);
         $pdf->Cell(40,5,'Sekertaris itjenad',0,1);
         $pdf->Cell(10,5,'5.',0,0);
         $pdf->Cell(40,5,'Waka Pusziad',0,1);
         $pdf->Cell(10,5,'5.',0,0);
         $pdf->Cell(40,5,'Ir Pusziad',0,1);
         $pdf->Cell(10,5,'5.',0,0);
         $pdf->Cell(40,5,'Kakupus I Ditkuad',0,1);
         $pdf->Cell(10,5,'6.',0,0);
         $pdf->Cell(40,5,'Paku Pusziad N.A 2.01.07',0,1);
         $pdf->Cell(53,0,'','B',1);
         // $pdf->Line(95, 105, 43,105);//end of lin
         // $pdf->Ln(2);
         // $pdf->PageNo();
         $pdf->Output();

    } 
   
    function verku_3()
    {
         $pdf = $this->loadLibrary('fpdf');
         
         $pdf->setAutoPageBreak(false); 
         
         $pdf->SetMargins(25.4,20.3,15.2,12.7); // Format A4
         $pdf->AddPage('P','A4');
        
         // Kop Surat
         $pdf->SetFont('Arial', '', 10);    
         $pdf->header();
         $pdf->Cell(65, -6, 'MARKAS BESAR ANGKATAN DARAT', 0, 1, 'C');
         $pdf->Cell(64, 15, 'INSPEKTORAT JENDERAL', 0, 1, 'C');
         $pdf->Cell(2);
         $pdf->Cell(62,-5,'','B',1);
         $pdf->Cell(253, 10, 'Bandung,          Mei 2019', 0, 1, 'C');
         $pdf->Ln(5);

         // Content
         $pdf->Cell(25, 5, 'Nomor', 0, 'LTR', 'L');
         $pdf->Cell(-2, 5, ':', 0, 'LTR','C');
         $pdf->Cell(2);
         $pdf->MultiCell(110, 5, 'B/            /           /NHV-Verku.IV/U/2019', 'J');
         $pdf->Cell(28, 5, 'Klasifikasi', 0, 'LTR', 'L');
         $pdf->Cell(-8, 5, ':', 0, 'LTR','C');
         $pdf->Cell(5);
         $pdf->MultiCell(110, 5, 'Biasa', 'J');
         $pdf->Cell(28, 5, 'Lampiran', 0, 'LTR', 'L');
         $pdf->Cell(-8, 5, ':', 0, 'LTR','C');
         $pdf->Cell(5);
         $pdf->MultiCell(110, 5,'', 'J');
         $pdf->Cell(28, 5, 'Perihal', 0, 'LTR', 'L');
         $pdf->Cell(-8, 5, ':', 0, 'LTR','C');
         $pdf->Cell(5);
         $pdf->MultiCell(60, 5, 'NHV perhatian I pada Wabku Bulan September 2019', 'J');
         $pdf->Cell(26);
         $pdf->Cell(58,0,'','B',1);
         // $pdf->Line(127, 73, 68, 73);
         $pdf->Ln(5);

         $pdf->Cell(240, 5, 'Kepada', 0, 1, 'C');
         $pdf->Cell(103);
         $pdf->Cell(10, 7, 'Yth.', 0, 0);
         $pdf->MultiCell(36, 7, 'Danseskoad', 0,'J');
         $pdf->Cell(232, 7, 'di', 0, 1, 'C');
         $pdf->Cell(243, 7, 'Bandung', 0, 1, 'C');
         $pdf->Ln(5);

         $pdf->Cell(25, 5, 'U.p.Dirbinlem', 0, 'LTR', 'L');
         $pdf->Ln(5);
         $pdf->Cell(10,5,'1.',0,0);
         $pdf->MultiCell(140,5,'Dasar :',0,'J');
         // $pdf->Ln(3);
         $pdf->Cell(15);

        $pdf->Cell(10,5,'a.',0,0);
         $pdf->MultiCell(125,5,'Keputusan Kasad Nomor Kep/574/VIII/2015 tanggal 20 Agustus 2015 Petunjuk Teknis tentang Verifikasi Bidang Keuangan; ',0,'J');
         $pdf->Ln(2);
         $pdf->Cell(15);

         $pdf->Cell(10,5,'b.',0,0);
         $pdf->MultiCell(125,5,'Keputusan Kasad Nomor 5 Tahun 2015 tentang Organisasi dan Tugas Inspektorat Jendral Angkatan Darat (Oragas Itjenad) Uji Coba;',0,'J');
         $pdf->Ln(2);
         $pdf->Cell(15);

         $pdf->Cell(10,5,'c.',0,0);
         $pdf->MultiCell(125,5,'Keputusan Irjenad Nomor Skep/01/I/2019 tanggal 2 Januari 2019 tentang Program dan Anggaran Itjenad TA 2019.',0,'J');
         $pdf->Ln(2);
         $pdf->Cell(15);

         $pdf->Cell(10,5,'d.',0,0);
         $pdf->MultiCell(125,5,'Surat Irjenad Nomor B/1046/VIII/NHV-Verku/2019 tanggal 16 Agustus 2019 tentang Nota Hasil Verifikasi Wabku bulan Maret 2019;dan',0,'J');
         $pdf->Ln(2);
         $pdf->Cell(15);

         $pdf->Cell(10,5,'e.',0,0);
         $pdf->MultiCell(125,5,'Surat Danseskoad Nomor B/111/VIII/2019 tanggal 28 Agustus 2019 tentang Jawaban NHV Itjenad',0,'J');
         $pdf->Ln(2);
         $pdf->Cell(20);

         $pdf->Cell(10,1,'',0,1);
         // $pdf->Cell(5);
         $pdf->Cell(10,5,'2. ',0,0);
         $pdf->MultiCell(140,5,'Setelah mempelajari/tanggapan yang tertuang dalam surat tersebut 1.e dengan ini disampaikan bahwa permasalahan yang di notakan belum seluruhnya dapat diterima karena untuk permasalahan pada BK 121/III-2019 Uang makan PNS bulan Februari 2019 dibyarkan sebesar Rp.665.000.- dan pada BK 155/III-2019 Tunjangan Kinerja di bayarakan Grade 2 sebesar Rp.2.089.0000.- Kelebihan terjadi karena atas nama mustar PNS II/a Nip.1961092619831004 seharunya MPP Tmt 1 Oktober 2018 Berdasarkan surat perintah  Danseskoad Nomor Sprin/1298/IX/2018 tanggal 28 September 2018 Tmt di perpanjang tidak mengambil MPP terhitung tanggal 1 Oktober 2018 s.d 30 September 2019 bahawa atas nama tersebut setelah diteliti kembali dalam Nota Jawaban Bukti Sprin di perpanjang Danseskoad Nomor Sprin/1298/IX/2018 tanggal 28 September 2018 tidak mengambil MPP terlampir  ',0,'J');
         $pdf->Ln(4);
         $pdf->Cell(15);

         $pdf->Cell(10,1,'',0,1);
         // $pdf->Cell(5);
         $pdf->Cell(10,5,'3.',0,0);
         $pdf->MultiCell(140,5,'Sehubungan  dengan hal tersebut di atas diminta kepada Danseskoad U.p Dirbinlem agar segera menyelesaikan permasalahan yang belum dapat diterima dilengkapi dengan bukti-bukti autentik pendukung dikirim ke Verku itben Itjenad jl.Menado No 8 Bandung Jawa Barat Kode Pos 40113 Telp/Fax. 022-4204248 Email Verkubdg@yahoo.com paling lambat 15 hari setelah nota ini diterima',0,'J');
         $pdf->Ln(5);
         
         $pdf->CheckPageBreak(31.8);
         // if ($s < 27 ) {
         //     $v = $pdf->Ln(5);
         // }else if($s == 27){
         //    $v =$pdf->AddPage();
         // }   
         $pdf->Cell(5);
         $pdf->Cell(10,5,'4.',0,0);
         $pdf->MultiCell(145,5,'Demikian untuk dimaklumi. ',0,'J');
         $pdf->Ln(3);
         // $pdf->Cell(80); 

         $pdf->Cell(140,5,"a.n Inspektur Jendral Angkatan Darat",0,1,'R');
         $pdf->Cell(126,5,"Inspektur Khusus",0,1,'R');
         $pdf->Cell(116,5,"u.b",0,1,'R');
         $pdf->Cell(120,5,"Kaverku",0,1,'R');
         $pdf->Cell(100 ,10,'',0,1);//end of line
         $pdf->Ln(5);

         $pdf->Cell(115,5,'Tembusan :',0,0);
         $pdf->Cell(8,5,"Drs. Damru",0,1,'R');
         $pdf->Cell(1);
         $pdf->Cell(140,5,"Kolonel Cku NRP 1910002720862",0,1,'R');
         $pdf->Ln(1);

         $pdf->Cell(10,5,'1.',0,0);
         $pdf->Cell(40,5,'Irjenad sebagai laporan',0,1);
         $pdf->Cell(10,5,'2.',0,0);
         $pdf->Cell(40,5,'Irben Itjenad',0,1);
         $pdf->Cell(10,5,'3.',0,0);
         $pdf->Cell(40,5,'Sekertaris Itjenad',0,1);
         $pdf->Cell(10,5,'4.',0,0);
         $pdf->Cell(40,5,'Kakupus II/Ditkuad',0,1);
         $pdf->Cell(10,5,'5.',0,0);
         $pdf->Cell(40,5,'Paku Seskoad NA 2.01.06',0,1);
         $pdf->Cell(53,0,'','B',1);

         
         // $pdf->Line(95, 105, 43,105);//end of lin
         // $pdf->Ln(2);
         // $pdf->PageNo();
         $pdf->Output();

    } 

    function verku_4()
    {
       $pdf = $this->loadLibrary('fpdf');
         
         // $pdf->setAutoPageBreak(auto,27); 
         
         $pdf->SetMargins(25.4,20.3); // Format A4
         $pdf->AddPage('P','A4');
        
         // Kop Surat
         $pdf->SetFont('Arial', '', 10);    
         $pdf->header();
         $pdf->Cell(65, -6, 'MARKAS BESAR ANGKATAN DARAT', 0, 1, 'C');
         $pdf->Cell(64, 15, 'INSPEKTORAT JENDERAL', 0, 1, 'C');
         $pdf->Cell(2);
         $pdf->Cell(62,-5,'','B',1);
         $pdf->Cell(253, 10, 'Bandung,          Mei 2019', 0, 1, 'C');
         $pdf->Ln(5);

         // Content
         $pdf->Cell(25, 5, 'Nomor', 0, 'LTR', 'L');
         $pdf->Cell(-2, 5, ':', 0, 'LTR','C');
         $pdf->Cell(2);
         $pdf->MultiCell(110, 5, 'B/            /           /NHV-Verku.IV/P/2019', 'J');
         $pdf->Cell(28, 5, 'Klasifikasi', 0, 'LTR', 'L');
         $pdf->Cell(-8, 5, ':', 0, 'LTR','C');
         $pdf->Cell(5);
         $pdf->MultiCell(110, 5, 'Biasa', 'J');
         $pdf->Cell(28, 5, 'Lampiran', 0, 'LTR', 'L');
         $pdf->Cell(-8, 5, ':', 0, 'LTR','C');
         $pdf->Cell(5);
         $pdf->MultiCell(110, 5,'', 'J');
         $pdf->Cell(28, 5, 'Perihal', 0, 'LTR', 'L');
         $pdf->Cell(-8, 5, ':', 0, 'LTR','C');
         $pdf->Cell(5);
         $pdf->MultiCell(60, 5, 'NHV Penutup wabku bulan Januari 2020', 'J');
         $pdf->Cell(26);
         $pdf->Cell(58,0,'','B',1);
         // $pdf->Line(127, 73, 68, 73);
         $pdf->Ln(5);

         $pdf->Cell(240, 5, 'Kepada', 0, 1, 'C');
         $pdf->Cell(103);
         $pdf->Cell(10, 7, 'Yth.', 0, 0);
         $pdf->MultiCell(36, 7, 'Danpussenarmed', 0,'J');
         $pdf->Cell(232, 7, 'di', 0, 1, 'C');
         $pdf->Cell(243, 7, 'Cimahi', 0, 1, 'C');
         $pdf->Ln(5);

         $pdf->Cell(25, 5, 'U.p.Dirum', 0, 'LTR', 'L');
         $pdf->Ln(5);
         $pdf->Cell(10,5,'1.',0,0);
         $pdf->MultiCell(140,5,'Dasar :',0,'J');
         // $pdf->Ln(3);
         $pdf->Cell(15);

        $pdf->Cell(10,5,'a.',0,0);
         $pdf->MultiCell(125,5,'Keputusan Kasad Nomor Skep/574/VIII/2015 tanggal 20 Agustus 2015 Petunjuk teknis tentang  Verifikasi Bidang Keuangan;',0,'J');
         $pdf->Ln(2);
         $pdf->Cell(15);

         $pdf->Cell(10,5,'b.',0,0);
         $pdf->MultiCell(125,5,'Peraturan kasad Nomor 26 Tahun 2019 tentang Organisasi dan Tugas Markas Besar TNI AD Lampiran III Organisasi dan Tugas Inspektorat Jendral TNI Angkatan Darat Lampiran III Organisasi dan Tugas Inspektorat Jendral TNI Angkatan Darat (Orgas Itjenad) uji coba;',0,'J');
         $pdf->Ln(2);
         $pdf->Cell(15);

         $pdf->Cell(10,5,'c.',0,0);
         $pdf->MultiCell(125,5,'Keputusan Irjenad Nomor B/644/V/NHV-Verku.IV/2020 tanggal 20-5-2020 tentang Nota Hasil Verifikasi pada wabku bulan Januari 2020;dan',0,'J');
         $pdf->Ln(2);
         $pdf->Cell(15);

         $pdf->Cell(10,5,'d.',0,0);
         $pdf->MultiCell(125,5,'Surat Danpussenarmed Nomor B/834/V/2020 tanggal 29-5-2020 tentang Jawaban NHV Itjenad',0,'J');
         $pdf->Ln(2);
         $pdf->Cell(20);

         $pdf->Cell(10,1,'',0,1);
         // $pdf->Cell(5);
         $pdf->Cell(10,5,'2. ',0,0);
         $pdf->MultiCell(140,5,'Setelah mempelajari jawaban/tanggapan yang tertuang dalam Surat tersebut 1.d diatas dengan ini disampaikan bahwa permaasalahan yang dinotakan telah terjawab dan dapat diterima;',0,'J');
         $pdf->Ln(4);
         $pdf->Cell(15);

         $pdf->Cell(10,1,'',0,1);
         // $pdf->Cell(5);
         // $pdf->Cell(10,5,'3.',0,0);
         // $pdf->MultiCell(140,5,'Dengan demikian maka NHV Irjenad yang tertuang dalam surat tersebut 1.c diatas dinyatakan ditutup dan selesai;dan',0,'J');
         // $pdf->Ln(5);
         
         $pdf->CheckPageBreak(73.7);
         // if ($s < 27 ) {
         //     $v = $pdf->Ln(5);
         // }else if($s == 27){
         //    $v =$pdf->AddPage();
         // }   
         // $pdf->Cell(5);
         $pdf->Cell(10,5,'4.',0,0);
         $pdf->MultiCell(145,5,'Demikian untuk dimaklumi. ',0,'J');
         $pdf->Ln(3);
         // $pdf->Cell(80); 

         $pdf->Cell(140,5,"a.n Inspektur Jendral Angkatan Darat",0,1,'R');
         $pdf->Cell(126,5,"Inspektur Khusus",0,1,'R');
         $pdf->Cell(116,5,"u.b",0,1,'R');
         $pdf->Cell(120,5,"Kaverku",0,1,'R');
         $pdf->Cell(100 ,10,'',0,1);//end of line
         $pdf->Ln(5);

         $pdf->Cell(125,5,'Tembusan :',0,0);
         $pdf->Cell(8,5,"Drs.E. Bambang Widoyoko",0,1,'R');
         $pdf->Cell(1);
         $pdf->Cell(130,5,"Kolonel Cku NRP 33754",0,1,'R');
         $pdf->Ln(1);

         $pdf->Cell(10,5,'1.',0,0);
         $pdf->Cell(40,5,'Irjenad sebagai laporan',0,1);
         $pdf->Cell(10,5,'2.',0,0);
         $pdf->Cell(40,5,'Irsus Itjenad',0,1);
         $pdf->Cell(10,5,'3.',0,0);
         $pdf->Cell(40,5,'Sekertaris Itjenad',0,1);
         $pdf->Cell(10,5,'4.',0,0);
         $pdf->Cell(40,5,'Irkodiklat',0,1);
         $pdf->Cell(10,5,'5.',0,0);
         $pdf->Cell(40,5,'Kakupus II/Ditkuad',0,1);
         $pdf->Cell(10,5,'6.',0,0);
         $pdf->Cell(40,5,'Paku Pussenarmed N.A 2.02.04',0,1);
         $pdf->Cell(62,0,'','B',1);

         
         // $pdf->Line(95, 105, 43,105);//end of lin
         // $pdf->Ln(2);
         // $pdf->PageNo();
         $pdf->Output();
    }

   
}