<?php

class Program extends Controller {

	private $table      = "tprogram";
	private $primaryKey = "autono";
	private $model      = "Program_model"; # please write with no space
	private $menu       = "Reference";
	private $title      = "Program";
	private $curl       = BASE_URL."program/";

	public function __construct()
    {
        $session = $this->loadHelper('Session_helper');
        if(!$session->get('username')){
        	$this->redirect('auth/login');
        }
    }
	
	function index()
	{
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['curl']        = $this->curl;
		$template            = $this->loadView('program_view');
		$template->set('data', $data);
		$template->render();
	}

	function get()
	{
		$request    = $_REQUEST;
		$columns    = array(
			array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'KDPROGRAM',  'dt' => 1 ),
			array( 'db' => 'NMPROGRAM',  'dt' => 2 ),
			array( 'db' => 'keterangan',   'dt' => 3 )
		);
		
		$model  = $this->loadModel($this->model);
		$result = $model->mget($request, $this->table, $this->primaryKey, $columns, $join);

		return json_encode($result);
	}

	public function add()
	{
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Add';
		$data['curl']        = $this->curl;
		$template            = $this->loadView('program_add');
		$template->set('data', $data);
		$template->render();
	}

	public function edit($x)
	{
		$id                  = $this->base64url_decode($x);
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Edit';
		$data['encode']      = $x;
		$data['curl']        = $this->curl;
		$data['aadata']      = $model->get($this->table, $this->primaryKey, $id);
		$template            = $this->loadView('program_edit');
		$template->set('data', $data);
		$template->render();
	}

	public function save()
	{
		$data               = array();
		$model              = $this->loadModel($this->model);
		$data['kdunit']     = 22 ;
		$data['KDPROGRAM']  = ucwords(htmlspecialchars($_REQUEST['KDPROGRAM'])) ;
		$data['NMPROGRAM']  = ucwords(htmlspecialchars($_REQUEST['NMPROGRAM'])) ;
		$data['keterangan'] = ucwords(htmlspecialchars($_REQUEST['keterangan'])) ;
		$data['autocode']   = $model->autocode($this->table, "PRG_");	
		$result             = $model->msave($this->table, $data, $this->title);
		$this->redirect('program');
	}

	public function update($x)
	{
		$data               = array();
		$id                 = $this->base64url_decode($x);
		$model              = $this->loadModel($this->model);
		$data['kdunit']     = 22 ;
		$data['KDPROGRAM']  = ucwords(htmlspecialchars($_REQUEST['KDPROGRAM'])) ;
		$data['NMPROGRAM']  = ucwords(htmlspecialchars($_REQUEST['NMPROGRAM'])) ;
		$data['keterangan'] = ucwords(htmlspecialchars($_REQUEST['keterangan'])) ;
		$result             = $model->mupdate($this->table, $data, $this->primaryKey, $id, $this->title);
		$this->redirect('program');
	}

	public function delete($x)
	{
		$id     = $this->base64url_decode($x);
		$model  = $this->loadModel($this->model);
		$result = $model->mdelete($this->table, $this->primaryKey, $id, $this->title);
		return $result;
	}
    
}