<?php

class Kka extends Controller {

	private $table      = "tkka";
	private $tableDetil = "tkkadetil";
	private $primaryKey = "autono";
	private $model      = "Kka_model"; # please write with no space
	private $menu       = "Transaksi";
	private $title      = "KKA";
	private $curl       = BASE_URL."kka/";
	
	public function __construct()
    {
        $session = $this->loadHelper('Session_helper');
        if(!$session->get('username')){
        	$this->redirect('auth/login');
        }
    }
	
	function index()
	{
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['curl']		 = $this->curl;
		$template            = $this->loadView('kka_view');
		$template->set('data', $data);
		$template->render();
	}

	function get()
	{
		$request = $_REQUEST;
		$columns = array(
			array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'id_pka',  'dt' => 1 ),
			array( 'db' => 'no_kka',  'dt' => 2 ),
			array( 'db' => 'tgl_kka',  'dt' => 3 ),
			array( 'db' => 'nm_audit',   'dt' => 4 ),
			array( 'db' => 'nm_sasaran_audit',   'dt' => 5 )
		);

		$join   = "a LEFT JOIN (SELECT autono AS kd_pka, no_pka FROM tpka) AS b ON a.id_pka = b.kd_pka LEFT JOIN (SELECT autono AS kd_sasaran_audit, nm_sasaran_audit FROM tsasaran_audit) AS c ON a.id_sasaran_audit = c.kd_sasaran_audit";
		$model  = $this->loadModel($this->model);
		$result = $model->mget($request, $this->table, $this->primaryKey, $columns, $join);

		return json_encode($result);
	}

	public function add()
	{
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Add';
		$data['curl']        = $this->curl;		
		$data['pka']         = $model->get_pka();		
		$data['kategori']    = $model->get_kategoriPengawasan();
		$data['himpunan']    = $model->mget_himpunan();
		$data['sasaran']     = $model->get_sasaranAudit();
		$data['personel']    = $model->get_personel();
		$template            = $this->loadView('kka_add');
		$template->set('data', $data);
		$template->render();
	}

	public function edit($x)
	{
		$id                   = $this->base64url_decode($x);
		$model                = $this->loadModel($this->model);
		$data                 = array();
		$data['breadcrumb1']  = $this->menu;
		$data['title']        = $this->title;
		$data['action']       = 'Edit';
		$data['encode']       = $x;
		$data['curl']         = $this->curl;
		$data['aadata']       = $model->get($this->table, $this->primaryKey, $id);
		$data['himpunan']     = $model->mget_himpunan();		
		$data['pka']          = $model->get_pkaEdit($this->table, $this->primaryKey, $id);
		$data['sasaran']      = $model->get_sasaranAuditEdit($this->table, $this->primaryKey, $id);
		$data['kategori']     = $model->get_kategoriPengawasanEdit($this->table, $this->primaryKey, $id);
		$data['subkategori']  = $model->get_subKategoriPengawasanEdit($this->table, $this->primaryKey, $id);
		$data['pers_disusun'] = $model->mget_personelEdit($this->table, 'disusun_oleh', $this->primaryKey, $id);
		$data['pers_direviu'] = $model->mget_personelEdit($this->table, 'direviu_oleh', $this->primaryKey, $id);
		$template             = $this->loadView('kka_edit');
		$template->set('data', $data);
		$template->render();
	}

	public function save()
	{
		$data                               = array();
		$model                              = $this->loadModel($this->model);
		$data['id_pka']                     = ucwords(htmlspecialchars($_REQUEST['id_pka'])) ;
		$data['no_kka']                     = ucwords(htmlspecialchars($_REQUEST['no_kka'])) ;
		$date                               = str_replace('/', '-', $_REQUEST['tgl_kka']);
		$data['tgl_kka']                    = date("Y-m-d",strtotime($date)) ;
		$data['nm_audit']                   = ucwords(htmlspecialchars($_REQUEST['nm_audit'])) ;	
		$data['id_sasaran_audit']           = ucwords(htmlspecialchars($_REQUEST['id_sasaran_audit'])) ;
		$data['periode']                    = ucwords(htmlspecialchars($_REQUEST['periode'])) ;
		$data['disusun_oleh']               = ucwords(htmlspecialchars($_REQUEST['disusun_oleh'])) ;
		$data['direviu_oleh']               = ucwords(htmlspecialchars($_REQUEST['direviu_oleh'])) ;
		$data['id_kategori_pengawasan']     = ucwords(htmlspecialchars($_REQUEST['id_kategori_pengawasan'])) ;
		$data['id_sub_kategori_pengawasan'] = ucwords(htmlspecialchars($_REQUEST['id_sub_kategori_pengawasan'])) ;
		$data['keterangan']                 = $model->escapeString($_REQUEST['keterangan']) ;
		$data['potensi']                    = $model->escapeString($_REQUEST['potensi']) ;
		$data['fakta']                      = $model->escapeString($_REQUEST['fakta']) ;
		$data['kriteria']                   = $model->escapeString($_REQUEST['kriteria']) ;
		$data['sebab']                      = $model->escapeString($_REQUEST['sebab']) ;
		$data['akibat']                     = $model->escapeString($_REQUEST['akibat']) ;
		$data['saran']                      = $model->escapeString($_REQUEST['saran']) ;
		$data['catatan']                    = $model->escapeString($_REQUEST['catatan']) ;
		$data['sumber']                     = $model->escapeString($_REQUEST['sumber']) ;
		$ctFakta                            = explode("</li>", $_REQUEST['fakta']);
		$data['jml_fakta']                  = count($ctFakta) - 1 ;
		$data['autocode']                   = $model->autocode($this->table, "KKA_") ;
		$result                             = $model->msave($this->table, $data, $this->title);
		// $last_id                  = $result['id'];
		// $ctFakta   				  = $model->getvalue("SELECT SUM(ROUND ((LENGTH(fakta) - LENGTH(REPLACE(fakta, '<li>', ''))) / LENGTH('<li>'))) - COUNT(autono) + 1 AS COUNT FROM tkka WHERE autono = '$last_id' GROUP BY autono");
		// $dtUpdate['jml_fakta']    = $ctFakta[0] ;
		// $result                   = $model->mupdate($this->table, $dtUpdate, $this->primaryKey, $last_id, $this->title);

		// $dataFakta			  = explode("</li>", $_REQUEST['fakta']);
		// $fakta              	  = $dataCt[0];

		// for ($i=0; $i < count($dataFakta); $i++) { 
		// 	$detil['autocode'] = $model->autocode($this->tableDetil, "DKKKA_");
		// 	$detil['id_kka']   = substr($dataFakta[$i], 4);
		// 	$detil['fakta']    = $dataFakta[$i];
		// 	// if(substr($dataFakta[$i], 4) == '<li>'){
		// 		$detilresult   = $model->msave($this->tableDetil, $detil, $this->title);
		// 	// }
		// }
		$this->redirect('kka');
	}

	public function update($x)
	{
		$data                               = array();
		$id                                 = $this->base64url_decode($x);
		$model                              = $this->loadModel($this->model);
		$data['id_pka']                     = ucwords(htmlspecialchars($_REQUEST['id_pka'])) ;
		$data['no_kka']                     = ucwords(htmlspecialchars($_REQUEST['no_kka'])) ;
		$date                               = str_replace('/', '-', $_REQUEST['tgl_kka']);
		$data['tgl_kka']                    = date("Y-m-d",strtotime($date)) ;
		$data['nm_audit']                   = ucwords(htmlspecialchars($_REQUEST['nm_audit'])) ;	
		$data['id_sasaran_audit']           = ucwords(htmlspecialchars($_REQUEST['id_sasaran_audit'])) ;
		$data['periode']                    = ucwords(htmlspecialchars($_REQUEST['periode'])) ;
		$data['disusun_oleh']               = ucwords(htmlspecialchars($_REQUEST['disusun_oleh'])) ;
		$data['direviu_oleh']               = ucwords(htmlspecialchars($_REQUEST['direviu_oleh'])) ;
		$data['id_kategori_pengawasan']     = ucwords(htmlspecialchars($_REQUEST['id_kategori_pengawasan'])) ;
		$data['id_sub_kategori_pengawasan'] = ucwords(htmlspecialchars($_REQUEST['id_sub_kategori_pengawasan'])) ;
		$data['keterangan']                 = $model->escapeString($_REQUEST['keterangan']) ;
		$data['potensi']                    = $model->escapeString($_REQUEST['potensi']) ;
		$data['fakta']                      = $model->escapeString($_REQUEST['fakta']) ;
		$data['kriteria']                   = $model->escapeString($_REQUEST['kriteria']) ;
		$data['sebab']                      = $model->escapeString($_REQUEST['sebab']) ;
		$data['akibat']                     = $model->escapeString($_REQUEST['akibat']) ;
		$data['saran']                      = $model->escapeString($_REQUEST['saran']) ;
		$data['catatan']                    = $model->escapeString($_REQUEST['catatan']) ;
		$data['sumber']                     = $model->escapeString($_REQUEST['sumber']) ;
		$ctFakta                            = explode("</li>", $_REQUEST['fakta']);
		// $ctFakta                         = $model->getvalue("SELECT SUM(ROUND ((LENGTH(fakta) - LENGTH(REPLACE(fakta, '<li>', ''))) / LENGTH('<li>'))) - COUNT(autono) + 1 AS COUNT FROM tkka WHERE autono = '1' GROUP BY autono");
		$data['jml_fakta']                  = count($ctFakta) - 1 ;
		$result                             = $model->mupdate($this->table, $data, $this->primaryKey, $id, $this->title);
		$this->redirect('kka');
	}

	public function delete($x)
	{
		$id     = $this->base64url_decode($x);
		$model  = $this->loadModel($this->model);
		$result = $model->mdelete($this->table, $this->primaryKey, $id, $this->title);
		return $result;
	}

	function gets_pka()
    {
		$id    = $_REQUEST['id_pka'];
		$model = $this->loadModel($this->model);
		$data  = $model->mget_pka($id);
        echo json_encode($data);
    }

    function gets_personel()
    {
		$id    = $_REQUEST['id_sprin'];
		$model = $this->loadModel($this->model);
		$data  = $model->mget_personel($id);
        echo json_encode($data);
    }

    function gets_sub_kategori()
    {
		$id    = $_REQUEST['id_kategori'];
		$model = $this->loadModel($this->model);
		$data  = $model->mget_sub_kategori($id);
        echo json_encode($data);
    }

	function load_Fpdf($x)
	{
		$model   = $this->loadModel('kka_model');
		$pdf     = $this->loadLibrary('fpdf');
		$id      = $this->base64url_decode($x);

		// Get Data KKA
		$valkka  = $model->load_kka($id);
		// Get Data Personel Disusun
		$valSus  = $model->load_personel($this->table, 'disusun_oleh', $this->primaryKey, $id);
		// Get Data Personel Direviu
		$valRev  = $model->load_personel($this->table, 'direviu_oleh', $this->primaryKey, $id);

		$expldF  = explode('<li>', $valkka['fakta']);		
		$expldK  = explode('<li>', $valkka['kriteria']);
		$expldSe = explode('<li>', $valkka['sebab']);
		$expldSa = explode('<li>', $valkka['saran']);
		
		// ** Surat Dinas **
			$alphabet = range('a', 'z');
			$pdf->SetMargins(36,9); // Format A4
			$pdf->AddPage('P', 'A4');

			// Kop Surat
			$pdf->SetFont('Arial', '', 10);
			$pdf->Cell(80, 5, 'INSPEKTORAT JENDERAL ANGKATAN DARAT', 0, 1, 'C');
			$pdf->Cell(84, 2, 'TIM CURRENT AUDIT', 0, 1, 'C');
			$pdf->Line(38, 24, 115, 24);
			$pdf->Ln(5);

			// Title
			$pdf->SetFont('Arial', 'B', 10);
			$pdf->Cell(153, 5, 'KERTAS KERJA AUDIT', 0, 1, 'C');
			$pdf->Ln(3);

			// Content
			$pdf->SetFont('Arial', '', 10);
			$x = $pdf->GetX();
			$y = $pdf->GetY();
			// Nama Audit			
			$pdf->Cell(25, 5, 'Nama Audit', 0, 0);
			$pdf->Cell(3, 5, ':', 0, 0);
			$pdf->MultiCell(35, 5, 'Sesdisjarahad', 0, 'L');
			// Sasaran Audit
			$pdf->Cell(25, 5, 'Sasaran Audit', 0, 0);
			$pdf->Cell(3, 5, ':', 0, 0);
			$pdf->MultiCell(35, 5, $valkka['nm_sasaran_audit'], 0, 'L');
			$pdf->SetX($x);
			// Periode
			$pdf->Cell(25, 5,'Periode Audit', 0, 0);
			$pdf->Cell(3, 5, ':', 0, 0);
			$pdf->MultiCell(35, 5, 'Tahun '.$valkka['periode'], 0, 'L');
			$pdf->SetY($y);
			// Nomor KKA
			$pdf->SetX(-110); $pdf->Cell(25, 5,'No. KKA', 0, 0);
			$pdf->SetX(-86); $pdf->Cell(3, 5, ':', 0, 0);
			$pdf->SetX(-83); $pdf->MultiCell(39, 5, $valkka['no_kka'], 0, 'L');
			$pdf->SetX($x);
			// Disusun Oleh
			$pdf->SetX(-110); $pdf->Cell(25, 5, 'Disusun Oleh', 0, 0);
			$pdf->SetX(-86); $pdf->Cell(3, 5, ':', 0, 0);
			$pdf->SetX(-83); $pdf->MultiCell(39, 5, ucwords(strtolower($valSus['nm_pangkat'])).' '.ucwords(strtolower($valSus['nm_korps'])).' '.ucwords(strtolower($valSus['nama'])), 0, 'L');
			$pdf->SetX($x);
			// Direviu Oleh
			$pdf->SetX(-110); $pdf->Cell(25, 5, 'Direviu Oleh', 0, 0);
			$pdf->SetX(-86); $pdf->Cell(3, 5, ':', 0, 0);
			$pdf->SetX(-83); $pdf->MultiCell(39, 5, ucwords(strtolower($valRev['nm_pangkat'])).' '.ucwords(strtolower($valRev['nm_korps'])).' '.ucwords(strtolower($valRev['nama'])), 0, 'L');
			$pdf->SetX($x);
			// Paraf
			$pdf->SetX(-110); $pdf->Cell(25, 5, 'Paraf', 0, 0);
			$pdf->SetX(-86); $pdf->Cell(3, 5, ':', 0, 0);
			$pdf->SetX(-80); $pdf->MultiCell(39, 5, ' ', 0, 'J');
			$pdf->SetX($x);
			// Tanggal
			$pdf->SetX(-110); $pdf->Cell(25, 5, 'Tanggal', 0, 0);
			$pdf->SetX(-86); $pdf->Cell(3, 5, ':', 0, 0);
			$pdf->SetX(-83); $pdf->MultiCell(39, 5, $valkka['day'].' '.$pdf->getMonth($valkka['month']).' '.$valkka['year'], 0, 'L');
			$pdf->ln(5);
			// Potensi
			$pdf->SetFont('Arial', 'B', 10);
			$pdf->Cell(50, 5, '1.   Potensi Permasalahan.', 0, 'LTR', 'L');
			$pdf->SetFont('Arial', '', 10);
			$pdf->SetX(42); $pdf->MultiCell(125, 5, '                                        '.strip_tags(preg_replace('/<p[^>]*>/', '', $valkka['potensi'])), 'J');
			$pdf->ln(5);
			// Fakta
			$pdf->SetFont('Arial', 'B', 10);
			$pdf->Cell(50, 5, '2.   Fakta yang ditemukan', 0, 'LTR', 'L');
			$pdf->SetFont('Arial', '', 10);
			$pdf->ln(7);
			for ($i=1; $i < count($expldF); $i++){
		   		$pdf->SetX(-168); $pdf->MultiCell(125, 5, $alphabet[$i - 1].'.     '.str_replace(array('</li>','</ol>'), "\r\n", $expldF[$i]), 'J');
		   		$pdf->Cell(50, 0, '', 0, 1, 'L');
			}
			$pdf->ln(0);
			// Kriteria
			$pdf->SetFont('Arial', 'B', 10);
			$pdf->Cell(50, 5, '3.   Kriteria', 0, 'LTR', 'L');
			$pdf->SetFont('Arial', '', 10);
			$pdf->ln(7);
			for ($i=1; $i < count($expldK); $i++){
		   		$expldK[$i] = str_replace('&nbsp;', '', $expldK[$i]);
		   		$pdf->SetX(-168); $pdf->MultiCell(125, 5, $alphabet[$i - 1].'.     '.str_replace(array('</li>','</ol>',), "\r\n", $expldK[$i]), 'J');
		   		$pdf->Cell(50, 0, '', 0, 1, 'L');
			}
			// Sebab
			$pdf->SetFont('Arial', 'B', 10);
			$pdf->Cell(50, 5, '4.   Sebab', 0, 'LTR', 'L');
			$pdf->SetFont('Arial', '', 10);
			$pdf->ln(7);
			for ($i=1; $i < count($expldSe); $i++){
		   		$pdf->SetX(-168); $pdf->MultiCell(125, 5, $alphabet[$i - 1].'.     '.str_replace(array('</li>','</ol>'), "\r\n", $expldSe[$i]), 'J');
		   		$pdf->Cell(50, 0, '', 0, 1, 'L');
			}
			// Akibat
			$pdf->SetFont('Arial', 'B', 10);
			$pdf->Cell(50, 5, '5.   Akibat', 0, 'LTR', 'L');
			$pdf->SetFont('Arial', '', 10);
			$pdf->SetX(42); $pdf->MultiCell(125, 5, '            '.strip_tags(preg_replace('/<p[^>]*>/', '', $valkka['akibat'])), 'J');
			$pdf->ln(5);
			// Saran
			$pdf->SetFont('Arial', 'B', 10);
			$pdf->Cell(50, 5, '6.   Saran', 0, 'LTR', 'L');
			$pdf->SetFont('Arial', '', 10);
			$pdf->ln(7);
			for ($i=1; $i < count($expldSa); $i++){
		   		$pdf->SetX(-168); $pdf->MultiCell(125, 5, $alphabet[$i - 1].'.     '.str_replace(array('</li>','</ol>'), "\r\n", $expldSa[$i]), 'J');
		   		$pdf->Cell(50, 0, '', 0, 1, 'L');
			}
			// Catatan:
			$pdf->SetFont('Arial', 'B', 10);
			$pdf->Cell(50, 5, '7.   Catatan:', 0, 'LTR', 'L');
			$pdf->SetFont('Arial', '', 10);
			$pdf->SetX(42); $pdf->MultiCell(125, 5, '     '.strip_tags(preg_replace('/<p[^>]*>/', '     ', $valkka['catatan'])), 'J');
			$pdf->ln(5);
			// Sumber:
			$pdf->SetFont('Arial', 'B', 10);
			$pdf->Cell(50, 5, '8.   Sumber data', 0, 'LTR', 'L');
			$pdf->SetFont('Arial', '', 10);
			$pdf->ln(8);
			$pdf->SetX(42); $pdf->MultiCell(115, 5, '-    '.strip_tags(preg_replace('/<p[^>]*>/', ' ', $valkka['sumber'])), 'J');

			$pdf->ln(5);
			$pdf->Cell(237, 10, 'Jakarta, '.$valkka['day'].' '.$pdf->getMonth($valkka['month']).' '.$valkka['year'], 0, 1, 'C');
			$pdf->Cell(237, -2, 'Auditor/Pemeriksa,', 0, 1, 'C');
			$pdf->ln(15);
			$pdf->Cell(237, 5, ucwords(strtolower($valRev['nama'])), 0, 1, 'C');
			$pdf->Cell(237, 5, ucwords(strtolower($valRev['nm_pangkat'])).' '.ucwords(strtolower($valRev['nm_korps'])).' NRP '.$valRev['nrp'], 0, 1, 'C');
			
		$pdf->Output();
		
	}

}