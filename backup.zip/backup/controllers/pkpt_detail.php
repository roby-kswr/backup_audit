<?php

class Pkpt_detail extends Controller {

	private $table      = "tpkpt_detil";
	private $tableRev   = "tpkpt_detil_rev";
	private $tablePk    = "tpkpt";
	private $tableSat   = "tpkptsat";
	private $tableView  = "tpkptrev";
	private $primaryKey = "autono";
	private $model      = "Pkpt_detail_model";
	private $menu       = "Transaksi";
	private $title      = "PKPT Detail";
	private $curl       = BASE_URL."pkpt_detail";

	public function __construct()
	{
		$session = $this->loadHelper('Session_helper');
		if(!$session->get('username')){
			$this->redirect('auth/login');
		}
	}

	public function index()
	{
		$id                  = $this->base64url_decode($x);
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['curl']	     = $this->curl;
		$template            = $this->loadView('pkpt_detail_view');
		$template->set('data', $data);
		$template->render();
	}


	public function detail($x,$y = null)

	{

		$uri = $this->loadHelper('Url_helper');

		$data                = array();

		$data['nomor_pkpt']  = $uri->segment(5);

		$data['flag']        = $uri->segment(6);

		$data['no']        = $uri->segment(7);

		$data['breadcrumb1'] = $this->menu;

		$data['title']       = $this->title;

		$data['curl']	     = $this->curl;

		$data['encode']      = $x;

		$data['nomor_pkpt']  = $y;

		$template            = $this->loadView('pkpt_detail_view');

		$template->set('data', $data);

		$template->render();

	}

	function getBulan($bln){

		$val = explode("-", $bln);
		switch ($val[1]){
			case 1: 
			return "Januari";
			break;
			case 2:
			return "Februari";
			break;
			case 3:
			return "Maret";
			break;
			case 4:
			return "April";
			break;
			case 5:
			return "Mei";
			break;
			case 6:
			return "Juni";
			break;
			case 7:
			return "Juli";
			break;
			case 8:
			return "Agustus";
			break;
			case 9:
			return "September";
			break;
			case 10:
			return "Oktober";
			break;
			case 11:
			return "November";
			break;
			case 12:
			return "Desember";
			break;
		}


	} 

	function get($x = null, $y = null)

	{

		$request    = $_REQUEST;

		$id         = $this->base64url_decode($x);
		$uri        = $this->loadHelper('Url_helper');
		$pkpt       = $uri->segment(5);

		$columns = array(

			array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'id_jns_audit',  'dt' => 1 ),
			array( 'db' => 'title',  'dt' => 2 ),
			array( 'db' => 'start',  'dt' => 3, 'formatter' => function( $d, $row ) { return $this->getBulan($d); } )

		);
		$model   = $this->loadModel($this->model);
		$join   = "";
		$result  = $model->mget_detail($request, $this->table, $this->primaryKey, $columns, $pkpt,$y,$join);

		



		return json_encode($result);

	}

	function getRev($x = null, $y = null)

	{

		$request    = $_REQUEST;

		$id         = $this->base64url_decode($x);
		$uri        = $this->loadHelper('Url_helper');
		$pkpt       = $uri->segment(5);

		$columns = array(

			array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'title',  'dt' => 1 ),
			array( 'db' => 'start',  'dt' => 2, 'formatter' => function( $d, $row ) { return $this->getBulan($d); } ),
			array( 'db' => 'nm_review',  'dt' => 3 ),


		);
		$model   = $this->loadModel($this->model);
		$result  = $model->mget_rev($request, $this->tableRev, $this->primaryKey, $columns, $pkpt,$y,$join);

		



		return json_encode($result);

	}

	function getrevMod($x)
	{
		$request = $_REQUEST;
		$id      = $this->base64url_decode($x);
		$model   = $this->loadModel($this->model);
		$columns = array(
			array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'nm_review',  'dt' => 1 ),
		);
		
		
		$result = $model->loadReview($request, $this->tableRev, $this->primaryKey, $columns, $id);

		return json_encode($result);
	}

	function getsatMod($x)
	{
		$request = $_REQUEST;
		$id      = $this->base64url_decode($x);
		$model   = $this->loadModel($this->model);
		$columns = array(
			array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'nm_kotama',  'dt' => 1 ),
		);
		
		
		$result = $model->loadSatker($request, $this->table, $this->primaryKey, $columns, $id);

		return json_encode($result);
	}


	public function add()
	{
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Add';
		$data['curl']	     = $this->curl;
		// $data['encode']	     = $x;
		$data['id_kotama']	 = $model->get_satker($this->tableSat);
		$template            = $this->loadView('pkpt_add');
		$template->set('data', $data);
		$template->render();
	}

	public function jdwl($x, $y)

	{
		$uri = $this->loadHelper('Url_helper');
		$id                  = $this->base64url_decode($x);
		$model               = $this->loadModel($this->model);
		// echo $data['no'];exit;
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Jadwal';
		$data['curl']	     = $this->curl;
		// $id 			     = $_POST['autono'];
		$data['nomor_pkpt']  = $uri->segment(5);
		$data['autono']  	 = $uri->segment(4);
		$data['autono']	     = $id;
		$data['encode']	     = $x;
		$data['nomor_pkpt']  = $y;
		$data['no']			 = $uri->segment(7);
		$data['flag']        = $uri->segment(6);

		$data['id_jns_audit']= $model->get_jenisAudit();
		$data['id_kotama'] 	 = $model->get_kotama2($y);
		$template            = $this->loadView('index_jadwal');
		$template->set('data', $data);
		$template->render();

	}

	public function review($x, $y)

	{
		$uri = $this->loadHelper('Url_helper');
		$id                  = $this->base64url_decode($x);
		$model               = $this->loadModel($this->model);

		$data['nomor_pkpt']  = $uri->segment(5);
		$data['autono']  = $uri->segment(4);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Jadwal';
		$data['curl']	     = $this->curl;
		// $id 			     = $_POST['autono'];
		$data['autono']	     = $id;
		$data['encode']	     = $x;
		$data['nomor_pkpt']  = $y;
		$data['no']			 = $uri->segment(7);
		$data['flag']        = $uri->segment(6);
		$data['review']= $model->get_review();
		$template            = $this->loadView('index_review');
		$template->set('data', $data);
		$template->render();

	}

	public function jdwlGet($x, $y)

	{
		$uri = $this->loadHelper('Url_helper');
		$id                  = $this->base64url_decode($x);
		$model               = $this->loadModel($this->model);

		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Jadwal';
		$data['curl']	     = $this->curl;
		// $id 			     = $_POST['autono'];
		// $data['encode']	     = $x;
		$data['encode']	     = $x;
		$data['nomor_pkpt']  = $y;
		$data['nomor_pkpt']  = $uri->segment(5);
		$data['flag']        = $uri->segment(6);
		$data['no']			 = $uri->segment(7);
		$data['id_jns_audit']= $model->get_jenisAudit();
		$data['id_kotama'] 	 = $model->get_kotamaEdit($this->tableSat, 'id_pkpt', $id);
		$data['aadata']      = $model->get($this->tablePk, $this->primaryKey, $id);
		$template            = $this->loadView('jadwal_readonly');
		$template->set('data', $data);
		$template->render();

	}

	public function jdwlGetRev($x, $y)

	{
		$uri = $this->loadHelper('Url_helper');
		$id                  = $this->base64url_decode($x);
		$model               = $this->loadModel($this->model);

		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Jadwal';
		$data['curl']	     = $this->curl;
		// $id 			     = $_POST['autono'];
		// $data['encode']	     = $x;
		$data['encode']	     = $x;
		$data['nomor_pkpt']  = $y;
		$data['nomor_pkpt']  = $uri->segment(5);
		$data['flag']        = $uri->segment(6);
		$data['no']			 = $uri->segment(7);
		$data['id_jns_audit']= $model->get_jenisAudit();
		$data['id_kotama'] 	 = $model->get_kotamaEdit($this->tableSat, 'id_pkpt', $id);
		$data['aadata']      = $model->get($this->tablePk, $this->primaryKey, $id);
		$template            = $this->loadView('rev_readonly');
		$template->set('data', $data);
		$template->render();

	}

	// public function edit($x)
	// {
	// 	$id                  = $this->base64url_decode($x);
	// 	$model               = $this->loadModel($this->model);
	// 	$uri = $this->loadHelper('Url_helper');
	// 	$data['nomor_pkpt']  = $uri->segment(5);
	// 	$data['encode']	     = $x;
	// 	$data['nomor_pkpt']  = $y;

	// 	// $uri                 = $this->loadHelper('Url_helper');
	// 	$data                = array();
	// 	$data['breadcrumb1'] = $this->menu;
	// 	$data['title']       = $this->title;
	// 	$data['action']      = 'Edit';
	// 	$data['encode']      = $x;
	// 	$data['curl']	     = $this->curl;
	// 	// // $data['child']       = $uri->segment(5);

	// 	$data['id_jns_audit']= $model->get_jenisAudit();
	// 	$data['id_kotama'] 	 = $model->get_kotamaEdit($this->tableSat, 'id_pkpt', $id);
	// 	$data['aadata']      = $model->get($this->table, $this->primaryKey, $id);
	// 	$template            = $this->loadView('pkpt_edit');
	// 	$template->set('data', $data);
	// 	$template->render();
	// }


	public function edit($x,$y)

	{

		$id                  = $this->base64url_decode($x);

		$model               = $this->loadModel($this->model);

		$uri                 = $this->loadHelper('Url_helper');

		$data                = array();

		// $data['tahun']		 = $uri->segment(7);

		// $data['bulan']		 = $uri->segment(8);

		$data['breadcrumb1'] = $this->menu;

		$data['title']       = $this->title;

		$data['action']      = 'Edit';

		$data['nomor_pkpt']  = $uri->segment(5);

		$data['curl']	     = $this->curl;

		$data['encode']	     = $x;
		$data['nomor_pkpt']  = $y;

		$data['color'] = 	$model->getColor();
		$data['id_jns_audit']= $model->get_jenisAudit();
		$data['id_kotama'] 	 = $model->get_kotamaEdit($this->tableSat, 'id_pkpt', $id);

		$data['aadata']      = $model->get($this->table, $this->primaryKey, $id);

		$template            = $this->loadView('pkpt_edit');

		$template->set('data', $data);

		$template->render();

	}

	public function editRev($x,$y)

	{

		$id                  = $this->base64url_decode($x);

		$model               = $this->loadModel($this->model);

		$uri                 = $this->loadHelper('Url_helper');

		$data                = array();

		// $data['tahun']		 = $uri->segment(7);

		// $data['bulan']		 = $uri->segment(8);

		$data['breadcrumb1'] = $this->menu;

		$data['title']       = $this->title;

		$data['action']      = 'Edit';

		$data['nomor_pkpt']  = $uri->segment(5);

		$data['curl']	     = $this->curl;

		$data['encode']	     = $x;

		$data['nomor_pkpt']  = $y;

		$data['color']       = $model->getColor();

		$data['review']      = $model->get_reviewEdit($this->tableView, 'id_pkpt', $id);

		$data['aadata']      = $model->get($this->tableRev, $this->primaryKey, $id);

		$template            = $this->loadView('pkpt_rev_edit');

		$template->set('data', $data);

		$template->render();

	}

	public function save()
	{
		$data                 = array();
		$model                = $this->loadModel($this->model);
		$data['parent_id']    = $this->base64url_decode($x) ;
		$data['title']   	= htmlspecialchars($_REQUEST['title']) ;
		// $data['satker']       = htmlspecialchars($_REQUEST['satker']) ;
		$data['id_pkpt']		= htmlspecialchars($_REQUEST['autono']);
		$data['id_jns_audit']      = htmlspecialchars($_REQUEST['id_jns_audit']) ;
		$data['color']      = htmlspecialchars($_REQUEST['color']) ;
		$data['start'] = date("Y-m-d",strtotime($_REQUEST['start']));
		$data['end'] = date("Y-m-d",strtotime($_REQUEST['end'])) ;
		$data['autocode']     = $model->autocode($this->table, "#autocode#");	
		$result               = $model->msave($this->table, $data, $this->title);
		$lastid               = $result['id'];
		$jmlsat 		      = count($_REQUEST['satker']);

		for ($i=0; $i < $jmlsat ; $i++){
			$satker['autocode']  = $model->autocode($this->tableSat, "SPSAT_");
			$satker['id_pkpt']  = $lastid;
			$satker['id_kotama'] = htmlspecialchars($_REQUEST['satker'][$i]);
			$satker['title']   	= htmlspecialchars($_REQUEST['title']) ;
			$satker['start'] = date("Y-m-d",strtotime($_REQUEST['start']));
			$satker['end'] = date("Y-m-d",strtotime($_REQUEST['end'])) ;
			$satresult 			 = $model->msave($this->tableSat, $satker, $this->title);
		}

		$this->redirect('pkpt');

	}

	public function saveRev()
	{
		$data                 = array();
		$model                = $this->loadModel($this->model);
		$data['parent_id']    = $this->base64url_decode($x) ;
		$data['title']   	  = htmlspecialchars($_REQUEST['title']) ;
		$data['id_pkpt']      = htmlspecialchars($_REQUEST['autono']);
		$data['color']        = htmlspecialchars($_REQUEST['color']) ;
		$data['start']        = date("Y-m-d",strtotime($_REQUEST['start']));
		$data['end']          = date("Y-m-d",strtotime($_REQUEST['end'])) ;
		$data['autocode']     = $model->autocode($this->tableRev, "#autocode#");	
		$result               = $model->msave($this->tableRev, $data, $this->title);
		$lastid               = $result['id'];
		$jmlsat 		      = count($_REQUEST['review']);

		for ($j=0; $j < $jmlsat ; $j++){
			$satker['autocode'] = $model->autocode($this->tableView, "SPREV_");
			$satker['id_pkpt']  = $lastid; 
			$satker['id_review']   = htmlspecialchars($_REQUEST['review'][$j]);
			$satker['title']   	= htmlspecialchars($_REQUEST['title']) ;
			$satker['start']    = date("Y-m-d",strtotime($_REQUEST['start']));
			$satker['end']      = date("Y-m-d",strtotime($_REQUEST['end'])) ;
			$satresult 			= $model->msave($this->tableView, $satker, $this->title);
		}

		$this->redirect('pkpt');

	}

	public function update($x)
	{
		$uri                = $this->loadHelper('Url_helper');
		$data               = array();
		$sat 				= array();
		$id                 = $this->base64url_decode($x);
		$model              = $this->loadModel($this->model);
		

		$child              = $uri->segment(4);
		$parent_id = $this->base64url_decode($uri->segment(4));
		$nomor_pkpt            = $uri->segment(5);
		// $uri                = $this->loadHelper('Url_helper');
		// $child              = $uri->segment(5);
		$data['title']	   	= htmlspecialchars($_REQUEST['title']) ;
		$data['id_jns_audit']	= htmlspecialchars($_REQUEST['id_jns_audit']);
		$data['start']  	= date("Y-m-d",strtotime($_REQUEST['start'])) ;
		$data['end']  		= date("Y-m-d",strtotime($_REQUEST['end'])) ;
		$data['color']		= htmlspecialchars($_REQUEST['color']) ;
		$result         	= $model->mupdate($this->table, $data, $this->primaryKey, $id, $this->title);

		$jmlsat               = count($_REQUEST['satker']);
		$hapusSatker 		  = $model->mdel($this->tableSat, 'id_pkpt', $id, $this->title);

		for ($j=0; $j < $jmlsat ; $j++) { 
			$satker['autocode']  = $model->autocode($this->tableSat, "SPSAT_");
			$satker['id_pkpt']   = $id;
			$satker['id_kotama'] = htmlspecialchars($_REQUEST['satker'][$j]);
			$satker['title']	   	= htmlspecialchars($_REQUEST['title']) ;
			$satker['start']  	= date("Y-m-d",strtotime($_REQUEST['start'])) ;
			$satker['end']  		= date("Y-m-d",strtotime($_REQUEST['end'])) ;
			$satresult           = $model->msave($this->tableSat, $satker, $this->title);
		}

		if($child){

			$this->redirect('pkpt_detail/detail/'.$child.'/'.$nomor_pkpt);

		} else {

			$this->redirect('pkpt_detail');

		}

	}

	public function update_rev($x)
	{
		$uri                = $this->loadHelper('Url_helper');
		$data               = array();
		$sat 				= array();
		$id                 = $this->base64url_decode($x);
		$model              = $this->loadModel($this->model);
		

		$child              = $uri->segment(4);
		$parent_id = $this->base64url_decode($uri->segment(4));
		$nomor_pkpt            = $uri->segment(5);
		// $uri                = $this->loadHelper('Url_helper');
		// $child              = $uri->segment(5);
		$data['title']	   	= htmlspecialchars($_REQUEST['title']) ;
		$data['start']  	= date("Y-m-d",strtotime($_REQUEST['start'])) ;
		$data['end']  		= date("Y-m-d",strtotime($_REQUEST['end'])) ;
		$data['color']		= htmlspecialchars($_REQUEST['color']) ;
		$result         	= $model->mupdate($this->tableRev, $data, $this->primaryKey, $id, $this->title);

		$jmlsat               = count($_REQUEST['review']);
		$hapusSatker 		  = $model->mdel($this->tableView, 'id_pkpt', $id, $this->title);

		for ($j=0; $j < $jmlsat ; $j++) { 
			$satker['autocode']  = $model->autocode($this->tableView, "SPREV_");
			$satker['id_pkpt']   = $id;
			$satker['id_review'] = htmlspecialchars($_REQUEST['review'][$j]);
			$satker['title']	   	= htmlspecialchars($_REQUEST['title']) ;
			$satker['start']  	= date("Y-m-d",strtotime($_REQUEST['start'])) ;
			$satker['end']  		= date("Y-m-d",strtotime($_REQUEST['end'])) ;
			$satresult           = $model->msave($this->tableView, $satker, $this->title);
		}

		if($child){

			$this->redirect('pkpt_detail/detail/'.$child.'/'.$nomor_pkpt);

		} else {

			$this->redirect('pkpt_detail');

		}

	}

	public function updatePkpt($x)
	{
		$data               = array();
		$sat 				= array();
		$id                 = $this->base64url_decode($x);
		$model              = $this->loadModel($this->model);
		$data['parent_id']  = $this->base64url_decode($x) ;
		// $uri                = $this->loadHelper('Url_helper');
		// $child              = $uri->segment(5);
		$data['nomor_pkpt']	   	= htmlspecialchars($_REQUEST['nomor_pkpt']) ;
		$data['keterangan']	= htmlspecialchars($_REQUEST['keterangan']);
		$result         	= $model->mupdate($this->tablePk, $data, $this->primaryKey, $id, $this->title);

		$this->redirect('pkpt');

	}

	Public function dragUpdateEvent()
	{	
		$model              = $this->loadModel($this->model);
		$result  			= $model->dragUpdateEvent();
		echo $result;
	}
	public function delete_sat($x)
	{
		$id                 = $this->base64url_decode($x);
		$model              = $this->loadModel($this->model);
		$result             = $model->mdelete($this->table, $this->primaryKey, $id, $this->title);
		$resultSat          = $model->mdelete($this->tableSat, 'id_pkpt', $id,  $this->title);

		$this->redirect('pkpt_detail');
	}

	public function delete_rev($x)
	{
		$id                 = $this->base64url_decode($x);
		$model              = $this->loadModel($this->model);
		$result             = $model->mdelete($this->tableRev, $this->primaryKey, $id, $this->title);
		$resultSat          = $model->mdelete($this->tableView, 'id_pkpt', $id,  $this->title);

		$this->redirect('pkpt_detail');
	}


	Public function getEvents($x, $y)
	{
		$uri                = $this->loadHelper('Url_helper');
		$data['nomor_pkpt'] = $uri->segment(5);

		$data['encode']      = $x;

		$data['nomor_pkpt']  = $y;


		$id 				= $_POST['autono'];
		$model              = $this->loadModel($this->model);
		$result             = $model->getpkpt_detils($y);
		echo json_encode($result);
	}

	Public function getEventsRev($x, $y)
	{
		$uri                = $this->loadHelper('Url_helper');
		$data['nomor_pkpt'] = $uri->segment(5);

		$data['encode']      = $x;

		$data['nomor_pkpt']  = $y;


		$id 				= $_POST['autono'];
		$model              = $this->loadModel($this->model);
		$result             = $model->getreview_detils($y);
		echo json_encode($result);
	}

	Public function getChecked($id)
	{	
		$id 				= $_POST['autono'];
		$data 				= array();
		$model              = $this->loadModel($this->model);

		$result=$model->getChecked($id);
		echo json_encode($result);
	}

	/*Delete Event*/
	Public function deleteEvent()
	{
		$id  		= $_POST['autono'];
		$model   	= $this->loadModel($this->model);
		$result 	= $model->deleteEvent($id);
		return $result;
	}

	Public function updateEvent(){
		$id 		= $_POST['autono'];
		$model 		= $this->loadModel($this->model);
		$result 	= $model->updateEvent($id);

		$jmlsat               = count($_REQUEST['satker']);
		$hapusSatker 		  = $model->mdel($this->tableSat, 'id_pkpt', $id, $this->title);

		for ($j=0; $j < $jmlsat ; $j++) { 
			$satker['autocode']  	 = $model->autocode($this->tableSat, "SPSAT_");
			$satker['id_pkpt']    = $id;
			$satker['id_kotama'] = htmlspecialchars($_REQUEST['satker'][$j]);
			$satresult          = $model->msave($this->tableSat, $satker, $this->title);
		}
		echo $result; 
	}

	function gets_pkptSatker($y)
	{		
		$uri                = $this->loadHelper('Url_helper');
		$data['nomor_pkpt'] = $uri->segment(5);

		$data['encode']      = $x;

		$data['nomor_pkpt']  = $y;

		$id    = $_REQUEST['id_jns_audit'];

		$model = $this->loadModel($this->model);
		$data  = $model->get_pkptSatker($y, $id);
		echo json_encode($data);
	} 


}

