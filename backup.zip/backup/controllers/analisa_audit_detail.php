<?php

class Analisa_audit_detail extends Controller {

	private $table      = "vt_anaupost_detail";
	private $primaryKey = "autono";
	private $model      = "Analisa_audit_detail_model";
	private $menu       = "Post Audit";
	private $title      = "analisa audit Detail";
	private $curl       = BASE_URL."analisa_audit_detail";
	

	public function __construct()
    {
        $session = $this->loadHelper('Session_helper');
        if(!$session->get('username')){
        	$this->redirect('auth/login');
        }
    }
	
	function index()
	{
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['curl']	     = $this->curl;
		$template            = $this->loadView('analisa_audit_detail_view');
		$template->set('data', $data);
		$template->render();
	}

	public function detail($x)
	{
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['curl']	     = $this->curl;
		$data['encode']      = $x;
		$template            = $this->loadView('analisa_audit_detail_view');
		$template->set('data', $data);
		$template->render();
	}

	function get($x = null)
	{
		$request    = $_REQUEST;
		$id         = $this->base64url_decode($x);
		$columns = array(
			array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'nrp_nip',  'dt' => 1 ),array( 'db' => 'waktu',  'dt' => 2 ),array( 'db' => 'nomor_kka',  'dt' => 3 ),
		);

		$model   = $this->loadModel($this->model);
		if($x){
			$result  = $model->mget_detail($request, $this->table, $this->primaryKey, $columns, $id);
		} else {
			$result  = $model->mget($request, $this->table, $this->primaryKey, $columns);
		}

		return json_encode($result);
	}

	public function add($x = null)
	{
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Add';
		$data['curl']	     = $this->curl;
		$data['encode']	     = $x;
		$template            = $this->loadView('analisa_audit_detail_add');
		$template->set('data', $data);
		$template->render();
	}

	public function edit($x)
	{
		$id                  = $this->base64url_decode($x);
		$model               = $this->loadModel($this->model);
		$uri                 = $this->loadHelper('Url_helper');
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Edit';
		$data['encode']      = $x;
		$data['curl']	     = $this->curl;
		$data['child']       = $uri->segment(5);
		$data['aadata']      = $model->get($this->table, $this->primaryKey, $id);
		$template            = $this->loadView('analisa_audit_detail_edit');
		$template->set('data', $data);
		$template->render();
	}

	public function save($x = null)
	{
		$data                 = array();
		$model                = $this->loadModel($this->model);
		$data['parent_id']    = $this->base64url_decode($x) ;
		$data['nrp_nip'] = htmlspecialchars($_REQUEST['nrp_nip']) ;
		$data['waktu'] = htmlspecialchars($_REQUEST['waktu']) ;
		$data['nomor_kka'] = htmlspecialchars($_REQUEST['nomor_kka']) ;

		$data['autocode']     = $model->autocode($this->table, "#autocode#");	
		$result               = $model->msave($this->table, $data, $this->title);
		if($x){
			$this->redirect('analisa_audit_detail/detail/'.$x);
		} else {
			$this->redirect('analisa_audit_detail');
		}
	}

	public function update($x)
	{
		$data               = array();
		$id                 = $this->base64url_decode($x);
		$model              = $this->loadModel($this->model);
		$uri                = $this->loadHelper('Url_helper');
		$child              = $uri->segment(5);
		$data['nrp_nip'] = htmlspecialchars($_REQUEST['nrp_nip']) ;
		$data['waktu'] = htmlspecialchars($_REQUEST['waktu']) ;
		$data['nomor_kka'] = htmlspecialchars($_REQUEST['nomor_kka']) ;
	
		$result             = $model->mupdate($this->table, $data, $this->primaryKey, $id, $this->title);
		if($child){
			$this->redirect('analisa_audit_detail/detail/'.$child);
		} else {
			$this->redirect('analisa_audit_detail');
		}
	}

	public function delete($x)
	{
		$id                 = $this->base64url_decode($x);
		$model              = $this->loadModel($this->model);
		$result             = $model->mdelete($this->table, $this->primaryKey, $id, $this->title);
		return $result;
	}
    
}