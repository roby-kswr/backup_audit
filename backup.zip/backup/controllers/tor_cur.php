<?php

class Tor_cur extends Controller {

	private $table      = "tor_cur";
	private $primaryKey = "autono";
	private $model      = "Tor_cur_model"; # please write with no space
	private $menu       = "Transaksi";
	private $title      = "TOR - Current";
	private $curl       = BASE_URL."tor_cur/";
	

	public function __construct()
    {
        $session = $this->loadHelper('Session_helper');
        if(!$session->get('username')){
        	$this->redirect('auth/login');
        }
    }
	
	function index()
	{
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['curl']        = $this->curl;
		$template            = $this->loadView('tor_cur_view');
		$template->set('data', $data);
		$template->render();
	}

	function get()
	{
		$request = $_REQUEST;
		$columns = array(
			array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'no_tor',  'dt' => 1 ),
			array( 'db' => 'tgl_tor',  'dt' => 2 ),
			array( 'db' => 'hasil',  'dt' => 3 ),
			array( 'db' => 'pagu',  'dt' => 4 ),
			array( 'db' => 'keterangan',   'dt' => 5 ),
			array( 'db' => 'file_dokumen',   'dt' => 6 ),
			array( 'db' => 'id_hps',   'dt' => 7 )
		);
		
		$model  = $this->loadModel($this->model);
		$result = $model->mget($request, $this->table, $this->primaryKey, $columns, $join);

		return json_encode($result);
	}

	function getfile($x, $y)
	{
		$id         = $this->base64url_decode($x);
		$request    = $_REQUEST;
		$primaryKey = "parent_id";
		$sTable     = "vt_files";
		$columns = array(
			array( 'db' => 'autono', 'dt' => 0 ),
			array( 'db' => 'nama_file',  'dt' => 1 ),
			array( 'db' => 'tipe_file',   'dt' => 2 ),
			array( 'db' => 'ukuran',   'dt' => 3 , 'formatter' => function( $d, $row ) { return number_format($d/1024). ' KB'; }),
			array( 'db' => 'keterangan',   'dt' => 4 ),
			array( 'db' => 'kode_parent',   'dt' => 5 )
			//array( 'db' => 'subdir',   'dt' => 6 )
		);

		$model  = $this->loadModel('tor_cur_model');
		$result = $model->getfiles($request, $sTable, $primaryKey, $columns, $id, $y);

		$row = json_encode($result);

		return $row;
	}

	public function add()
	{
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Add';
		$data['curl']        = $this->curl;
		$data['id_hps']      = $model->hps_post();
		$data['id_program']  = $model->get_program();
		$data['id_kegiatan'] = $model->get_kegiatan();
		$data['id_personel'] = $model->get_personel();
		$template            = $this->loadView('tor_cur_add');
		$template->set('data', $data);
		$template->render();
	}

	public function edit($x)
	{
		$id                  = $this->base64url_decode($x);
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Edit';
		$data['encode']      = $x;
		$data['curl']        = $this->curl;
		$data['id_program']  = $model->get_programEdit($this->table, $this->primaryKey, $id);
		$data['id_kegiatan'] = $model->get_kegiatanEdit($this->table, $this->primaryKey, $id);
		$data['id_personel'] = $model->get_personelEdit($this->table, $this->primaryKey, $id);
		$data['attch']       = $model->get_file_attachment($id);
		$data['aadata']      = $model->get($this->table, $this->primaryKey, $id);
		$template            = $this->loadView('tor_cur_edit');
		$template->set('data', $data);
		$template->render();
	}

	public function save()
	{
		$data                 = array();
		$model                = $this->loadModel($this->model);
		$data['parent_id']    = $this->base64url_decode($x) ;
		$data['no_tor']       = ucwords(htmlspecialchars($_REQUEST['no_tor'])) ;
		$date                 = str_replace('/', '-', $_REQUEST['tgl_tor']);
		$data['tgl_tor']      = date("Y-m-d",strtotime($date)) ;
		$data['id_program']   = htmlspecialchars($_REQUEST['id_program']) ;
		$data['id_hps']       = htmlspecialchars($_REQUEST['id_hps']) ;
		$data['id_kegiatan']  = htmlspecialchars($_REQUEST['id_kegiatan']) ;
		$data['hasil']        = ucwords(htmlspecialchars($_REQUEST['hasil'])) ;
		$data['pagu']         = htmlspecialchars($_REQUEST['pagu']) ;
		$data['id_personel']  = htmlspecialchars($_REQUEST['id_personel']) ;
		$data['keterangan']   = ucwords(htmlspecialchars($_REQUEST['keterangan'])) ;
		$data['file_dokumen'] = !empty($_FILES['file_dokumen']['name'][0]) ?  1 : 0;
		$data['autocode']     = $model->autocode($this->table, "TR_");	
		$result               = $model->msave($this->table, $data, $this->title);
		$lastid               = $result['id'];

		# Insert files
		$files1        = array();
		$files1['dir'] = "TOR_CUR";
		if(!empty($_FILES['file_dokumen']['name'][0])) {
		    $file_ary1 = $model->reArrayFiles($_FILES['file_dokumen']);
		    foreach ($file_ary1 as $file1) {
				$files1['kode_parent'] = $data['autocode'];
				$files1['parent_id']   = $lastid;
				$files1['nama_file']   = $this->randName($file1['name']);
				$files1['tipe_file']   = $file1['type'];
				$files1['ukuran']      = $file1['size'];
				$files1['ftable']      = $this->table;

				if(!empty($file1['name'])){ $model->savefile($files1); } 
		    }
		}

		# Upload file
		if(isset($_FILES['file_dokumen'])){ $model->uploads('TOR_CUR', $_FILES['file_dokumen'], $data['autocode']); 
	}

		$this->redirect('tor_cur');
	}

	public function update($x)
	{
		$data                 = array();
		$id                   = $this->base64url_decode($x);
		$model                = $this->loadModel($this->model);
		$autocode             = $model->getval($this->table, 'autocode', 'autono', $id);
		$data['no_tor']       = ucwords(htmlspecialchars($_REQUEST['no_tor'])) ;
		$date                 = str_replace('/', '-', $_REQUEST['tgl_tor']);
		$data['tgl_tor']      = date("Y-m-d",strtotime($date)) ;
		$data['id_hps']   	  = htmlspecialchars($_REQUEST['id_hps']) ;
		$data['id_program']   = htmlspecialchars($_REQUEST['id_program']) ;
		$data['id_kegiatan']  = htmlspecialchars($_REQUEST['id_kegiatan']) ;
		$data['hasil']        = ucwords(htmlspecialchars($_REQUEST['hasil'])) ;
		$data['pagu']         = htmlspecialchars($_REQUEST['pagu']) ;
		$data['id_personel']  = htmlspecialchars($_REQUEST['id_personel']) ;
		$data['keterangan']   = ucwords(htmlspecialchars($_REQUEST['keterangan'])) ;
		$data['file_dokumen'] = !empty($_FILES['file_dokumen']['name'][0]) ?  1 : 0;
		$result               = $model->mupdate($this->table, $data, $this->primaryKey, $id, $this->title);

		# Insert files
		$files1        = array();
		$files1['dir'] = "TOR_CUR";
		if(!empty($_FILES['file_dokumen']['name'][0])) {
		    $file_ary1 = $model->reArrayFiles($_FILES['file_dokumen']);
		    foreach ($file_ary1 as $file1) {
				$files1['kode_parent'] = $autocode;
				$files1['parent_id']   = $id;
				$files1['nama_file']   = $this->randName($file1['name']);
				$files1['tipe_file']   = $file1['type'];
				$files1['ukuran']      = $file1['size'];
				$files1['ftable']      = $this->table;

				if(!empty($file1['name'])){ $model->savefile($files1); } 
		    }
		    # Update field dokumen
			$f1                 = array();
			$f1['file_dokumen'] = 1;
			$row1               = $model->mupdate($this->table, $f1, $this->primaryKey, $id, $this->title);
		}

		# Upload file
		if(isset($_FILES['file_dokumen'])){ $model->uploads('TOR_CUR', $_FILES['file_dokumen'], $autocode); }

		$this->redirect('tor_cur');
	}

	public function delete($x)
	{
		$id     = $this->base64url_decode($x);
		$model  = $this->loadModel($this->model);
		$result = $model->mdelete($this->table, $this->primaryKey, $id, $this->title);
		return $result;
	}

	public function deletefile($x = null)
	{
		$data   = array();
		$id     = $this->base64url_decode($x);
		$model  = $this->loadModel($this->model);
		$result = $model->deletes_file($id);
		$this->redirect('tor_cur_edit'/$id);
	}

	public function download($key = null)
	{
		if($key){
			$id     = $this->base64url_decode($key);
			$model  = $this->loadModel($this->model);
			$data   = $model->getvalue("SELECT dir, kode_parent, subdir, nama_file FROM vt_files WHERE autono = $id");
			$path   = $data[0]."/".$data[1]."/".$data[2]."/";
			$result = $this->download_file($data[3], $path);
			return $result;
		} else {
			echo "Not found";
		}

	}
    
}