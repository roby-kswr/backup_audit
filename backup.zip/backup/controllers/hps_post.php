<?php

class Hps_post extends Controller {

	private $table      = "hps_post";
	private $tableSat   = "vt_upload_hps_post";
	private $primaryKey = "autono";
	private $primaryKey2 = "autocode";
	private $model      = "Hps_post_model"; # please write with no space
	private $menu       = "Ekstrak Data";
	private $title      = "HPS - Post ";
	private $curl       = BASE_URL."hps_post/";
	private $curl2      = BASE_URL."hps_post";
	

	public function __construct()
    {
        $session = $this->loadHelper('Session_helper');
        if(!$session->get('username')){
        	$this->redirect('auth/login');
        }
    }

	function index()
	{
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['curl']		 = $this->curl;
		$data['curl2']		 = $this->curl2;
		$template            = $this->loadView('hps_post_view');
		$template->set('data', $data);
		$template->render();
	}

	function get($x = null)
	{
		$request = $_REQUEST;
		$columns = array(
			array( 'db' => 'autono',      'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'no_hps', 'dt' => 1 ),
			array( 'db' => 'tahun',       'dt' => 2 ),
			array( 'db' => 'file_name',   'dt' => 3 ),
			array( 'db' => 'satminkal',   'dt' => 4 ),
			array( 'db' => 'autocode',    'dt' => 5 ),
			array( 'db' => 'program',     'dt' => 6 ),
			array( 'db' => 'giat',        'dt' => 7 ),
			array( 'db' => 'output',      'dt' => 8 ),
			array( 'db' => 'suboutput',   'dt' => 9 ),
			array( 'db' => 'komponen',    'dt' => 10 ),
			array( 'db' => 'subkomponen', 'dt' => 11 ),
			array( 'db' => 'akun',        'dt' => 12 ),
			array( 'db' => 'sum_score',   'dt' => 13 ),
			array( 'db' => 'nm_satminkal',   'dt' => 14 )
			
			
		);

		// $join = "a
		// 		 LEFT JOIN (SELECT nm_satminkal,kd_satminkal AS kode_satminkal FROM tsatminkal ) AS b ON a.satminkal = b.kode_satminkal";

		$model   = $this->loadModel($this->model);
		if($x){
			$result  = $model->mget_detail($request, $this->table, $this->primaryKey, $columns,$join, $id);
		} else {
			$result  = $model->mget($request, $this->table, $this->primaryKey, $columns);
		}

		return json_encode($result);
	}

	public function add()
	{
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Add';
		$data['curl']		 = $this->curl;

        $data['satminkal']	 = $model->get_satmin();
        $data['program']	 = $model->get_program();
        $data['giat']		 = $model->get_kegiatan();
        $data['output']		 = $model->output();
        $data['suboutput']   = $model->suboutput();
        $data['komponen']    = $model->get_komponen();
        $data['subkomponen'] = $model->get_subkomponen();
        $data['akun'] 		 = $model->get_akun();

		$template            = $this->loadView('hps_post_add');
		$template->set('data', $data);
		$template->render();
	}

	public function edit($x)
	{
		$id                  = $this->base64url_decode($x);
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Edit';
		$data['encode']      = $x;
		$data['curl']		 = $this->curl;
		$data['aadata']      = $model->get($this->table, $this->primaryKey, $id);

		$data['satminkal']	 = $model->get_satmin();
        $data['program']	 = $model->get_program();
        $data['giat']		 = $model->get_kegiatan();
        $data['output']		 = $model->output();
        $data['suboutput']   = $model->suboutput();
        $data['komponen']    = $model->get_komponen();
        $data['subkomponen'] = $model->get_subkomponen();
        $data['akun'] 		 = $model->get_akun();

		$template            = $this->loadView('hps_post_edit');
		$template->set('data', $data);
		$template->render();
	}

	public function save()

	{


		$data                 = array();

		$model                = $this->loadModel($this->model);
		$data['parent_id']    = $this->base64url_decode($x) ;

		$data['satminkal']    = htmlspecialchars($_REQUEST['satminkal']) ;
		$data['program']      = htmlspecialchars($_REQUEST['program']) ;
		$data['giat']         = htmlspecialchars($_REQUEST['giat']) ;
		$data['output']       = htmlspecialchars($_REQUEST['output']) ;
		$data['suboutput']    = htmlspecialchars($_REQUEST['suboutput']) ;
		$data['komponen']     = htmlspecialchars($_REQUEST['komponen']) ;
		$data['subkomponen']  = htmlspecialchars($_REQUEST['subkomponen']) ;
		$data['akun']         = htmlspecialchars($_REQUEST['akun']) ;

		$data['no_hps']       = htmlspecialchars($_REQUEST['no_hps']) ;
		$data['tahun']        = htmlspecialchars($_REQUEST['tahun']) ;
		$data['file_name']    = $_FILES['file_name']['name'] ;
		$data['autocode']     = $model->autocode($this->table, "ekhps_");
		// $s	  				  = $model->aut();
		
		$result               = $model->msave($this->table, $data, $this->title);
		$last_id            = $result['id'];

		$uploadDyn			  = $model->uploadHpspos($_FILES['file_name'],$data['satminkal'],$data['tahun'],$data['autocode']);

		$import_hps		      = $model->import_hps_post($data['satminkal'],$data['tahun'], $s, $data['autocode'], $last_id);
        
        $this->redirect('hps_post_detail/detail/'.$data['satminkal'].'/'.$data['autocode']);
        // $this->redirect('ekstrakhps');
	}

	public function update($x)
	{
		$data           	= array();
		$id             	= $this->base64url_decode($x);
		$model          	= $this->loadModel($this->model);
		$data['satker']     = htmlspecialchars($_REQUEST['satker']) ;
		$data['tahun']      = htmlspecialchars($_REQUEST['tahun']) ;
		$data['file_name']	= htmlspecialchars($_REQUEST['file_name']) ;
		$result         	= $model->mupdate($this->table, $data, $this->primaryKey, $id, $this->title);
		$this->redirect('hps_post');
	}

	public function delete($x)
	{
		$id        = $this->base64url_decode($x);
		$model     = $this->loadModel($this->model);
		$resultSat = $model->mdelete($this->tableSat,'parent_id', $id, $this->title);
		$result    = $model->mdelete($this->table, $this->primaryKey,$id, $this->title);
		
		
		return $result;
	}

}