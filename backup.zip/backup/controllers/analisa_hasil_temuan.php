<?php



class Analisa_hasil_temuan extends Controller {



	// private $table      = "vt_verku_renlak";
	private $table      = "dja_pagu";

	private $primaryKey = "id";

	private $model      = "Analisa_hasil_temuan_model";

	private $menu       = "Analisa";

	private $title      = "Analisa Hasil Temuan";

	private $curl       = BASE_URL."analisa_hasil_temuan";

	



	public function __construct()

    {

        $session = $this->loadHelper('Session_helper');

        if(!$session->get('username')){

        	$this->redirect('auth/login');

        }

    }

	

	function index()

	{

		$data                = array();

		$data['breadcrumb1'] = $this->menu;

		$data['title']       = $this->title;

		$data['curl']	     = $this->curl;

		$template            = $this->loadView('analisa_hasil_temuan_view');

		$template->set('data', $data);

		$template->render();

	}



	public function detail($x)

	{

		$data                = array();

		$data['breadcrumb1'] = $this->menu;

		$data['title']       = $this->title;

		$data['curl']	     = $this->curl;

		$data['encode']      = $x;

		$template            = $this->loadView('analisa_hasil_temuan_view');

		$template->set('data', $data);

		$template->render();

	}



	function get($x = null)

	{

		$request    = $_REQUEST;

		$uri        = $this->loadHelper('Url_helper');

		$id         = $this->base64url_decode($x);

		$tahun = $uri->segment(5);

		$bulan = $uri->segment(6);

		$columns = array(

			array( 'db' => 'id', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),

			array( 'db' => 'kd_kotama',  'dt' => 1 ),array( 'db' => 'nm_satminkal',  'dt' => 2 ),array( 'db' => 'belanja_pegawai',  'dt' => 3 ),array( 'db' => 'belanja_barang',  'dt' => 4 ),array( 'db' => 'belanja_modal',  'dt' => 5 ),array( 'db' => 'kd_satminkal',  'dt' => 9 ),array( 'db' => 'total_hps',  'dt' => 10 ),array( 'db' => 'total_tor',  'dt' => 11 ),array( 'db' => 'total_rab',  'dt' => 12 ),array( 'db' => 'total_sph',  'dt' => 13 ),array( 'db' => 'total_kontrak',  'dt' => 14 ),array( 'db' => 'total_bast',  'dt' => 15 ),array( 'db' => 'total_ku17',  'dt' => 16 ),array( 'db' => 'total_sp2d',  'dt' => 17 ),

		);



		$model   = $this->loadModel($this->model);

		if($x){

			$result  = $model->mget_detail($request, $this->table, $this->primaryKey, $columns, $id);

		} else {

			$result  = $model->mget($request, $this->table, $this->primaryKey, $columns, 'tahun', $tahun,$bulan);
			

		}



		return json_encode($result);

	}



	public function add($x = null)

	{

		$model               = $this->loadModel($this->model);

		$data                = array();

		$data['breadcrumb1'] = $this->menu;

		$data['title']       = $this->title;

		$data['action']      = 'Add';

		$data['curl']	     = $this->curl;

		$data['encode']	     = $x;

		$template            = $this->loadView('analisa_hasil_temuan_add');

		$template->set('data', $data);

		$template->render();

	}



	public function edit($x)

	{

		$id                  = $this->base64url_decode($x);

		$model               = $this->loadModel($this->model);

		$uri                 = $this->loadHelper('Url_helper');

		$data                = array();

		$data['breadcrumb1'] = $this->menu;

		$data['title']       = $this->title;

		$data['action']      = 'Edit';

		$data['encode']      = $x;

		$data['curl']	     = $this->curl;

		$data['child']       = $uri->segment(5);

		$data['aadata']      = $model->get($this->table, $this->primaryKey, $id);

		$template            = $this->loadView('analisa_hasil_temuan_edit');

		$template->set('data', $data);

		$template->render();

	}



	public function save($x = null)

	{

		$data                 = array();

		$model                = $this->loadModel($this->model);

		$data['parent_id']    = $this->base64url_decode($x) ;

		$data['tahun'] = htmlspecialchars($_REQUEST['tahun']) ;
		$data['status'] = htmlspecialchars($_REQUEST['status']) ;
		$data['satker'] = htmlspecialchars($_REQUEST['satker']) ;


		$data['autocode']     = $model->autocode($this->table, "#autocode#");	

		$result               = $model->msave($this->table, $data, $this->title);

		if($x){

			$this->redirect('analisa_hasil_temuan/detail/'.$x);

		} else {

			$this->redirect('analisa_hasil_temuan');

		}

	}



	public function update($x)

	{

		$data               = array();

		$id                 = $this->base64url_decode($x);

		$model              = $this->loadModel($this->model);

		$uri                = $this->loadHelper('Url_helper');

		$child              = $uri->segment(5);

		$data['tahun'] = htmlspecialchars($_REQUEST['tahun']) ;
		$data['status'] = htmlspecialchars($_REQUEST['status']) ;
		$data['satker'] = htmlspecialchars($_REQUEST['satker']) ;
	

		$result             = $model->mupdate($this->table, $data, $this->primaryKey, $id, $this->title);

		if($child){

			$this->redirect('analisa_hasil_temuan/detail/'.$child);

		} else {

			$this->redirect('analisa_hasil_temuan');

		}

	}



	public function delete($x)

	{

		$id                 = $this->base64url_decode($x);

		$model              = $this->loadModel($this->model);

		$result             = $model->mdelete($this->table, $this->primaryKey, $id, $this->title);

		return $result;

	}

    

}