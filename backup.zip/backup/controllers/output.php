<?php



class Output extends Controller {



	private $table      = "toutput";

	private $primaryKey = "autono";

	private $model      = "Output_model"; # please write with no space

	private $menu       = "Reference";

	private $title      = "Output";

	private $curl       = BASE_URL."output/";





	public function __construct()

    {

        $session = $this->loadHelper('Session_helper');

        if(!$session->get('username')){

        	$this->redirect('auth/login');

        }

    }



	function index()

	{

		$data                = array();

		$data['breadcrumb1'] = $this->menu;

		$data['title']       = $this->title;

		$data['curl']		 = $this->curl;

		$template            = $this->loadView('output_view');

		$template->set('data', $data);

		$template->render();

	}



	function get()

	{

		$request = $_REQUEST;

		$columns = array(

			array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),

			array( 'db' => 'nm_kegiatan', 'dt' => 1 ),

			array( 'db' => 'kd_output',   'dt' => 2 ),

			array( 'db' => 'nm_output',   'dt' => 3 ),

            array( 'db' => 'tahun_awal',  'dt' => 4 ),

            array( 'db' => 'tahun_akhir', 'dt' => 5 ),

            array( 'db' => 'keterangan',  'dt' => 6 )

		);



		$model   = $this->loadModel($this->model);

		$result  = $model->mget($request, $this->table, $this->primaryKey, $columns);



		return json_encode($result);

	}



	public function add()

	{

		$model               = $this->loadModel($this->model);

		$data                = array();

		$data['breadcrumb1'] = $this->menu;

		$data['title']       = $this->title;

		$data['action']      = 'Add';

		$data['curl']		 = $this->curl;

        $data['id_kegiatan'] = $model->kegiatan();

		$template            = $this->loadView('output_add');

		$template->set('data', $data);

		$template->render();

	}



	public function edit($x)

	{

		$id                  = $this->base64url_decode($x);

		$model               = $this->loadModel($this->model);

		$data                = array();

		$data['breadcrumb1'] = $this->menu;

		$data['title']       = $this->title;

		$data['action']      = 'Edit';

		$data['encode']      = $x;

		$data['curl']		 = $this->curl;

		$data['aadata']      = $model->get($this->table, $this->primaryKey, $id);

		$data['id_kegiatan'] = $model->kegiatan();

		$template            = $this->loadView('output_edit');

		$template->set('data', $data);

		$template->render();

	}



	public function save()



	{



		$data                 = array();



		$model                = $this->loadModel($this->model);



		$data['parent_id']    = $this->base64url_decode($x) ;

		$data['id_kegiatan']       = htmlspecialchars($_REQUEST['id_kegiatan']) ;

		$data['kd_output']        = htmlspecialchars($_REQUEST['kd_output']) ;

        $data['nm_output']        = htmlspecialchars($_REQUEST['nm_output']) ;

        $data['tahun_awal']        = htmlspecialchars($_REQUEST['tahun_awal']) ;

        $data['tahun_akhir']        = htmlspecialchars($_REQUEST['tahun_akhir']) ;

        $data['keterangan']        = htmlspecialchars($_REQUEST['keterangan']) ;





		$data['autocode']     = $model->autocode($this->table, "OutP_");	



		$result               = $model->msave($this->table, $data, $this->title);

        

        $this->redirect('output');

	}



	public function update($x)

	{

		$data           	= array();

		$id             	= $this->base64url_decode($x);

		$model          	= $this->loadModel($this->model);

        $data['id_kegiatan']       = htmlspecialchars($_REQUEST['id_kegiatan']) ;

		$data['kd_output']        = htmlspecialchars($_REQUEST['kd_output']) ;

        $data['nm_output']        = htmlspecialchars($_REQUEST['nm_output']) ;

        $data['tahun_awal']        = htmlspecialchars($_REQUEST['tahun_awal']) ;

        $data['tahun_akhir']        = htmlspecialchars($_REQUEST['tahun_akhir']) ;

        $data['keterangan']        = htmlspecialchars($_REQUEST['keterangan']) ;

		$result         	= $model->mupdate($this->table, $data, $this->primaryKey, $id, $this->title);

		$this->redirect('output');

	}



	public function delete($x)

	{

		$id     = $this->base64url_decode($x);

		$model  = $this->loadModel($this->model);

		$result = $model->mdelete($this->table, $this->primaryKey, $id, $this->title);

		return $result;

	}



}