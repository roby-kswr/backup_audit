<?php



class Analisa_renlak_vermat extends Controller {



	// private $table      = "vt_verku_renlak";
	private $table      = "tkotama";

	private $primaryKey = "autono";

	private $model      = "Analisa_renlak_vermat_model";

	private $menu       = "Analisa";

	private $title      = "Rencana Pelaksanaan Kegiatan";

	private $curl       = BASE_URL."analisa_renlak_vermat";

	



	public function __construct()

    {

        $session = $this->loadHelper('Session_helper');

        if(!$session->get('username')){

        	$this->redirect('auth/login');

        }

    }

	

	function index()

	{

		$data                = array();

		$data['breadcrumb1'] = $this->menu;

		$data['title']       = $this->title;

		$data['curl']	     = $this->curl;

		$template            = $this->loadView('analisa_renlak_vermat_view');

		$template->set('data', $data);

		$template->render();

	}



	public function detail($x)

	{

		$data                = array();

		$data['breadcrumb1'] = $this->menu;

		$data['title']       = $this->title;

		$data['curl']	     = $this->curl;

		$data['encode']      = $x;

		$template            = $this->loadView('analisa_renlak_vermat_view');

		$template->set('data', $data);

		$template->render();

	}



	function get($x = null)

	{

		$request    = $_REQUEST;

		$uri        = $this->loadHelper('Url_helper');

		$id         = $this->base64url_decode($x);

		$tahun = $uri->segment(5);

		$bulan = $uri->segment(6);

		$columns = array(

			array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),

			array( 'db' => 'kd_kotama',  'dt' => 1 ),
			array( 'db' => 'nm_kotama',  'dt' => 2 ),
			array( 'db' => 'belanja_pegawai',  'dt' => 3 ),
			array( 'db' => 'belanja_barang',  'dt' => 4 ),
			array( 'db' => 'belanja_modal',  'dt' => 5 ),

		);



		$model   = $this->loadModel($this->model);

		if($x){

			$result  = $model->mget_detail($request, $this->table, $this->primaryKey, $columns, $id);

		} else {

			$result  = $model->mget($request, $this->table, $this->primaryKey, $columns, 'tahun', $tahun,$bulan);
			

		}



		return json_encode($result);

	}



	public function add($x = null)

	{

		$model               = $this->loadModel($this->model);

		$data                = array();

		$data['breadcrumb1'] = $this->menu;

		$data['title']       = $this->title;

		$data['action']      = 'Add';

		$data['curl']	     = $this->curl;

		$data['encode']	     = $x;

		$template            = $this->loadView('analisa_renlak_vermat_add');

		$template->set('data', $data);

		$template->render();

	}



	public function edit($x)

	{

		$id                  = $this->base64url_decode($x);

		$model               = $this->loadModel($this->model);

		$uri                 = $this->loadHelper('Url_helper');

		$data                = array();

		$data['breadcrumb1'] = $this->menu;

		$data['title']       = $this->title;

		$data['action']      = 'Edit';

		$data['encode']      = $x;

		$data['curl']	     = $this->curl;

		$data['child']       = $uri->segment(5);

		$data['aadata']      = $model->get($this->table, $this->primaryKey, $id);

		$template            = $this->loadView('analisa_renlak_vermat_edit');

		$template->set('data', $data);

		$template->render();

	}



	public function save($x = null)

	{

		$data                 = array();

		$model                = $this->loadModel($this->model);

		$data['parent_id']    = $this->base64url_decode($x) ;

		$data['tahun'] = htmlspecialchars($_REQUEST['tahun']) ;
		$data['status'] = htmlspecialchars($_REQUEST['status']) ;
		$data['satker'] = htmlspecialchars($_REQUEST['satker']) ;


		$data['autocode']     = $model->autocode($this->table, "#autocode#");	

		$result               = $model->msave($this->table, $data, $this->title);

		if($x){

			$this->redirect('analisa_renlak_vermat/detail/'.$x);

		} else {

			$this->redirect('analisa_renlak_vermat');

		}

	}



	public function update($x)

	{

		$data               = array();

		$id                 = $this->base64url_decode($x);

		$model              = $this->loadModel($this->model);

		$uri                = $this->loadHelper('Url_helper');

		$child              = $uri->segment(5);

		$data['tahun'] = htmlspecialchars($_REQUEST['tahun']) ;
		$data['status'] = htmlspecialchars($_REQUEST['status']) ;
		$data['satker'] = htmlspecialchars($_REQUEST['satker']) ;
	

		$result             = $model->mupdate($this->table, $data, $this->primaryKey, $id, $this->title);

		if($child){

			$this->redirect('analisa_renlak_vermat/detail/'.$child);

		} else {

			$this->redirect('analisa_renlak_vermat');

		}

	}



	public function delete($x)

	{

		$id                 = $this->base64url_decode($x);

		$model              = $this->loadModel($this->model);

		$result             = $model->mdelete($this->table, $this->primaryKey, $id, $this->title);

		return $result;

	}

    

}