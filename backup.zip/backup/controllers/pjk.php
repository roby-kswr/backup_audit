<?php

class Pjk extends Controller {

	private $table      = "view_pjk";
	private $primaryKey = "id";
	private $model      = "Pjk_model"; # please write with no space
	private $menu       = "Transaksi";
	private $title      = "Pertanggungjawaban Keuangan";
	private $curl       = BASE_URL."pjk/";
	
	public function __construct()
	{
		$session = $this->loadHelper('Session_helper');
		if(!$session->get('username')){
			$this->redirect('auth/login');
		}
	}
	
	function index()
	{
		$model = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['curl']        = $this->curl;
		$data['satker']      = $model->satker();
		$data['bidang']   = $model->bidang();
		$template            = $this->loadView('pjk_view');
		$template->set('data', $data);
		$template->render();
	}

	function get($satker)
	{
		$request = $_REQUEST;

		$sat        = $satker;

		$bid         = $bidang;

		$columns = array(
			array( 'db' => 'id', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'nmsatker',  'dt' => 1 ),
			array( 'db' => 'wasgiat',   'dt' => 2 ),
			array( 'db' => 'jml_pagu',   'dt' => 3 ),
			array( 'db' => 'nilai_hps',   'dt' => 4 ),
			array( 'db' => 'nilai_rab',   'dt' => 5 ),
			array( 'db' => 'nilai_sph',   'dt' => 6 ),
			array( 'db' => 'nilai_kontrak',   'dt' => 7 ),
			array( 'db' => 'nilai_sp2d',   'dt' => 8 ),
		);

		$join   = "AS t1 
		LEFT JOIN (SELECT `kdsatker` AS kode, `nmsatker` FROM dja_satker) AS t2 ON t1.KDSATKER = t2.kode
		LEFT JOIN (SELECT `kd_bidang` AS kode_bid, `wasgiat` AS nm_giat FROM tbidang) AS t3 ON t1.wasgiat = t3.nm_giat ";
		$model  = $this->loadModel($this->model);
		if ($satker != '00') {

			$result  = $model->mgetsat($request, $this->table, $this->primaryKey, $columns ,$sat, $join);

		}
		else{

			$result  = $model->mget($request, $this->table, $this->primaryKey, $columns ,$join);



		}

		return json_encode($result);
	}

	public function add()
	{
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Add';
		$data['curl']        = $this->curl;		
		$data['id_sprin']    = $model->get_maxId($this->table);
		$data['pkpt']        = $model->get_pkpt();
		// $data['kotama']      = $model->get_kotama();
		$data['jabwas']      = $model->get_jabatanWasrik();
		$data['personel']    = $model->get_personel();
		$data['tembusan']    = $model->get_tembusan();
		$template            = $this->loadView('sprin_add');
		$template->set('data', $data);
		$template->render();
	}

	public function edit($x)
	{
		$id                  = $this->base64url_decode($x);
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Edit';
		$data['encode']      = $x;
		$data['curl']        = $this->curl;
		$data['pkpt']        = $model->get_pkptEdit($this->table, 'id_pkpt', $id);
		$data['kotama']      = $model->get_kotama();
		$data['jabwas']      = $model->get_jabatanWasrik();
		$data['personel']    = $model->get_personel();
		$data['tembusan']    = $model->get_tembusan();
		$data['aadata']      = $model->get($this->table, $this->primaryKey, $id);
		$template            = $this->loadView('sprin_edit');
		$template->set('data', $data);
		$template->render();
	}

	public function save()
	{
		$data               = array();
		$temb               = array();
		$model              = $this->loadModel($this->model);
		$data['id_pkpt']    = htmlspecialchars($_REQUEST['id_pkpt']) ;
		$data['no_sprin']   = ucwords(htmlspecialchars($_REQUEST['no_sprin'])) ;
		$date               = str_replace('/', '-', $_REQUEST['tgl_sprin']);
		$data['tgl_sprin']  = date("Y-m-d",strtotime($date)) ;
		$data['keterangan'] = $model->escapeString($_REQUEST['keterangan']) ;
		$data['menimbang']  = $model->escapeString($_REQUEST['menimbang']) ;
		$data['dasar']      = $model->escapeString($_REQUEST['dasar']) ;
		$data['kepada']     = $model->escapeString($_REQUEST['kepada']) ;
		$data['untuk']      = $model->escapeString($_REQUEST['untuk']) ;
		$data['autocode']   = $model->autocode($this->table, "SP_");
		$upload             = $model->uploads('sprin', $_FILES['file_name'], $data['autocode']);
		$result             = $model->msave($this->table, $data, $this->title);
		$last_id            = $result['id'];
		$jmlCmbTemb         = count($_REQUEST['temb']);

		for ($i=0; $i < $jmlCmbTemb ; $i++) { 
			$temb['autocode']    = $model->autocode($this->tableTemb, "SPTEMB_");
			$temb['id_sprin']    = $last_id;
			$temb['id_tembusan'] = htmlspecialchars($_REQUEST['temb'][$i]);
			$tembresult          = $model->msave($this->tableTemb, $temb, $this->title);
		}
		
		$this->redirect('sprin');
	}

	public function update($x)
	{
		$data               = array();
		$temb               = array();
		$id                 = $this->base64url_decode($x);
		$model              = $this->loadModel($this->model);
		$cekJmlTemb         = $model->getval($this->tableTemb, 'autono', 'id_sprin', $id);
		$data['id_pkpt']    = htmlspecialchars($_REQUEST['id_pkpt']) ;
		$data['no_sprin']   = ucwords(htmlspecialchars($_REQUEST['no_sprin'])) ;
		$date               = str_replace('/', '-', $_REQUEST['tgl_sprin']);
		$data['tgl_sprin']  = date("Y-m-d",strtotime($date)) ;
		$data['keterangan'] = $model->escapeString($_REQUEST['keterangan']) ;
		$data['menimbang']  = $model->escapeString($_REQUEST['menimbang']) ;
		$data['dasar']      = $model->escapeString($_REQUEST['dasar']) ;
		$data['kepada']     = $model->escapeString($_REQUEST['kepada']) ;
		$data['untuk']      = $model->escapeString($_REQUEST['untuk']) ;
		$upload             = $model->uploads('sprin', $_FILES['file_name'], $data['autocode']);	
		$result             = $model->mupdate($this->table, $data, $this->primaryKey, $id, $this->title);
		$jmlCmbTemb         = count($_REQUEST['temb']);
		$resultdTemb        = $model->mdelete($this->tableTemb, 'id_sprin', $id, $this->title);
		
		for ($i=0; $i < $jmlCmbTemb ; $i++) { 
			$temb['autocode']    = $model->autocode($this->tableTemb, "SPTEMB_");
			$temb['id_sprin']    = $id;
			$temb['id_tembusan'] = htmlspecialchars($_REQUEST['temb'][$i]);
			$resultTemb          = $model->msave($this->tableTemb, $temb, $this->title);
		}		

		$this->redirect('sprin');
	}

	public function delete($x)
	{
		$id         = $this->base64url_decode($x);
		$model      = $this->loadModel($this->model);
		$result     = $model->mdelete($this->table, $this->primaryKey, $id, $this->title);
		return $result;
	}

}