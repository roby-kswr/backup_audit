<?php

class Renlag_int_post extends Controller {

	private $table       = "dja_pagu";
	private $tbl_hps     = "tbl_hps";
	private $tbl_tor     = "tbl_tor";
	private $tbl_rab     = "tbl_rab";
	private $tbl_sph     = "tbl_sph";
	private $tbl_kontrak = "tbl_kontrak";
	private $tbl_bast    = "tbl_bast";
	private $tbl_ku17    = "tbl_ku17";
	private $tbl_sp2d    = "tbl_sp2d";
	private $tblF    	 = "vt_files";
	private $primaryKey  = "id";
	private $primaryKey2  = "autono";

	private $model       = "Renlag_int_post_model"; # please write with no space
	private $menu        = "Transaksi";
	private $title       = "Renlakgiat Bidang Intel";
	private $curl        = BASE_URL."renlag_int_post/";
	private $curl2        = BASE_URL."static/files/dokumen/dochps/";
	private $curl3        = BASE_URL."static/files/dokumen/doctor/";
	private $curl4        = BASE_URL."static/files/dokumen/docrab/";
	private $curl5        = BASE_URL."static/files/dokumen/excelhps/";
	private $curl6        = BASE_URL."static/files/dokumen/exceltor/";
	private $curl7        = BASE_URL."static/files/dokumen/excelrab/";
	private $curl8    	  = BASE_URL."hps_detail/";
	

	public function __construct()
    {
        $session = $this->loadHelper('Session_helper');
        if(!$session->get('username')){
        	$this->redirect('auth/login');
        }
    }
	
	function index()
	{

		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['curl']        = $this->curl;
		$data['curl2']        = $this->curl2;
		$data['curl3']        = $this->curl3;
		$data['curl4']        = $this->curl4;
		$data['curl5']        = $this->curl5;
		$data['curl6']        = $this->curl6;
		$data['curl7']        = $this->curl7;
		$data['curl8']        = $this->curl8;
		$template            = $this->loadView('renlag_int_post_index');
		$template->set('data', $data);
		$template->render();


	}

	function detail($x)
	{
		$model               = $this->loadModel($this->model);
		$id                  = $this->base64url_decode($x);
		$get                 = $model->getvalue("SELECT * FROM $this->table WHERE id = $id");
		$sat                 = $model->getvalue("SELECT * FROM tsatminkal WHERE kd_satminkal = ".$get['kdsatker']."");
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['curl']        = $this->curl;
		$data['curl2']        = $this->curl2;
		$data['curl3']        = $this->curl3;
		$data['curl4']        = $this->curl4;
		$data['curl5']        = $this->curl5;
		$data['curl6']        = $this->curl6;
		$data['curl7']        = $this->curl7;
		$data['curl8']        = $this->curl8;
		$data['nmsatker']    = $sat['nm_satminkal'];
		$data['encode']      = $x;

		// $dataupload   		 = $model->getvalue("SELECT dir, kode_parent, subdir, nama_file, tipe_file FROM vt_files WHERE parent_id = $id AND dir = 'dochps'");
		// echo $dataupload['nama_file'];exit;
		$template            = $this->loadView('renlag_int_post_view');
		$template->set('data', $data);
		$template->render();
	}

	function get()
	{
		$request = $_REQUEST;
		$columns = array(
			array( 'db' => 'id', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'thang',  'dt' => 1 ),
			array( 'db' => 'wasgiat',  'dt' => 2 ),
			array( 'db' => 'urskmpnen',  'dt' => 3 ),
			array( 'db' => 'jml_pagu',   'dt' => 4 )
		);
		
		$join   = "AS t1 LEFT JOIN (SELECT `kdsatker`, `nmsatker` FROM dja_satker) AS t2 ON t1.KDSATKER = t2.kdsatker";
		$model  = $this->loadModel($this->model);
		$result = $model->mgetDipa($request, $this->table, $this->primaryKey, $columns, $join);

		return json_encode($result);
	}

	function getfile()
	{
		$id         = $this->base64url_decode($x);
		$request    = $_REQUEST;
		$primaryKey = "parent_id";
		$sTable     = "vt_files";
		$columns = array(
			array( 'db' => 'autono', 'dt' => 0 ),
			array( 'db' => 'parent_id',  'dt' => 1 ),
			array( 'db' => 'kode_parent',   'dt' => 2 ),
			array( 'db' => 'ukuran',   'dt' => 3 , 'formatter' => function( $d, $row ) { return number_format($d/1024). ' KB'; }),
			array( 'db' => 'tipe_file',   'dt' => 4 ),
			array( 'db' => 'nama_file',   'dt' => 5 )
			//array( 'db' => 'subdir',   'dt' => 6 )
		);

		$model  = $this->loadModel('renlag_int_post_model');
		$result = $model->getfiles($request, $sTable, $primaryKey, $columns, $id);

		$row = json_encode($result);

		return $row;
	}

	function getRenlag()
	{
		$request = $_REQUEST;
		$columns = array(
			array( 'db' => 'id', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'thang',  'dt' => 1 ),
			array( 'db' => 'kdsatker',  'dt' => 2 ),
			array( 'db' => 'kdprogram',   'dt' => 3 ),
			array( 'db' => 'kdgiat',   'dt' => 4 ),
			array( 'db' => 'kdoutput',   'dt' => 5 ),
			array( 'db' => 'kdsoutput',   'dt' => 6 ),
			array( 'db' => 'SUM(jml_pagu)',   'dt' => 7 , 'formatter' => function( $d, $row ) { return number_format($d); } ),
			array( 'db' => 'nm_satminkal',   'dt' => 8 ),
			array( 'db' => 'wasgiat',   'dt' => 9 )
		);
		
		$model  = $this->loadModel($this->model);
		$result = $model->mgetRenlag($request, $this->table, $this->primaryKey, $columns);

		return json_encode($result);
	}

	function getdetail($x)
	{
		$request = $_REQUEST;
		$id      = $this->base64url_decode($x);
		$model   = $this->loadModel($this->model);
		$columns = array(
			array( 'db' => 'id', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'urskmpnen',  'dt' => 1 ),
			array( 'db' => 'kdsatker',  'dt' => 2 ),
			array( 'db' => 'kdprogram',   'dt' => 3 ),
			array( 'db' => 'kdgiat',   'dt' => 4 ),
			array( 'db' => 'kdoutput',   'dt' => 5 ),
			array( 'db' => 'kdsoutput',   'dt' => 6 ),
			array( 'db' => 'SUM(jml_pagu)',   'dt' => 7 , 'formatter' => function( $d, $row ) { return number_format($d); } ),
			array( 'db' => 'wasgiat',   'dt' => 8 ),
			array( 'db' => 'total_hps',   'dt' => 9 ),
			array( 'db' => 'total_tor',   'dt' => 10 ),
			array( 'db' => 'total_rab',   'dt' => 11 )
		);
		
		
		$result = $model->mgetDetail($request, $this->table, $this->primaryKey, $columns, $id);

		return json_encode($result);
	}

	function getrab($x)
	{
		$request = $_REQUEST;
		$id      = $this->base64url_decode($x);
		$model   = $this->loadModel($this->model);
		$columns = array(
			array( 'db' => 'id', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'kdakun',  'dt' => 1 ),
			array( 'db' => 'nmakun',  'dt' => 2 ),
			array( 'db' => 'SUM(jml_pagu)',   'dt' => 3 , 'formatter' => function( $d, $row ) { return number_format($d); } )
		);
		
		
		$result = $model->mgetRab($request, $this->table, $this->primaryKey, $columns, $id);

		return json_encode($result);
	}


	function getAkun($x, $y)
	{
		$id         = $this->base64url_decode($x);
		$request    = $_REQUEST;
		$primaryKey = "id";
		$sTable     = "dja_pagu";
		$columns = array(
			array( 'db' => 'kdakun', 'dt' => 1 ),
			array( 'db' => 'nmakun',  'dt' => 2 ),
			array( 'db' => 'jml_pagu',  'dt' => 3 )
		);

		$join   = "AS t1 LEFT JOIN (SELECT kdakun AS `kodeakun`, `nmakun` FROM dja_akun) AS t2 ON t1.kdakun = t2.kodeakun";
		$model  = $this->loadModel('renlag_model');
		$result = $model->mgetAkun($request, $sTable, $primaryKey, $columns, $join, $id, $y);

		$row = json_encode($result);

		return $row;
	}

	function getdatahps($x)
	{
		$id         = $this->base64url_decode($x);
		$request    = $_REQUEST;
		$primaryKey = "autono";
		$sTable     = $this->tbl_hps;
		$columns = array(
			array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'tanggal_hps', 'dt' => 1 ),
			array( 'db' => 'nilai_hps',  'dt' => 2 , 'formatter' => function( $d, $row ) { return number_format($d); } ),
			array( 'db' => 'file_hps',  'dt' => 3 ),
			array( 'db' => 'wasgiat',  'dt' => 4 ),
			array( 'db' => 'satker',  'dt' => 5 ),
			array( 'db' => 'nama_file',  'dt' => 7 ),
			array( 'db' => 'nama_file_1',  'dt' => 8 ),
			array( 'db' => 'tanggal_hps',  'dt' => 9, 'formatter' => function( $d, $row ) { return date('Y',strtotime($d)); } ),
			array( 'db' => 'autocode',  'dt' => 6 )
		);

		$model  = $this->loadModel('renlag_int_post_model');
		$result = $model->mgetdatadetail2($request, $sTable, $primaryKey, $columns, $id);

		$row = json_encode($result);

		return $row;
	}

	function getdatator($x)
	{
		$id         = $this->base64url_decode($x);
		$request    = $_REQUEST;
		$primaryKey = "autono";
		$sTable     = $this->tbl_tor;
		$columns = array(
			array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'tanggal_tor', 'dt' => 1 ),
			array( 'db' => 'nilai_tor',  'dt' => 2 , 'formatter' => function( $d, $row ) { return number_format($d); } ),
			array( 'db' => 'nama_file',  'dt' => 7 ),
			array( 'db' => 'nama_file_2',  'dt' => 8 ),
			array( 'db' => 'file_tor',  'dt' => 3 )
		);

		$model  = $this->loadModel('renlag_int_post_model');
		$result = $model->mgetdatadetail2($request, $sTable, $primaryKey, $columns, $id);

		$row = json_encode($result);

		return $row;
	}

	function getdatarab($x)
	{
		$id         = $this->base64url_decode($x);
		$request    = $_REQUEST;
		$primaryKey = "autono";
		$sTable     = $this->tbl_rab;
		$columns = array(
			array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'tanggal_rab', 'dt' => 1 ),
			array( 'db' => 'nilai_rab',  'dt' => 2 , 'formatter' => function( $d, $row ) { return number_format($d); } ),
			array( 'db' => 'nama_file',  'dt' => 7 ),
			array( 'db' => 'nama_file_1',  'dt' => 8 ),
			array( 'db' => 'file_rab',  'dt' => 3 )
		);

		$model  = $this->loadModel('renlag_int_post_model');
		$result = $model->mgetdatadetail2($request, $sTable, $primaryKey, $columns, $id);

		$row = json_encode($result);

		return $row;
	}

	function getdatasph($x)
	{
		$id         = $this->base64url_decode($x);
		$request    = $_REQUEST;
		$primaryKey = "autono";
		$sTable     = $this->tbl_sph;
		$columns = array(
			array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'tanggal_sph', 'dt' => 1 ),
			array( 'db' => 'nilai_sph',  'dt' => 2 , 'formatter' => function( $d, $row ) { return number_format($d); } ),
			array( 'db' => 'file_sph',  'dt' => 3 )
		);

		$model  = $this->loadModel('renlag_int_post_model');
		$result = $model->mgetdatadetail($request, $sTable, $primaryKey, $columns, $id);

		$row = json_encode($result);

		return $row;
	}

	function getdatakontrak($x)
	{
		$id         = $this->base64url_decode($x);
		$request    = $_REQUEST;
		$primaryKey = "autono";
		$sTable     = $this->tbl_kontrak;
		$columns = array(
			array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'tanggal_kontrak', 'dt' => 1 ),
			array( 'db' => 'nilai_kontrak',  'dt' => 2 , 'formatter' => function( $d, $row ) { return number_format($d); } ),
			array( 'db' => 'file_kontrak',  'dt' => 3 ),
			array( 'db' => 'termin',  'dt' => 4 )
		);

		$model  = $this->loadModel('renlag_int_post_model');
		$result = $model->mgetdatadetail($request, $sTable, $primaryKey, $columns, $id);

		$row = json_encode($result);

		return $row;
	}

	function getdatabast($x)
	{
		$id         = $this->base64url_decode($x);
		$request    = $_REQUEST;
		$primaryKey = "autono";
		$sTable     = $this->tbl_bast;
		$columns = array(
			array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'tanggal_bast', 'dt' => 1 ),
			array( 'db' => 'nilai_bast',  'dt' => 2 , 'formatter' => function( $d, $row ) { return number_format($d); } ),
			array( 'db' => 'file_bast',  'dt' => 3 )
		);

		$model  = $this->loadModel('renlag_int_post_model');
		$result = $model->mgetdatadetail($request, $sTable, $primaryKey, $columns, $id);

		$row = json_encode($result);

		return $row;
	}

	function getdataku17($x)
	{
		$id         = $this->base64url_decode($x);
		$request    = $_REQUEST;
		$primaryKey = "autono";
		$sTable     = $this->tbl_ku17;
		$columns = array(
			array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'tanggal_ku17', 'dt' => 1 ),
			array( 'db' => 'nilai_ku17',  'dt' => 2 , 'formatter' => function( $d, $row ) { return number_format($d); } ),
			array( 'db' => 'file_ku17',  'dt' => 3 )
		);

		$model  = $this->loadModel('renlag_int_post_model');
		$result = $model->mgetdatadetail($request, $sTable, $primaryKey, $columns, $id);

		$row = json_encode($result);

		return $row;
	}

	function getdatasp2d($x)
	{
		$id         = $this->base64url_decode($x);
		$request    = $_REQUEST;
		$primaryKey = "autono";
		$sTable     = $this->tbl_sp2d;
		$columns = array(
			array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'tanggal_sp2d', 'dt' => 1 ),
			array( 'db' => 'nilai_sp2d',  'dt' => 2 , 'formatter' => function( $d, $row ) { return number_format($d); } ),
			array( 'db' => 'file_sp2d',  'dt' => 3 ),
			array( 'db' => 'termin',  'dt' => 4 )
		);

		$model  = $this->loadModel('renlag_int_post_model');
		$result = $model->mgetdatadetail($request, $sTable, $primaryKey, $columns, $id);

		$row = json_encode($result);

		return $row;
	}

	public function add()
	{
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Add';
		$data['curl']        = $this->curl;
		$data['thang']       = $model->mget_thang();
		$data['renlag']      = $model->mget_renlag();
		$template            = $this->loadView('renlag_int_post_add');
		$template->set('data', $data);
		$template->render();
	}

	public function edit($x)
	{
		$id                  = $this->base64url_decode($x);
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Edit';
		$data['encode']      = $x;
		$data['curl']        = $this->curl;
		$data['id_jenbel']   = $model->get_jenBelEdit($this->table, $this->primaryKey, $id);
		$data['aadata']      = $model->get($this->table, $this->primaryKey, $id);
		$template            = $this->loadView('renlag_int_post_edit');
		$template->set('data', $data);
		$template->render();
	}

	public function save()
	{
		$data               = array();
		$model              = $this->loadModel($this->model);
		$data['id_jenbel']  = ucwords(htmlspecialchars($_REQUEST['id_jenbel'])) ;
		$data['kd_akun']    = ucwords(htmlspecialchars($_REQUEST['kd_akun'])) ;
		$data['nm_akun']    = ucwords(htmlspecialchars($_REQUEST['nm_akun'])) ;
		$data['keterangan'] = ucwords(htmlspecialchars($_REQUEST['keterangan'])) ;
		$data['autocode']   = $model->autocode($this->table, "AKN_");	
		$result             = $model->msave($this->table, $data, $this->title);
		$this->redirect('renlag_int_post');
	}

	public function savehps($x)

	{		
		$data                  = array();	
		$model                 = $this->loadModel($this->model);
		$data['parent_id']     = $this->base64url_decode($x) ;
		$dt                    = $model->getdt($data['parent_id']);
		$data['satker']        = $dt['kdsatker'] ;
		$data['wasgiat']       = $dt['wasgiat'] ;
		$data['tanggal_hps']   = $model->escapeString($_REQUEST['tanggal_hps']) ;
		$data['nilai_hps']     = $model->escapeString($_REQUEST['nilai_hps']) ;		
		$data['file_hps']      = !empty($_FILES['file_hps']['name'][0]) ?  1 : 0;
		$data['file_excelhps'] = !empty($_FILES['file_excelhps']['name'][0]) ?  1 : 0;
		$data['autocode']      = $model->autocode($this->tbl_hps, "HPS-");	
		
		$result                = $model->msave($this->tbl_hps, $data, $this->title);
		$lastid                = $result['id'];
		
		# Insert files
		$files1              = array();
		$files1['dir']       = "dochps";
		$files1['subdir']    = "";
		if(!empty($_FILES['file_hps']['name'][0])) {
		    $file_ary1 = $model->reArrayFiles($_FILES['file_hps']);
		    foreach ($file_ary1 as $file1) {
				$files1['kode_parent'] = $data['autocode'];
				$files1['parent_id']   = $lastid;
				$files1['nama_file']   = $file1['name'];
				$files1['tipe_file']   = $file1['type'];
				$files1['ukuran']      = $file1['size'];
				$files1['ftable']      = $this->tbl_hps;

				if(!empty($file1['name'])){ $model->savefile($files1); } 
		    }
		}

		$files2              = array();
		$files2['dir']       = "excelhps";
		$files2['subdir']    = "";
		if(!empty($_FILES['file_excelhps']['name'][0])) {
		    $file_ary2 = $model->reArrayFiles($_FILES['file_excelhps']);
		    foreach ($file_ary2 as $file2) {
				$files2['kode_parent'] = $data['autocode'];
				$files2['parent_id']   = $lastid;
				$files2['nama_file']   = $file2['name'];
				$files2['tipe_file']   = $file2['type'];
				$files2['ukuran']      = $file2['size'];
				$files2['ftable']      = $this->tbl_hps;

				if(!empty($file2['name'])){ $model->savefile($files2); } 
		    }
		}
		# Upload file
		if(isset($_FILES['file_hps'])){ $model->uploads1('dokumen', $_FILES['file_hps'], $files1['dir'], $files1['subdir']); }
		if(isset($_FILES['file_excelhps'])){ $model->uploads1('dokumen', $_FILES['file_excelhps'], $files2['dir'], $files2['subdir']); }


		return true;

	}

	public function savetor($x)

	{		
		$data                  = array();	
		$model                 = $this->loadModel($this->model);
		$data['parent_id']     = $this->base64url_decode($x) ;
		$dt                    = $model->getdt($data['parent_id']);
		$data['satker']        = $dt['kdsatker'] ;
		$data['wasgiat']       = $dt['wasgiat'] ;
		$data['tanggal_tor']   = $model->escapeString($_REQUEST['tanggal_tor']) ;
		$data['nilai_tor']     = $model->escapeString($_REQUEST['nilai_tor']) ;		
		$data['file_tor']      = !empty($_FILES['file_tor']['name'][0]) ?  1 : 0;
		$data['file_exceltor'] = !empty($_FILES['file_exceltor']['name'][0]) ?  1 : 0;
		$data['autocode']      = $model->autocode($this->tbl_tor, "TOR-");	
		
		$result                = $model->msave($this->tbl_tor, $data, $this->title);
		$lastid                = $result['id'];
		
		# Insert files
		$files1              = array();
		$files1['dir']       = "doctor";
		$files1['subdir']    = "";
		if(!empty($_FILES['file_tor']['name'][0])) {
		    $file_ary1 = $model->reArrayFiles($_FILES['file_tor']);
		    foreach ($file_ary1 as $file1) {
				$files1['kode_parent'] = $data['autocode'];
				$files1['parent_id']   = $lastid;
				$files1['nama_file']   = $file1['name'];
				$files1['tipe_file']   = $file1['type'];
				$files1['ukuran']      = $file1['size'];
				$files1['ftable']      = $this->tbl_tor;

				if(!empty($file1['name'])){ $model->savefile($files1); } 
		    }
		}

		$files2              = array();
		$files2['dir']       = "exceltor";
		$files2['subdir']    = "";
		if(!empty($_FILES['file_exceltor']['name'][0])) {
		    $file_ary2 = $model->reArrayFiles($_FILES['file_exceltor']);
		    foreach ($file_ary2 as $file2) {
				$files2['kode_parent'] = $data['autocode'];
				$files2['parent_id']   = $lastid;
				$files2['nama_file']   = $file2['name'];
				$files2['tipe_file']   = $file2['type'];
				$files2['ukuran']      = $file2['size'];
				$files2['ftable']      = $this->tbl_tor;

				if(!empty($file2['name'])){ $model->savefile($files2); } 
		    }
		}
		# Upload file
		if(isset($_FILES['file_tor'])){ $model->uploads1('dokumen', $_FILES['file_tor'], $files1['dir'], $files1['subdir']); }
		if(isset($_FILES['file_exceltor'])){ $model->uploads1('dokumen', $_FILES['file_exceltor'], $files2['dir'], $files2['subdir']); }


		return true;

	}

	public function saverab($x)

	{		
		$data                  = array();	
		$model                 = $this->loadModel($this->model);
		$data['parent_id']     = $this->base64url_decode($x) ;
		$dt                    = $model->getdt($data['parent_id']);
		$data['satker']        = $dt['kdsatker'] ;
		$data['wasgiat']       = $dt['wasgiat'] ;
		$data['tanggal_rab']   = $model->escapeString($_REQUEST['tanggal_rab']) ;
		$data['nilai_rab']     = $model->escapeString($_REQUEST['nilai_rab']) ;		
		$data['file_rab']      = !empty($_FILES['file_rab']['name'][0]) ?  1 : 0;
		$data['file_excelrab'] = !empty($_FILES['file_excelrab']['name'][0]) ?  1 : 0;
		$data['autocode']      = $model->autocode($this->tbl_rab, "RAB-");	
		
		$result                = $model->msave($this->tbl_rab, $data, $this->title);
		$lastid                = $result['id'];
		
		# Insert files
		$files1              = array();
		$files1['dir']       = "docrab";
		$files1['subdir']    = "";
		if(!empty($_FILES['file_rab']['name'][0])) {
		    $file_ary1 = $model->reArrayFiles($_FILES['file_rab']);
		    foreach ($file_ary1 as $file1) {
				$files1['kode_parent'] = $data['autocode'];
				$files1['parent_id']   = $lastid;
				$files1['nama_file']   = $file1['name'];
				$files1['tipe_file']   = $file1['type'];
				$files1['ukuran']      = $file1['size'];
				$files1['ftable']      = $this->tbl_rab;

				if(!empty($file1['name'])){ $model->savefile($files1); } 
		    }
		}

		$files2              = array();
		$files2['dir']       = "excelrab";
		$files2['subdir']    = "";
		if(!empty($_FILES['file_excelrab']['name'][0])) {
		    $file_ary2 = $model->reArrayFiles($_FILES['file_excelrab']);
		    foreach ($file_ary2 as $file2) {
				$files2['kode_parent'] = $data['autocode'];
				$files2['parent_id']   = $lastid;
				$files2['nama_file']   = $file2['name'];
				$files2['tipe_file']   = $file2['type'];
				$files2['ukuran']      = $file2['size'];
				$files2['ftable']      = $this->tbl_rab;

				if(!empty($file2['name'])){ $model->savefile($files2); } 
		    }
		}
		# Upload file
		if(isset($_FILES['file_rab'])){ $model->uploads1('dokumen', $_FILES['file_rab'], $files1['dir'], $files1['subdir']); }
		if(isset($_FILES['file_excelrab'])){ $model->uploads1('dokumen', $_FILES['file_excelrab'], $files2['dir'], $files2['subdir']); }


		return true;

	}

	public function update($x)
	{
		$data               = array();
		$id                 = $this->base64url_decode($x);
		$model              = $this->loadModel($this->model);
		$data['id_jenbel']  = ucwords(htmlspecialchars($_REQUEST['id_jenbel'])) ;
		$data['kd_akun']    = ucwords(htmlspecialchars($_REQUEST['kd_akun'])) ;
		$data['nm_akun']    = ucwords(htmlspecialchars($_REQUEST['nm_akun'])) ;
		$data['keterangan'] = ucwords(htmlspecialchars($_REQUEST['keterangan'])) ;
		$result             = $model->mupdate($this->table, $data, $this->primaryKey, $id, $this->title);
		$this->redirect('renlag_int_post');
	}

	public function delete($x)
	{
		$id     = $this->base64url_decode($x);
		$model  = $this->loadModel($this->model);
		$result = $model->mdelete1($this->tbl_hps, $this->primaryKey, $id, $this->title);
		return $result;
	}

	// public function delete($x)
	// {
	// 	$id     = $this->base64url_decode($x);
	// 	$model  = $this->loadModel($this->model);
	// 	$result = $model->mdelete1($this->tbl_hps, $this->primaryKey2, 'autono', $this->title);
	// 	return false;

	// }

	public function deletes($x)
	{
		$id      = $this->base64url_decode($x);
		$model   = $this->loadModel($this->model);
		$resultF = $model->mdelete($this->tblF,'parent_id', $id, $this->title);
		$result  = $model->mdelete($this->tbl_hps, $this->primaryKey2, $id, $this->title);
		return $result;
	}
	
	public function deletes2($x)
	{
		$id     = $this->base64url_decode($x);
		$model  = $this->loadModel($this->model);
		$resultF = $model->mdelete($this->tblF,'parent_id', $id, $this->title);
		$result = $model->mdelete($this->tbl_tor, $this->primaryKey2, $id, $this->title);
		return $result;
	}

	public function deletes3($x)
	{
		$id     = $this->base64url_decode($x);
		$model  = $this->loadModel($this->model);
		$resultF = $model->mdelete($this->tblF,'parent_id', $id, $this->title);
		$result = $model->mdelete($this->tbl_rab, $this->primaryKey2, $id, $this->title);
		return $result;
	}

	// public function downloadpdf($key = null)
	// {
	// 	if($key){
	// 		$id     = $this->base64url_decode($key);
	// 		$model  = $this->loadModel($this->model);
	// 		$data   = $model->getvalue("SELECT dir, kode_parent, subdir, nama_file FROM vt_files WHERE parent_id = $id AND dir = 'dochps'");
	// 		$path   = "/".$data[1]."/".$data[2]."/";
	// 		$result = $this->download_file($data[3], $path);
	// 		// echo $path.$data[3];
	// 		return $result;
	// 	} else {
	// 		echo $path;
	// 	}

	// }

	// public function downloadexcel($key = null)
	// {
	// 	if($key){
	// 		$id     = $this->base64url_decode($key);
	// 		$model  = $this->loadModel($this->model);
	// 		$data   = $model->getvalue("SELECT dir, kode_parent, subdir, nama_file FROM vt_files WHERE parent_id = $id AND dir = 'excelhps'");
	// 		$path   = $data[0]."/".$data[1]."/";
	// 		$result = $this->download_file($data[3], $path);
	// 		//echo $path.$data[3];
	// 		return $result;
	// 	} else {
	// 		echo $path;
	// 	}

	// }

	public function download($key)
	{
		if($key){
			$id     = $this->base64url_decode($key);
			$model  = $this->loadModel($this->model);
			$data   = $model->getvalue("SELECT dir, kode_parent, subdir, nama_file, tipe_file FROM vt_files WHERE parent_id = $id AND dir = 'dochps'");
			// echo $data;exit;
			// echo $data['nama_file'];exit;
			$path   = BASE_URL."static/files/dokumen/".$data[0]."/";
			// echo $path.$data['nama_file'];exit;
			$result = $this->output_file($path, $data[3], $data[4]);
			// return $result;
			echo $path;

		} else {
			return false;
			// echo $path;
		}

	}

	function output_file($filepath, $filename, $mime_type='')
	{
	    if(!empty($filename)){


		    $size = filesize($filepath);
		    $filename = rawurldecode($filename);

		    @ob_end_clean();
		    if(ini_get('zlib.output_compression'))
		    ini_set('zlib.output_compression', 'Off');
		    header('Content-Type: ' . $mime_type);
		    header('Content-Disposition: attachment; filename="'.$filename.'"');
		    header("Content-Transfer-Encoding: binary");
		    header('Accept-Ranges: bytes');

		    if(isset($_SERVER['HTTP_RANGE']))
		    {
		        list($a, $range) = explode("=",$_SERVER['HTTP_RANGE'],2);
		        list($range) = explode(",",$range,2);
		        list($range, $range_end) = explode("-", $range);
		        $range=intval($range);
		        if(!$range_end) {
		            $range_end=$size-1;
		        } else {
		            $range_end=intval($range_end);
		        }

		        $new_length = $range_end-$range+1;
		        header("HTTP/1.1 206 Partial Content");
		        header("Content-Length: $new_length");
		        header("Content-Range: bytes $range-$range_end/$size");
		    } else {
		        $new_length=$size;
		        header("Content-Length: ".$size);
		    }

		    $chunksize = 1*(1024*1024);
		    $bytes_send = 0;
		    if ($filepath = fopen($filepath, 'r'))
		    {
		        if(isset($_SERVER['HTTP_RANGE']))
		        fseek($filepath, $range);

		        while(!feof($filepath) &&
		            (!connection_aborted()) &&
		            ($bytes_send<$new_length)
		        )
		        {
		            $buffer = fread($filepath, $chunksize);
		            echo($buffer);
		            flush();
		            $bytes_send += strlen($buffer);
		        }
		        fclose($filepath);
		    } 
		   die();
		} else {
			echo "File not found!".$filepath;
		}
	}

    
}