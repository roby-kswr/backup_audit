<?php

class Sub_kategori extends Controller {

	private $table         = "tsubkategori";
	private $tableKategori = "tkategori";
	private $primaryKey    = "autono";
	private $model         = "Sub_kategori_model"; # please write with no space
	private $menu          = "Reference";
	private $title         = "Sub Kategori";
	private $curl          = BASE_URL."sub_kategori/";
	

	public function __construct()
    {
        $session = $this->loadHelper('Session_helper');
        if(!$session->get('username')){
        	$this->redirect('auth/login');
        }
    }
	
	function index()
	{
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['curl']        = $this->curl;
		$template            = $this->loadView('sub_kategori_view');
		$template->set('data', $data);
		$template->render();
	}

	function get()
	{
		$request = $_REQUEST;
		$columns = array(
			array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'nm_bidang',  'dt' => 1 ),
			array( 'db' => 'nm_kategori',  'dt' => 2 ),
			array( 'db' => 'nm_sub_kategori',  'dt' => 3 ),
			array( 'db' => 'keterangan',   'dt' => 4 )
		);

		$join	= "a LEFT JOIN (SELECT autono AS kd_kategori, nm_kategori FROM tkategori) AS b ON a.id_kategori=b.kd_kategori
				   LEFT JOIN (SELECT autono AS kd_bidang, nm_bidang FROM tbidang) AS c ON a.id_bidang=c.kd_bidang";
		$model  = $this->loadModel($this->model);
		$result = $model->mget($request, $this->table, $this->primaryKey, $columns, $join);

		return json_encode($result);
	}

	public function add()
	{
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Add';
		$data['curl']        = $this->curl;
		$data['bidang']      = $model->get_bidang();
		$data['kategori']    = $model->get_kategori();
		$template            = $this->loadView('sub_kategori_add');
		$template->set('data', $data);
		$template->render();
	}

	public function edit($x)
	{
		$id                  = $this->base64url_decode($x);
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Edit';
		$data['encode']      = $x;
		$data['curl']        = $this->curl;
		$data['aadata']      = $model->get($this->table, $this->primaryKey, $id);
		$data['bidang']      = $model->get_bidangEdit($this->table, $this->primaryKey, $id);
		$data['kategori']    = $model->get_kategoriEdit($this->table, $this->primaryKey, $id);
		$template            = $this->loadView('sub_kategori_edit');
		$template->set('data', $data);
		$template->render();
	}

	public function save()
	{
		$data                    = array();
		$model                   = $this->loadModel($this->model);
		$data['id_bidang']       = htmlspecialchars($_REQUEST['id_bidang']) ;
		$data['id_kategori']     = htmlspecialchars($_REQUEST['id_kategori']) ;
		$data['nm_sub_kategori'] = ucwords(htmlspecialchars($_REQUEST['nm_sub_kategori'])) ;
		$data['keterangan']      = ucwords(htmlspecialchars($_REQUEST['keterangan'])) ;
		$data['autocode']        = $model->autocode($this->table, "SKTGR_");	
		$result                  = $model->msave($this->table, $data, $this->title);
		$this->redirect('sub_kategori');
	}

	public function update($x)
	{
		$data                    = array();
		$id                      = $this->base64url_decode($x);
		$model                   = $this->loadModel($this->model);
		$data['id_bidang']       = htmlspecialchars($_REQUEST['id_bidang']) ;
		$data['id_kategori']     = htmlspecialchars($_REQUEST['id_kategori']) ;
		$data['nm_sub_kategori'] = ucwords(htmlspecialchars($_REQUEST['nm_sub_kategori'])) ;
		$data['keterangan']      = ucwords(htmlspecialchars($_REQUEST['keterangan'])) ;
		$result                  = $model->mupdate($this->table, $data, $this->primaryKey, $id, $this->title);
		$this->redirect('sub_kategori');
	}

	public function delete($x)
	{
		$id     = $this->base64url_decode($x);
		$model  = $this->loadModel($this->model);
		$result = $model->mdelete($this->table, $this->primaryKey, $id, $this->title);
		return $result;
	}
		
	function load_kategori()
    {
        $id_bidang = $_REQUEST['id_bidang'];
		$model 	   = $this->loadModel($this->model);
        $data  	   = $model->getId_kategori($id_bidang);
        echo json_encode($data);
    } 
    
}