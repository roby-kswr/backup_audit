<?php

class Pkpt_anev extends Controller {

	private $table      = "tpkpt_detil";
	private $tablePk    = "tpkpt";
	private $tableSat   = "tpkptsat";
	private $primaryKey = "autono";
	private $model      = "Pkpt_model";
	private $menu       = "Transaksi";
	private $title      = "PKPT View";
	private $curl       = BASE_URL."pkpt";

	public function __construct()
	{
		$session = $this->loadHelper('Session_helper');
		if(!$session->get('username')){
			$this->redirect('auth/login');
		}
	}

	public function index()
	{
		$id                  = $this->base64url_decode($x);
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['curl']	     = $this->curl;
		$template            = $this->loadView('pkpt_anev_view');
		$template->set('data', $data);
		$template->render();
	}

	public function detail()
	{
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['curl']	     = $this->curl;
		// $data['encode']      = $x;
		$template            = $this->loadView('pkpt_anev_view');
		$template->set('data', $data);
		$template->render();
	}

	function get($x = null)
	{
		$request    = $_REQUEST;
		$uri        = $this->loadHelper('Url_helper');
		$pkpt       = $uri->segment(5);
		$id         = $this->base64url_decode($x);
		$columns = array(
			array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'nomor_pkpt',  'dt' => 1 ),
			array( 'db' => 'keterangan',  'dt' => 2 ),
			array( 'db' => 'flag',  'dt' => 3 ),
		);
		$model   = $this->loadModel($this->model);
		// $result  = $model->mget($request, $this->tablePk, $this->primaryKey, $columns);
		if($x){

			$result  = $model->mget_detail($request, $this->tablePk, $this->primaryKey, $columns, $id);

		} else {

			$result  = $model->mget($request, $this->tablePk, $this->primaryKey, $columns, 'autono', $pkpt);
			

		}
		return json_encode($result);
	}


	public function jdwl()

	{
		$id                  = $this->base64url_decode($x);
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Jadwal';
		$data['curl']	     = $this->curl;
		// $id 			     = $_POST['autono'];
		// $data['encode']	     = $x;
		$data['id_jns_audit']= $model->get_jenisAudit();
		$data['pkpt']        = $model->get_PKPT();
		$data['id_kotama'] 	 = $model->get_kotamaEdit($this->tableSat, 'id_pkpt', $id);
		$data['aadata']      = $model->get($this->tablePk, $this->primaryKey, $id);
		$template            = $this->loadView('index_jadwal');
		$template->set('data', $data);
		$template->render();

	}

	// public function jdwlGet($x)

	// {
	// 	$id                  = $this->base64url_decode($x);
	// 	$model               = $this->loadModel($this->model);
	// 	$data                = array();
	// 	$data['breadcrumb1'] = $this->menu;
	// 	$data['title']       = $this->title;
	// 	$data['action']      = 'Jadwal';
	// 	$data['encode']      = $x;
	// 	$data['curl']	     = $this->curl;
	// 	// $id 			     = $_POST['autono'];
	// 	// $data['encode']	     = $x;
	// 	$data['id_jns_audit']= $model->get_jenisAudit();
	// 	$data['pkpt']        = $model->get_PKPT();
	// 	$data['id_kotama'] 	 = $model->get_kotamaEdit($this->tableSat, 'id_pkpt', $id);
	// 	$template            = $this->loadView('jadwal_readonly');
	// 	$template->set('data', $data);
	// 	$template->render();

	// }

	public function audit($x)
	{


		$return  = implode(',', $color);

		return $return;
	}

	public function bulan($value)
	{
		switch ($value) {
			case 1:
			$bln = "JAN";
			break;
			case 2:
			$bln = "FEB";
			break;
			case 3:
			$bln = "MAR";
			break;
			case 4:
			$bln = "APR";
			break;
			case 5:
			$bln = "MEI";
			break;
			case 6:
			$bln = "JUN";
			break;
			case 7:
			$bln = "JUL";
			break;
			case 8:
			$bln = "AGS";
			break;
			case 9:
			$bln = "SEP";
			break;
			case 10:
			$bln = "OKT";
			break;
			case 11:
			$bln = "NOV";
			break;
			case 12:
			$bln = "DES";
			break;

			default:
			$bln = "";
			break;
		}

		return $bln;
	}



	function print($x,$y)
	{
		$uri    = $this->loadHelper('Url_helper');
		$id     = $this->base64url_decode($x);
		$data['nomor_pkpt']  = $uri->segment(5);
		$data['nomor_pkpt'] = $y;
		$pdf    = $this->loadLibrary('fpdf');
		$thn    = date('Y');
		$model  = $this->loadModel($this->model);
		$pdf->AddPage('L','A4');

		$pkpt   = $model->pkpt($thn);
		$satker = $model->pkpt_detail($id);
		$review = $model->pkpt_rev($id);
		$tahun  = substr($y, -4);

		$title  = "KALENDER KEGIATAN REVIU DAN WASRIK ITJENAD TA ".$tahun;
		$pdf->SetFont('Arial','B',15);
		$w = $pdf->GetStringWidth($title)+6;
		$pdf->SetX((297-$w)/2);
		$pdf->SetDrawColor(0,80,180);
		$pdf->SetFillColor(230,230,0);
		$pdf->SetTextColor(220,50,50);
		$pdf->SetLineWidth(1);

         // Title
		$pdf->Cell($w,9,$title,1,1,'C',true);

		$pdf->Ln(10);
		$pdf->SetFont('Arial','B',12);
         // Tahun
		$pdf->SetLeftMargin(25);
		$pdf->SetY(91);
		$pdf->SetDrawColor(0,80,180);
		$pdf->SetFillColor(224,224,224);
		$pdf->SetTextColor(32,32,32);
		$pdf->SetLineWidth(0.2);
		$pdf->Cell(240,9, $tahun,1,0,'C',true); 

		$pdf->SetDrawColor(0,80,180);
		$pdf->SetTextColor(32,32,32); 
		$pdf->SetLineWidth(0.2);
		$pdf->Cell(20,9, $tahun+1,1,0,'C',true); 


         // Bulan
		$pdf->SetLeftMargin(25);
		$pdf->SetY(100);
		$i = 1;

		foreach ($satker as $key => $val) {
			$w = $pdf->GetStringWidth($val['bulan'])+6;
			switch ($val['jenis_audit']) {
				case 'Post':
				$pdf->SetFillColor(102,178,255);
				break;
				case 'Current':
				$pdf->SetFillColor(0,204,0);
				break;
				case 'Pre':
				$pdf->SetFillColor(255,102,102);
				break;

				default:
				$pdf->SetFillColor(0,204,0);
				break;
			}
			$pdf->SetDrawColor(0,80,180);
			$pdf->SetTextColor(32,32,32); 
			$pdf->SetLineWidth(0.2);
			$pdf->Cell(20,9, $this->bulan($val['bulan']),1,0,'C',true); 

		}
         // Next Year
		$pdf->SetDrawColor(0,80,180);
		$pdf->SetTextColor(32,32,32); 
		$pdf->SetFillColor(255,102,102);
		$pdf->SetLineWidth(0.2);
		$pdf->Cell(20,9, "JAN",1,0,'C',true); 






         // Satker      
		$pdf->SetX(25);
		$pdf->SetFont('Arial','',10);
		foreach ($satker as $key => $sat) {

			if($sat['bulan']){
				if($sat['bulan'] & 1){
					$y = 130;
				} else {
					$y = 160;
				}

				$pdf->SetY($y);
				$pdf->SetLeftMargin(5+$sat['bulan']*20);

				$pdf->SetFont('Arial','',7);
				foreach ($sat['satker'] as $key => $kotama) {               
					switch ($sat['jenis_audit']) {
						case 'Post':
						$pdf->SetFillColor(102,178,255);
						break;
						case 'Current':
						$pdf->SetFillColor(0,204,0);
						break;
						case 'Pre':
						$pdf->SetFillColor(255,102,102);
						break;

						default:
						$pdf->SetFillColor(0,204,0);
						break;
					}

					$pdf->Cell(32,5,$kotama['nm_kotama'],0,1,'C',true); 
				}

				$x = (20 * $sat['bulan'])+20;
				$pdf->Line($x, 109,$x, $y-2);

				$pdf->SetFont('ZapfDingbats');
				$pdf->SetY($y-1);
				$pdf->SetX($x-2);
				$pdf->Cell(50,0,chr(116),0,1);

			}
		}




          // Review      
		$pdf->SetX(25);
		$pdf->SetFont('Arial','',10);
		foreach ($review as $key => $rev) {

			if($rev['bulan']){
				if($rev['bulan'] & 1){
					$y1 = 60;
				} else {
					$y1 = 40;
				}

				$pdf->SetY($y1);
				$pdf->SetLeftMargin(5+$rev['bulan']*20);

				$x1 = (20 * $rev['bulan'])+20;
				$pdf->Line($x1, 91,$x1, $y1+10);

				$pdf->SetFont('Arial','',7);
				foreach ($rev['satker'] as $key => $review) {               
					switch ($rev['jenis_audit']) {
						case 'Post':
						$pdf->SetFillColor(102,178,255);
						break;
						case 'Current':
						$pdf->SetFillColor(0,204,0);
						break;
						case 'Pre':
						$pdf->SetFillColor(255,102,102);
						break;

						default:
						$pdf->SetFillColor(0,204,0);
						break;
					}

					$pdf->MultiCell(32,5,$review['nm_review'],0,'J', true);
				}



              // $pdf->SetFont('ZapfDingbats');
              // $pdf->SetY($y1-1);
              // $pdf->SetX($x1-2);
              // $pdf->Cell(50,0,chr(115),0,1);

			}
		}

		$pdf->Output();
	}


}

