<?php

class Progja extends Controller {

	private $table       = "dja_pagu";
	// private $tableDipa   = "dja_pagu";
	private $primaryKey  = "id";
	// private $primaryKeys = "id";
	private $model       = "Progja_model"; # please write with no space
	private $menu        = "Transaksi";
	private $title       = "Progja";
	private $curl        = BASE_URL."progja/";
	

	public function __construct()
    {
        $session = $this->loadHelper('Session_helper');
        if(!$session->get('username')){
        	$this->redirect('auth/login');
        }
    }
	
	function index()
	{
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['curl']        = $this->curl;
		$template            = $this->loadView('progja_index');
		$template->set('data', $data);
		$template->render();
	}

	function detail($x)
	{
		$id                  = $this->base64url_decode($x);
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['curl']        = $this->curl;
		$data['encode']      = $x;
		$template            = $this->loadView('progja_view');
		$template->set('data', $data);
		$template->render();
	}

	function get()
	{
		$request = $_REQUEST;
		$columns = array(
			array( 'db' => 'id', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'thang',  'dt' => 1 ),
			array( 'db' => 'wasgiat',  'dt' => 2 ),
			array( 'db' => 'urskmpnen',  'dt' => 3 ),
			array( 'db' => 'jml_pagu',   'dt' => 4 )
		);
		
		$join   = "AS t1 LEFT JOIN (SELECT `kdsatker`, `nmsatker` FROM dja_satker) AS t2 ON t1.KDSATKER = t2.kdsatker";
		$model  = $this->loadModel($this->model);
		$result = $model->mgetDipa($request, $this->table, $this->primaryKey, $columns, $join);

		return json_encode($result);
	}

	function getProgja()
	{
		$request = $_REQUEST;
		$columns = array(
			array( 'db' => 'id', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'thang',  'dt' => 1 ),
			array( 'db' => 'urskmpnen',  'dt' => 2 ),
			array( 'db' => 'kdprogram',   'dt' => 3 ),
			array( 'db' => 'kdgiat',   'dt' => 4 ),
			array( 'db' => 'kdoutput',   'dt' => 5 ),
			array( 'db' => 'kdsoutput',   'dt' => 6 ),
			array( 'db' => 'SUM(jml_pagu)',   'dt' => 7 , 'formatter' => function( $d, $row ) { return number_format($d); } )
		);
		
		$model  = $this->loadModel($this->model);
		$result = $model->mgetProgja($request, $this->table, $this->primaryKey, $columns);

		return json_encode($result);
	}

	function getdetail($x)
	{
		$request = $_REQUEST;
		$id      = $this->base64url_decode($x);
		$model   = $this->loadModel($this->model);
		$columns = array(
			array( 'db' => 'id', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'urskmpnen',  'dt' => 1 ),
			array( 'db' => 'kdsatker',  'dt' => 2 ),
			array( 'db' => 'kdprogram',   'dt' => 3 ),
			array( 'db' => 'kdgiat',   'dt' => 4 ),
			array( 'db' => 'kdoutput',   'dt' => 5 ),
			array( 'db' => 'kdsoutput',   'dt' => 6 ),
			array( 'db' => 'SUM(jml_pagu)',   'dt' => 7 , 'formatter' => function( $d, $row ) { return number_format($d); } ),
			array( 'db' => 'nm_satminkal',   'dt' => 8 ),
			array( 'db' => 'wasgiat',   'dt' => 9 )
		);
		
		
		$result = $model->mgetDetail($request, $this->table, $this->primaryKey, $columns, $id);

		return json_encode($result);
	}

	function getrab($x)
	{
		$request = $_REQUEST;
		$id      = $this->base64url_decode($x);
		$model   = $this->loadModel($this->model);
		$columns = array(
			array( 'db' => 'id', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'kdakun',  'dt' => 1 ),
			array( 'db' => 'nmakun',  'dt' => 2 ),
			array( 'db' => 'SUM(jml_pagu)',   'dt' => 3 , 'formatter' => function( $d, $row ) { return number_format($d); } )
		);
		
		
		$result = $model->mgetRab($request, $this->table, $this->primaryKey, $columns, $id);

		return json_encode($result);
	}


	function getAkun($x, $y)
	{
		$id         = $this->base64url_decode($x);
		$request    = $_REQUEST;
		$primaryKey = "id";
		$sTable     = "dja_pagu";
		$columns = array(
			array( 'db' => 'kdakun', 'dt' => 1 ),
			array( 'db' => 'nmakun',  'dt' => 2 ),
			array( 'db' => 'jml_pagu',  'dt' => 3 )
			//array( 'db' => 'subdir',   'dt' => 6 )
		);

		$join   = "AS t1 LEFT JOIN (SELECT kdakun AS `kodeakun`, `nmakun` FROM dja_akun) AS t2 ON t1.kdakun = t2.kodeakun";
		$model  = $this->loadModel('progja_model');
		$result = $model->mgetAkun($request, $sTable, $primaryKey, $columns, $join, $id, $y);

		$row = json_encode($result);

		return $row;
	}

	public function add()
	{
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Add';
		$data['curl']        = $this->curl;
		$data['thang']       = $model->mget_thang();
		$data['progja']      = $model->mget_progja();
		$template            = $this->loadView('progja_add');
		$template->set('data', $data);
		$template->render();
	}

	public function edit($x)
	{
		$id                  = $this->base64url_decode($x);
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Edit';
		$data['encode']      = $x;
		$data['curl']        = $this->curl;
		$data['id_jenbel']   = $model->get_jenBelEdit($this->table, $this->primaryKey, $id);
		$data['aadata']      = $model->get($this->table, $this->primaryKey, $id);
		$template            = $this->loadView('progja_edit');
		$template->set('data', $data);
		$template->render();
	}

	public function save()
	{
		$data               = array();
		$model              = $this->loadModel($this->model);
		$data['id_jenbel']  = ucwords(htmlspecialchars($_REQUEST['id_jenbel'])) ;
		$data['kd_akun']    = ucwords(htmlspecialchars($_REQUEST['kd_akun'])) ;
		$data['nm_akun']    = ucwords(htmlspecialchars($_REQUEST['nm_akun'])) ;
		$data['keterangan'] = ucwords(htmlspecialchars($_REQUEST['keterangan'])) ;
		$data['autocode']   = $model->autocode($this->table, "AKN_");	
		$result             = $model->msave($this->table, $data, $this->title);
		$this->redirect('progja');
	}

	public function update($x)
	{
		$data               = array();
		$id                 = $this->base64url_decode($x);
		$model              = $this->loadModel($this->model);
		$data['id_jenbel']  = ucwords(htmlspecialchars($_REQUEST['id_jenbel'])) ;
		$data['kd_akun']    = ucwords(htmlspecialchars($_REQUEST['kd_akun'])) ;
		$data['nm_akun']    = ucwords(htmlspecialchars($_REQUEST['nm_akun'])) ;
		$data['keterangan'] = ucwords(htmlspecialchars($_REQUEST['keterangan'])) ;
		$result             = $model->mupdate($this->table, $data, $this->primaryKey, $id, $this->title);
		$this->redirect('progja');
	}

	public function delete($x)
	{
		$id     = $this->base64url_decode($x);
		$model  = $this->loadModel($this->model);
		$result = $model->mdelete($this->table, $this->primaryKey, $id, $this->title);
		return $result;
	}

	// function loads_progja()
 //    {
	// 	$id    = $_REQUEST['id_pppa'];
	// 	$model = $this->loadModel($this->model);
	// 	$data  = $model->load_progja($id);
 //        echo json_encode($data);
 //    }

 //    function loads_TotalPagu()
 //    {
	// 	$thang     = $_REQUEST['thang'];
	// 	$kdsatker  = $_REQUEST['kdsatker'];
	// 	$kdfungsi  = $_REQUEST['kdfungsi'];
	// 	$kdsfung   = $_REQUEST['kdsfung'];
	// 	$kdprogram = $_REQUEST['kdprogram'];
	// 	$kdgiat    = $_REQUEST['kdgiat'];
	// 	$kdoutput  = $_REQUEST['kdoutput'];
	// 	$kdlokasi  = $_REQUEST['kdlokasi'];
	// 	$kdkabkota = $_REQUEST['kdkabkota'];
	// 	$kddekon   = $_REQUEST['kddekon'];
	// 	$kdsoutput = $_REQUEST['kdsoutput'];
	// 	$kdkmpnen  = $_REQUEST['kdkmpnen'];
	// 	$kdskmpnen = $_REQUEST['kdskmpnen'];
	// 	$kdkppn    = $_REQUEST['kdkppn'];
	// 	$kdjenbel  = $_REQUEST['kdjenbel'];
	// 	$model     = $this->loadModel($this->model);
	// 	$data      = $model->load_TotalPagu($thang,$kdsatker,$kdfungsi,$kdsfung,$kdprogram,$kdgiat,$kdoutput,$kdlokasi,$kdkabkota,$kddekon,$kdsoutput,$kdkmpnen,$kdskmpnen,$kdkppn,$kdjenbel);
 //        echo json_encode($data);
 //    } 

 //    function load_akun($thang,$kdsatker,$kdfungsi,$kdsfung,$kdprogram,$kdgiat,$kdoutput,$kdlokasi,$kdkabkota,$kddekon,$kdsoutput,$kdkmpnen,$kdskmpnen,$kdkppn,$kdjenbel)
	// {
	// 	$request = $_REQUEST;
	// 	$model   = $this->loadModel($this->model);
	// 	// $id      = $this->base64url_decode($get_id);
	// 	$last_id = $model->get_maxId($this->table);
	// 	$columns = array(
	// 		array( 'db' => 'id', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
	// 		array( 'db' => 'kdakun',  'dt' => 1 ),
	// 		array( 'db' => 'nmakun',  'dt' => 2 ),
	// 		array( 'db' => 'jml_pagu',   'dt' => 3 )
	// 	);

	// 	$join = "LEFT JOIN (SELECT kdakun AS kodeakun, nmakun FROM dja_akun) as b ON a.kdakun=b.kodeakun";
		
	// 	$sWhere = "thang = '$thang' AND 
	// 			   kdsatker = '$kdsatker' AND
	// 			   kdfungsi = '$kdfungsi' AND
	// 			   kdsfung = '$kdsfung' AND
	// 			   kdprogram = '$kdprogram' AND
	// 			   kdgiat = '$kdgiat' AND
	// 			   kdoutput = '$kdoutput' AND
	// 			   kdlokasi = '$kdlokasi' AND
	// 			   kdkabkota = '$kdkabkota' AND
	// 			   kddekon = '$kddekon' AND
	// 			   kdsoutput = '$kdsoutput' AND
	// 			   kdkmpnen = '$kdkmpnen' AND
	// 			   kdskmpnen = '$kdskmpnen'  AND
	// 			   kdkppn = '$kdkppn' AND
	// 			   kdjenbel = '$kdjenbel'
	// 			  ";
	
	// 	$result = $model->mgetdetail($request, $this->tableDipa, $this->primaryKeys, $columns, $join, $sWhere);

	// 	return json_encode($result);
	// }
    
}