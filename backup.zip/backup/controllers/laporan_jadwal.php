<?php

class Laporan_jadwal extends Controller
{
  
  private $table      = "tbidang";
  private $primaryKey = "id";
  private $menu       = "Analisa";
  private $model      = "laporan_jadwal_model";
  private $title      = "Laporan Jadwal";
  private $curl       = BASE_URL."laporan_jadwal";

  function __construct()
   {
      $session = $this->loadHelper('Session_helper');

        if(!$session->get('username')){

         $this->redirect('auth/login');

      }
   }

   function index()
   {
      $model = $this->loadModel($this->model);

      $data                = array();
      $data['breadcrumb1'] = $this->menu;
      $data['curl']        = $this->curl;
      $data['title']       = $this->title;
      $data['satker']      = $model->satker();
      $template            = $this->loadView('laporan_pelaksanaan_progja_intel_view');
      $template->set('data', $data);

      $template->render();
   }

   public function audit($x)
   {
    

    $return  = implode(',', $color);

    return $return;
   }

   public function bulan($value)
   {
     switch ($value) {
        case 1:
         $bln = "JAN";
         break;
        case 2:
         $bln = "FEB";
         break;
        case 3:
         $bln = "MAR";
         break;
        case 4:
         $bln = "APR";
         break;
        case 5:
         $bln = "MEI";
         break;
        case 6:
         $bln = "JUN";
         break;
        case 7:
         $bln = "JUL";
         break;
        case 8:
         $bln = "AGS";
         break;
        case 9:
         $bln = "SEP";
         break;
        case 10:
         $bln = "OKT";
         break;
        case 11:
         $bln = "NOV";
         break;
        case 12:
         $bln = "DES";
         break;
       
       default:
         $bln = "";
         break;
     }

     return $bln;
   }



    function print()
     {
        $pdf    = $this->loadLibrary('fpdf');
        $thn    = date('Y');
        $model  = $this->loadModel($this->model);
        $pdf->AddPage('L','A4');
        $pdf->SetMargins(25,10,25);
        
        $pkpt   = $model->pkpt($thn);
        $satker = $model->pkpt_detail($pkpt['autono']);
        $review = $model->pkpt_rev($pkpt['autono']);
        $tahun  = substr($pkpt['nomor_pkpt'], -4);
        
        $title  = "KALENDER KEGIATAN REVIU DAN WASRIK ITJENAD TA ".$tahun;
        $pdf->SetFont('Arial','B',15);
        $w = $pdf->GetStringWidth($title)+6;
        $pdf->SetX((297-$w)/2);
        $pdf->SetDrawColor(0,80,180);
        $pdf->SetFillColor(230,230,0);
        $pdf->SetTextColor(220,50,50);
        $pdf->SetLineWidth(1);

         // Title
         $pdf->Cell($w,9,$title,1,1,'C',true);

         $pdf->Ln(10);
         $pdf->SetFont('Arial','B',12);
         // Tahun
         $pdf->SetLeftMargin(25);
         $pdf->SetY(91);
         $pdf->SetDrawColor(0,80,180);
         $pdf->SetFillColor(224,224,224);
         $pdf->SetTextColor(32,32,32);
         $pdf->SetLineWidth(0.2);
         $pdf->Cell(240,9, $tahun,1,0,'C',true); 

        //Next year
            $pdf->SetDrawColor(0,80,180);
            $pdf->SetTextColor(32,32,32); 
            $pdf->SetLineWidth(0.2);
            $pdf->Cell(20,9, $tahun+1,1,0,'C',true); 


         // Bulan
         $pdf->SetLeftMargin(25);
         $pdf->SetY(100);
         $i = 1;
         $pr = 1;
         $ps = 1;
         $ct = 1;

         foreach ($satker as $key => $val) {
            $w = $pdf->GetStringWidth($val['bulan'])+6;
            switch ($val['jenis_audit']) {
              case 'Post':
                $pdf->SetFillColor(102,178,255);
                $post = $ps++;
                break;
              case 'Current':
                $pdf->SetFillColor(0,204,0);
                $current = $ct++;
                break;
              case 'Pre':
                $pdf->SetFillColor(255,102,102);
                $pre = $pr++;
                break;

              default:
               $pdf->SetFillColor(0,204,0);
                break;
            }
            $pdf->SetDrawColor(0,80,180);
            $pdf->SetTextColor(32,32,32); 
            $pdf->SetLineWidth(0.2);
            $pdf->Cell(20,9, $this->bulan($val['bulan']),1,0,'C',true); 

            // coba arrow
            // $pdf->Ln();
            // $pdf->SetY($y+10);
            // $pdf->Cell(20,9, '',1,0,'C',true); 
            
         }
         // Next Year
        $pdf->SetDrawColor(0,80,180);
        $pdf->SetTextColor(32,32,32); 
        $pdf->SetFillColor(255,102,102);
        $pdf->SetLineWidth(0.2);
        $pdf->Cell(20,9, "JAN",1,0,'C',true); 

      
      
        



         // Satker      
          $pdf->SetX(25);
          $pdf->SetFont('Arial','',10);
          foreach ($satker as $key => $sat) {

            if($sat['bulan']){
              if($sat['bulan'] & 1){
                $y = 130;
              } else {
                $y = 160;
              }
              
              $pdf->SetY($y);
              $pdf->SetLeftMargin(5+$sat['bulan']*20);
              
              $pdf->SetFont('Arial','',7);
              $pdf->SetLineWidth(0.3);
              foreach ($sat['satker'] as $key => $kotama) {               
                switch ($sat['jenis_audit']) {
                  case 'Post':
                    $pdf->SetFillColor(102,178,255);
                    break;
                  case 'Current':
                    $pdf->SetFillColor(0,204,0);
                    break;
                  case 'Pre':
                    $pdf->SetFillColor(255,102,102);
                    break;

                  default:
                   $pdf->SetFillColor(0,204,0);
                    break;
                }
               
                $pdf->Cell(32,5,$kotama['nm_kotama'],0,1,'L',true); 
              }

              $x = (20 * $sat['bulan'])+20;
              $pdf->Line($x, 109,$x, $y-2);

              $pdf->SetFont('ZapfDingbats');
              $pdf->SetY($y-1);
              $pdf->SetX($x-2);
              $pdf->Cell(50,0,chr(116),0,1);


            }

        
             


          }


                      // Arrow
              // if($post>=1){
              //   $panj = $post*17.5;
              //   $pdf->SetY(118);
              //   $pdf->SetFont('ZapfDingbats','',36);
              //   $pdf->SetTextColor(0,80,180); 
              //   $pdf->SetX($panj+18.5);
              //   $pdf->Cell(109,0,chr(217),0,1);

              //   $pdf->SetLeftMargin(25);
              //   $pdf->SetY(115);
              //   $pdf->SetDrawColor(0,80,180);
              //   $pdf->SetTextColor(32,32,32); 
              //   $pdf->SetFillColor(102,178,255);
              //   $pdf->SetLineWidth(0.2);
              //   $pdf->SetFont('Arial','BI',10);
              //   $pdf->Cell($panj,5, 'POST AUDIT','TB',0,'C',true); 
              // }

 



          // Review      
          $pdf->SetX(25);
          $pdf->SetFont('Arial','',10);
          foreach ($review as $key => $rev) {

            if($rev['bulan']){
              if($rev['bulan'] & 1){
                $y1 = 60;
              } else {
                $y1 = 40;
              }
              
              $pdf->SetY($y1);
              $pdf->SetLeftMargin(5+$rev['bulan']*20);

              $x1 = (20 * $rev['bulan'])+20;
              $pdf->SetLineWidth(0.2);
              $pdf->SetDrawColor(0,0,0);
              $pdf->Line($x1, 91,$x1, $y1+0);
              
              $pdf->SetFont('Arial','',7);
              foreach ($rev['satker'] as $key => $review) {               
                switch ($rev['jenis_audit']) {
                  case 'Post':
                    $pdf->SetX($x1-15);
                    $pdf->SetLineWidth(0.3);
                    $pdf->SetFillColor(102,178,255);
                    break;
                  case 'Current':
                  $pdf->SetX($x1-15);
                     $pdf->SetLineWidth(0.3);
                    $pdf->SetFillColor(0,204,0);
                    break;
                  case 'Pre':
                  $pdf->SetX($x1-15);
                    $pdf->SetLineWidth(0.3);
                    $pdf->SetFillColor(255,102,102);
                    break;

                  default:
                   $pdf->SetFillColor(0,204,0);
                    break;
                }          
            
                 $pdf->MultiCell(32,5,$review['nm_review'],1,'J', true); 
              }

              

              // $pdf->SetFont('ZapfDingbats');
              // $pdf->SetY($y1-1);
              // $pdf->SetX($x1-2);
              // $pdf->Cell(50,0,chr(115),0,1);

            }
          }

          // arrow
         $pdf->SetLeftMargin(25);
         $pdf->SetY(112);
         $i = 1;
         $prs = 1;
         $pss = 1;
         $cts = 1;
         $wid = 0;
         foreach ($satker as $key => $vals) {
            switch ($vals['jenis_audit']) {
              case 'Post':
                $pdf->SetFillColor(102,178,255);
                break;
              case 'Current':
                $pdf->SetFillColor(0,204,0);
                break;
              case 'Pre':
                $pdf->SetFillColor(255,102,102);
                break;

              default:
               $pdf->SetFillColor(0,204,0);
                break;
            }


              $pdf->SetDrawColor(0,80,180);
              $pdf->SetTextColor(255,255,255); 
              $pdf->SetLineWidth(0.2);
              $pdf->SetFont('Arial','BI',9);
              if($pss++ == $post){
                $pdf->SetFillColor(102,178,255);
                $pdf->Cell($post*20,6, ''.'POST AUDIT','TB',0,'C',true); 

                if($prs++ == $pre){
                  $pdf->SetFillColor(255,102,102);
                  $pdf->Cell($pre*20,6, 'PRE AUDIT','TB',0,'C',true); 

                  
                }


              }

              if($cts++ == $current){
                $pdf->SetFillColor(0,204,0);
                $pdf->Cell($current*20,6, 'CURRENT AUDIT','TB',0,'C',true); 
              }
              
              

            
            
            
         }


                $pdf->SetLeftMargin(25);
                $pdf->SetY(172);
                $pdf->SetDrawColor(0,80,180);
                $pdf->SetTextColor(96,96,96); 
                $pdf->SetFillColor(102,178,255);
                $pdf->SetLineWidth(0.2);
                $pdf->SetFont('Arial','I',9);
                $pdf->Cell(5,5, '',1,0,'C',true); $pdf->Cell(30,5, 'Post Audit ',0,0,'L',false); 
                $pdf->Ln();

                $pdf->SetLeftMargin(25);
                $pdf->SetY(178);
                $pdf->SetDrawColor(0,80,180);
                $pdf->SetTextColor(96,96,96);  
                $pdf->SetFillColor(0,204,0);
                $pdf->SetLineWidth(0.2);
                $pdf->SetFont('Arial','I',9);
                $pdf->Cell(5,5, '',1,0,'C',true); $pdf->Cell(30,5, 'Current Audit',0,0,'L',false); 

                $pdf->SetLeftMargin(25);
                $pdf->SetY(184);
                $pdf->SetDrawColor(0,80,180);
                $pdf->SetTextColor(96,96,96);  
                $pdf->SetFillColor(255,102,102);
                $pdf->SetLineWidth(0.2);
                $pdf->SetFont('Arial','I',9);
                $pdf->Cell(5,5, '',1,0,'C',true); $pdf->Cell(30,5, 'Pre Audit',0,0,'L',false); 



        $pdf->Output();
    }


}