<?php

class Grafik_operasi extends Controller {

	private $table      = "ttakwal";
	private $tableTemb  = "ttakwaltemb";
	private $tableProgja= "dja_pagu";
	private $tableFiles = "vt_files";
	private $primaryKey = "wasgiat";
	private $model      = "Grafik_operasi_model"; # please write with no space
	private $menu       = "Graphics View";
	private $title      = "Grafik Pelaksanaan Progja Operasi";
	private $curl       = BASE_URL."grafik_operasi/";
	

	public function __construct()
	{
		$session = $this->loadHelper('Session_helper');
		if(!$session->get('username')){
			$this->redirect('auth/login');
		}
	}
	
	function index()
	{
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$model                    = $this->loadModel($this->model);	
		$data['curl']        = $this->curl;
		$data['id_bidang']   = $model->get_bidang();
		$template            = $this->loadView('grafik_operasi_view');
		$template->set('data', $data);
		$template->render();
	}

	function loadProgja()
	{
		$request = $_REQUEST;
		$model   = $this->loadModel($this->model);
		$columns = array(
			// array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'urskmpnen',  'dt' => 1 ),
			array( 'db' => 'nm_bidang',   'dt' => 2 ),
			array( 'db' => 'jml_pagu',   'dt' => 3 ),
			array( 'db' => 'thang',   'dt' => 4 ),
		);
		$join   = "";
		$sWhere = "";
		$result  = $model->load_progja($request, $this->tableProgja, $this->primaryKey, $columns, $join, $sWhere);

		return json_encode($result);
	}

	function load_Pagu()
	{
		$request = $_REQUEST;
		$model   = $this->loadModel($this->model);
		$columns = array(
			// array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'urskmpnen',  'dt' => 1 ),
			array( 'db' => 'nm_bidang',   'dt' => 2 ),
			array( 'db' => 'jml_pagu',   'dt' => 3 ),
		);
		$join   = "";
		$sWhere = "";
		$result  = $model->load_pagu($request, $this->tableProgja, $this->primaryKey, $columns, $join, $sWhere);

		return json_encode($result);
	}

	function belanja_barangKons() {    
		$model = $this->loadModel($this->model);
		$data  = $model->belanja_barangKon();
		return json_encode($data);  
	}

	function belanja_modalKons() {    
		$model = $this->loadModel($this->model);
		$data  = $model->belanja_modalKon();
		return json_encode($data);  
	}

	function belanja_personelKons() {    
		$model = $this->loadModel($this->model);
		$data  = $model->belanja_personelKon();
		return json_encode($data);  
	}
	
	function belanja_personels() {    
		$model = $this->loadModel($this->model);
		$data  = $model->belanja_personel();
		return json_encode($data);  
	}

	function belanja_personelsDrill() {    
		$model = $this->loadModel($this->model);
		$data  = $model->belanja_personelDrill();
		return json_encode($data);  
	}

	function belanja_barangs() {    
		$model = $this->loadModel($this->model);
		$data  = $model->belanja_barang();
		return json_encode($data);  
	}

	function belanja_barangsDrill() {    
		$model = $this->loadModel($this->model);
		$data  = $model->belanja_barangDrill();
		return json_encode($data);  
	}

	function belanja_modals() {    
		$model = $this->loadModel($this->model);
		$data  = $model->belanja_modal();
		return json_encode($data);  
	}

	function belanja_modalsDrill() {    
		$model = $this->loadModel($this->model);
		$data  = $model->belanja_modalDrill();
		return json_encode($data);  
	}

	function loadPagu() {    
		$model = $this->loadModel($this->model);
		$data  = $model->hasil_pagu();
		return json_encode($data);  
	}

	function tots_pagu() {    
		$model = $this->loadModel($this->model);
		$data  = $model->tot_pagu();
		return json_encode($data); 

	}

	function tots_kontrak() {    
		$model = $this->loadModel($this->model);
		$data  = $model->tot_kontrak();
		return json_encode($data);  
	}
}