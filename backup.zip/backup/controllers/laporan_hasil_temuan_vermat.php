<?php
/**
 * 
 */
class Laporan_hasil_temuan_vermat extends Controller
{

    private $table      = "vt_vermat_temuan";

    private $primaryKey = "autono";

    private $model      = "Laporan_hasil_temuan_vermat_model";

    private $title      = "Laporan hasil temuan";

    private $menu       = "Laporan";

    private $curl       = BASE_URL."laporan_hasil_temuan_vermat";
   
   function __construct()
   {
      $session = $this->loadHelper('Session_helper');

        if(!$session->get('username')){

         $this->redirect('auth/login');

      }
   }

   function index()
   {
      // $model = $this->loadModel($this->model);

      $data                = array();
      $data['breadcrumb1'] = $this->menu;
      $data['curl']        = $this->curl;
      $data['title']       = $this->title;
      // $data['kotama']      = $model->getkotama();
      $template            = $this->loadView('laporan_hasil_temuan_vermat_view');
      $template->set('data', $data);
      $template->render();
   }

   function get($tahun,$bulan)
  {

    $request    = $_REQUEST;

   
    $columns = array(

      array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
      array( 'db' => 'bulan',  'dt' => 1 ),
      array( 'db' => 'tahun',  'dt' => 2 ),
      array( 'db' => 'nm_satminkal',  'dt' => 3 ),
      array( 'db' => 'satminkal',  'dt' => 4 ),
      array( 'db' => 'kategori',  'dt' =>  5),


    );
    $model   = $this->loadModel($this->model);
    
    $result  = $model->mget($request,$this->table, $this->primaryKey, $columns,$tahun,$bulan);



    return json_encode($result);

  }

	function vermat()
   {
      $model = $this->loadModel($this->model);

          $help  = $this->loadHelper('Url_helper');

         $tahun      = $help->segment(4);

         $bulan      = $help->segment(5);

         $satminkal  = $help->segment(6);

         $v     = $model->getvalue("SELECT * FROM vt_vermat_temuan a LEFT JOIN tsatminkal b ON 
                                    a.satminkal = b.kd_satminkal WHERE  a.satminkal = '$satminkal' AND bulan = '$bulan' AND tahun = '$tahun' GROUP BY satminkal"); 

         $temuan = $model->query("SELECT * FROM vt_vermat_temuan_detail WHERE  satminkal = '$satminkal' AND tahun = '$tahun' AND bulan = '$bulan' AND kategori = '$kat' ORDER BY `order` ASC ");


         $dasar = $model->query("SELECT * FROM vt_vermat_nhv_dasar WHERE  satminkal = '$satminkal' AND tahun = '$tahun' AND bulan = '$bulan'  ORDER BY `order` ASC");

         $tembusan  = $model->query("SELECT b.nm_tembusan FROM nhv_temb_vermat a LEFT JOIN  ttembusan b ON a.id_tembusan = b.autono 
                                      WHERE  a.satminkal = '$satminkal' AND a.tahun = '$tahun' AND a.bulan = '$bulan'  ORDER BY a.id_tembusan ASC");

         $ttd  = $model->getvalue("SELECT b.nrp,b.nama,a.klasifikasi,a.lampiran,a.perihal,b.jabatan,nm_pangkat FROM vt_vermat_nhv a     
                                    LEFT JOIN tpers b ON b.nrp = a.tanda_tangan
                                    LEFT JOIN tpangkat c ON b.id_pangkat =  c.kd_pangkat WHERE a.satminkal = '$satminkal' AND a.tahun = '$tahun' AND 
                                    a.bulan = '$bulan'");

         $nomor  = $model->getvalue("SELECT nomor_nhv FROM vt_vermat_tup WHERE satminkal = '$satminkal' AND tahun = '$tahun' AND bulan = '$bulan'  ");

      $pdf   = $this->loadLibrary('fpdf');
     
      $pdf->SetMargins(25.4,20.3,15.2,12.7); // Format A4
      $pdf->AddPage('P', 'A4');

      // Kop Surat
      $pdf->SetFont('Arial', '', 10);
      $pdf->Cell(65, 5, 'MARKAS BESAR ANGKATAN DARAT', 0, 1, 'C');
      $pdf->Cell(64, 2, 'INSPEKTORAT JENDERAL', 0, 1, 'C');
      $pdf->Cell(62,2,'','B',1);
      $pdf->Cell(253, 10, 'Bandung,          Mei 2020', 0, 1, 'C');
      $pdf->Ln(5);

      // Content
      $pdf->Cell(25, 5, 'Nomor', 0, 'LTR', 'L');
      $pdf->Cell(-2, 5, ':', 0, 'LTR','C');
      $pdf->Cell(2);
      $pdf->MultiCell(110, 5, .$nomor['nomor_nhv'].'/NHV-Vermat 1/2020', 'J');
      $pdf->Cell(28, 5, 'Klasifikasi', 0, 'LTR', 'L');
      $pdf->Cell(-8, 5, ':', 0, 'LTR','C');
      $pdf->Cell(5);
      $pdf->MultiCell(110, 5, $ttd['klasifikasi'], 'J');
      $pdf->Cell(28, 5, 'Lampiran', 0, 'LTR', 'L');
      $pdf->Cell(-8, 5, ':', 0, 'LTR','C');
      $pdf->Cell(5);
      $pdf->MultiCell(110, 5,$ttd['lampiran'], 'J');
      $pdf->Cell(28, 5, 'Perihal', 0, 'LTR', 'L');
      $pdf->Cell(-8, 5, ':', 0, 'LTR','C');
      $pdf->Cell(5);
      $pdf->MultiCell(60, 5, $ttd['perihal'], 'J');
      $pdf->Cell(26);
      $pdf->Cell(58,0,'','B',1);
      $pdf->Ln(5);

         $pdf->Cell(240, 5, 'Kepada', 0, 1, 'C');
         $pdf->Ln(2);
         $pdf->Cell(103);
         $pdf->Cell(10, 4, 'Yth.', 0, 0);
         $pdf->MultiCell(33, 4, strtolower(ucfirst($v['nm_satminkal'])), 0,'J');
         $pdf->Ln(2);
         $pdf->Cell(232, 7, 'di', 0, 1, 'C');
         $pdf->Cell(243, 7, 'Bandung', 0, 1, 'C');
         $pdf->Ln(5);

      // $pdf->Cell(25, 5, 'U.p. Kavermat Itben Itjenad', 0, 'LTR', 'L');
      // $pdf->Ln(10);
        $pdf->Cell(10,5,'1.',0,0);
         $pdf->MultiCell(25,5,'Dasar :',0,'J');
         // $pdf->Ln(3);
         $pdf->Cell(15);

         $pdf->Cell(10,5,'a.',0,0);
         $pdf->MultiCell(125,5,'PPeraturan Kasad Nomor 5 Tahun 2015 tentang Organisasi dan Tugas Inspektorat Jendral Angkatan Darat (Orgas Itjenad) Uji Coba;  ',0,'J');
         $pdf->Ln(5);
         $pdf->Cell(15);

         $pdf->Cell(10,5,'b.',0,0);
         $pdf->MultiCell(125,5,'Keputusan Kasad Nomor Kep/575/VIII/2015 tanggal 20 Agustus 2015 tentang Petunjuk Teknis tentang Verifikasi materil;',0,'J');
         $pdf->Ln(5);
         $pdf->Cell(15);

         $pdf->Cell(10,5,'c.',0,0);
         $pdf->MultiCell(125,5,'Surat Keputusan Kasad Nomor Skep/500/IX/1989 tanggal 25 September 1989 tentang kewajiban dan wewenang penertiban umum dan pengurusan perbendaharaan dalam rangka pengawasan dan pemeriksaan di lingkungan TNI AD',0,'J');
         $pdf->Ln(5);
         $pdf->Cell(15);

         $pdf->Cell(10,5,'d.',0,0);
         $pdf->MultiCell(125,5,'Keputusan Irjenad Nomor Kep/01/I/2020 2 januari 2020 tentang program kerja dan anggaran Itjenad TA 2020;dan',0,'J');
         $pdf->Ln(5);
         $pdf->Cell(15);

         $pdf->Cell(10,5,'e.',0,0);
         $pdf->MultiCell(125,5,'Surat pengantar dari Kebekangdam II/Swj Nomor B/Speng-73/I/2020 tanggal 29 Januari 2020 tentang pengiriman pertanggungjawaban Bekal II/BMP Tepbek II-44-01.A Smt II TA 2019 ',0,'J');
         $pdf->Ln(5);
         $pdf->Cell(20);


         $pdf->Cell(10,1,'',0,1);
         // $pdf->Cell(5);
         $pdf->Cell(10,5,'2. ',0,0);
         $pdf->MultiCell(140,5,'Dari hasil Verifikasi pertanggungjawaban bekal III/BMP Tepbek II-44-01.A Bekangdam II/Swj Smt II TA 2019 sesuai butir 1.e diatas ditemukan permasalahan pada administrasi pengeluaran yaitu terdapat selisih antara bentuk 32-4004 (bukti pengeluaran BMP) dengan bentuk 32-4006 (surat perintah pngeluaran BMP) sebanyak 1.348 liter sebagai berikut :  ',0,'J');
         $pdf->Ln(4);

         $pdf->Cell(15);

         $pdf->Cell(10,5,'a. ',0,0);
         $pdf->MultiCell(126,5,'Pada bentuk 32-4004 Nomor 14/4004/VIII/2019 tanggal 15 Agustus 2019 pengeluaran HSD Bio Solar sebanyak 5.596 liter;dan   ',0,'J');
         $pdf->Ln(5);

         $pdf->Cell(15);
         $pdf->Cell(10,5,'b. ',0,0);
         $pdf->MultiCell(126,5,'ada bentuk 32-4006 nomor 14/4006/VIII/2019 tanggal 15 Agustus 2019 pengeluaran HSD Bio Solar sebanyak 4.248 liter  ',0,'J');
         $pdf->Ln(5);

        
         $pdf->Cell(10,1,'',0,1);
         // $pdf->Cell(5);
         $pdf->Cell(10,5,'3.',0,0);
         $pdf->MultiCell(140,5,'Sehubungan dengan hal diatas diminta bekangdam II/Swj unutk memberikan penjelasan dilengkapi bukti-bukti autentik pendukungnya dikirim ke Vermat Itben Itjenad Jl.Manado No.8 Bandung paling lambat 15 hari setelah nota ini diterima.',0,'J');
         $pdf->Ln(10);

         // $pdf->Cell(5);
         $pdf->Cell(10,5,'4.',0,0);
         $pdf->MultiCell(140,5,'Demikian untuk dimaklumi.',0,'J');
         $pdf->Ln(5);


         $pdf->Cell(140,5,"a.n Inspektur Jendral Angkatan Darat",0,1,'R');
         $pdf->Cell(133,5,"Inspektur perbendaharaan",0,1,'R');
         $pdf->Cell(114,5,"u.b",0,1,'R');
         $pdf->Cell(120,5,"Kavermat",0,1,'R');
         $pdf->Cell(100 ,10,'',0,1);//end of line
         $pdf->Ln(10);

         $pdf->Cell(125,5,'Tembusan :',0,0);
         $pdf->Cell(8,5,"Joko Prianto S.sos.,M.M",0,1,'R');
         $pdf->Cell(1);
         $pdf->Cell(140,5,"Kolonel Cpl NRP 1900026750968",0,1,'R');
         $pdf->Ln(1);

         $pdf->Cell(10,5,'1.',0,0);
         $pdf->Cell(40,5,'Irjenad sebagai laporan',0,1);
         $pdf->Cell(10,5,'2.',0,0);
         $pdf->Cell(40,5,'Irben Itjenad',0,1);
         $pdf->Cell(10,5,'3.',0,0);
         $pdf->Cell(40,5,'Dirbekangad',0,1);
         $pdf->Cell(10,5,'4.',0,0);
         $pdf->Cell(40,5,'Irdam II/Swj',0,1);
         $pdf->Cell(10,5,'5.',0,0);
         $pdf->Cell(40,5,'Aslog kasdam II/Swj',0,1);
         $pdf->Cell(10,5,'6.',0,0);
         $pdf->MultiCell(50,5,'Dentapbek II-44-01.A/Lht Bekangdam II/Swj',0,1);
         $pdf->Cell(51,0,'','B',1); // Line end
         $pdf->Ln(2);

      // $no = 1;
      // foreach ($valTemb as $key => $valueTemb)
      // {       
      //    if(count($valTemb) > 1){
      //       $pdf->Cell(60, 4, $no++.'.      '.$valueTemb['nm_tembusan'], 0, 1, 'L');
      //       //$pdf->Line(43, 233, 70, 233);
      //    }else{
      //       $pdf->Cell(65, 4, $valueTemb['nm_tembusan'], 0, 1, 'L');
      //       //$pdf->Line(43, 233, 70, 233);
      //    }
      // }
      
      // // Footer
      //    global $totalPageForFooter;
      //    if($pdf->PageNo() != $totalPageForFooter){
      //       if($pdf->PageNo() != 1){
      //          $pdf->SetY(15);
      //          $pdf->SetFont('Arial', '', 12);
      //          $pdf->Cell(0, 10,''.$pdf->PageNo(),0,0,'C');
      //          $pdf->Ln(10);
               
      //          $pdf->SetFont('Arial', '', 12);
      //          $pdf->SetY(100);
      //          $pdf->Cell(12, 5, '1', 'LRT',0,'C');
      //          $pdf->Cell(10, 5, '2', 'LRT', 0, 'C');
      //          $pdf->Cell(55, 5, '3', 'LRT', 0, 'C');
      //          $pdf->Cell(30, 5, '4', 'LRT', 0, 'C');
      //          $pdf->Cell(35, 5, '5', 'LRT', 0, 'C');
      //          $pdf->Cell(37, 5, '6', 'LRT', 0, 'C');
      //          $pdf->Cell(30, 5, '7', 'LRT', 0, 'C');
      //          $pdf->Cell(29, 5, '8', 'LRT', 0, 'C');
      //          $pdf->Ln(0);
      //       }
      //    }

      //$pdf->AcceptPageBreak();
      //$pdf->AliasNbPages();
      $pdf->Output();
   }
      
}