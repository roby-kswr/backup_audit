<?php



class Analisa_renlak_vermat_detail extends Controller {



	private $table      = "vt_vermat_renlak_detail";

	private $primaryKey = "autono";

	private $model      = "Analisa_renlak_vermat_detail_model";

	private $menu       = "Analisa";

	private $title      = "Rencana Pelaksanaan Kegiatan Detail";

	private $curl       = BASE_URL."analisa_renlak_vermat_detail";

	



	public function __construct()

    {

        $session = $this->loadHelper('Session_helper');

        if(!$session->get('username')){

        	$this->redirect('auth/login');

        }

    }

	

	function index()

	{

		$data                = array();

		$data['breadcrumb1'] = $this->menu;

		$data['title']       = $this->title;

		$data['curl']	     = $this->curl;

		$template            = $this->loadView('analisa_renlak_vermat_detail_view');

		$template->set('data', $data);

		$template->render();

	}



	public function detail($x,$y,$z)

	{

		$uri = $this->loadHelper('Url_helper');

		$data                = array();

		$data['tahun']		 = $uri->segment(3);

		$data['bulan']		 = $uri->segment(4);

		$data['breadcrumb1'] = $this->menu;

		$data['title']       = $this->title;

		$data['curl']	     = $this->curl;

		$data['encode']      = $x;

		$data['tahun']      = $y;

		$data['bulan'] 		 = $z;

		$template            = $this->loadView('analisa_renlak_vermat_detail_view');

		$template->set('data', $data);

		$template->render();

	}



	function get($x = null, $y = null, $z = null)

	{

		$request    = $_REQUEST;

		$id         = $this->base64url_decode($x);

		$columns = array(

			array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),

			array( 'db' => 'upload',  'dt' => 1 ),array( 'db' => 'keterangan',  'dt' => 2 ),array( 'db' => 'nm_renlak',  'dt' => 3 ),

		);



		$model   = $this->loadModel($this->model);
		$join   = "a LEFT JOIN (SELECT autono AS kd_renlak, nm_renlak FROM trenlak ) AS b ON a.kategori = b.kd_renlak";
		if($x){

			$result  = $model->mget_detail($request, $this->table, $this->primaryKey, $columns, $id,$y,$z,$join);

		} else {

			$result  = $model->mget($request, $this->table, $this->primaryKey, $columns);

		}



		return json_encode($result);

	}



	public function add($x = null,$y = null,$z = null)

	{
		$uri = $this->loadHelper('Url_helper');

		$model               = $this->loadModel($this->model);

		$data                = array();

		$data['tahun']		 = $uri->segment(3);

		$data['bulan']		 = $uri->segment(4);

		$data['breadcrumb1'] = $this->menu;

		$data['title']       = $this->title;

		$data['action']      = 'Add';

		$data['curl']	     = $this->curl;

		$data['encode']      = $x;

		$data['tahun']      = $y;

		$data['bulan'] 		 = $z;

		$template            = $this->loadView('analisa_renlak_vermat_detail_add');

		$data['kategori']   = $model->get_vermat_ren();

		$template->set('data', $data);

		$template->render();

	}



	public function edit($x,$y = null,$z = null,$zz = null)

	{

		$id                  = $this->base64url_decode($x);

		$model               = $this->loadModel($this->model);

		$uri                 = $this->loadHelper('Url_helper');

		$data                = array();

		// $data['tahun']		 = $uri->segment(7);

		// $data['bulan']		 = $uri->segment(8);

		$data['breadcrumb1'] = $this->menu;

		$data['title']       = $this->title;

		$data['action']      = 'Edit';

		$data['encode']      = $x;

		$data['keyy']      = $y;

		$data['tahun']      = $z;

		$data['bulan'] 		 = $zz;

		$data['curl']	     = $this->curl;

		$data['child']       = $uri->segment(5);

		$data['aadata']      = $model->get($this->table, $this->primaryKey, $id);

		$template            = $this->loadView('analisa_renlak_vermat_detail_edit');

		$data['kategori']   = $model->get_vermat_ren();

		$template->set('data', $data);

		$template->render();

	}



	public function save($x = null,$y = null,$z = null)

	{
		$uri = $this->loadHelper('Url_helper');

		

		$data                 = array();

		

		$model                = $this->loadModel($this->model);

		$data['parent_id']    = $this->base64url_decode($x) ;

		$data['tahun']		 = $uri->segment(5);

		$data['bulan']		 = $uri->segment(6);

		$data['kategori']   = htmlspecialchars($_REQUEST['kategori']) ;
		$data['upload']        = $_FILES['upload']['name'] ;
		$data['keterangan'] = htmlspecialchars($_REQUEST['keterangan']) ;


		$data['autocode']     = $model->autocode($this->table, "#autocode#");	



		$uploadDyn			 = $model->uploadRenlak($_FILES['upload'],$data['parent_id'],$data['tahun'],$data['bulan'],'renlak_vermat');

		$result               = $model->msave($this->table, $data, $this->title);

		if($x){

			$this->redirect('analisa_renlak_vermat_detail/detail/'.$x.'/'.$data['tahun'].'/'.$data['bulan']);

		} else {

			$this->redirect('analisa_renlak_vermat_detail');

		}

	}



	public function update($x,$y = null,$z = null,$zz = null)

	{

		$data               = array();

		$id                 = $this->base64url_decode($x);

		$model              = $this->loadModel($this->model);

		$uri                = $this->loadHelper('Url_helper');

		$child              = $uri->segment(5);

		$parent_id = $this->base64url_decode($uri->segment(5));

		// $data['keyy']      = $y;

		$tahun      = $uri->segment(6);

		$bulan 		 = $uri->segment(7);

		$data['kategori']  = htmlspecialchars($_REQUEST['kategori']) ;

		if ($_FILES['upload']['name']!='')
		{ $data['upload']        = $_FILES['upload']['name'] ; 
		 $uploadDyn			 = $model->uploadRenlak_update($_FILES['upload'],$parent_id,$tahun,$bulan,'renlak_vermat');
			}

		$data['keterangan'] = htmlspecialchars($_REQUEST['keterangan']) ;
	

		$result             = $model->mupdate($this->table, $data, $this->primaryKey, $id, $this->title);

		if($child){

			$this->redirect('analisa_renlak_vermat_detail/detail/'.$child.'/'.$tahun.'/'.$bulan);

		} else {

			$this->redirect('analisa_renlak_vermat_detail');

		}

	}



	public function delete($x)

	{

		$id                 = $this->base64url_decode($x);

		$model              = $this->loadModel($this->model);

		$result             = $model->mdelete($this->table, $this->primaryKey, $id, $this->title);

		return $result;

	}

    

}