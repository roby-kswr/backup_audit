<?php
/**
 * 
 */
class Analisa_tj_verku2 extends Controller
{

	private $table      = "tsatminkal";

	private $table2		= "vt_jnhv_verku";

	private $primaryKey  = "autono";

	private $primaryKey1 = "tahun";

	private $primaryKey2 = "bulan";

	private $primaryKey3 = "kotama";

	private $primaryKey4 = "satminkal";

	private $model      = "Analisa_tj_verku2_model";

	private $menu       = "Analisa";

	private $title      = "Analisa Tanggapan Jawaban Nota Hasil Verifikasi ";

	private $curl       = BASE_URL."analisa_tj_verku2";

	private $curl2      = BASE_URL."laporan_hasil_temuan/verku_1";


	
	public function __construct()

    {

        $session = $this->loadHelper('Session_helper');

        if(!$session->get('username')){

        	$this->redirect('auth/login');

        }
    }


    public function index()
	{

		$data                = array();

		$data['breadcrumb1'] = $this->menu;

		$data['title']       = $this->title;

		$data['curl']	     = $this->curl;

		$data['curl2']	     = $this->curl2;

		$template            = $this->loadView('analisa_tj_verku_view');

		$template->set('data', $data);

		$template->render();

	}

	
	function get($tahun , $bulan)

	{

		$request    = $_REQUEST;

		// $uri        = $this->loadHelper('Url_helper');

		// $id         = $this->base64url_decode($x);


		// $tahun = $uri->segment(5);

		// $bulan = $uri->segment(6);

		$columns = array(

			array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),

			array('db'=>'autono_j', 'dt'=> 1),
			array( 'db' => 'kd_satminkal',  'dt' => 2 ),
			array( 'db' => 'nm_satminkal',  'dt' => 3 ),
			array( 'db' => 'jawaban',  'dt' => 4 ),
			array('db'=>'kd_kotama', 'dt'=> 5 ),
			array('db'=> 'status_jawaban','dt'=>6),
			array('db' =>'tanggapan_jawaban', 'dt'=>7 )
		);



		$model   = $this->loadModel($this->model);

			$join   = " AS t2
						LEFT JOIN (SELECT a.autono AS autono_j, a.kotama AS kotama, a.satminkal AS satminkal , a.jawaban AS jawaban, a.status_jawaban AS status_jawaban, a.tanggapan_jawaban AS tanggapan_jawaban  FROM vt_jnhv_verku a 
						LEFT JOIN (SELECT MAX(autono) AS autono FROM vt_jnhv_verku WHERE tahun='".$tahun."' AND bulan='".$bulan."' GROUP BY kotama, satminkal) AS t1 ON a.autono = t1.autono
						WHERE t1.autono IS NOT NULL) t3 ON t2.kd_kotama = t3.kotama AND t2.kd_satminkal = t3.satminkal";
		// if($x){

			$result  = $model->mget_detail($request, $this->table, $this->primaryKey, $columns, $join);

		// } else {

		// 	$result  = $model->mget($request, $this->table, $this->primaryKey, $columns);

		// }

		return json_encode($result);
	}

	public function detail($x)

	{

		$id                  = $this->base64url_decode($x);

		$model               = $this->loadModel($this->model);

		$uri                 = $this->loadHelper('Url_helper');

		$data                = array();

		$data['breadcrumb1'] = $this->menu;

		$data['title']       = $this->title;

		$data['action']      = 'Edit';

		$data['encode']      = $x;

		$data['curl']	     = $this->curl;

		$data['autono']		 = $uri->segment(4);

		$data['tahun']		 = $uri->segment(5);

		$data['bulan']		 = $uri->segment(6);

		$data['kotama']		 = $uri->segment(7);

		$data['satminkal']	 = $uri->segment(8);

		// $data['child']       = $uri->segment(5);

		$data['aadata']      = $model->get($this->table, $this->primaryKey, $id);

		$template            = $this->loadView('analisa_tj_verku_detail');

		$data['aadata']      = $model->getvalue("SELECT * FROM vt_jnhv_verku WHERE autono = '$data[autono]' AND kotama = '$data[kotama]' AND satminkal = '$data[satminkal]'  AND tahun = '$data[tahun]' AND bulan = '$data[bulan]'");

		// $data['stat']		 = $model->query("SELECT * FROM t_nhv_status ORDER BY autono DESC"); 

		$template->set('data', $data);

		$template->render();

	}

	public function edit($x)

	{

		$id                  = $this->base64url_decode($x);

		$model               = $this->loadModel($this->model);

		$uri                 = $this->loadHelper('Url_helper');

		$data                = array();

		$data['breadcrumb1'] = $this->menu;

		$data['title']       = $this->title;

		$data['action']      = 'Edit';

		$data['encode']      = $x;

		$data['curl']	     = $this->curl;

		$data['autono']		 = $uri->segment(4);

		$data['tahun']		 = $uri->segment(5);

		$data['bulan']		 = $uri->segment(6);

		$data['kotama']		 = $uri->segment(7);

		$data['satminkal']	 = $uri->segment(8);

		// $data['child']       = $uri->segment(5);

		$data['aadata']      = $model->get($this->table, $this->primaryKey, $id);

		$template            = $this->loadView('analisa_tj_verku_edit');

		$data['aadata']      = $model->getvalue("SELECT * FROM vt_jnhv_verku WHERE autono = '$data[autono]' AND kotama = '$data[kotama]' AND satminkal = '$data[satminkal]'  AND tahun = '$data[tahun]' AND bulan = '$data[bulan]'");

		 $data['stat']		 = $model->query("SELECT * FROM t_nhv_status WHERE autono !='5' ORDER BY autono DESC"); 

		$template->set('data', $data);

		$template->render();

	}

	public function update($x)

	{

		$data               = array();

		$id                 = $this->base64url_decode($x);

		$model              = $this->loadModel($this->model);

		$uri                = $this->loadHelper('Url_helper');

		// $child              = $uri->segment(5);

        $autono  			 = $uri->segment(4);
       
		$tahun				 = $uri->segment(5);

		$bulan 				 = $uri->segment(6);

		$kotama 			 = $uri->segment(7);

		$satminkal 			 = $uri->segment(8);

		$data['tanggapan_jawaban'] = htmlspecialchars($_REQUEST['tanggapan']) ;
	

		$data['status_jawaban'] = htmlspecialchars($_REQUEST['status']) ;
	
		
		$result  = $model->mupdate($this->table2, $data,  $this->primaryKey, $autono, $this->primaryKey1, $tahun, $this->primaryKey2, $bulan,$this->primaryKey3, $kotama,$this->primaryKey4, $satminkal,  $this->title);


		$this->redirect('analisa_tj_verku');

	}


}






?>