<?php

class Sprin extends Controller {

	private $table      = "tsprin";
	private $tableTemb  = "tsprintemb";
	private $tablePers  = "tsprinpers";
	private $primaryKey = "autono";
	private $model      = "Sprin_model"; # please write with no space
	private $menu       = "Transaksi";
	private $title      = "Sprin";
	private $curl       = BASE_URL."sprin/";
	
	public function __construct()
    {
        $session = $this->loadHelper('Session_helper');
        if(!$session->get('username')){
        	$this->redirect('auth/login');
        }
    }
	
	function index()
	{
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['curl']        = $this->curl;
		$template            = $this->loadView('sprin_view');
		$template->set('data', $data);
		$template->render();
	}

	function get()
	{
		$request = $_REQUEST;
		$columns = array(
			array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'no_pkpt',  'dt' => 1 ),
			array( 'db' => 'no_sprin',   'dt' => 2 ),
			array( 'db' => 'tgl_sprin',   'dt' => 3 ),
			array( 'db' => 'file_name',   'dt' => 4 ),
		);

		$join   = "a LEFT JOIN (SELECT autono AS kd_pkpt, nomor_pkpt AS no_pkpt FROM tpkpt) AS b ON a.id_pkpt=b.kd_pkpt";
		$model  = $this->loadModel($this->model);
		$result = $model->mget($request, $this->table, $this->primaryKey, $columns, $join);

		return json_encode($result);
	}

	public function add()
	{
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Add';
		$data['curl']        = $this->curl;		
		$data['id_sprin']    = $model->get_maxId($this->table);
		$data['pkpt']        = $model->get_pkpt();
		$data['jabwas']      = $model->get_jabatanWasrik();
		$data['personel']    = $model->mget_personel();
		$data['tembusan']    = $model->get_tembusan();
		$template            = $this->loadView('sprin_add');
		$template->set('data', $data);
		$template->render();
	}

	public function edit($x)
	{
		$id                  = $this->base64url_decode($x);
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Edit';
		$data['encode']      = $x;
		$data['curl']        = $this->curl;
		$data['pkpt']        = $model->get_sprinEdit($this->table, $this->primaryKey, $id);
		// $data['bulan']       = $model->get_pkptEdit($this->table, $this->primaryKey, $id);
		$data['jabwas']      = $model->get_jabatanWasrik();
		$data['personel']    = $model->mget_personel();
		$data['tembusan']    = $model->get_tembusan();
		$data['aadata']      = $model->get($this->table, $this->primaryKey, $id);
		$template            = $this->loadView('sprin_edit');
		$template->set('data', $data);
		$template->render();
	}

	public function save()
	{
		$data                  = array();
		$temb                  = array();
		$model                 = $this->loadModel($this->model);
		$data['id_pkpt']       = htmlspecialchars($_REQUEST['id_pkpt']) ;
		$data['id_pkpt_detil'] = htmlspecialchars($_REQUEST['bulan']) ;
		$data['no_sprin']      = ucwords(htmlspecialchars($_REQUEST['no_sprin'])) ;
		$date                  = str_replace('/', '-', $_REQUEST['tgl_sprin']) ;
		$data['tgl_sprin']     = date("Y-m-d",strtotime($date)) ;
		$dateStart             = str_replace('/', '-', $_REQUEST['tgl_mulai']) ;
		$data['tgl_mulai']     = date("Y-m-d",strtotime($dateStart)) ;
		$dateEnd               = str_replace('/', '-', $_REQUEST['tgl_selesai']) ;
		$data['tgl_selesai']   = date("Y-m-d",strtotime($dateEnd)) ;
		$data['keterangan']    = $model->escapeString($_REQUEST['keterangan']) ;
		$data['menimbang']     = $model->escapeString($_REQUEST['menimbang']) ;
		$data['dasar']         = $model->escapeString($_REQUEST['dasar']) ;
		$data['kepada']        = $model->escapeString($_REQUEST['kepada']) ;
		$data['untuk']         = $model->escapeString($_REQUEST['untuk']) ;
		$data['autocode']      = $model->autocode($this->table, "SP_");
		$upload                = $model->uploads('sprin', $_FILES['file_name'], $data['autocode']);
		$result                = $model->msave($this->table, $data, $this->title);
		$last_id               = $result['id'];
		$jmlCmbTemb            = count($_REQUEST['temb']);

		for ($i=0; $i < $jmlCmbTemb ; $i++) { 
			$temb['autocode']    = $model->autocode($this->tableTemb, "SPTEMB_");
			$temb['id_sprin']    = $last_id;
			$temb['id_tembusan'] = htmlspecialchars($_REQUEST['temb'][$i]);
			$tembresult          = $model->msave($this->tableTemb, $temb, $this->title);
		}
		
		$this->redirect('sprin');
	}

	public function update($x)
	{
		$data                  = array();
		$temb                  = array();
		$id                    = $this->base64url_decode($x);
		$model                 = $this->loadModel($this->model);
		$cekJmlTemb            = $model->getval($this->tableTemb, 'autono', 'id_sprin', $id);
		$data['id_pkpt']       = htmlspecialchars($_REQUEST['id_pkpt']) ;
		$data['id_pkpt_detil'] = htmlspecialchars($_REQUEST['bulan']) ;
		$data['no_sprin']      = ucwords(htmlspecialchars($_REQUEST['no_sprin'])) ;
		$date                  = str_replace('/', '-', $_REQUEST['tgl_sprin']) ;
		$data['tgl_sprin']     = date("Y-m-d",strtotime($date)) ;
		$dateStart             = str_replace('/', '-', $_REQUEST['tgl_mulai']) ;
		$data['tgl_mulai']     = date("Y-m-d",strtotime($dateStart)) ;
		$dateEnd               = str_replace('/', '-', $_REQUEST['tgl_selesai']) ;
		$data['tgl_selesai']   = date("Y-m-d",strtotime($dateEnd)) ;
		$data['keterangan']    = $model->escapeString($_REQUEST['keterangan']) ;
		$data['menimbang']     = $model->escapeString($_REQUEST['menimbang']) ;
		$data['dasar']         = $model->escapeString($_REQUEST['dasar']) ;
		$data['kepada']        = $model->escapeString($_REQUEST['kepada']) ;
		$data['untuk']         = $model->escapeString($_REQUEST['untuk']) ;
		$upload                = $model->uploads('sprin', $_FILES['file_name'], $data['autocode']);	
		$result                = $model->mupdate($this->table, $data, $this->primaryKey, $id, $this->title);
		$jmlCmbTemb            = count($_REQUEST['temb']);
		$resultTemb            = $model->mdelete($this->tableTemb, 'id_sprin', $id, $this->title);
		
		for ($i=0; $i < $jmlCmbTemb ; $i++) { 
			$temb['autocode']    = $model->autocode($this->tableTemb, "SPTEMB_");
			$temb['id_sprin']    = $id;
			$temb['id_tembusan'] = htmlspecialchars($_REQUEST['temb'][$i]);
			$resultTemb          = $model->msave($this->tableTemb, $temb, $this->title);
		}

		$this->redirect('sprin');
	}

	public function delete($x)
	{
		$id         = $this->base64url_decode($x);
		$model      = $this->loadModel($this->model);
		$result     = $model->mdelete($this->table, $this->primaryKey, $id, $this->title);
		$resultPers = $model->mdelete($this->tablePers, 'id_sprin', $id, $this->title);
		$resultTemb = $model->mdelete($this->tableTemb, 'id_sprin', $id, $this->title);
		return $result;
	}
	
	public function savePers($x)
	{
		$data                     = array();
		$model                    = $this->loadModel($this->model);
		$data['id_sprin']         = $model->get_maxId($this->table);
		$data['id_kotama'] 		  = $x;
		$data['nrp']      		  = htmlspecialchars($_REQUEST['nrp']) ;
		$data['id_jabatanwasrik'] = htmlspecialchars($_REQUEST['jbtn']) ;
		$data['autocode']         = $model->autocode($this->tablePers, "SPP_");
		$result                   = $model->msave($this->tablePers, $data, $this->title);
				
		//$this->redirect('sprin');
		if($result){
			echo 1;
		}else{
			echo 0;
		}
	}

	public function editPers($x,$y)
	{
		$data                     = array();
		$id                   	  = $this->base64url_decode($x);
		$model                    = $this->loadModel($this->model);
		$data['id_sprin']         = $id;
		$data['id_kotama'] 		  = $y;
		$data['id_personel']      = htmlspecialchars($_REQUEST['nrp']) ;
		$data['id_jabatanwasrik'] = htmlspecialchars($_REQUEST['jbtn']) ;
		$data['autocode']         = $model->autocode($this->tablePers, "SPP_");
		$result                   = $model->msave($this->tablePers, $data, $this->title);
				
		if($result){
			echo 1;
		}else{
			echo 0;
		}
	}

	public function deletePers($x)
	{
		$id         = $this->base64url_decode($x);
		$model      = $this->loadModel($this->model);
		$resultTemb = $model->mdelete($this->tablePers, $this->primaryKey, $id, $this->title);
		return $result;
	}

	function loadPers($id)
	{
		$request = $_REQUEST;
		$model   = $this->loadModel($this->model);
		$id      = $this->base64url_decode($id);
		$last_id = $model->get_maxId($this->table);
		$columns = array(
			array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'nama',  'dt' => 1 ),
			array( 'db' => 'nm_pangkat',   'dt' => 2 ),
			array( 'db' => 'nm_korps',   'dt' => 3 ),
			array( 'db' => 'nrp',   'dt' => 4 ),
			array( 'db' => 'jabatan',   'dt' => 5 ),
			array( 'db' => 'nm_jabatan_wasrik',   'dt' => 6 ),
			array( 'db' => 'nm_kotama',   'dt' => 7 )
		);
		$join   = "LEFT JOIN (SELECT autono AS kd_pers, nrp AS id_personel, nama, id_korps, id_pangkat, jabatan FROM tpers) b ON a.nrp = b.id_personel
				   LEFT JOIN (SELECT autono as kd_pangkat, nm_pangkat FROM tpangkat) c ON b.id_pangkat = c.kd_pangkat
				   LEFT JOIN (SELECT autono as kd_korps, nm_korps FROM tkorps) d ON b.id_korps = d.kd_korps
				   LEFT JOIN (SELECT autono as kd_jabwas, nm_jabatan_wasrik FROM tjabatanwasrik) e ON a.id_jabatanwasrik = e.kd_jabwas
				   LEFT JOIN (SELECT autono as kd_kotama, nm_kotama FROM tkotama) f ON FIND_IN_SET (f.kd_kotama, a.id_kotama)";
		if($id)
		{
			$sWhere = "id_sprin = $id";
		} 
		else 
		{
			$sWhere = "id_sprin = $last_id";
		}
	
		$result  = $model->mgetdetail($request, $this->tablePers, $this->primaryKey, $columns, $join, $sWhere);

		return json_encode($result);
	}

	function load_Fpdf($x)
	{
		$model = $this->loadModel('sprin_model');
		$pdf   = $this->loadLibrary('fpdf');
		$id    = $this->base64url_decode($x);
		
		// Get Data Sprin
		$dtSprin  = $model->load_sprin($id);
		// Get Data Kotama
		$dtKotama = $model->load_kotama($id);
		// Get Data Personel
		$sWhere = "AND `status` = 0";
		$dtPers = $model->load_personel($id, $sWhere);
		// Get Data Tembusan		
		$dtTembusan = $model->load_tembusan($id);
		
		$expldD = explode('<li>', $dtSprin['dasar']);
		$expldU = explode('<li>', $dtSprin['untuk']);		
		
		// ** Surat Dinas **
			$pdf->SetMargins(42,10); // Format A4
			$pdf->AddPage('P', 'A4');

			// Kop Surat
			$pdf->SetFont('Arial', '', 10);
			$pdf->Cell(65, 5, 'MARKAS BESAR ANGKATAN DARAT', 0, 1, 'C');
			$pdf->Cell(64, 2, 'INSPEKTORAT JENDERAL', 0, 1, 'C');
			$pdf->Line(44, 25, 105, 25);
			$pdf->Ln(5);

			// Title
			$pdf->Cell(153, 5, 'SURAT PERINTAH', 0, 1, 'C');
			$pdf->Cell(152, 5, 'Nomor '.$dtSprin['no_sprin'], 0, 1, 'C');
			$pdf->Ln(5);

			// Content
			$pdf->Cell(28, 5, 'Menimbang', 0, 'LTR', 'L');
			$pdf->Cell(10, 5, ':', 0, 'LTR','C');
			$pdf->MultiCell(110, 5, strip_tags(preg_replace('/<p[^>]*>/', '        ', $dtSprin['menimbang']) ), 'J');

			// Dasar
			$pdf->Cell(28, 5, 'Dasar', 0, 'LTR', 'L');
			$pdf->Cell(10, 5, ':', 0, 'LTR','C');
			for ($i=1; $i < count($expldD); $i++){
		   		$pdf->MultiCell(110, 5, $i.'.     '.str_replace(array('</li>','</ol>'), "\r\n", $expldD[$i]), 'J');
		   		$pdf->Cell(28, 5, '', 0, 'LTR', 'L');
		   		$pdf->Cell(10, 5, '', 0, 'LTR','C');	
			}				
			$pdf->ln(-5);
			$pdf->Cell(153, 12, 'DIPERINTAHKAN', 0, 1, 'C');
			// Kepada
			$pdf->Cell(28, 5, 'Kepada', 0, 'LTR', 'L');
			$pdf->Cell(10, 5, ':', 0, 'LTR','C');
			$pdf->MultiCell(110, 5, strip_tags(preg_replace('/<p[^>]*>/', '        ', $dtSprin['kepada']) ), 'J');
			// Untuk
			$pdf->Cell(28, 5, 'Untuk', 0, 'LTR', 'L');
			$pdf->Cell(10, 5, ':', 0, 'LTR','C');
			for ($i=1; $i < count($expldU); $i++){
		   		$pdf->MultiCell(110, 5, $i.'.     '.str_replace(array('</li>','</ol>'), "\r\n", $expldU[$i]), 'J');
		   		$pdf->Cell(28, 5, '', 0, 'LTR', 'L');
		   		$pdf->Cell(10, 5, '', 0, 'LTR','C');	
			}
			$pdf->ln(0);
			$pdf->Cell(0, 0, 'Selesai.', 0, 1, 'L');
			$pdf->Cell(216, 5, 'Dikeluarkan di Jakarta', 0, 1, 'C');
			$pdf->Cell(123, 3, 'pada tanggal           ', 0, 1, 'R');
			$pdf->Cell(148, -3, $pdf->getMonth($dtSprin['bulan']).' '.$dtSprin['tahun'], 0, 1, 'R');
			$pdf->ln(6);
			$pdf->SetX(-77); $pdf->MultiCell(56, -2, '', 'T', 'R');
			$pdf->Cell(237, 10, 'Inspektur Jenderal Angkatan Darat,', 0, 1, 'C');
			$pdf->Cell(237, 25, 'Suko Pranoto', 0, 1, 'C');
			$pdf->Cell(237, -17, 'Mayor Jenderal TNI', 0, 1, 'C');
			$pdf->Cell(65, 16, 'Tembusan:', 0, 1, 'L');
			
			$num = 1;
			foreach ($dtTembusan as $key => $valTemb)
			{		  
				if(count($dtTembusan) > 1){
					$pdf->Cell(65, 4, $num++.'.      '.$valTemb['nm_tembusan'], 0, 1, 'L');
				}else{
					$pdf->Cell(65, 4, $valTemb['nm_tembusan'], 0, 1, 'L');
				}
			}

		// ** Daftar Susunan Tim Pengawasan **
			$pdf->SetMargins(33,23); // Format A4 Landscape
			$pdf->AddPage('L', 'A4');

			// Kop Surat
			$pdf->SetFont('Arial', '', 10);
			$pdf->Cell(65, 5, 'MARKAS BESAR ANGKATAN DARAT', 0, 1, 'C');
			$pdf->Cell(64, 2, 'INSPEKTORAT JENDERAL', 0, 1, 'C');
			$pdf->Line(35, 52, 95, 52);

			$pdf->Cell(239, -9, 'Lampiran Surat Perintah Irjenad', 0, 1, 'R');
			$pdf->Cell(239, 18, 'Nomor             '.$dtSprin['no_sprin'], 0, 1, 'R');
			$pdf->Cell(239, -9, 'Tanggal                '.$pdf->getMonth($dtSprin['bulan']).' '.$dtSprin['tahun'], 0, 1, 'R');
			$pdf->SetXY(-76,58); $pdf->MultiCell(50, 0, '', 'T', 'R');
			$pdf->Ln(5);

			// Title
			$pdf->Cell(250, 5, 'DAFTAR SUSUNAN TIM PENGAWASAN '.strtoupper($dtSprin['id_jns_audit']).' AUDIT TA '.$dtSprin['tahun'], 0, 1, 'C');
			for ($i=0; $i < count($dtKotama); $i++){
				$ktm[$i]= $dtKotama[$i]['nm_kotama'];
			}
			$pdf->Cell(249, 3, 'DI'.' '.implode(' DAN ', $ktm), 0, 1, 'C');			
			$pdf->Ln(5);

			//Table	
			// * Baris Pertama
			$pdf->Cell(22, 5, 'NOMOR', 'LRTB', 0, 'C');
			$pdf->Cell(50, 10, 'NAMA', 'LRTB', 0, 'C');
			$pdf->Cell(35, 5, 'PANGKAT,', 'LRT', 0, 'C');
			$pdf->Cell(35, 5, 'JABATAN', 'LRT', 0, 'C');
			$pdf->Cell(37, 5, 'JABATAN DALAM', 'LRT', 0, 'C');
			$pdf->Cell(30, 10, 'SAS SATUAN', 'LRTB', 0, 'C');
			$pdf->Cell(29, 5, 'WAKTU', 'LRT', 0, 'C');
			// Total Max 880 Kertas A4
			$pdf->Cell(30, 5, '', 0, 0);
			$pdf->Ln();

			// * Baris Kedua
			$pdf->Cell(12, 5, 'URUT', 'LRB', 0, 'C');
			$pdf->Cell(10, 5, 'BAG', 'LRB', 0, 'C');
			$pdf->Cell(50, 0, '', 0, 0);
			$pdf->Cell(35, 5, 'KORPS, NRP', 'LRB', 0, 'C');
			$pdf->Cell(35, 5, 'KESATUAN', 'LRB', 0, 'C');
			$pdf->Cell(37, 5, 'TIM', 'LRB', 0, 'C');
			$pdf->Cell(30, 0, '', 'LR', 0, 'C');
			$pdf->Cell(29, 5, 'PELAKSANAAN', 'LRB', 0, 'C');
			$pdf->Ln();

			// * Baris Ketiga
			$pdf->Cell(12, 5, '1', 'LRB', 0, 'C');
			$pdf->Cell(10, 5, '2', 'LRB', 0, 'C');
			$pdf->Cell(50, 5, '3', 'LRB', 0, 'C');
			$pdf->Cell(35, 5, '4', 'LRB', 0, 'C');
			$pdf->Cell(35, 5, '5', 'LRB', 0, 'C');
			$pdf->Cell(37, 5, '6', 'LRB', 0, 'C');
			$pdf->Cell(30, 5, '7', 'LRB', 0, 'C');
			$pdf->Cell(29, 5, '8', 'LRB', 0, 'C');
			$pdf->Ln();
						
			// * Kolom Data
			$pdf->SetWidths(array(12,10,50,35,35,37,30,29,''));
			$pdf->SetAligns(array('C','C','L','L','L','L','C','C','C'));
			$pdf->RowBLess(array('','','','','','','','',''));
			
			$no = 1;
			$x  = 1;
			foreach ($dtPers as $key => $valPers)
				// for ($i=1; $i < count($valPers); $i++){
				// 	$ktm[$i]= $dtPers['nm_kotama'];
				// }
				// $tes = implode(' DAN ', $ktm);
			{
				if($valPers['m_start'] == $valPers['m_end']){
					$date = $valPers['d_start'].' s.d '.$valPers['d_end'].' '.$this->getMonth($valPers['m_end']).' '.$valPers['y_end'];
				}else{
					$date = $valPers['d_start'].' '.$this->getMonth($valPers['m_start']).' s.d '.$valPers['d_end'].' '.$this->getMonth($valPers['m_end']).' '.$valPers['y_end'];
				}			

				$pdf->RowBLess(
					array($no++,
					$x++, 
					ucwords(strtolower($valPers['nama'])),
					$valPers['nm_pangkat']." ".$valPers['nm_korps']."\n".$valPers['nrp'],
					ucwords(strtolower($valPers['jabatan'])),
					$valPers['nm_jabatan_wasrik'],
					str_replace(',', ' dan ', ucwords(strtolower($valPers['nm_kotama']))),
					$date,
					''
				));
			}

			foreach ($dtKotama as $key => $valKtm)	
			{
				$y = 1;
				$pdf->SetFont('Arial', 'B', 10);
				$pdf->RowBLess(array('', '', strtoupper(($valKtm['nm_kotama'])), '', '', '', '', '', ''));
			
				$nm_ktm = $valKtm['nm_kotama'];
				// Get Data Personel	
				$sWhere = "AND `status` != 0 AND `nm_kotama` = '$nm_ktm'";
				$dtPers = $model->load_personel($id,$sWhere);

				foreach ($dtPers as $key => $valuePers)	
				{		  
					$pdf->SetFont('Arial', '', 10);
					$pdf->RowBLess(
						array($no++,
						$y++, 
						ucwords(strtolower($valuePers['nama'])),
						$valuePers['nm_pangkat']." ".$valuePers['nm_korps']."\n".$valuePers['nrp'],
						ucwords(strtolower($valuePers['jabatan'])),
						$valuePers['nm_jabatan_wasrik'],
						str_replace(',', ' dan ', ucwords(strtolower($valuePers['nm_kotama']))),
						$date,
						''
					));
				}
			}

			if("{nb}"){			
				$pdf->RowLineB(array('','','','','','','','',''));
			}			

			$pdf->SetFont('Arial', '', 10);
			$pdf->Cell(400, 10, 'Inspektorat Jenderal Angkatan Darat,', 0, 1, 'C');
			$pdf->ln(10);	
			$pdf->Cell(400, 5, 'Suko Pranoto', 0, 1, 'C');
			$pdf->Cell(400, 5, 'Mayor Jenderal TNI', 0, 1, 'C');

			//Footer
			global $totalPageForFooter;
			if($pdf->PageNo() != $totalPageForFooter){
				if($pdf->PageNo() > 2){
					$pdf->SetY(35);
					$pdf->Ln(10);					
					$pdf->SetFont('Arial', '', 10);
					$pdf->SetY(39);
					$pdf->Cell(12, 5, '1', 'LRTB',0,'C');
					$pdf->Cell(10, 5, '2', 'LRTB', 0, 'C');
					$pdf->Cell(50, 5, '3', 'LRTB', 0, 'C');
					$pdf->Cell(35, 5, '4', 'LRTB', 0, 'C');
					$pdf->Cell(35, 5, '5', 'LRTB', 0, 'C');
					$pdf->Cell(37, 5, '6', 'LRTB', 0, 'C');
					$pdf->Cell(30, 5, '7', 'LRTB', 0, 'C');
					$pdf->Cell(29, 5, '8', 'LRTB', 0, 'C');
					$pdf->Ln(0);
				}
			}

		$pdf->Output();
		
	}

	function gets_bulan()
    {
		$id    = $_REQUEST['id_pkpt'];
		$model = $this->loadModel($this->model);
		$data  = $model->mget_bulan($id);
        echo json_encode($data);
    } 

    function gets_kotama()
    {
		$id    = $_REQUEST['parent_id'];
		$model = $this->loadModel($this->model);
		$data  = $model->mget_kotama($id);
        echo json_encode($data);
    }

    function getMonth($bln)
{
	switch ($bln) {
	case 1:
		$bulan = "Jan";
		break;
	case 2:
		$bulan = "Feb";
		break;
	case 3:
		$bulan = "Mar";
		break;
	case 4:
		$bulan = "Apr";
		break;
	case 5:
		$bulan = "Mei";
		break;
	case 6:
		$bulan = "Jun";
		break;
	case 7:
		$bulan = "Jul";
		break;
	case 8:
		$bulan = "Agust";
		break;
	case 9:
		$bulan = "Sept";
		break;
	case 10:
		$bulan = "Okt";
		break;
	case 11:
		$bulan = "Nov";
		break;
	case 12:
		$bulan = "Des";
		break;
		
	default:
		
		break;
}
return $bulan;
}

}