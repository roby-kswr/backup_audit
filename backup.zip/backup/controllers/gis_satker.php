<?php

class Gis_satker extends Controller {

	private $menu       = "GIS View";
	private $title      = "Data View per Satker";
	private $curl       = BASE_URL."gis_satker/";
	

	public function __construct()
    {
        $session = $this->loadHelper('Session_helper');
        if(!$session->get('username')){
        	$this->redirect('auth/login');
        }
    }
	
	function index()
	{
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['curl']        = $this->curl;
		$template            = $this->loadView('gis_satker_view');
		$template->set('data', $data);
		$template->render();
	}

    
}