<?php

class Pka_model extends Model {

	public function mget($request, $table, $primaryKey, $columns, $join = null)
	{
		
		$result = $this->simple($request, $table, $primaryKey, $columns, $join);
		
		return $result;

	}

	public function mgetManage($request, $table, $primaryKey, $columns)
	{
		
		$result = $this->simple($request, $table, $primaryKey, $columns);
		
		return $result;

	}

	public function get($table, $primaryKey, $id)
	{
		
		$result = $this->query("SELECT *, DATE_FORMAT(tgl_pka, '%d/%m/%Y') AS tanggal_pka FROM $table WHERE $primaryKey = '$id'");
		
		return $result;

	}

	public function msave($table, $data = array(), $title)
	{
		
		$result = $this->sqlinsert($table, $data, $title);
		
		return $result;

	}

	public function mupdate($table, $data = array(), $primaryKey, $id, $title)
	{
		
		$result = $this->sqlupdate($table, $data, $primaryKey, $id, $title);
		
		return $result;

	}

	public function mdelete($table, $primaryKey, $id, $title)
    {
        
        $result = $this->sqldelete($table, $primaryKey, $id, $title);
		
		return $result;

    }

    public function show_groups($id)
	{
		
		$result = $this->execute("SELECT autono as id, group_name as title, parent_id FROM tpkamanage WHERE id_pka = '$id'");
		
		return $result;

	}

	public function get_groups($id)
	{
		
		$result = $this->query("SELECT autono, group_name, if(autono = $id, 'selected', '') as pselect FROM tpkamanage WHERE id_pka = '$id'");
		
		return $result;

	}

	public function getManage($table, $primaryKey, $id)
	{
		
		$result = $this->query("SELECT * FROM $table WHERE $primaryKey = '$id'");
		
		return $result;

	}

	public function mget_kotama($id)

	{
		
		$result = $this->query("SELECT autono, nm_kotama FROM tkotama a LEFT JOIN (SELECT id_kotama FROM tsprinpers WHERE id_sprin = '$id') b ON a.autono = b.id_kotama WHERE IF(b.id_kotama IS NULL, '', 'selected') = 'selected' GROUP BY autono");
		
		return $result;

	}

	public function mget_satker($id)

	{
		
		$result = $this->query("SELECT autono, nm_satker FROM tsatker WHERE id_kotama = '$id'");
		
		return $result;

	}

	public function mget_personelEdit($table, $field, $id)
	
	{
		
		$result = $this->query("SELECT nrp, LOWER(nama) AS nama, IF(b.disusun_oleh IS NULL, '', 'selected') AS pselect FROM tpers a LEFT JOIN (SELECT disusun_oleh FROM $table WHERE `$field` = '$id') b ON a.nrp = b.disusun_oleh ORDER BY nrp ASC");		
		
		return $result;

	}

	public function get_sprin()
	
	{
		
		$result = $this->query("SELECT autono, no_sprin FROM tsprin");		
		
		return $result;

	}

	// public function get_sprin()
	
	// {
		
	// 	$result = $this->query("SELECT autono, no_sprin FROM tsprin a WHERE NOT EXISTS (SELECT id_sprin FROM tpka b WHERE a.autono = b.id_sprin)");		
		
	// 	return $result;

	// }

	public function get_sprinEdit($table, $field, $id)
	
	{
		
		$result = $this->query("SELECT autono, no_sprin, id_kotama, nm_kotama, IF(b.id_sprin IS NULL, '', 'selected') AS pselect 
								FROM tsprin a 
									LEFT JOIN (SELECT id_sprin, id_kotama FROM $table WHERE `$field` = '$id') b ON a.autono = b.id_sprin 
									LEFT JOIN (SELECT autono as kd_kotama, nm_kotama FROM tkotama) c ON b.id_kotama = c.kd_kotama 
								ORDER BY autono ASC");
		
		return $result;
	
	}


	// public function get_pkaEdit($table, $field, $id)
	// {
		
	// 	$result = $this->query("SELECT autono, no_pka FROM $table WHERE autono = '$id'  ORDER BY autono ASC");		
	// 	return $result;

	// }

	public function insertTree($lastId, $idPka, $idSatker, $nmSatker)

	{
		
		$result = $this->query("INSERT INTO tpkamanage (`parent_id`, `id_pka`, `id_satker`, `group_name`) VALUES ((SELECT t.autono FROM tpkamanage t
							    WHERE t.group_name LIKE '%Sasaran Audit%' AND t.id_pka = '$lastId'), '$idPka', '$idSatker', '$nmSatker')");
		
		return $result;

	}

	public function deleteTree($idPka, $idSatker)

	{
		
		$result = $this->query("DELETE FROM tpkamanage WHERE `id_pka` = $idPka AND `id_satker` = '$idSatker'");
		
		return $result;

	}

	public function load_pka($table, $id)
	{
		
		$result = $this->getvalue("SELECT autono, nm_kotama, sasaran, bidang, tahun, no_pka, month(tgl_pka) as `month`, year(tgl_pka) as `year`
								   FROM $table a LEFT JOIN (SELECT autono AS kd_kotama, nm_kotama FROM tkotama) AS b ON a.id_kotama = b.kd_kotama
								   WHERE autono = '$id'");
		
		return $result;

	}

	public function load_jnsAudit($id)
	{
		
		$result = $this->getvalue("SELECT id_jns_audit AS nm_jns_audit FROM tsprin a LEFT JOIN (SELECT id_pkpt AS kd_pkpt, id_jns_audit FROM tpkpt_detil) AS b ON a.id_pkpt = b.kd_pkpt WHERE autono = '$id'");
		
		return $result;

	}

	public function load_personel($table, $field, $id)
	{
		
		$result = $this->getvalue("SELECT `nama`, `nm_pangkat`, `nm_korps`, `nrp` 
								   FROM $table a 
			 						LEFT JOIN (SELECT autono AS kd_pers, nrp, nama, id_korps, id_pangkat FROM tpers) b ON a.disusun_oleh = b.nrp
		 	   						LEFT JOIN (SELECT autono as kd_pangkat, nm_pangkat FROM tpangkat) c ON b.id_pangkat = c.kd_pangkat
		 	   						LEFT JOIN (SELECT autono as kd_korps, nm_korps FROM tkorps) d ON b.id_korps = d.kd_korps
			 	   				   WHERE $field = '$id'");
		
		return $result;

	}

	// public function load_managePrnt($table, $id)
	// {
	// 	$result = $this->query("SELECT autono, group_name, oleh, waktu, no_kka FROM $table WHERE id_pka = '$id' AND parent_id = '0'");
	// 	return $result;
	// }

	public function load_manage($table, $id, $sWhere)
	{
		
		$result = $this->query("SELECT autono, group_name, oleh, waktu, no_kka FROM $table WHERE id_pka = '$id' $sWhere");
		
		return $result;

	}

	// public function insertTree($id, $idKotama)

	// {
	// 	$result = $this->query("INSERT INTO tpkamanage (`parent_id`, `id_pka`, `group_name`) SELECT t.autono, t.id_pka, s.nm_satker FROM tpkamanage t, tsatker s
	// 						    WHERE (t.group_name LIKE '%Sasaran Audit%' AND t.id_pka = '$id') AND s.id_kotama = '$idKotama'");
	// 	return $result;
	// }

}
