<?php

class Gis_kotama extends Controller {

	private $menu       = "GIS View";
	private $title      = "Data View per Kotama";
	private $curl       = BASE_URL."gis_kotama/";
	

	public function __construct()
    {
        $session = $this->loadHelper('Session_helper');
        if(!$session->get('username')){
        	$this->redirect('auth/login');
        }
    }
	
	function index()
	{
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['curl']        = $this->curl;
		$template            = $this->loadView('gis_kotama_view');
		$template->set('data', $data);
		$template->render();
	}

    
}