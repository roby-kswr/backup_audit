<?php

class Tembusan extends Controller {

	private $table      = "ttembusan";
	private $primaryKey = "autono";
	private $model      = "Tembusan_model"; # please write with no space
	private $menu       = "Reference";
	private $title      = "Tembusan";
	private $curl       = BASE_URL."tembusan/";
	

	public function __construct()
    {
        $session = $this->loadHelper('Session_helper');
        if(!$session->get('username')){
        	$this->redirect('auth/login');
        }
    }
	
	function index()
	{
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['curl']		 = $this->curl;
		$template            = $this->loadView('tembusan_view');
		$template->set('data', $data);
		$template->render();
	}

	function get()
	{
		$request = $_REQUEST;
		$columns = array(
			array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'nm_tembusan',  'dt' => 1 ),
			array( 'db' => 'keterangan',   'dt' => 2 )
		);

		$model   = $this->loadModel($this->model);
		$result  = $model->mget($request, $this->table, $this->primaryKey, $columns, $join);

		return json_encode($result);
	}

	public function add()
	{
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Add';
		$data['curl']		 = $this->curl;
		$template            = $this->loadView('tembusan_add');
		$template->set('data', $data);
		$template->render();
	}

	public function edit($x)
	{
		$id                  = $this->base64url_decode($x);
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Edit';
		$data['encode']      = $x;
		$data['curl']		 = $this->curl;
		$data['aadata']      = $model->get($this->table, $this->primaryKey, $id);
		$template            = $this->loadView('tembusan_edit');
		$template->set('data', $data);
		$template->render();
	}

	public function save()
	{
		$data                = array();
		$model               = $this->loadModel($this->model);
		$data['nm_tembusan'] = ucwords($model->escapeString($_REQUEST['nm_tembusan'])) ;
		$data['keterangan']  = ucwords($model->escapeString($_REQUEST['keterangan'])) ;
		$data['autocode']  	 = $model->autocode($this->table, "TEMB_");	
		$result              = $model->msave($this->table, $data, $this->title);
		$this->redirect('tembusan');
	}

	public function update($x)
	{
		$data           	 = array();
		$id             	 = $this->base64url_decode($x);
		$model          	 = $this->loadModel($this->model);
		$data['nm_tembusan'] = ucwords($model->escapeString($_REQUEST['nm_tembusan'])) ;
		$data['keterangan']  = ucwords($model->escapeString($_REQUEST['keterangan'])) ;
		$result         	 = $model->mupdate($this->table, $data, $this->primaryKey, $id, $this->title);
		$this->redirect('tembusan');
	}

	public function delete($x)
	{
		$id     = $this->base64url_decode($x);
		$model  = $this->loadModel($this->model);
		$result = $model->mdelete($this->table, $this->primaryKey, $id, $this->title);
		return $result;
	}
    
}