<?php

class Kka_anev extends Controller {

	private $table      = "tkka";
	private $tableDetil = "tkkadetil";
	private $primaryKey = "autono";
	private $model      = "Kka_model"; # please write with no space
	private $menu       = "Transaksi";
	private $title      = "KKA View";
	private $curl       = BASE_URL."kka_anev/";
	
	public function __construct()
    {
        $session = $this->loadHelper('Session_helper');
        if(!$session->get('username')){
        	$this->redirect('auth/login');
        }
    }
	
	function index()
	{
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['curl']		 = $this->curl;
		$template            = $this->loadView('kka_anev_view');
		$template->set('data', $data);
		$template->render();
	}

	function get()
	{
		$request = $_REQUEST;
		$columns = array(
			array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'id_pka',  'dt' => 1 ),
			array( 'db' => 'no_kka',  'dt' => 2 ),
			array( 'db' => 'tgl_kka',  'dt' => 3 ),
			array( 'db' => 'nm_audit',   'dt' => 4 ),
			array( 'db' => 'id_sasaran_audit',   'dt' => 5 )
		);

		$join   = "a LEFT JOIN (SELECT autono AS kd_pka, no_pka FROM tpka) AS b ON a.id_pka = b.kd_pka";
		$model  = $this->loadModel($this->model);
		$result = $model->mget($request, $this->table, $this->primaryKey, $columns, $join);

		return json_encode($result);
	}

	function gets_pka()
    {
		$id    = $_REQUEST['id_pka'];
		$model = $this->loadModel($this->model);
		$data  = $model->mget_pka($id);
        echo json_encode($data);
    }

    function gets_personel()
    {
		$id    = $_REQUEST['id_sprin'];
		$model = $this->loadModel($this->model);
		$data  = $model->mget_personel($id);
        echo json_encode($data);
    }

	function load_Fpdf($x)
	{
		$model   = $this->loadModel('kka_model');
		$pdf     = $this->loadLibrary('fpdf');
		$id      = $this->base64url_decode($x);
		$valkka  = $model->load_kka($id);
		$valPers = $model->load_personel($this->table, $this->primaryKey, $id);
		$expldF  = explode('<li>', $valkka['fakta']);		
		$expldK  = explode('<li>', $valkka['kriteria']);
		$expldSe = explode('<li>', $valkka['sebab']);
		$expldSa = explode('<li>', $valkka['saran']);
		
		// ** Surat Dinas **
			$alphabet = range('a', 'z');
			$pdf->SetMargins(36,9); // Format A4
			$pdf->AddPage('P', 'A4');

			// Kop Surat
			$pdf->SetFont('Arial', '', 10);
			$pdf->Cell(80, 5, 'INSPEKTORAT JENDERAL ANGKATAN DARAT', 0, 1, 'C');
			$pdf->Cell(84, 2, 'TIM CURRENT AUDIT', 0, 1, 'C');
			$pdf->Line(38, 24, 115, 24);
			$pdf->Ln(8);

			// Title
			$pdf->Cell(153, 5, 'KERTAS KERJA AUDIT', 0, 1, 'C');
			$pdf->Ln(8);

			// Content
			// Nama Audit
			$pdf->Cell(25, 0, 'Nama Audit', 0, 0, 'L');
			$pdf->Cell(3, 0, ':', 0, 0, 'L');
			$pdf->MultiCell(40, 0, $valkka['nm_audit'], 0, 'J');
			// Nomor KKA
			$pdf->SetX(-154); $pdf->Cell(0, 0, 'No. KKA', 0, 0,'C');
			$pdf->SetX(-79); $pdf->Cell(5, 0, ':', 0, 0, 'L');
			$pdf->SetX(-76); $pdf->MultiCell(60, 0, $valkka['no_kka'], 0, 'J');
			$pdf->Ln(4);
			// Sasaran Audit
			$pdf->Cell(25, 5, 'Sasaran Audit', 0, 0, 'L');
			$pdf->Cell(3, 5, ':', 0, 0, 'L');
			$pdf->MultiCell(40, 5, $valkka['sasaran_audit'], 0, 'J');
			// Disusun Oleh
			$pdf->SetX(-103); $pdf->Cell(0, -5, 'Disusun Oleh', 0, 0, 'L');
			$pdf->SetX(-81); $pdf->Cell(5, -5, ':', 0, 0, 'R');
			$pdf->SetX(-76); $pdf->MultiCell(50, -5, ucwords(strtolower($valPers['nm_pangkat'])).' '.ucwords(strtolower($valPers['nm_korps'])).' '.ucwords(strtolower($valPers['nama'])), 0, 'J');
			$pdf->Ln(4);
			// Periode
			$pdf->Cell(25, 10, 'Periode Audit', 0, 0, 'L');
			$pdf->Cell(3, 10, ':', 0, 0, 'L');
			$pdf->MultiCell(40, 10, $valkka['periode'], 0, 'J');
			// Direviu Oleh
			$pdf->SetX(-103); $pdf->Cell(0, -10, 'Direviu Oleh', 0, 0, 'L');
			$pdf->SetX(-81); $pdf->Cell(5, -10, ':', 0, 0, 'R');
			$pdf->SetX(-76); $pdf->MultiCell(60, -10, 'Kolonel Cba M. Budi Utomo, S.I.P', 0, 'J');
			$pdf->ln(4);
			// Paraf
			$pdf->SetX(-103); $pdf->Cell(0, 15, 'Paraf', 0, 0, 'L');
			$pdf->SetX(-79); $pdf->Cell(5, 15, ':', 0, 0, 'L');
			$pdf->SetX(-76); $pdf->MultiCell(60, 15, '', 0, 'J');
			$pdf->ln(4);
			// Tanggal
			$pdf->SetX(-103); $pdf->Cell(0, -10, 'Tanggal', 0, 0, 'L');
			$pdf->SetX(-79); $pdf->Cell(5, -10, ':', 0, 0, 'L');
			$pdf->SetX(-76); $pdf->MultiCell(60, -10, $valkka['day'].' '.$pdf->getMonth($valkka['month']).' '.$valkka['year'], 0, 'J');	
			$pdf->ln(15);
			// Potensi
			$pdf->SetFont('Arial', 'B', 10);
			$pdf->Cell(50, 5, '1.   Potensi Permasalahan.', 0, 'LTR', 'L');
			$pdf->SetFont('Arial', '', 10);
			$pdf->SetX(42); $pdf->MultiCell(125, 5, '                                        '.strip_tags(preg_replace('/<p[^>]*>/', '', $valkka['potensi'])), 'J');
			$pdf->ln(5);
			// Fakta
			$pdf->SetFont('Arial', 'B', 10);
			$pdf->Cell(50, 5, '2.   Fakta yang ditemukan', 0, 'LTR', 'L');
			$pdf->SetFont('Arial', '', 10);
			$pdf->ln(7);
			for ($i=1; $i < count($expldF); $i++){
		   		$pdf->SetX(-168); $pdf->MultiCell(125, 5, $alphabet[$i - 1].'.     '.str_replace(array('</li>','</ol>'), "\r\n", $expldF[$i]), 'J');
		   		$pdf->Cell(50, 0, '', 0, 1, 'L');
			}
			$pdf->ln(0);
			// Kriteria
			$pdf->SetFont('Arial', 'B', 10);
			$pdf->Cell(50, 5, '3.   Kriteria', 0, 'LTR', 'L');
			$pdf->SetFont('Arial', '', 10);
			$pdf->ln(7);
			for ($i=1; $i < count($expldK); $i++){
		   		$expldK[$i] = str_replace('&nbsp;', '', $expldK[$i]);
		   		$pdf->SetX(-168); $pdf->MultiCell(125, 5, $alphabet[$i - 1].'.     '.str_replace(array('</li>','</ol>',), "\r\n", $expldK[$i]), 'J');
		   		$pdf->Cell(50, 0, '', 0, 1, 'L');
			}
			// Sebab
			$pdf->SetFont('Arial', 'B', 10);
			$pdf->Cell(50, 5, '4.   Sebab', 0, 'LTR', 'L');
			$pdf->SetFont('Arial', '', 10);
			$pdf->ln(7);
			for ($i=1; $i < count($expldSe); $i++){
		   		$pdf->SetX(-168); $pdf->MultiCell(125, 5, $alphabet[$i - 1].'.     '.str_replace(array('</li>','</ol>'), "\r\n", $expldSe[$i]), 'J');
		   		$pdf->Cell(50, 0, '', 0, 1, 'L');
			}
			// Akibat
			$pdf->SetFont('Arial', 'B', 10);
			$pdf->Cell(50, 5, '5.   Akibat', 0, 'LTR', 'L');
			$pdf->SetFont('Arial', '', 10);
			$pdf->SetX(42); $pdf->MultiCell(125, 5, '            '.strip_tags(preg_replace('/<p[^>]*>/', '', $valkka['akibat'])), 'J');
			$pdf->ln(5);
			// Saran
			$pdf->SetFont('Arial', 'B', 10);
			$pdf->Cell(50, 5, '6.   Saran', 0, 'LTR', 'L');
			$pdf->SetFont('Arial', '', 10);
			$pdf->ln(7);
			for ($i=1; $i < count($expldSa); $i++){
		   		$pdf->SetX(-168); $pdf->MultiCell(125, 5, $alphabet[$i - 1].'.     '.str_replace(array('</li>','</ol>'), "\r\n", $expldSa[$i]), 'J');
		   		$pdf->Cell(50, 0, '', 0, 1, 'L');
			}
			// Catatan:
			$pdf->SetFont('Arial', 'B', 10);
			$pdf->Cell(50, 5, '7.   Catatan:', 0, 'LTR', 'L');
			$pdf->SetFont('Arial', '', 10);
			$pdf->SetX(42); $pdf->MultiCell(125, 5, '     '.strip_tags(preg_replace('/<p[^>]*>/', '     ', $valkka['catatan'])), 'J');
			$pdf->ln(5);
			// Sumber:
			$pdf->SetFont('Arial', 'B', 10);
			$pdf->Cell(50, 5, '8.   Sumber data', 0, 'LTR', 'L');
			$pdf->SetFont('Arial', '', 10);
			$pdf->ln(8);
			$pdf->SetX(42); $pdf->MultiCell(115, 5, '-    '.strip_tags(preg_replace('/<p[^>]*>/', ' ', $valkka['sumber'])), 'J');

			$pdf->ln(5);
			$pdf->Cell(237, 10, 'Jakarta, '.$valkka['day'].' '.$pdf->getMonth($valkka['month']).' '.$valkka['year'], 0, 1, 'C');
			$pdf->Cell(237, -2, 'Auditor/Pemeriksa,', 0, 1, 'C');
			$pdf->ln(15);
			$pdf->Cell(237, 5, ucwords(strtolower($valPers['nama'])), 0, 1, 'C');
			$pdf->Cell(237, 5, ucwords(strtolower($valPers['nm_pangkat'])).' '.ucwords(strtolower($valPers['nm_korps'])).' NRP '.$valPers['nrp'], 0, 1, 'C');
			
		$pdf->Output();
		
	}

}