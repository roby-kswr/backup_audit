<?php

class Main extends Controller {

	public function __construct()
    {
        $session = $this->loadHelper('Session_helper');

        if(!$session->get('username')){

        	$this->redirect('auth/login');

        }
    }
	
	function index()
	{
		$model               = $this->loadModel('Dashboard_model');
		$data                = array();
		$data['breadcrumb1'] = 'Dashboard';
		$data['title']       = 'Main';
		$template            = $this->loadView('dashboard_view');
		$template->set('data', $data);
		$template->render();
	}

    
}

?>
