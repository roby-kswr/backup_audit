<?php



class Suboutput extends Controller {



private $table      = "tsuboutput";

private $primaryKey = "autono";

private $model      = "Suboutput_model"; # please write with no space

private $menu       = "Reference";

private $title      = "Sub Output";

private $curl       = BASE_URL."suboutput/";





public function __construct()

    {

        $session = $this->loadHelper('Session_helper');

        if(!$session->get('username')){

        $this->redirect('auth/login');

        }

    }



function index()

{

$data                = array();

$data['breadcrumb1'] = $this->menu;

$data['title']       = $this->title;

$data['curl']        = $this->curl;

$template            = $this->loadView('suboutput_view');

$template->set('data', $data);

$template->render();

}



function get()

{

$request = $_REQUEST;

$columns = array(

array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),

            array( 'db' => 'tahun_anggaran', 'dt'       => 1 ),
            array( 'db' => 'nm_uo',          'dt'       => 2 ),
            array( 'db' => 'nm_program',     'dt'       => 3 ),
            array( 'db' => 'nm_kegiatan',    'dt'       => 4 ),
            array( 'db' => 'nm_output',       'dt'       => 5 ),
            array( 'db' => 'kd_subout',      'dt'       => 6 ),
            array( 'db' => 'nm_subout',      'dt'       => 7 )

);
$model   = $this->loadModel($this->model);
$result  = $model->mget($request, $this->table, $this->primaryKey, $columns);
return json_encode($result);

}



public function add()

{

$model               = $this->loadModel($this->model);

$data                = array();

$data['breadcrumb1'] = $this->menu;

$data['title']       = $this->title;

$data['action']      = 'Add';

$data['curl'] = $this->curl;
        $data['id_uo']       = $model->uo();
        $data['id_program']  = $model->program();
        $data['id_kegiatan'] = $model->kegiatan();
        $data['id_output']   = $model->output();
$template            = $this->loadView('suboutput_add');

$template->set('data', $data);

$template->render();

}



public function edit($x)

{

$id                  = $this->base64url_decode($x);

$model               = $this->loadModel($this->model);

$data                = array();

$data['breadcrumb1'] = $this->menu;

$data['title']       = $this->title;

$data['action']      = 'Edit';

$data['encode']      = $x;

$data['curl'] = $this->curl;

$data['aadata']      = $model->get($this->table, $this->primaryKey, $id);

$data['id_uo']       = $model->uo();
        $data['id_program']  = $model->program();
        $data['id_kegiatan'] = $model->kegiatan();
        $data['id_output']   = $model->output();

$template            = $this->loadView('suboutput_edit');

$template->set('data', $data);

$template->render();

}



public function save()



{
$data                 = array();
$model                = $this->loadModel($this->model);
$data['parent_id']    = $this->base64url_decode($x) ;

        $data['tahun_anggaran']        = htmlspecialchars($_REQUEST['tahun_anggaran']) ;
        $data['id_uo']        = htmlspecialchars($_REQUEST['id_uo']) ;
        $data['id_program']   = htmlspecialchars($_REQUEST['id_program']) ;
        $data['id_kegiatan']  = htmlspecialchars($_REQUEST['id_kegiatan']) ;
        $data['id_output']    = htmlspecialchars($_REQUEST['id_output']) ;
        $data['kd_subout']    = htmlspecialchars($_REQUEST['kd_subout']) ;
        $data['nm_subout']    = htmlspecialchars($_REQUEST['nm_subout']) ;

$data['autocode']     = $model->autocode($this->table, "SubO_");
$result               = $model->msave($this->table, $data, $this->title);
        $this->redirect('suboutput');

}



public function update($x)

{

$data           = array();

$id             = $this->base64url_decode($x);

$model          = $this->loadModel($this->model);

$data['tahun_anggaran']        = htmlspecialchars($_REQUEST['tahun_anggaran']) ;
$data['id_uo']        = htmlspecialchars($_REQUEST['id_uo']) ;
        $data['id_program']   = htmlspecialchars($_REQUEST['id_program']) ;
        $data['id_kegiatan']  = htmlspecialchars($_REQUEST['id_kegiatan']) ;
        $data['id_output']    = htmlspecialchars($_REQUEST['id_output']) ;
$data['kd_subout']    = htmlspecialchars($_REQUEST['kd_subout']) ;
        $data['nm_subout']    = htmlspecialchars($_REQUEST['nm_subout']) ;

$result         = $model->mupdate($this->table, $data, $this->primaryKey, $id, $this->title);

$this->redirect('suboutput');

}



public function delete($x)

{

$id     = $this->base64url_decode($x);

$model  = $this->loadModel($this->model);

$result = $model->mdelete($this->table, $this->primaryKey, $id, $this->title);

return $result;

}



}