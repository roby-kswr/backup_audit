<?php

class Rab_post extends Controller {

	private $table      = "rab_post";
	private $primaryKey = "autono";
	private $model      = "Rab_post_model"; # please write with no space
	private $menu       = "Ekstrak Data";
	private $title      = "RAB - Post";
	private $curl       = BASE_URL."rab_post/";
	private $curl2      = BASE_URL."rab_post";
	

	public function __construct()
    {
        $session = $this->loadHelper('Session_helper');
        if(!$session->get('username')){
        	$this->redirect('auth/login');
        }
    }

	function index()
	{
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['curl']		 = $this->curl;
		$data['curl2']		 = $this->curl2;
		$template            = $this->loadView('rab_post_view');
		$template->set('data', $data);
		$template->render();
	}

	function get($x = null)
	{
		$request = $_REQUEST;
		$columns = array(
			array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'tor',  'dt' => 1 ),
			array( 'db' => 'no_rab',  'dt' => 2 ),
			array( 'db' => 'tahun',  'dt' => 3 ),
			array( 'db' => 'file_name',   'dt' => 4 ),
			array( 'db' => 'autocode',   'dt' => 5 ),
			array( 'db' => 'sum_score',   'dt' => 6 )

			
			
		);

		$model   = $this->loadModel($this->model);
		if($x){
			$result  = $model->mget_detail($request, $this->table, $this->primaryKey, $columns, $id);
		} else {
			$result  = $model->mget($request, $this->table, $this->primaryKey, $columns);
		}

		return json_encode($result);
	}

	public function add()
	{
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Add';
		$data['curl']		 = $this->curl;
        $data['tor']		 = $model->tor_post();
		$template            = $this->loadView('rab_post_add');
		$template->set('data', $data);
		$template->render();
	}

	public function edit($x)
	{
		$id                  = $this->base64url_decode($x);
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Edit';
		$data['encode']      = $x;
		$data['curl']		 = $this->curl;
		$data['aadata']      = $model->get($this->table, $this->primaryKey, $id);
		$data['tor']   	     = $model->tor_post();
		$template            = $this->loadView('rab_post_edit');
		$template->set('data', $data);
		$template->render();
	}

	public function save()

	{


		$data                 = array();

		$model                = $this->loadModel($this->model);

		$data['parent_id']    = $this->base64url_decode($x) ;

		$data['tor']          = htmlspecialchars($_REQUEST['tor']) ;

		$data['no_rab']       = htmlspecialchars($_REQUEST['no_rab']) ; 

		$data['tahun']        = htmlspecialchars($_REQUEST['tahun']) ;

		$data['file_name']    = $_FILES['file_name']['name'] ;

		$data['autocode']    = $model->autocode($this->table, "rabpost_");			

		$result              = $model->msave($this->table, $data, $this->title);

		$last_id             = $result['id'];

		$uploadDyn			 = $model->uploadRabpos($_FILES['file_name'],$data['tor'],$data['tahun'],$data['autocode']);

		$import_span		 = $model->import_rab_post($data['tor'],$data['tahun'],$data['autocode'],$last_id);
		// echo $import_span;  


         $this->redirect('rab_post_detail/detail/'.$data['tor'].'/'.$data['autocode']);
        // $this->redirect('rab_post');
	}

	// public function update($x)
	// {
	// 	$data           	= array();
	// 	$id             	= $this->base64url_decode($x);
	// 	$model          	= $this->loadModel($this->model);
	// 	$data['tor']        = htmlspecialchars($_REQUEST['tor']) ;
	// 	$data['tahun']      = htmlspecialchars($_REQUEST['tahun']) ;
		
	// 	if ($_FILES['file_name']['name']!='')
	// 	{ $data['file_name']        = $_FILES['file_name']['name'] ; 
	// 	 $uploadDyn			 = $model->uploadTor_update($_FILES['file_name'],$parent_id,$tahun,$bulan,'rab_post');
	// 		}

	// 	$import_span		 = $model->import_rab_post($data['tor'],$data['tahun']);
	// 	// echo $import_span;  
 
	// 	$data['autocode']    = $model->autocode($this->table, "rabpost_");	


	// 	$result         	= $model->mupdate($this->table, $data, $this->primaryKey, $id, $this->title);
	// 	$this->redirect('rab_post');
	// }

	

	public function delete($x)
	{
		$id     = $this->base64url_decode($x);
		$model  = $this->loadModel($this->model);
		$result = $model->mdelete($this->table, $this->primaryKey, $id, $this->title);
		return $result;
	}

}