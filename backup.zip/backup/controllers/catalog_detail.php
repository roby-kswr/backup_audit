<?php

class Catalog_detail extends Controller {

	private $table       = "vt_upload_catalog";
	private $primaryKey  = "autono";
	private $primaryKey2 = "tahun";	
	private $primaryKey3 = "autocode";
	private $model       = "Catalog_detail_model";
	private $menu        = "Detail";
	private $title       = "Ekstrak Catalog";
	private $curl        = BASE_URL."catalog_detail";
	

	public function __construct()
    {
        $session = $this->loadHelper('Session_helper');
        if(!$session->get('username')){
        	$this->redirect('auth/login');
        }
    }
	
	function index()
	{
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['curl']	     = $this->curl;
		$template            = $this->loadView('catalog_detail_view');
		$template->set('data', $data);
		$template->render();
	}

	public function detail($x,$y)
	{
		$uri = $this->loadHelper('Url_helper');
		$data                    = array();
		$data['tahun']		 	 = $uri->segment(2);
		$data['autocode']		 = $uri->segment(3);
		$data['breadcrumb1']     = $this->menu;
		$data['title']           = $this->title;
		$data['curl']	         = $this->curl;
		$data['encode']          = $x;
		$data['tahun']       = $x;
		$data['autocode']        = $y;
		$template                = $this->loadView('catalog_detail_view');
		$template->set('data', $data);
		$template->render();
	}

	function get($x = null, $y = null)
	{
		$request      = $_REQUEST;
		//$id         = $this->base64url_decode($x);
		$columns = array(
			array( 'db' => 'autono',      'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'tahun',   'dt' => 1 ),			
			array( 'db' => 'no_urut',     'dt' => 2 ),
			array( 'db' => 'keterangan',  'dt' => 3 ),
			array( 'db' => 'satuan',      'dt' => 4 ),
			array( 'db' => 'harga',       'dt' => 5 )



		);

		$model   = $this->loadModel($this->model);
		if($x){
			$result  = $model->mget_detail($request, $this->table,$x,$y, $columns, $x);
		} else {
			$result  = $model->mget($request, $this->table, $this->primaryKey, $columns);
		}

		return json_encode($result);
	}

	    
}