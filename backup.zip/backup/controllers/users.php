<?php

class Users extends Controller {

	private $table      = "tuser";
	private $primaryKey = "autono";
	private $model      = "Users_model"; # please write with no space
	private $menu       = "Reference";
	private $title      = "Users";
	private $curl       = BASE_URL."users/";
	

	public function __construct()
    {
        $session = $this->loadHelper('Session_helper');
        if(!$session->get('username')){
        	$this->redirect('auth/login');
        }
    }
	
	function index()
	{
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['curl']		 = $this->curl;
		$template            = $this->loadView('users_view');
		$template->set('data', $data);
		$template->render();
	}

	function get()
	{
		$request    = $_REQUEST;
		$columns = array(
			array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'user_id',  'dt' => 1 ),
			array( 'db' => 'user_fullname',   'dt' => 2 ),
			array( 'db' => 'jabatanVal',   'dt' => 3 ),
			array( 'db' => 'user_grupVal',   'dt' => 4 )
		);

		$model   = $this->loadModel($this->model);
		$result  = $model->mget($request, $this->table, $this->primaryKey, $columns);

		return json_encode($result);
	}

	public function add()
	{
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Add';
		$data['curl']		 = $this->curl;
		$data['groups']      = $model->query("SELECT autono, group_name FROM tusergroup");
		$data['position']    = $model->query("SELECT autono, nama_jabatan FROM torganizationstructure");
		$template            = $this->loadView('users_add');
		$template->set('data', $data);
		$template->render();
	}

	public function edit($x)
	{
		$id                  = $this->base64url_decode($x);
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Edit';
		$data['encode']      = $x;
		$data['curl']		 = $this->curl;
		$data['groups']      = $model->query("SELECT autono, group_name FROM tusergroup");
		$data['position']    = $model->query("SELECT autono, nama_jabatan FROM torganizationstructure");
		$data['aadata']      = $model->get($this->table, $this->primaryKey, $id);
		$template            = $this->loadView('users_edit');
		$template->set('data', $data);
		$template->render();
	}

	public function save()
	{
		global $config;

		$data                  = array();
		$model                 = $this->loadModel($this->model);
		$data['user_id']       = htmlspecialchars($_REQUEST['user_id']) ;
		$data['user_fullname'] = htmlspecialchars($_REQUEST['user_fullname']) ;
		$data['jabatan']       = htmlspecialchars($_REQUEST['position']) ;
		$data['user_grup']     = htmlspecialchars($_REQUEST['user_grup']) ;
		$data['user_password'] = sha1(md5(htmlspecialchars($_REQUEST['user_password']).$config['key'])) ;
		$data['jabatanVal']    = $model->getval('torganizationstructure', 'nama_jabatan', 'autono', $data['jabatan']) ;
		$data['user_grupVal']  = $model->getval('tusergroup', 'group_name', 'autono', $data['user_grup']);
		$data['tempat_lahir']  = htmlspecialchars($_REQUEST['tempat_lahir']) ;
		$data['tgl_lahir']     = htmlspecialchars($_REQUEST['tgl_lahir']) ;
		$result                = $model->msave($this->table, $data, $this->title);
		$this->redirect('users');
	}

	public function update($x)
	{
		global $config;

		$data                  = array();
		$id                    = $this->base64url_decode($x);
		$model                 = $this->loadModel($this->model);
		$data['user_id']       = htmlspecialchars($_REQUEST['user_id']) ;
		$data['user_fullname'] = htmlspecialchars($_REQUEST['user_fullname']) ;
		$data['jabatan']       = htmlspecialchars($_REQUEST['position']) ;
		$data['user_grup']     = htmlspecialchars($_REQUEST['user_grup']) ;
		$data['user_password'] = sha1(md5(htmlspecialchars($_REQUEST['user_password']).$config['key'])) ;
		$data['jabatanVal']    = $model->getval('torganizationstructure', 'nama_jabatan', 'autono', $data['jabatan']) ;
		$data['user_grupVal']  = $model->getval('tusergroup', 'group_name', 'autono', $data['user_grup']) ;
		$data['tempat_lahir']  = htmlspecialchars($_REQUEST['tempat_lahir']) ;
		$data['tgl_lahir']     = htmlspecialchars($_REQUEST['tgl_lahir']) ;
		
		$result                = $model->mupdate($this->table, $data, $this->primaryKey, $id, $this->title);
		$this->redirect('users');
	}

	public function delete($x)
	{
		$id                 = $this->base64url_decode($x);
		$model              = $this->loadModel($this->model);
		$result             = $model->mdelete($this->table, $this->primaryKey, $id, $this->title);
		return $result;
	}
    
}