<?php

class Manajemen_dipa extends Controller {

	private $table      = "dja_pagu";
	private $primaryKey = "id";
	private $model      = "Manajemen_dipa_model"; # please write with no space
	private $menu       = "Manajemen Data";
	private $title      = "DIPA";
	private $curl       = BASE_URL."manajemen_dipa/";
	

	public function __construct()
    {
        $session = $this->loadHelper('Session_helper');
        if(!$session->get('username')){
        	$this->redirect('auth/login');
        }
    }

	function index()
	{
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['curl']		 = $this->curl;
		$template            = $this->loadView('manajemen_dipa_view');
		$template->set('data', $data);
		$template->render();
	}

	function get()
	{
		$request = $_REQUEST;
		$columns = array(
			array( 'db' => 'id', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'thang',  'dt' => 1 ),
			array( 'db' => 'kddept',  'dt' => 2 ),
			array( 'db' => 'kdunit',   'dt' => 3 ),
			array( 'db' => 'nmsatker',  'dt' => 4 ),
			array( 'db' => 'kdfungsi',  'dt' => 5 ),
			array( 'db' => 'kdsfung',   'dt' => 6 ),
			array( 'db' => 'kdprogram',  'dt' => 7 ),
			array( 'db' => 'kdgiat',  'dt' => 8 ),
			array( 'db' => 'kdoutput',  'dt' => 9 ),
			array( 'db' => 'kdsoutput',   'dt' => 10 ),
			array( 'db' => 'kdkmpnen',  'dt' => 11 ),
			array( 'db' => 'kdskmpnen',  'dt' => 12 ),
			array( 'db' => 'kdjenbel',   'dt' => 13 ),
			array( 'db' => 'kdakun',  'dt' => 14 ),
			array( 'db' => 'jml_pagu',  'dt' => 15, 'formatter' => function( $d, $row ) { return number_format($d, 2); } ),
			array( 'db' => 'urskmpnen',  'dt' => 16),
			array( 'db' => 'wasgiat',  'dt' => 17)

			//array( 'db' => 'JML12',  'dt' => 8, 'formatter' => function( $d, $row ) { return number_format($d, 2); } ),
		);

		$model   = $this->loadModel($this->model);
		$result  = $model->mget($request, $this->table, $this->primaryKey, $columns);

		return json_encode($result);
	}

	public function add()
	{
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Add';
		$data['curl']		 = $this->curl;
        $data['satker']		 = $model->satker();
		$template            = $this->loadView('manajemen_dipa_add');
		$template->set('data', $data);
		$template->render();
	}

	public function edit($x)
	{
		$id                  = $this->base64url_decode($x);
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Edit';
		$data['encode']      = $x;
		$data['curl']		 = $this->curl;
		$data['aadata']      = $model->get($this->table, $this->primaryKey, $id);
		$data['satker']   	 = $model->satker();
		$template            = $this->loadView('manajemen_dipa_edit');
		$template->set('data', $data);
		$template->render();
	}

	public function save()

	{
		$model          	     = $this->loadModel($this->model);
		# Insert files
		$files1					 = array();
		$files1['dir'] 			 = "zip";
		$files1['kode_parent'] 	= "FED01";
		$files1['subdir'] 		 = "";
		if(!empty($_FILES['file_dipa']['name'][0])) {
		    $file_ary1 = $model->reArrayFiles($_FILES['file_fedlog']);
		    foreach ($file_ary1 as $file1) {
				$files1['kode_parent'] = $data['autocode'];
				$files1['parent_id']   = $lastid;
				$files1['nama_file']   = $this->randName($file1['name']);
				$files1['tipe_file']   = $file1['type'];
				$files1['ukuran']      = $file1['size'];
				$files1['ftable']      = $this->table;

				if(!empty($file1['name'])){ $model->savefile($files1); } 
		    }
		}
		# Upload file
		if(isset($_FILES['file_fedlog'])){ $model->uploads($files1['dir'], $_FILES['file_fedlog'], $files1['kode_parent'], $files1['subdir']); }

		$zip         = new ZipArchive;
		$dir         = ROOT_DIR.'static/files/'.$files1['dir'].'/'.$files1['kode_parent'].'/';
		$filename    = $files1['nama_file'];
		$storagname  = $dir.$filename;
		if ($zip->open($dir.$filename) === TRUE) {
		    $zip->extractTo($dir);
		    $zip->close();
		    $this->redirect('manajemen_fedlog/fedlogtrees');
		} else {
		    echo 'failed';
		}
        
        
	}

	public function fedlogtree()
	{
		$data                = array();
		$data['direktori']   = scandir(ROOT_DIR."static/files/zip/FEDLOG/");
		$data['breadcrumb1'] = 'Extrak Data';
		$data['title']       = 'Fedlog';
		$template            = $this->loadView('manajemen_fedlog_tree');
		$template->set('data', $data);
		$template->render();
		
	}

	public function fedlogtrees()
	{
		$data                = array();
		$data['curl']        = $this->curl;
		$data['breadcrumb1'] = 'Extrak Data';
		$data['title']       = 'Fedlog';
		$template            = $this->loadView('manajemen_fedlog_json');
		$template->set('data', $data);
		$template->render();
		
	}

	function human_filesize($bytes, $decimals = 2) {
      $sz = 'BKMGTP';
      $factor = floor((strlen($bytes) - 1) / 3);
      return sprintf("%.{$decimals}f", $bytes / pow(1024, $factor)) . @$sz[$factor];
    }


	public function jsontree()
	{
		$data            = array();
		$dt['direktori'] = scandir(ROOT_DIR."static/files/zip/FEDLOG/");
		$data['title']   = array();

		foreach ($dt['direktori'] as $key => $value) {
			$ds['key']       = (int) substr($value,4,1);
			$ds['expanded']  = true;
			$ds['parent_id'] = 0;
			$ds['selected']  = false;
			$ds['folder']    = true;
			$ds['title']     = $value;
			$ds['tooltip']   = $value;;
			$ds['children']  = array();
          if(substr($value, 0, 4) == "DISC"){
            $storagename = ROOT_DIR.'static/files/zip/FEDLOG/'.$value;
            $subdir = scandir($storagename);
            $dt = array();
	        foreach ($subdir as $key => $sub) {
				$ukuran =  filesize($storagename.'/'.$sub);
				$size   = $this->human_filesize($ukuran);
				$tab    = explode(".", $sub);
	        	if($tab[1] == 'TAB'){
					$dt['key']       = $tab[0];
					$dt['expanded']  = true;
					$dt['folder']    = false;
					$dt['parent_id'] = (int) substr($value,4,1);
					$dt['selected']  = false;
					$dt['title']     = $sub;
					$dt['tooltip']   = $sub;
					$dt['filesize']  = $size;
					$dt['dir']       = $value;

					if(file_exists($storagename.'/'.$tab[0].'.txt')){
						$dt['exstatus']       = '<a href="'.BASE_URL.strtolower($tab[0]).'" class="btn btn-success btn-sx"><i class="icon-database2 position-left"></i> View</a>';
					} else {
						$dt['exstatus']       = '<span class="label bg-warning-400">Not Extracted</span>';
					}

					array_push($ds['children'], $dt);
	        	} 
	        }     

	        $branch[] = $ds;

          }
        }

        return json_encode($branch);
		
	}

	public function extracttextperline()
	{
		$model       = $this->loadModel($this->model);
		$datas       = $_REQUEST['arrdata'];
		$j           = count($datas);
		$storagename = ROOT_DIR."static/files/zip/FEDLOG/";	

		for ($i=0; $i < $j; $i++) { 
			$storagefile        = $storagename.$datas[$i]['data']['dir'].'/'.$datas[$i]['key'].'.txt';
			$data['group_id']   = $group_id;
			$data['group_name'] = $group_name;
			$data['menu_id']    = $this->base64url_decode($datas[$i]['key']);
			if($datas[$i]['selected'] == true){
				
				$result = exec('decomp '.$storagename.$datas[$i]['data']['dir'].' "SELECT * FROM '.$datas[$i]['key'].'" '.$storagefile); 

				if(file_exists($storagefile)){		
					$open   = fopen($storagefile,'r');
					$field  = fgets($open);
					$column = explode('|', str_replace('\r\n', '', $field));

 					for ($r=0; $r < count($column); $r++) { 
 						$es[$r] = $model->escapeString($column[$r]);
 						$arrcolname[] = str_replace('\r\n', "", $es[$r]);
 					}

 					$fieldname = '`'.implode("`, `", $arrcolname).'`';
 					$j = count($column);



					// #Create table
							$tableName     = $datas[$i]['key'];
							$db['db_name'] = "satudata_eaudit";
							$drop          = $model->execute("DROP TABLE IF EXISTS ".$db['db_name'].".`$tableName`;");
							$tableCreate   = "CREATE TABLE `$tableName` (".PHP_EOL;

							for ($t=0; $t < $j ; $t++) { 
								if($t == ($j - 1)){
									$separator = "";
								} else {
									$separator = ",";
								}
								$tableCreate .= "`".trim($column[$t])."` varchar(255) DEFAULT NULL".$separator.PHP_EOL;
							}

							$tableCreate .= ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";
							$rtbel       = $model->execute($tableCreate);


					while (!feof($open)) 
					{
						$getDataList = fgets($open);

						if($getDataList){
							$explodeData = explode('|',$getDataList);			
							$k = count($column);

							for ($n=0; $n < count($explodeData) ; $n++) { 
								$arrdt[$n] = "'".$model->escapeString($explodeData[$n])."'"; 
							}
							
						    $qry = $model->execute("INSERT INTO ".$datas[$i]['key'] ." (". $fieldname .") VALUES (".(implode(", ", $arrdt)).");");
						}
						
					}


				}
				
			} 
			
			
		}

		return json_encode($qry);
	}

	public function doextract()
	{
		$model       = $this->loadModel($this->model);
		$datas       = $_REQUEST['arrdata'];
		$j           = count($datas);
		$storagename = ROOT_DIR."static/files/zip/FEDLOG/";	

		for ($i=0; $i < $j; $i++) { 
			$storagefile        = $storagename.$datas[$i]['data']['dir'].'/'.$datas[$i]['key'].'.txt';
			$data['group_id']   = $group_id;
			$data['group_name'] = $group_name;
			$data['menu_id']    = $this->base64url_decode($datas[$i]['key']);
			if($datas[$i]['selected'] == true){
				
				$result = exec('decomp '.$storagename.$datas[$i]['data']['dir'].' "SELECT * FROM '.$datas[$i]['key'].'" '.$storagefile); 

				if(file_exists($storagefile)){		
					$open   = fopen($storagefile,'r');
					$field  = fgets($open);
					$column = explode('|', str_replace('\r\n', '', $field));

 					for ($r=0; $r < count($column); $r++) { 
 						$es[$r] = $model->escapeString($column[$r]);
 						$arrcolname[] = str_replace('\r\n', "", $es[$r]);
 					}

 					$fieldname = '`'.implode("`, `", $arrcolname).'`';
 					$j = count($column);

 					// #Gen Crud
 					// Start generate controller

 					$file_name          = strtolower($datas[$i]['key']);
					$controller_script  = $model->tempscript('controller'); 
					$controller_dir     = APP_DIR."controllers/";
					$controller         = fopen($controller_dir.$file_name.".php", "w") or die("Unable to open file controller!");
					$controller_content = $controller_script;
					$controller_content = str_replace("#class#", ucfirst($file_name), $controller_content);
					$controller_content = str_replace("#primary#", $arrcolname[0], $controller_content);
					$controller_content = str_replace("#table#", $file_name, $controller_content);
					$controller_content = str_replace("#model#", ucfirst($file_name), $controller_content);
					$controller_content = str_replace("#menu#", "FEDLOG", $controller_content);
					$controller_content = str_replace("#title#", $datas[$i]['key'], $controller_content);
					$controller_content = str_replace("#url#", $file_name, $controller_content);
					//$jcol               = count($column);

					$arrcol = '';
					$arrcolumns = '';
					$headerview = '';
					$dataview = '';
					$dataadd = '';
					$dataedit = '';

					$i = 0;
					foreach ($arrcolname as $key => $col) {
						$arrcol .= "array( 'db' => '".$col."',  'dt' => ".$i++." ),";
						$arrcolumns .= "\t\t".'$data['."'".$col."'".'] = htmlspecialchars($_REQUEST['."'".$col."'".']) ;'."\n";
						$headerview .= "\t\t\t\t\t\t\t\t\t"."<th class=\"text-center\">".ucfirst(str_replace('_', ' ', $col))."</th>"."\n";
						$dataview .= "\t\t\t\t\t\t"."{".'"data"'.": ".($i-1).",width:'auto'},"."\n";
						
					}
					// $headerview .= "\t\t\t\t\t\t\t\t\t"."<th class=\"text-center\">Actions</th>"."\n";
					
					$controller_content = str_replace("#columns_table#", $arrcol, $controller_content);
					$controller_content = str_replace("#columns#", $arrcolumns, $controller_content);
					
					fwrite($controller, $controller_content);
					fclose($controller);


					// Start generate model
					$models_script  = $model->tempscript('model'); 
					$models_dir     = APP_DIR."models/";
					$models         = fopen($models_dir.$file_name."_model.php", "w") or die("Unable to open file model!");
					$models_content = $models_script;
					$models_content = str_replace("#class#", ucfirst($file_name), $models_content);
					fwrite($models, $models_content);
					fclose($models);

					// Start generate view
					$view_script  = $model->tempscript('view'); 
					$view_dir     = APP_DIR."views/";
					$view         = fopen($view_dir.$file_name."_view.php", "w") or die("Unable to open file view!");
					$view_content = $view_script;
					$view_content = str_replace("#headerview#", $headerview, $view_content);
					$view_content = str_replace("#dataview#", $dataview, $view_content);

					fwrite($view, $view_content);
					fclose($view);


					// #Create table
							$tableName     = $datas[$i]['key'];
							$db['db_name'] = "satudata_eaudit";
							$drop          = $model->execute("DROP TABLE IF EXISTS ".$db['db_name'].".`$tableName`;");
							$tableCreate   = "CREATE TABLE `$tableName` (".PHP_EOL;

							for ($t=0; $t < $j ; $t++) { 
								if($t == ($j - 1)){
									$separator = "";
								} else {
									$separator = ",";
								}
								$tableCreate .= "`".trim($column[$t])."` varchar(255) DEFAULT NULL".$separator.PHP_EOL;
							}

							$tableCreate .= ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";
							$rtbel       = $model->execute($tableCreate);


					if($rtbel){

						$sto = str_replace("\\", "/", $storagefile);
						$qry = $model->execute("LOAD DATA INFILE '".$sto."' 
												INTO TABLE ".$datas[$i]['key']."
												FIELDS TERMINATED BY '|' 
												IGNORE 1 LINES");
					}


				}
				
			} 
			
			
		}

		return json_encode($qry);
	}

	public function update($x)
	{
		$data           	= array();
		$id             	= $this->base64url_decode($x);
		$model          	= $this->loadModel($this->model);
		$data['satker']     = htmlspecialchars($_REQUEST['satker']) ;
		$data['tahun']      = htmlspecialchars($_REQUEST['tahun']) ;
		$data['file_name']	= htmlspecialchars($_REQUEST['file_name']) ;
		$result         	= $model->mupdate($this->table, $data, $this->primaryKey, $id, $this->title);
		$this->redirect('manajemen_feed');
	}

	public function delete($x)
	{
		$id     = $this->base64url_decode($x);
		$model  = $this->loadModel($this->model);
		$result = $model->mdelete($this->table, $this->primaryKey, $id, $this->title);
		return $result;
	}

}