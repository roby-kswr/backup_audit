<?php

class Tjahp extends Controller {

	private $table      = "tahp";
	private $tableJwb	= "jahp";
	private $tableTemb  = "vt_jahp";
	private $primaryKey = "autono";
	private $model      = "Tjahp_model"; # please write with no space
	private $menu       = "Transaksi";
	private $title      = "TJ-AHP";
	private $curl       = BASE_URL."tjahp";
	

	public function __construct()
	{
		$session = $this->loadHelper('Session_helper');
		if(!$session->get('username')){
			$this->redirect('auth/login');
		}
	}
	
	public function index()
	{
		$id                  = $this->base64url_decode($x);
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['curl']	     = $this->curl;
		$template            = $this->loadView('tjahp_view');
		$template->set('data', $data);
		$template->render();
	}

	public function detail($x)

	{

		$id                  = $this->base64url_decode($x);

		$model               = $this->loadModel($this->model);

		$uri                 = $this->loadHelper('Url_helper');

		$data                = array();

		$data['breadcrumb1'] = $this->menu;

		$data['title']       = $this->title;

		$data['action']      = 'Edit';

		$data['encode']      = $x;

		$data['curl']	     = $this->curl;

		$data['autono']		 = $uri->segment(4);

		// $data['autono']	     = $id;

		// $data['child']       = $uri->segment(5);

		$data['aadata']      = $model->get($this->table, $this->primaryKey, $id);

		$data['attch']       = $model->get_file_attachment($data['autono']);

		$template            = $this->loadView('tj_ahp_detail');

		$data['aadata']      = $model->getvalue("SELECT total,jawaban,data_dukung_j FROM vt_jahp AS a
			LEFT JOIN(SELECT MAX(autono) AS total FROM vt_jahp WHERE id_ahp = '$data[autono]') AS t1 ON t1.total = a.`autono`
			GROUP BY autono DESC LIMIT 1");

		// $data['stat']		 = $model->query("SELECT * FROM t_nhv_status ORDER BY autono DESC"); 

		$template->set('data', $data);

		$template->render();

	}

	function get()
	{
		$request = $_REQUEST;
		$columns = array(
			array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'nomor',  'dt' => 1 ),
			array( 'db' => 'jawaban',   'dt' => 2 ),
			array( 'db' => 'status_jawaban',   'dt' => 3 ),
			array('db' =>'tanggapan_jawaban', 'dt'=> 4),
			array('db' =>'autono_j', 'dt'=> 5),


		);

		$join = "a LEFT JOIN(SELECT b.autono AS autono_j, b.id_ahp AS kd_ahp, b.jawaban AS jawaban,b.status_jawaban AS status_jawaban,b.tanggapan_jawaban AS tanggapan_jawaban 
		FROM vt_jahp b LEFT JOIN(SELECT MAX(autono) AS autono FROM vt_jahp GROUP BY id_ahp) AS t1 ON b.autono = t1.autono 
		WHERE t1.autono IS NOT NULL ) b ON b.kd_ahp = a.autono";
		$model  = $this->loadModel($this->model);
		$result = $model->mget($request, $this->table, $this->primaryKey, $columns, $join);

		return json_encode($result);
	}

	public function add()
	{
		$model                    = $this->loadModel($this->model);
		$data                     = array();
		$data['breadcrumb1']      = $this->menu;
		$data['title']            = $this->title;
		$data['action']           = 'Add';
		$data['curl']             = $this->curl;		
		$data['no_sprin']         = $model->get_sprin();
		// $data['id_jns_audit']     = $model->get_jenisAudit();
		$data['id_kotama']        = $model->get_kotama();
		$data['id_tembusan']      = $model->get_tembusan();
		$template                 = $this->loadView('jahp_add');
		$template->set('data', $data);
		$template->render();
	}

	public function edit($x)

	{

		$id                  = $this->base64url_decode($x);

		$model               = $this->loadModel($this->model);

		$uri                 = $this->loadHelper('Url_helper');

		$data                = array();

		$data['breadcrumb1'] = $this->menu;

		$data['title']       = $this->title;

		$data['action']      = 'Edit';

		$data['encode']      = $x;

		$data['curl']	     = $this->curl;

		$data['autono']		 = $uri->segment(4);

		// $data['child']       = $uri->segment(5);

		$data['aadata']      = $model->get($this->table, $this->primaryKey, $id);

		$template            = $this->loadView('tj_ahp_edit');

		$data['aadata']      = $model->getvalue("SELECT * FROM vt_jahp WHERE autono = '$data[autono]'");

		$data['stat']		 = $model->query("SELECT * FROM t_nhv_status WHERE autono !='5' ORDER BY autono DESC"); 

		$template->set('data', $data);

		$template->render();

	}

	public function analisa($x)
	{
		$id                       = $this->base64url_decode($x);
		$model                    = $this->loadModel($this->model);
		$data                     = array();
		$data['breadcrumb1']      = $this->menu;
		$data['title']            = $this->title;
		$data['action']           = 'Edit';
		$data['encode']           = $x;
		$data['curl']             = $this->curl;
		$data['temuan']      	  = $model->get_temuanEdit($this->tableJwb, 'kd_ahp', $id);
		$data['aadata']           = $model->get($this->table, $this->primaryKey, $id);
		$template                 = $this->loadView('jahp_detail_edit');
		$template->set('data', $data);
		$template->render();
	}

	public function save()
	{
		$data                 = array();
		$temb                 = array();
		$model                = $this->loadModel($this->model);
		$data['klasifikasi']  = htmlspecialchars($_REQUEST['klasifikasi']) ;
		$data['nomor']        = htmlspecialchars($_REQUEST['nomor']) ;
		$data['lampiran']     = htmlspecialchars($_REQUEST['lampiran']) ;
		$data['perihal']      = htmlspecialchars($_REQUEST['perihal']) ;
		$data['menimbang']    = $model->escapeString($_REQUEST['menimbang']) ;
		$data['dasar']        = $model->escapeString($_REQUEST['dasar']) ;
		$data['kepada']       = $model->escapeString($_REQUEST['kepada']) ;
		$data['untuk']        = $model->escapeString($_REQUEST['untuk']) ;
		$data['kesatuan']     = htmlspecialchars($_REQUEST['kesatuan']) ;
		$date                 = str_replace('/', '-', $_REQUEST['tgl_sprin']);
		$data['tgl_sprin']    = date("Y-m-d",strtotime($date)) ;
		$data['no_sprin']     = htmlspecialchars($_REQUEST['no_sprin']) ;
		$data['kinerja']      = htmlspecialchars($_REQUEST['kinerja']) ;
		$data['fakta']        = htmlspecialchars($_REQUEST['fakta']) ;
		$data['kriteria']     = $model->escapeString($_REQUEST['kriteria']) ;
		$data['sebab']        = $model->escapeString($_REQUEST['sebab']) ;
		$data['akibat']       = $model->escapeString($_REQUEST['akibat']) ;
		$data['rekomendasi']  = $model->escapeString($_REQUEST['rekomendasi']) ;
		$data['autocode']     = $model->autocode($this->table, "AHP_");
		$result               = $model->msave($this->table, $data, $this->title);
		$last_id              = $result['id'];
		$jmlCmbTemb           = count($_REQUEST['temb']);

		for ($i=0; $i < $jmlCmbTemb ; $i++) { 
			$temb['autocode']    = $model->autocode($this->tableTemb, "SPTEMB_");
			$temb['id_ahp']    = $last_id;
			$temb['id_tembusan'] = htmlspecialchars($_REQUEST['temb'][$i]);
			$tembresult          = $model->msave($this->tableTemb, $temb, $this->title);
		}

		$this->redirect('jahp');
	}

	public function update($x)
	{
		$data               = array();

		$id                 = $this->base64url_decode($x);

		$model              = $this->loadModel($this->model);

		$uri                = $this->loadHelper('Url_helper');

		// $child              = $uri->segment(5);

		$autono  			 = $uri->segment(4);

		$autono 			 = $id;

		$data['id_ahp'] = $autono ;

		$data['tanggapan_jawaban'] = htmlspecialchars($_REQUEST['tanggapan']) ;


		$data['status_jawaban'] = htmlspecialchars($_REQUEST['status']) ;


		$result  = $model->msave($this->tableTemb, $data,  $this->primaryKey, $id,  $this->title);


		$this->redirect('tjahp');
	}

	public function saveJawaban($x)
	{
		// $uri 				  = $this->loadHelper('Url_helper');
		// $data['jwb']  		  = $uri->segment(4);
		// $data['jwb']		  = $y; 
		$data                 = array();
		$id                   = $this->base64url_decode($x);
		$model                = $this->loadModel($this->model);
		// $getJmlTemb           = 1;
		$data['kd_ahp']       = htmlspecialchars($_REQUEST['autono']) ;
		$data['no_ahp']       = htmlspecialchars($_REQUEST['no_ahp']) ;
		$data['jawaban']      = htmlspecialchars($_REQUEST['temuan']) ;
		$data['keterangan']   = $model->escapeString($_REQUEST['keterangan']) ;
		$result               = $model->msave($this->tableJwb, $data, $this->title);

		$this->redirect('jahp');
	}

	public function updateJawaban($x)
	{
		// $uri 				  = $this->loadHelper('Url_helper');
		// $data['jwb']  		  = $uri->segment(4);
		// $data['jwb']		  = $y; 
		$data                 = array();
		$id                   = $this->base64url_decode($x);
		$model                = $this->loadModel($this->model);
		// $getJmlTemb           = 1;
		$data['kd_ahp']       = htmlspecialchars($_REQUEST['autono']) ;
		$data['no_ahp']       = htmlspecialchars($_REQUEST['no_ahp']) ;
		$data['jawaban']      = htmlspecialchars($_REQUEST['temuan']) ;
		$data['keterangan']   = $model->escapeString($_REQUEST['keterangan']) ;
		$result               = $model->mupdate($this->tableJwb, $data, 'kd_ahp', $id, $this->title);

		$this->redirect('jahp');
	}

	public function delete($x)
	{
		$id         = $this->base64url_decode($x);
		$model      = $this->loadModel($this->model);
		$result     = $model->mdelete($this->table, $this->primaryKey, $id, $this->title);
		$resultTemb = $model->mdelete($this->tableTemb, 'id_ahp', $id, $this->title);
		return $result;
	}

	function load_Fpdf($x)
	{
		$model   = $this->loadModel('sprin_model');
		$pdf     = $this->loadLibrary('fpdf');
		$id      = $this->base64url_decode($x);
		$val     = $model->getvalue("SELECT * FROM tihp AS a 
			LEFT JOIN tihpsatker AS b ON b.id_ihp = a.autono
			LEFT JOIN tkotama AS c ON c.autono = b.id_kotama 
			WHERE a.autono = $id");
		$expldF  = explode('<li>', $val['fakta']);
		$expldJ  = explode('<li>', $val['kriteria']);
		$expldP  = explode('<li>', $val['dasar']);
		$expldKet = explode('<li>', $val['konten']);
		$expldTe = explode('<li>', $val['temuan']);	



		// ** Surat Dinas **
			$pdf->SetMargins(25.4,20.3,15.2,12.7); // Format A4
			$pdf->AddPage('P', 'A4');

			// Kop Surat
			$pdf->SetFont('Arial', '', 10);
			$pdf->Cell(70, 5, 'MARKAS BESAR ANGKATAN DARAT', 0, 1, 'C');
			$pdf->Cell(70, 2, 'INSPEKTORAT JENDRAL', 0, 1, 'C');
			$pdf->Cell(70,2,'','B',1);
			$pdf->SetX(145); $pdf->Cell(0,0,'Jakarta, 16 September 2020',0,0,'L');
			$pdf->Ln(8);

			// Title
			// $pdf->Cell(153, 5, 'KERTAS KERJA AUDIT', 0, 1, 'C');
			// $pdf->Ln(8);
			// Content
			$pdf->Cell(25, 5, 'Nomor', 0, 0, 'L');
			$pdf->Cell(3, 5, ':', 0, 0, 'L');
			$pdf->MultiCell(40, 5, $val['no_ihp'], 0, 'J');
			// Sasaran Audit
			$pdf->Cell(25, 5, 'Klasifikasi', 0, 0, 'L');
			$pdf->Cell(3, 5, ':', 0, 0, 'L');
			$pdf->MultiCell(40, 5, $val['klasifikasi'], 0, 'J');
			// Periode
			$pdf->Cell(25, 5, 'Lampiran', 0, 0, 'L');
			$pdf->Cell(3, 5, ':', 0, 0, 'L');
			$pdf->MultiCell(40, 5, $val['lampiran'], 0, 'J');
			// Perihal
			$pdf->Cell(25, 5, 'Perihal', 0, 0, 'L');
			$pdf->Cell(3, 5, ':', 0, 0, 'L');
			$pdf->MultiCell(80, 5, $val['perihal'], 0, 'J');
			$pdf->Cell(80,0,'','B',1);
			// Paraf
			$pdf->SetX(155); $pdf->Cell(0, 10, 'Kepada', 0, 0, 'L');
			$pdf->SetX(-60); $pdf->Cell(5, 25, 'Yth. Aspam Kasad', 0, 0, 'L');
			$pdf->SetX(-50); $pdf->Cell(5, 35, 'di', 0, 0, 'L');
			$pdf->SetX(-55); $pdf->Cell(5, 45, 'Jakarta', 0, 0, 'L');
			$pdf->SetX(-70); $pdf->MultiCell(5, 30, '', 0, 'J');
			$pdf->ln(5);
			// Potensi
			$pdf->SetFont('Arial', '', 10);
			$pdf->Cell(50, 5, '1.   Dasar', 0, 'LTR', 'L');
			$pdf->ln(5);
			for ($i=1; $i < count($expldP); $i++){
				$pdf->SetX(-168); $pdf->MultiCell(140, 5, $i.'.     '.str_replace(array('</li>','</ol>','<br>'), "\r\n", $expldP[$i]), 'C');
				$pdf->Cell(50, 0, '', 0, 1, 'L');
			}	
			// Fakta
			$pdf->SetFont('Arial', '', 10);
			$pdf->Cell(50, 5, '2.   ', 0, 'LTR', 'L');
			$pdf->SetX(-170); $pdf->MultiCell(130, 5, strip_tags(preg_replace('/<p[^>]*>/','',$val['temuan'])),'J');
			$pdf->ln(2);
			// Diharapkan
			$pdf->SetFont('Arial', '', 10);
			$pdf->MultiCell(150, 5, '3. Diharapkan jawaban/tanggapan Pangdam I/BB sebagai tindak lanjut atas Atensi ini, diterima Irjenad  dalam waktu 15 (lima belas) hari setelah Atensi ini diterima Pangdam I/BB, dengan dilengkapi/dilampiri bukti administrasi tindak lanjut saran AHP.', 0, 'J');
			$pdf->MultiCell(140, 5, strip_tags(preg_replace('/<p[^>]*>/', '   ', $val['sebab'])), 'J');
			$pdf->ln(2);
			// Sumber:
			$pdf->SetFont('Arial', '', 10);
			$pdf->MultiCell(150, 5, '4. Agar Pangdam I/BB pada saat mengirimkan jawaban/tanggapan AHP, supaya disertakan Copy File dalam bentuk Compact Disk (CD).', 0, 'J');
			$pdf->MultiCell(140, 5, strip_tags(preg_replace('/<p[^>]*>/', '    ', $val['akibat'])), 'J');
			$pdf->ln(2);

			// Demikian:
			$pdf->SetFont('Arial', '', 10);
			$pdf->Cell(50, 5, '5. Demikian untuk dimaklumi.', 0, 'LTR', 'L');
			$pdf->MultiCell(140, 5, strip_tags(preg_replace('/<p[^>]*>/', '    ', $val['akibat'])), 'J');
			$pdf->ln(2);

			$pdf->Cell(237, 3, 'a.n. Inspektur Jenderal Angaktan Darat', 0, 1, 'C');
			$pdf->Cell(237, 3, 'Inspektur Umum,', 0, 1, 'C');
			$pdf->ln(15);
			$pdf->Cell(237, 3, 'Darmono Susastro, S.I.P.', 0, 1, 'C');
			$pdf->Cell(237, 5, 'Brigadir Jenderal TNI', 0, 1, 'C');
			$pdf->Cell(50, 3, 'Tembusan :', 0, 1, 'L');
			$pdf->Cell(50, 5, '1. Irjenad', 0, 1, 'L');
			$pdf->Cell(50, 5, '2. Irben Itjenad', 0, 1, 'L');
			$pdf->Cell(50,0,'','B',1);

			$pdf->AddPage();
			$pdf->Cell(150,0, 'Lampiran Surat Irjenad',0,1,'R');
			$pdf->SetFont('Arial','B',10);
			$pdf->Cell(70, 5, 'MARKAS BESAR ANGKATAN DARAT', 0, 1, 'C');
			$pdf->SetFont('Arial','',10);
			$pdf->Cell(150,0, 'Nomor R/IHP/ /III/2020',0,1,'R');
			$pdf->SetFont('Arial','B',10);
			$pdf->Cell(70, 2, 'INSPEKTORAT JENDRAL', 0, 1, 'C');
			$pdf->SetFont('Arial','',10);
			$pdf->Cell(150,4, 'Tanggal 23 Maret 2020',0,1,'R');
			$pdf->Cell(70,0,'','B',1);
			$pdf->SetX(-75); $pdf->Cell(40,0,'','B',1);
			$pdf->Ln(10);

			$pdf->SetFont('Arial','B',10);
			$pdf->MultiCell(150,5,'ATENSI HASIL PENGAWASAN',0,'C');
			$pdf->Ln(0);
			$pdf->SetFont('Arial','',10);
			$pdf->Cell(50,5,'KESATUAN',0,0,'L');
			$pdf->MultiCell(80,5, ': KODAM I/BB',0,'J');
			$pdf->Cell(50,5,'TANGGAL PENGAWASAN',0,0,'L');
			$pdf->MultiCell(80,5, ': 8 S.D. 20 FEBRUARI 2019',0,'J');
			$pdf->Cell(50,5,'SPRIN IRJENAD NOMOR',0,0,'L');
			$pdf->MultiCell(80,5, ': SPRIN/57/II/2019 TANGGAL 1 FEBRUARI 2019',0,'J');
			$pdf->Ln(10);

			$pdf->SetFont('Arial','B',10);
			$pdf->Cell(5,5,'I.',0,0,'L');
			$pdf->MultiCell(50,5, 'KINERJA',0,'J');
			$pdf->Ln(5);
			$pdf->SetFont('Arial','B',10);
			if($val['id_temuan'] == 1){
				$pdf->Cell(0,0,'   	   A.  Tidak Efektif.',0,0,'L');
				$pdf->ln(8);	

				$pdf->Cell(40,5,'a.	Puspenerbad.',0,0,'R');
				$pdf->SetFont('Arial','',10);
				$pdf->MultiCell(110,5, strip_tags(preg_replace('/<p[^>]*>/', '    ', $val['konten'])),0,'J');
				$pdf->ln(5);
				$pdf->Cell(30,5,'1)',0,0,'C');
				$pdf->Cell(30,5,'Fakta.',0,0,'L');
				$pdf->ln(5);	
				for ($i=1; $i < count($expldF); $i++){
					$pdf->SetX(-155); $pdf->MultiCell(120, 5, $i.'.     '.str_replace(array('</li>','</ol>','<br>'), "\r\n", $expldF[$i]), 'C');
					$pdf->Cell(50, 0, '', 0, 1, 'L');
				}	
				$pdf->Cell(30,5,'2)',0,0,'C');
				$pdf->Cell(40,5,'Kriteria.',0,0,'L');
				$pdf->ln(5);
				for ($i=1; $i < count($expldJ); $i++){
					$pdf->SetX(-155); $pdf->MultiCell(120, 5, $i.'.     '.str_replace(array('</li>','</ol>','<br>'), "\r\n", $expldJ[$i]), 'C');
					$pdf->Cell(50, 0, '', 0, 1, 'L');
				}	

				
			}else{
				$pdf->ln(5);
				$pdf->Cell(0,0,'   	   A.  Tidak Efisien. Nihil.',0,0,'L');
			}

			$pdf->ln(5);

			if($val['id_temuan'] == 2){
				$pdf->Cell(0,0,'   	   B.  Tidak Efisien.',0,0,'L');
				$pdf->ln(8);	
				$pdf->Cell(40,5,'a.	Puspenerbad.',0,0,'R');
				$pdf->SetFont('Arial','',10);
				$pdf->MultiCell(110,5, strip_tags(preg_replace('/<p[^>]*>/', '    ', $val['konten'])),0,'J');
				$pdf->ln(5);
				$pdf->Cell(30,5,'1)',0,0,'C');
				$pdf->Cell(30,5,'Fakta.',0,0,'L');
				$pdf->ln(5);	
				for ($i=1; $i < count($expldF); $i++){
					$pdf->SetX(-155); $pdf->MultiCell(120, 5, $i.'.     '.str_replace(array('</li>','</ol>','<br>'), "\r\n", $expldF[$i]), 'C');
					$pdf->Cell(50, 0, '', 0, 1, 'L');
				}	
				$pdf->Cell(30,5,'2)',0,0,'C');
				$pdf->Cell(40,5,'Kriteria.',0,0,'L');
				$pdf->ln(5);
				for ($i=1; $i < count($expldJ); $i++){
					$pdf->SetX(-155); $pdf->MultiCell(120, 5, $i.'.     '.str_replace(array('</li>','</ol>','<br>'), "\r\n", $expldJ[$i]), 'C');
					$pdf->Cell(50, 0, '', 0, 1, 'L');
				}	

			}else{
				$pdf->ln(5);
				$pdf->Cell(0,0,'   	   B.  Tidak Efisien. Nihil.',0,0,'L');
			}

			$pdf->ln(5);

			if($val['id_temuan'] == 3){
				$pdf->Cell(0,0,'   	   C.  Tidak Ekonomis.',0,0,'L');
				$pdf->ln(8);	
				$pdf->Cell(40,5,'a.	Puspenerbad.',0,0,'R');
				$pdf->SetFont('Arial','',10);
				$pdf->MultiCell(110,5, strip_tags(preg_replace('/<p[^>]*>/', '    ', $val['konten'])),0,'J');
				$pdf->ln(5);
				$pdf->Cell(30,5,'1)',0,0,'C');
				$pdf->Cell(30,5,'Fakta.',0,0,'L');
				$pdf->ln(5);	
				for ($i=1; $i < count($expldF); $i++){
					$pdf->SetX(-155); $pdf->MultiCell(120, 5, $i.'.     '.str_replace(array('</li>','</ol>','<br>'), "\r\n", $expldF[$i]), 'C');
					$pdf->Cell(50, 0, '', 0, 1, 'L');
				}	
				$pdf->Cell(30,5,'2)',0,0,'C');
				$pdf->Cell(40,5,'Kriteria.',0,0,'L');
				$pdf->ln(5);
				for ($i=1; $i < count($expldJ); $i++){
					$pdf->SetX(-155); $pdf->MultiCell(120, 5, $i.'.     '.str_replace(array('</li>','</ol>','<br>'), "\r\n", $expldJ[$i]), 'C');
					$pdf->Cell(50, 0, '', 0, 1, 'L');
				}	

			}else{
				$pdf->ln(5);
				$pdf->Cell(0,0,'   	   C.  Tidak Ekonomis. Nihil.',0,0,'L');
			}

			$pdf->ln(5);
			if($val['id_temuan'] == 4){
				$pdf->Cell(0,0,'   	   D.  Ketidaktaatan/Ketidakpatuhan terhadap aturan.',0,0,'L');
				$pdf->ln(8);	
				$pdf->Cell(50,5,'a. '.$val['nm_kotama'],0,0,'R');
				$pdf->SetFont('Arial','',10);
				$pdf->MultiCell(100,5, strip_tags(preg_replace('/<p[^>]*>/', '    ', $val['konten'])),0,'J');
				$pdf->ln(5);
				$pdf->Cell(30,5,'1)',0,0,'C');
				$pdf->Cell(30,5,'Fakta.',0,0,'L');
				$pdf->ln(5);	
				for ($i=1; $i < count($expldF); $i++){
					$pdf->SetX(-155); $pdf->MultiCell(120, 5, $i.'.     '.str_replace(array('</li>','</ol>','<br>'), "\r\n", $expldF[$i]), 'C');
					$pdf->Cell(50, 0, '', 0, 1, 'L');
				}	
				$pdf->Cell(30,5,'2)',0,0,'C');
				$pdf->Cell(40,5,'Kriteria.',0,0,'L');
				$pdf->ln(5);
				for ($i=1; $i < count($expldJ); $i++){
					$pdf->SetX(-155); $pdf->MultiCell(120, 5, $i.'.     '.str_replace(array('</li>','</ol>','<br>'), "\r\n", $expldJ[$i]), 'C');
					$pdf->Cell(50, 0, '', 0, 1, 'L');
				}	

			}else{
				$pdf->ln(8);
				$pdf->Cell(0,0,'   	   D.  Ketidaktaatan/Ketidakpatuhan terhadap aturan. Nihil.',0,0,'L');
			}
			
			$pdf->Output();

		}

	}