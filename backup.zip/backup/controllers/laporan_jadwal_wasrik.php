<?php
/**
 * 
 */
class Laporan_jadwal_wasrik extends Controller
{
	private $table      = "tpkpt_detil";
	private $tablePk    = "tpkpt";
	private $tableSat   = "tpkptsat";
	private $primaryKey = "autono";
	private $model      = "laporan_jadwal_wasrik_model";
	private $menu       = "Transaksi";
	private $title      = "Laporan Jadwal Wasrik";
	private $curl       = BASE_URL."laporan_jadwal_wasrik";	


    public function __construct()
	{
		$session = $this->loadHelper('Session_helper');
		if(!$session->get('username')){
			$this->redirect('auth/login');
		}
	}

	public function index()
	{
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['curl']	       = $this->curl;
    $data['tahun']       = $model->getTahun();
    $data['ttd']         = $model->ttd();
		$template            = $this->loadView('laporan_jadwal_wasrik_view');
		$template->set('data', $data);
		$template->render();
	}

	 function getBulan($bln){

        $val = explode("-", $bln);
                switch ($val[1]){
                    case 1: 
                        return "Januari";
                        break;
                    case 2:
                        return "Febuari";
                        break;
                    case 3:
                        return "Maret";
                        break;
                    case 4:
                        return "April";
                        break;
                    case 5:
                        return "Mei";
                        break;
                    case 6:
                        return "Juni";
                        break;
                    case 7:
                        return "Juli";
                        break;
                    case 8:
                        return "Agustus";
                        break;
                    case 9:
                        return "September";
                        break;
                    case 10:
                        return "Oktober";
                        break;
                    case 11:
                        return "November";
                        break;
                    case 12:
                        return "Desember";
                        break;
                }


            } 

  function pecah($x)
  {
    $s = explode('-', $x);
    return $s[1];
  }

  function get($tahun,$audit)

  {

    $request    = $_REQUEST;

    $id          = 'PKPT-'.$tahun;
    $wheres      = $audit;

  //   $hlp               = $this->loadHelper('Url_helper');
    $columns = array(

      array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
      array( 'db' => 'start',  'dt' => 4, 'formatter' => function( $d, $row ) { return $this->getBulan($d); } ),
      array( 'db' => 'aut',  'dt' => 1 ),
      array( 'db' => 'id_kotama',  'dt' => 2 ),
      array( 'db' => 'nm_kotama',  'dt' => 3 ),
      array( 'db' => 'title', 'dt'=> 5 ),
      array( 'db' => 'tgl_mulai', 'dt'=> 6 ),
      array( 'db' => 'tgl_selesai', 'dt'=> 7 ),
      array( 'db' => 'no_sprin', 'dt'=> 8 ),
       array( 'db' => 'start', 'dt' => 9, 'formatter' => function( $d, $row ) { return $this->pecah($d); } )


    );
    $model   = $this->loadModel($this->model);
    $join   = "a LEFT JOIN (SELECT id_pkpt AS pkt, autono AS aut, id_jns_audit  FROM tpkpt_detil) AS b  ON a.id_pkpt = b.aut
               LEFT JOIN (SELECT nm_kotama, kd_kotama FROM tkotama ) AS c ON a.id_kotama = c.kd_kotama 
               LEFT JOIN (SELECT autono AS au, id_pkpt, no_sprin, IF(tgl_mulai IS NULL, '00-00-0000', DATE_FORMAT(tgl_mulai,'%d-%m-%Y')) AS tgl_mulai, IF(tgl_selesai IS NULL, '00-00-0000', DATE_FORMAT(tgl_selesai,'%d-%m-%Y')) AS tgl_selesai FROM tsprin ) AS d ON d.id_pkpt = b.pkt";
    
    $result  = $model->mget($request, 'tpkptsat', $this->primaryKey, $columns, $id ,$wheres, $join);



    return json_encode($result);

  }

  function print()
     {
        $pdf = $this->loadLibrary('fpdf');

        $tahun = 'PKPT-'.$_REQUEST['filtertahun'];
        $audit = $_REQUEST['filteraudit'];

        $exp = explode('-', $tahun);
        $ss = $exp[1];
        // membuat halaman baru
        $pdf->AddPage('L','A4');
        // setting jenis font yang akan digunakan
        $pdf->setX(23);

        $pdf->Image(ROOT_DIR.'static/images/mabesad.png',18,10,18);
        
        // Arial bold 12
       $pdf->Ln(1);
       $pdf->SetFont('Arial','B',18);
        
        // Geser Ke Kanan 35mm
       $pdf->Cell(95);
        
        // Judul

       $pdf->Cell(80,7,'E-AUDIT TNI AD',0,1,'C');
       $pdf->Cell(95);
       $pdf->SetFont('Arial','B',13);
       $pdf->Cell(80,10,'INSPEKTORAT JENDRAL ANGKATAN DARAT',0,1,'C');
        // Garis Bawah Double
       $pdf->Ln(5);
       $pdf->Cell(2);
       $pdf->Cell(265,0,'','B',1,'L');
       $pdf->Cell(2);
       $pdf->Cell(265,1,'','B',1,'L');
       // $pdf->Cell(260,1,'','B',0,'L');
        
        // Line break 5mm
        $pdf->Ln(3);
        $pdf->SetFont('Arial','B',12);
        $pdf->Cell(40); 
        $pdf->Cell(195,7,'LAPORAN JADWAL '.strtoupper($audit).' WASRIK '.$ss,0,1,'C');
        $pdf->SetFont('Arial','B',12);
        $pdf->Ln(2);
        
        //header
      $pdf->Cell(20, 15, 'NO', 'LRT', 0, 'C');
      $pdf->Cell(70, 15, 'NAMA KOTAMA', 'LRT', 0, 'C');
      $pdf->Cell(35, 15, 'RENCANA', 'LRT', 0, 'C');
      $pdf->Cell(82, 5, 'WAKTU PELAKSANAAN', 'LRTB', 0, 'C');
      $pdf->Cell(60, 15, 'NO SPRIN', 'LRT', 0, 'C');
      // Total Max 880 Kertas A4
      $pdf->Cell(30, 5, '', 0, 0);
      $pdf->Ln();

      // * Baris Kedua
      $pdf->Cell(40, 0, '', 0, 0);
      $pdf->Cell(50, 0, '', 0, 0);
      $pdf->Cell(35, 0, '', 0, 0);
      $pdf->Cell(40, 7, 'TANGGAL MULAI', 'R', 0, 'C');
      $pdf->Cell(42, 7, 'TANGGAL SELESAI', 'L', 0, 'C');
      $pdf->Cell(30, 7, '', 0, 0);
      $pdf->Ln();


      $pdf->SetY(35);
      $pdf->Ln(10);         
      $pdf->SetFont('Arial', '', 10);
      $pdf->SetY(65);
      $pdf->Cell(20, 5, '1', 'LRTB',0,'C');
      $pdf->Cell(70, 5, '2', 'LRTB', 0, 'C');
      $pdf->Cell(35, 5, '3', 'LRTB', 0, 'C');
      $pdf->Cell(40, 5, '4', 'LRTB', 0, 'C');
      $pdf->Cell(42, 5, '5', 'LRTB', 0, 'C');
      $pdf->Cell(60, 5, '6', 'LRTB', 0, 'C');
      $pdf->Cell(30, 7, '', 0, 0);
      $pdf->Ln(5);


        //body

        $pdf->SetFont('Arial', '', 10);
        $pdf->SetWidths(array(20, 70, 35,40,42,60));
        $pdf->SetAligns(array('C', 'C', 'C', 'C','C','C'));

        $model = $this->loadModel($this->model);

        

        $query = $model->query("SELECT autono,aut,id_kotama,nm_kotama,`start`,title,DATE_FORMAT(tgl_mulai, '%d-%m-%Y') AS tgl_mulai,DATE_FORMAT(tgl_selesai, '%d-%m-%Y') AS tgl_selesai,no_sprin FROM tpkptsat a 
                                LEFT JOIN (SELECT id_pkpt AS pkt, autono AS aut, id_jns_audit ,title AS til FROM tpkpt_detil) AS b ON a.id_pkpt = b.aut 
                                LEFT JOIN (SELECT nm_kotama, kd_kotama FROM tkotama ) AS c ON a.id_kotama = c.kd_kotama 
                                LEFT JOIN (SELECT autono AS au, id_pkpt, no_sprin, tgl_mulai,tgl_selesai FROM tsprin ) AS d ON d.id_pkpt = b.pkt 
                                WHERE a.title = '$tahun' AND b.id_jns_audit = '$audit' ORDER BY a.`start` ");

        $no = 1;
        foreach ($query as $row){
          // $pdf->setX(20);
           $pdf->Row(
            array($no++,
            $row['nm_kotama'],
            $this->getBulan($row['start']),
            $row['tgl_mulai'],
            $row['tgl_selesai'],
            $row['no_sprin']            
        ));

        }

        $ttd = $_REQUEST['ttd'];

        if ($ttd != '') {
           $quer = $model->getvalue("SELECT a.nm_personel, a.autono, a.nrp , a.id_jabatan ,b.nm_korps, c.nm_pangkat FROM ttandatangan a 
                                  LEFT JOIN tkorps b    ON a.id_korps = b.kd_korps 
                                  LEFT JOIN  tpangkat c ON a.id_pangkat = c.kd_pangkat WHERE a.autono = '$ttd'");


          $pdf->Ln(5);
          $pdf->CheckPageBreak(60);

          $pdf->Cell(215);
          $pdf->Cell(10,5,$quer['id_jabatan'],0,1,'C');
          // $pdf->Cell(240,5,"Inspektur Khusus",0,1,'R');
          // $pdf->Cell(116,5,"u.b",0,1,'R');
          // $pdf->Cell(120,5,"Kaverku",0,1,'R');
          $pdf->Cell(100 ,10,'',0,1);//end of line
          $pdf->Ln(10);

          $pdf->Cell(215,5,'',0,0);
          $pdf->Cell(15,5,$quer['nm_personel'],0,1,'C');
          $pdf->Cell(215,5,'',0,0);
          $pdf->Cell(16,5,$quer['nm_pangkat']. " ".$quer['nm_korps']." NRP ".$quer['nrp'],0,1,'C');
          $pdf->Ln(1);
        }else{
          echo "";
        }

       

      //   global $totalPageForFooter;
      // if($pdf->PageNo() != $totalPageForFooter){
      //   if($pdf->PageNo() > 1){
      //     $pdf->SetY(25);
      //     $pdf->Ln(10);         
      //     $pdf->SetFont('Arial', '', 10);
      //     $pdf->SetY(25);
      //     $pdf->Cell(20, 6, '1', 'LRTB',0,'C');
      //     $pdf->Cell(70, 6, '2', 'LRTB', 0, 'C');
      //     $pdf->Cell(35, 6, '3', 'LRTB', 0, 'C');
      //     $pdf->Cell(40, 6, '4', 'LRTB', 0, 'C');
      //     $pdf->Cell(42, 6, '5', 'LRTB', 0, 'C');
      //     $pdf->Cell(60, 6, '6', 'LRTB', 0, 'C');
      //     $pdf->Ln(0);
      //   }
      // }





        $pdf->Output();
    }

}								