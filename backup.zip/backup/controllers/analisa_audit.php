<?php

class Analisa_audit extends Controller {

	private $table      = "vt_anaupost";
	private $primaryKey = "autono";
	private $model      = "Analisa_audit_model";
	private $menu       = "Post Audit";
	private $title      = "analisa audit";
	private $curl       = BASE_URL."analisa_audit";
	

	public function __construct()
    {
        $session = $this->loadHelper('Session_helper');
        if(!$session->get('username')){
        	$this->redirect('auth/login');
        }
    }
	
	function index()
	{
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['curl']	     = $this->curl;
		$template            = $this->loadView('analisa_audit_view');
		$template->set('data', $data);
		$template->render();
	}

	public function detail($x)
	{
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['curl']	     = $this->curl;
		$data['encode']      = $x;
		$template            = $this->loadView('analisa_audit_view');
		$template->set('data', $data);
		$template->render();
	}

	function get($x = null)
	{
		$request    = $_REQUEST;
		$id         = $this->base64url_decode($x);
		$columns = array(
			array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'nomor_sprin',  'dt' => 1 ),array( 'db' => 'entitas',  'dt' => 2 ),array( 'db' => 'sasaran',  'dt' => 3 ),array( 'db' => 'tanggal',  'dt' => 4 ),array( 'db' => 'nomor_pka',  'dt' => 5 ),
		);

		$model   = $this->loadModel($this->model);
		if($x){
			$result  = $model->mget_detail($request, $this->table, $this->primaryKey, $columns, $id);
		} else {
			$result  = $model->mget($request, $this->table, $this->primaryKey, $columns);
		}

		return json_encode($result);
	}

	public function add($x = null)
	{
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Add';
		$data['curl']	     = $this->curl;
		$data['encode']	     = $x;
		$template            = $this->loadView('analisa_audit_add');
		$template->set('data', $data);
		$template->render();
	}

	public function edit($x)
	{
		$id                  = $this->base64url_decode($x);
		$model               = $this->loadModel($this->model);
		$uri                 = $this->loadHelper('Url_helper');
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Edit';
		$data['encode']      = $x;
		$data['curl']	     = $this->curl;
		$data['child']       = $uri->segment(5);
		$data['aadata']      = $model->get($this->table, $this->primaryKey, $id);
		$template            = $this->loadView('analisa_audit_edit');
		$template->set('data', $data);
		$template->render();
	}

	public function save($x = null)
	{
		$data                 = array();
		$model                = $this->loadModel($this->model);
		$data['parent_id']    = $this->base64url_decode($x) ;
		$data['nomor_sprin'] = htmlspecialchars($_REQUEST['nomor_sprin']) ;
		$data['entitas'] = htmlspecialchars($_REQUEST['entitas']) ;
		$data['sasaran'] = htmlspecialchars($_REQUEST['sasaran']) ;
		$data['tanggal'] = htmlspecialchars($_REQUEST['tanggal']) ;
		$data['nomor_pka'] = htmlspecialchars($_REQUEST['nomor_pka']) ;

		$data['autocode']     = $model->autocode($this->table, "#autocode#");	
		$result               = $model->msave($this->table, $data, $this->title);
		if($x){
			$this->redirect('analisa_audit/detail/'.$x);
		} else {
			$this->redirect('analisa_audit');
		}
	}

	public function update($x)
	{
		$data               = array();
		$id                 = $this->base64url_decode($x);
		$model              = $this->loadModel($this->model);
		$uri                = $this->loadHelper('Url_helper');
		$child              = $uri->segment(5);
		$data['nomor_sprin'] = htmlspecialchars($_REQUEST['nomor_sprin']) ;
		$data['entitas'] = htmlspecialchars($_REQUEST['entitas']) ;
		$data['sasaran'] = htmlspecialchars($_REQUEST['sasaran']) ;
		$data['tanggal'] = htmlspecialchars($_REQUEST['tanggal']) ;
		$data['nomor_pka'] = htmlspecialchars($_REQUEST['nomor_pka']) ;
	
		$result             = $model->mupdate($this->table, $data, $this->primaryKey, $id, $this->title);
		if($child){
			$this->redirect('analisa_audit/detail/'.$child);
		} else {
			$this->redirect('analisa_audit');
		}
	}

	public function delete($x)
	{
		$id                 = $this->base64url_decode($x);
		$model              = $this->loadModel($this->model);
		$result             = $model->mdelete($this->table, $this->primaryKey, $id, $this->title);
		return $result;
	}
    
}