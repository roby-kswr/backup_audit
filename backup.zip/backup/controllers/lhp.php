<?php

class Lhp extends Controller {

	private $table      = "tlhp";
	private $tableDetil = "tlhpdetil";
	private $primaryKey = "autono";
	private $model      = "Lhp_model"; # please write with no space
	private $menu       = "Transaksi";
	private $title      = "LHP";
	private $curl       = BASE_URL."lhp/";
	
	public function __construct()
    {
        $session = $this->loadHelper('Session_helper');
        if(!$session->get('username')){
        	$this->redirect('auth/login');
        }
    }
	
	function index()
	{
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['curl']		 = $this->curl;
		$template            = $this->loadView('lhp_view');
		$template->set('data', $data);
		$template->render();
	}

	function get()
	{
		$request = $_REQUEST;
		$columns = array(
			array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'no_lhp',  'dt' => 1 ),
			array( 'db' => 'tgl_lhp',  'dt' => 2 ),
			array( 'db' => 'perihal',  'dt' => 3 )
		);

		//$join   = "a LEFT JOIN (SELECT autono AS kd_pka, no_pka FROM tpka) AS b ON a.id_pka = b.kd_pka";
		$model  = $this->loadModel($this->model);
		$result = $model->mget($request, $this->table, $this->primaryKey, $columns, $join);

		return json_encode($result);
	}

	public function add()
	{
		$model                     = $this->loadModel($this->model);
		$data                      = array();
		$data['breadcrumb1']       = $this->menu;
		$data['title']             = $this->title;
		$data['action']            = 'Add';
		$data['curl']              = $this->curl;
		$data['sprin']             = $model->get_sprin();
		$data['klasifikasi_surat'] = $model->get_klasifikasiSurat();
		$data['kka']               = $model->get_kka();
		$data['tembusan']          = $model->get_tembusan();
		$template                  = $this->loadView('lhp_add');
		$template->set('data', $data);
		$template->render();
	}

	public function edit($x)
	{
		$id                  = $this->base64url_decode($x);
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Edit';
		$data['encode']      = $x;
		$data['curl']        = $this->curl;
		$data['aadata']      = $model->get($this->table, $this->primaryKey, $id);
		//$data['pka']         = $model->get_pkaEdit($this->table, $this->primaryKey, $id);
		//$data['personel']    = $model->get_personelEdit();
		$template            = $this->loadView('lhp_edit');
		$template->set('data', $data);
		$template->render();
	}

	public function save()
	{
		$data                         = array();
		$model                        = $this->loadModel($this->model);
		$data['id_sprin']             = ucwords(htmlspecialchars($_REQUEST['id_sprin'])) ;
		$data['no_lhp']               = ucwords(htmlspecialchars($_REQUEST['no_lhp'])) ;
		$date                         = str_replace('/', '-', $_REQUEST['tgl_lhp']);
		$data['tgl_lhp']              = date("Y-m-d",strtotime($date)) ;
		$data['id_klasifikasi_surat'] = ucwords(htmlspecialchars($_REQUEST['klasifikasi_surat'])) ;	
		$data['lampiran']             = ucwords(htmlspecialchars($_REQUEST['lampiran'])) ;
		$data['perihal']              = $model->escapeString($_REQUEST['perihal']) ;
		$data['konten']               = $model->escapeString($_REQUEST['konten']) ;
		$data['autocode']             = $model->autocode($this->table, "LHP_");	
		$result                       = $model->msave($this->table, $data, $this->title);
		$this->redirect('lhp');
	}

	public function update($x)
	{
		$data                         = array();
		$id                           = $this->base64url_decode($x);
		$model                        = $this->loadModel($this->model);
		$data['id_sprin']             = ucwords(htmlspecialchars($_REQUEST['id_sprin'])) ;
		$data['no_lhp']               = ucwords(htmlspecialchars($_REQUEST['no_lhp'])) ;
		$date                         = str_replace('/', '-', $_REQUEST['tgl_lhp']);
		$data['tgl_lhp']              = date("Y-m-d",strtotime($date)) ;
		$data['id_klasifikasi_surat'] = ucwords(htmlspecialchars($_REQUEST['klasifikasi_surat'])) ;	
		$data['lampiran']             = ucwords(htmlspecialchars($_REQUEST['lampiran'])) ;
		$data['perihal']              = $model->escapeString($_REQUEST['perihal']) ;
		$data['konten']               = $model->escapeString($_REQUEST['konten']) ;
		$result                       = $model->mupdate($this->table, $data, $this->primaryKey, $id, $this->title);
		$this->redirect('lhp');
	}

	public function delete($x)
	{
		$id     = $this->base64url_decode($x);
		$model  = $this->loadModel($this->model);
		$result = $model->mdelete($this->table, $this->primaryKey, $id, $this->title);
		return $result;
	}

	public function saveDetil()
	{
		$data   = array();
		$model  = $this->loadModel($this->model);
		$jmlCmb = count($_REQUEST['kka']);

		for ($i=0; $i < $jmlCmb; $i++) { 
			$data['autocode'] = $model->autocode($this->tableDetil, "DLHP_");
			$data['id_lhp']   = $model->get_maxId($this->table);
			$data['id_sprin'] = htmlspecialchars($_REQUEST['sprin']) ;
			$data['id_kka']   = htmlspecialchars($_REQUEST['kka'][$i]);
		}
		
		if($_REQUEST['kka'] != null){
			$result = $model->msave($this->tableDetil, $data, $this->title);
		}
				
		if($result){
			echo 1;
		}else{
			echo 0;
		}
	}

	public function deleteData($x)
	{
		$id       = $this->base64url_decode($x);
		$model    = $this->loadModel($this->model);
		$resultDt = $model->mdelete($this->tableDetil, $this->primaryKey, $id, $this->title);
		return $result;
	}

	function loadData($get_id)
	{
		$request = $_REQUEST;
		$model   = $this->loadModel($this->model);
		$id      = $this->base64url_decode($get_id);
		$last_id = $model->get_maxId($this->table);
		$columns = array(
			array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'no_kka',  'dt' => 1 ),
			array( 'db' => 'tgl_kka',   'dt' => 2 ),
			array( 'db' => 'nm_audit',   'dt' => 3 ),
			array( 'db' => 'sasaran_audit',   'dt' => 4 )
		);
		$join   = "LEFT JOIN (SELECT autono AS kd_kka, no_kka, tgl_kka, nm_audit, sasaran_audit FROM tkka) b ON a.id_kka = b.kd_kka";

		if($id)
		{
			$sWhere = "id_lhp = $id";
		} 
		else 
		{
			$sWhere = "id_lhp = $last_id";
		}
	
		$result  = $model->mgetdetail($request, $this->tableDetil, $this->primaryKey, $columns, $join, $sWhere);

		return json_encode($result);
	}

	function load_Fpdf($x)
	{
		$model   = $this->loadModel('sprin_model');
		$pdf     = $this->loadLibrary('fpdf');
		$id      = $this->base64url_decode($x);
		$val     = $model->getvalue("SELECT * FROM tlhp WHERE autono = $id");
		$expldF  = explode('<li>', $val['fakta']);
		$expldSe = explode('<li>', $val['sebab']);
		$expldSa = explode('<li>', $val['saran']);	
		
		// ** Surat Dinas **
			$pdf->SetMargins(36,9); // Format A4
			$pdf->AddPage('P', 'A4');

			// Kop Surat
			$pdf->SetFont('Arial', '', 10);
			$pdf->Cell(80, 5, 'INSPEKTORAT JENDERAL ANGKATAN DARAT', 0, 1, 'C');
			$pdf->Cell(84, 2, 'TIM CURRENT AUDIT', 0, 1, 'C');
			$pdf->Line(38, 24, 115, 24);
			$pdf->Ln(8);

			// Title
			$pdf->Cell(153, 5, 'KERTAS KERJA AUDIT', 0, 1, 'C');
			$pdf->Ln(8);

			// Content
			$pdf->Cell(25, 0, 'Nama Audit', 0, 0, 'L');
			$pdf->Cell(3, 0, ':', 0, 0, 'L');
			$pdf->MultiCell(40, 0, $val['nm_audit'], 0, 'J');
			// Nomor LHP
			$pdf->SetX(-154); $pdf->Cell(0, 0, 'No. LHP', 0, 0,'C');
			$pdf->SetX(-79); $pdf->Cell(5, 0, ':', 0, 0, 'L');
			$pdf->SetX(-76); $pdf->MultiCell(60, 0, $val['no_kka'], 0, 'J');
			$pdf->Ln(4);
			// Sasaran Audit
			$pdf->Cell(25, 5, 'Sasaran Audit', 0, 0, 'L');
			$pdf->Cell(3, 5, ':', 0, 0, 'L');
			$pdf->MultiCell(40, 5, $val['sasaran_audit'], 0, 'J');
			// Disusun Oleh
			$pdf->SetX(-103); $pdf->Cell(0, -15, 'Disusun Oleh', 0, 0, 'L');
			$pdf->SetX(-81); $pdf->Cell(5, -15, ':', 0, 0, 'R');
			$pdf->SetX(-76); $pdf->MultiCell(60, -15, 'Letkol Cpl Rizky MP.', 0, 'J');
			$pdf->Ln(4);
			// Periode
			$pdf->Cell(25, 30, 'Periode Audit', 0, 0, 'L');
			$pdf->Cell(3, 30, ':', 0, 0, 'L');
			$pdf->MultiCell(40, 30, $val['periode'], 0, 'J');
			// Direviu Oleh
			$pdf->SetX(-103); $pdf->Cell(0, -30, 'Direviu Oleh', 0, 0, 'L');
			$pdf->SetX(-81); $pdf->Cell(5, -30, ':', 0, 0, 'R');
			$pdf->SetX(-76); $pdf->MultiCell(60, -30, 'Kolonel Cba M. Budi Utomo, S.I.P', 0, 'J');
			$pdf->ln(4);
			// Paraf
			$pdf->SetX(-103); $pdf->Cell(0, 35, 'Paraf', 0, 0, 'L');
			$pdf->SetX(-79); $pdf->Cell(5, 35, ':', 0, 0, 'L');
			$pdf->SetX(-76); $pdf->MultiCell(60, 35, '', 0, 'J');
			$pdf->ln(4);
			// Tanggal
			$pdf->SetX(-103); $pdf->Cell(0, -30, 'Tanggal', 0, 0, 'L');
			$pdf->SetX(-79); $pdf->Cell(5, -30, ':', 0, 0, 'L');
			$pdf->SetX(-76); $pdf->MultiCell(60, -30, '19 November 2019', 0, 'J');	
			$pdf->ln(25);
			// Potensi
			$pdf->SetFont('Arial', 'B', 10);
			$pdf->Cell(50, 5, '1.   Potensi Permasalahan', 0, 'LTR', 'L');
			$pdf->SetFont('Arial', '', 10);
			$pdf->MultiCell(115, 5, strip_tags(preg_replace('/<p[^>]*>/', ' ', $val['potensi'])), 'J');		
			$pdf->ln(5);
			// Fakta
			$pdf->SetFont('Arial', 'B', 10);
			$pdf->Cell(50, 5, '2.   Fakta yang ditemukan', 0, 'LTR', 'L');
			$pdf->SetFont('Arial', '', 10);
			$pdf->ln(8);
			for ($i=1; $i < count($expldF); $i++){
		   		$pdf->SetX(-168); $pdf->MultiCell(125, 5, $i.'.     '.str_replace(array('</li>','</ol>'), "\r\n", $expldF[$i]), 'J');
		   		$pdf->Cell(50, 0, '', 0, 1, 'L');
			}
			$pdf->ln(0);
			// Kriteria
			$pdf->SetFont('Arial', 'B', 10);
			$pdf->Cell(50, 5, '3.   Kriteria', 0, 'LTR', 'L');
			$pdf->SetFont('Arial', '', 10);
			$pdf->ln(10);
			// Sebab
			$pdf->SetFont('Arial', 'B', 10);
			$pdf->Cell(50, 5, '4.   Sebab', 0, 'LTR', 'L');
			$pdf->SetFont('Arial', '', 10);
			$pdf->ln(8);
			for ($i=1; $i < count($expldSe); $i++){
		   		$pdf->SetX(-168); $pdf->MultiCell(125, 5, $i.'.     '.str_replace(array('</li>','</ol>'), "\r\n", $expldSe[$i]), 'J');
		   		$pdf->Cell(50, 0, '', 0, 1, 'L');
			}
			// Akibat
			$pdf->SetFont('Arial', 'B', 10);
			$pdf->Cell(50, 5, '5.   Akibat', 0, 'LTR', 'L');
			$pdf->SetFont('Arial', '', 10);
			$pdf->MultiCell(115, 5, strip_tags(preg_replace('/<p[^>]*>/', ' ', $val['akibat'])), 'J');
			$pdf->ln(10);
			// Sebab
			$pdf->SetFont('Arial', 'B', 10);
			$pdf->Cell(50, 5, '6.   Saran', 0, 'LTR', 'L');
			$pdf->SetFont('Arial', '', 10);
			$pdf->ln(8);
			for ($i=1; $i < count($expldSa); $i++){
		   		$pdf->SetX(-168); $pdf->MultiCell(125, 5, $i.'.     '.str_replace(array('</li>','</ol>'), "\r\n", $expldSa[$i]), 'J');
		   		$pdf->Cell(50, 0, '', 0, 1, 'L');
			}
			// Catatan:
			$pdf->SetFont('Arial', 'B', 10);
			$pdf->Cell(50, 5, '7.   Catatan:', 0, 'LTR', 'L');
			$pdf->SetFont('Arial', '', 10);
			$pdf->ln(8);
			$pdf->MultiCell(115, 5, strip_tags(preg_replace('/<p[^>]*>/', ' ', $val['catatan'])), 'J');
			$pdf->ln(10);
			// Sumber:
			$pdf->SetFont('Arial', 'B', 10);
			$pdf->Cell(50, 5, '8.   Sumber data', 0, 'LTR', 'L');
			$pdf->SetFont('Arial', '', 10);
			$pdf->ln(8);
			$pdf->MultiCell(115, 5, strip_tags(preg_replace('/<p[^>]*>/', ' ', $val['sumber'])), 'J');

			$pdf->ln(5);
			$pdf->Cell(237, 10, 'Bandung, 19 November 2019', 0, 1, 'C');
			$pdf->Cell(237, -2, 'Auditor/Pemeriksa,', 0, 1, 'C');
			$pdf->ln(15);
			$pdf->Cell(237, 5, 'Rizki Mugia Priatna', 0, 1, 'C');
			$pdf->Cell(237, 5, 'Letkol Cpl NRP 11970055470175', 0, 1, 'C');
			
		$pdf->Output();
		
	}

	function gets_kka()
    {
		$id_sprin = $_REQUEST['id_sprin'];
		$model    = $this->loadModel($this->model);
		$data     = $model->getId_kka($id_sprin);
        echo json_encode($data);
    } 

}