<?php

class Pkpt extends Controller {

	private $table      = "tpkpt_detil";
	private $tablePk    = "tpkpt";
	private $tableSat   = "tpkptsat";
	private $primaryKey = "autono";
	private $model      = "Pkpt_model";
	private $menu       = "Transaksi";
	private $title      = "PKPT";
	private $curl       = BASE_URL."pkpt";

	public function __construct()
	{
		$session = $this->loadHelper('Session_helper');
		if(!$session->get('username')){
			$this->redirect('auth/login');
		}
	}

	public function index()
	{
		$id                  = $this->base64url_decode($x);
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['curl']	     = $this->curl;
		$template            = $this->loadView('pkpt_view');
		$template->set('data', $data);
		$template->render();
	}

	public function detail()
	{
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['curl']	     = $this->curl;
		// $data['encode']      = $x;
		$template            = $this->loadView('pkpt_view');
		$template->set('data', $data);
		$template->render();
	}

	function get($x = null)
	{
		$request    = $_REQUEST;
		$uri        = $this->loadHelper('Url_helper');
		$pkpt       = $uri->segment(5);
		$id         = $this->base64url_decode($x);
		$columns = array(
			array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'nomor_pkpt',  'dt' => 1 ),
			array( 'db' => 'keterangan',  'dt' => 2 ),
			array( 'db' => 'flag',  'dt' => 3 ),
		);
		$model   = $this->loadModel($this->model);
		// $result  = $model->mget($request, $this->tablePk, $this->primaryKey, $columns);
		if($x){

			$result  = $model->mget_detail($request, $this->tablePk, $this->primaryKey, $columns, $id);

		} else {

			$result  = $model->mget($request, $this->tablePk, $this->primaryKey, $columns, 'autono', $pkpt);
			

		}
		return json_encode($result);
	}


	public function add()
	{
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Add';
		$data['curl']	     = $this->curl;
		// $data['encode']	     = $x;
		$data['id_kotama']	 = $model->get_satker($this->tableSat);
		$template            = $this->loadView('pkpt_add');
		$template->set('data', $data);
		$template->render();
	}

	public function jdwl()

	{
		$id                  = $this->base64url_decode($x);
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Jadwal';
		$data['curl']	     = $this->curl;
		// $id 			     = $_POST['autono'];
		// $data['encode']	     = $x;
		$data['id_jns_audit']= $model->get_jenisAudit();
		$data['pkpt']        = $model->get_PKPT();
		$data['id_kotama'] 	 = $model->get_kotamaEdit($this->tableSat, 'id_pkpt', $id);
		$data['aadata']      = $model->get($this->tablePk, $this->primaryKey, $id);
		$template            = $this->loadView('index_jadwal');
		$template->set('data', $data);
		$template->render();

	}

	// public function jdwlGet($x)

	// {
	// 	$id                  = $this->base64url_decode($x);
	// 	$model               = $this->loadModel($this->model);
	// 	$data                = array();
	// 	$data['breadcrumb1'] = $this->menu;
	// 	$data['title']       = $this->title;
	// 	$data['action']      = 'Jadwal';
	// 	$data['encode']      = $x;
	// 	$data['curl']	     = $this->curl;
	// 	// $id 			     = $_POST['autono'];
	// 	// $data['encode']	     = $x;
	// 	$data['id_jns_audit']= $model->get_jenisAudit();
	// 	$data['pkpt']        = $model->get_PKPT();
	// 	$data['id_kotama'] 	 = $model->get_kotamaEdit($this->tableSat, 'id_pkpt', $id);
	// 	$template            = $this->loadView('jadwal_readonly');
	// 	$template->set('data', $data);
	// 	$template->render();

	// }

	public function edit($x)
	{
		$id                  = $this->base64url_decode($x);
		$model               = $this->loadModel($this->model);
		// $uri                 = $this->loadHelper('Url_helper');
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Edit';
		$data['encode']      = $x;
		$data['curl']	     = $this->curl;
		// // $data['child']       = $uri->segment(5);
		
		$data['id_jns_audit']= $model->get_jenisAudit();
		$data['id_kotama'] 	 = $model->get_kotamaEdit($this->tableSat, 'id_pkpt', $id);
		$data['aadata']      = $model->get($this->table, $this->primaryKey, $id);
		$template            = $this->loadView('pkpt_edit');
		$template->set('data', $data);
		$template->render();
	}

	public function editPkpt($x)
	{
		$id                  = $this->base64url_decode($x);
		$model               = $this->loadModel($this->model);
		// $uri                 = $this->loadHelper('Url_helper');
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Edit';
		$data['encode']      = $x;
		$data['curl']	     = $this->curl;
		// // $data['child']       = $uri->segment(5);
		$data['aadata']      = $model->get($this->tablePk, $this->primaryKey, $id);
		$template            = $this->loadView('index_edit');
		$template->set('data', $data);
		$template->render();
	}

	public function approvePkpt($x)
	{
		$id                  = $this->base64url_decode($x);
		$model               = $this->loadModel($this->model);
		// $uri                 = $this->loadHelper('Url_helper');
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Approve';
		$data['encode']      = $x;
		$data['curl']	     = $this->curl;
		// // $data['child']       = $uri->segment(5);
		$data['aadata']      = $model->get($this->tablePk, $this->primaryKey, $id);
		$template            = $this->loadView('index_approve');
		$template->set('data', $data);
		$template->render();
	}

	public function save()
	{
		$data                 = array();
		$model                = $this->loadModel($this->model);
		$data['parent_id']    = $this->base64url_decode($x) ;
		$data['title']   	= htmlspecialchars($_REQUEST['title']) ;
		// $data['satker']       = htmlspecialchars($_REQUEST['satker']) ;
		$data['id_jns_audit']      = htmlspecialchars($_REQUEST['id_jns_audit']) ;
		$data['color']      = htmlspecialchars($_REQUEST['color']) ;
		$data['start'] = date("Y-m-d",strtotime($_REQUEST['start']));
		$data['end'] = date("Y-m-d",strtotime($_REQUEST['end'])) ;
		$data['autocode']     = $model->autocode($this->table, "#autocode#");	
		$result               = $model->msave($this->table, $data, $this->title);
		$lastid               = $result['id'];
		$jmlsat 		      = count($_REQUEST['satker']);

		for ($i=0; $i < $jmlsat ; $i++){
			$satker['autocode']  = $model->autocode($this->tableSat, "SPSAT_");
			$satker['id_pkpt']  = $lastid;
			$satker['id_kotama'] = htmlspecialchars($_REQUEST['satker'][$i]);
			$satker['title']   	= htmlspecialchars($_REQUEST['title']) ;
			$satker['start'] = date("Y-m-d",strtotime($_REQUEST['start']));
			$satker['end'] = date("Y-m-d",strtotime($_REQUEST['end'])) ;
			$satresult 			 = $model->msave($this->tableSat, $satker, $this->title);
		}

		$this->redirect('pkpt');

	}

	public function saveTo()
	{
		$data                 = array();
		$model                = $this->loadModel($this->model);
		$data['parent_id']    = $this->base64url_decode($x) ;
		$data['nomor_pkpt']   = htmlspecialchars($_REQUEST['nomor_pkpt']) ;
		// $data['satker']    = htmlspecialchars($_REQUEST['satker']) ;
		$data['keterangan']   = htmlspecialchars($_REQUEST['keterangan']) ;
		$data['flag']         = htmlspecialchars($_REQUEST['flag']) ;
		$data['autocode']     = $model->autocode($this->tablePk, "#autocode#");	
		$result               = $model->msave($this->tablePk, $data, $this->title);

		$this->redirect('pkpt');

	}

	public function update($x)
	{
		$data               = array();
		$sat 				= array();
		$id                 = $this->base64url_decode($x);
		$model              = $this->loadModel($this->model);
		$data['parent_id']  = $this->base64url_decode($x) ;
		// $uri                = $this->loadHelper('Url_helper');
		// $child              = $uri->segment(5);
		$data['title']	   	= htmlspecialchars($_REQUEST['title']) ;
		$data['id_jns_audit']	= htmlspecialchars($_REQUEST['id_jns_audit']);
		$data['start']  	= date("Y-m-d",strtotime($_REQUEST['start'])) ;
		$data['end']  		= date("Y-m-d",strtotime($_REQUEST['end'])) ;
		$data['color']		= htmlspecialchars($_REQUEST['color']) ;
		$result         	= $model->mupdate($this->table, $data, $this->primaryKey, $id, $this->title);

		$jmlsat               = count($_REQUEST['satker']);
		$hapusSatker 		  = $model->mdel($this->tableSat, 'id_pkpt', $id, $this->title);

		for ($j=0; $j < $jmlsat ; $j++) { 
			$satker['autocode']  = $model->autocode($this->tableSat, "SPSAT_");
			$satker['id_pkpt']   = $id;
			$satker['id_kotama'] = htmlspecialchars($_REQUEST['satker'][$j]);
			$satker['title']	   	= htmlspecialchars($_REQUEST['title']) ;
			$satker['start']  	= date("Y-m-d",strtotime($_REQUEST['start'])) ;
			$satker['end']  		= date("Y-m-d",strtotime($_REQUEST['end'])) ;
			$satresult           = $model->msave($this->tableSat, $satker, $this->title);
		}

		$this->redirect('pkpt/jdwlGet');

	}

	public function updatePkpt($x)
	{
		$data               = array();
		$sat 				= array();
		$id                 = $this->base64url_decode($x);
		$model              = $this->loadModel($this->model);
		$data['parent_id']  = $this->base64url_decode($x) ;
		// $uri                = $this->loadHelper('Url_helper');
		// $child              = $uri->segment(5);
		$data['nomor_pkpt']	   	= htmlspecialchars($_REQUEST['nomor_pkpt']) ;
		$data['keterangan']	= htmlspecialchars($_REQUEST['keterangan']);
		$data['flag']	= htmlspecialchars($_REQUEST['flag']);
		$result         	= $model->mupdate($this->tablePk, $data, $this->primaryKey, $id, $this->title);

		$this->redirect('pkpt');

	}

	Public function dragUpdateEvent()
	{	
		$model              = $this->loadModel($this->model);
		$result  			= $model->dragUpdateEvent();
		echo $result;
	}

	public function delete($x)
	{
		$id                 = $this->base64url_decode($x);
		$model              = $this->loadModel($this->model);
		$result 	        = $model->deleteEvent($id);
		// $resultSat          = $model->mdelete($this->tableSat, 'id_pkpt', $id,  $this->title);
		return $result;
	}

	// public function delete($x)
	// {
	// 	$id                 = $this->base64url_decode($x);
	// 	$model              = $this->loadModel($this->model);
	// 	$result             = $model->mdelete($this->table, $this->primaryKey, $id, $this->title);
	// 	$resultSat          = $model->mdelete($this->tableSat, 'id_pkpt', $id,  $this->title);

	// 	$this->redirect('pkpt');
	// }

	Public function getEvents()
	{
		$id 				= $_POST['autono'];
		$model              = $this->loadModel($this->model);
		$result             = $model->getpkpt_detils();
		echo json_encode($result);
	}

	Public function getChecked($id)
	{	
		$id 				= $_POST['autono'];
		$data 				= array();
		$model              = $this->loadModel($this->model);

		$result=$model->getChecked($id);
		echo json_encode($result);
	}

	/*Delete Event*/
	Public function deleteEvent()
	{
		$id  		= $_POST['autono'];
		$model   	= $this->loadModel($this->model);
		$result 	= $model->deleteEvent($id);
		return $result;
	}

	Public function updateEvent(){
		$id 		= $_POST['autono'];
		$model 		= $this->loadModel($this->model);
		$result 	= $model->updateEvent($id);

		$jmlsat               = count($_REQUEST['satker']);
		$hapusSatker 		  = $model->mdel($this->tableSat, 'id_pkpt', $id, $this->title);

		for ($j=0; $j < $jmlsat ; $j++) { 
			$satker['autocode']  	 = $model->autocode($this->tableSat, "SPSAT_");
			$satker['id_pkpt']    = $id;
			$satker['id_kotama'] = htmlspecialchars($_REQUEST['satker'][$j]);
			$satresult          = $model->msave($this->tableSat, $satker, $this->title);
		}
		echo $result; 
	}

	public function audit($x)
	{


		$return  = implode(',', $color);

		return $return;
	}

	public function bulan($value)
	{
		switch ($value) {
			case 1:
			$bln = "JAN";
			break;
			case 2:
			$bln = "FEB";
			break;
			case 3:
			$bln = "MAR";
			break;
			case 4:
			$bln = "APR";
			break;
			case 5:
			$bln = "MEI";
			break;
			case 6:
			$bln = "JUN";
			break;
			case 7:
			$bln = "JUL";
			break;
			case 8:
			$bln = "AGS";
			break;
			case 9:
			$bln = "SEP";
			break;
			case 10:
			$bln = "OKT";
			break;
			case 11:
			$bln = "NOV";
			break;
			case 12:
			$bln = "DES";
			break;

			default:
			$bln = "";
			break;
		}

		return $bln;
	}



	function print($x,$y)
	{
		$uri    = $this->loadHelper('Url_helper');
		$id     = $this->base64url_decode($x);
		$data['nomor_pkpt']  = $uri->segment(5);
		$data['nomor_pkpt'] = $y;
		$pdf    = $this->loadLibrary('fpdf');
		$thn    = date('Y');
		$model  = $this->loadModel($this->model);
		$pdf->AddPage('L','A4');

		$pkpt   = $model->pkpt($thn);
		$satker = $model->pkpt_detail($id);
		$review = $model->pkpt_rev($id);
		$tahun  = substr($y, -4);

		$title  = "KALENDER KEGIATAN REVIU DAN WASRIK ITJENAD TA ".$tahun;
		$pdf->SetFont('Arial','B',15);
		$w = $pdf->GetStringWidth($title)+6;
		$pdf->SetX((297-$w)/2);
		$pdf->SetDrawColor(0,80,180);
		$pdf->SetFillColor(230,230,0);
		$pdf->SetTextColor(220,50,50);
		$pdf->SetLineWidth(1);

         // Title
		$pdf->Cell($w,9,$title,1,1,'C',true);

		$pdf->Ln(10);
		$pdf->SetFont('Arial','B',12);
         // Tahun
		$pdf->SetLeftMargin(25);
		$pdf->SetY(91);
		$pdf->SetDrawColor(0,80,180);
		$pdf->SetFillColor(224,224,224);
		$pdf->SetTextColor(32,32,32);
		$pdf->SetLineWidth(0.2);
		$pdf->Cell(240,9, $tahun,1,0,'C',true); 

		$pdf->SetDrawColor(0,80,180);
		$pdf->SetTextColor(32,32,32); 
		$pdf->SetLineWidth(0.2);
		$pdf->Cell(20,9, $tahun+1,1,0,'C',true); 


         // Bulan
         $pdf->SetLeftMargin(25);
         $pdf->SetY(100);
         $i = 1;
         $pr = 1;
         $ps = 1;
         $ct = 1;

         foreach ($satker as $key => $val) {
            $w = $pdf->GetStringWidth($val['bulan'])+6;
            switch ($val['jenis_audit']) {
              case 'Post':
                $pdf->SetFillColor(102,178,255);
                $post = $ps++;
                break;
              case 'Current':
                $pdf->SetFillColor(0,204,0);
                $current = $ct++;
                break;
              case 'Pre':
                $pdf->SetFillColor(255,102,102);
                $pre = $pr++;
                break;

              default:
               $pdf->SetFillColor(0,204,0);
                break;
            }
            $pdf->SetDrawColor(0,80,180);
            $pdf->SetTextColor(32,32,32); 
            $pdf->SetLineWidth(0.2);
            $pdf->Cell(20,9, $this->bulan($val['bulan']),1,0,'C',true); 
            
         }
         // Next Year
        $pdf->SetDrawColor(0,80,180);
        $pdf->SetTextColor(32,32,32); 
        $pdf->SetFillColor(255,102,102);
        $pdf->SetLineWidth(0.2);
        $pdf->Cell(20,9, "JAN",1,0,'C',true); 







         // Satker      
		$pdf->SetX(25);
		$pdf->SetFont('Arial','',10);
		$pdf->SetLineWidth(0.3);
		foreach ($satker as $key => $sat) {

			if($sat['bulan']){
				if($sat['bulan'] & 1){
					$y = 130;
				} else {
					$y = 160;
				}

				$pdf->SetY($y);
				$pdf->SetLeftMargin(5+$sat['bulan']*20);

				$pdf->SetFont('Arial','',7);
				foreach ($sat['satker'] as $key => $kotama) {               
					switch ($sat['jenis_audit']) {
						case 'Post':
						$pdf->SetFillColor(102,178,255);
						break;
						case 'Current':
						$pdf->SetFillColor(0,204,0);
						break;
						case 'Pre':
						$pdf->SetFillColor(255,102,102);
						break;

						default:
						$pdf->SetFillColor(0,204,0);
						break;
					}

					$pdf->Cell(32,5,$kotama['nm_kotama'],0,1,'L',true); 
				}

				$x = (20 * $sat['bulan'])+20;
				$pdf->Line($x, 109,$x, $y-2);

				$pdf->SetFont('ZapfDingbats');
				$pdf->SetY($y-1);
				$pdf->SetX($x-2);
				$pdf->Cell(50,0,chr(116),0,1);

			}
		}



        // Arrow
   /*            if($post>=1){
                $panj = $post*17.5;
                $pdf->SetY(118);
                $pdf->SetFont('ZapfDingbats','',36);
                $pdf->SetTextColor(0,80,180); 
                $pdf->SetX($panj+18.5);
                $pdf->Cell(109,0,chr(217),0,1);

                $pdf->SetLeftMargin(25);
                $pdf->SetY(115);
                $pdf->SetDrawColor(0,80,180);
                $pdf->SetTextColor(32,32,32); 
                $pdf->SetFillColor(102,178,255);
                $pdf->SetLineWidth(0.2);
                $pdf->SetFont('Arial','BI',10);
                $pdf->Cell($panj,5, 'POST AUDIT','TB',0,'C',true); 
              } */


         // Review      
          $pdf->SetX(25);
          $pdf->SetFont('Arial','',10);
          foreach ($review as $key => $rev) {

            if($rev['bulan']){
              if($rev['bulan'] & 1){
                $y1 = 60;
              } else {
                $y1 = 40;
              }
              
              $pdf->SetY($y1);
              $pdf->SetLeftMargin(5+$rev['bulan']*20);

              $x1 = (20 * $rev['bulan'])+20;
              $pdf->SetLineWidth(0.2);
              $pdf->SetDrawColor(0,0,0);
              $pdf->Line($x1, 91,$x1, $y1+0);
              
              $pdf->SetFont('Arial','',7);
              foreach ($rev['satker'] as $key => $review) {               
                switch ($rev['jenis_audit']) {
                  case 'Post':
                    $pdf->SetX($x1-15);
                    $pdf->SetLineWidth(0.4);
                    $pdf->SetFillColor(102,178,255);
                    break;
                  case 'Current':
                   $pdf->SetX($x1-15);
                    $pdf->SetLineWidth(0.4);
                    $pdf->SetFillColor(0,204,0);
                    break;
                  case 'Pre':
                   $pdf->SetX($x1-15);
                    $pdf->SetLineWidth(0.4);
                    $pdf->SetFillColor(255,102,102);
                    break;

                  default:
                   $pdf->SetFillColor(0,204,0);
                    break;
                }          
            
                 $pdf->MultiCell(32,5,$review['nm_review'],1,'J', true); 
              }

              

              // $pdf->SetFont('ZapfDingbats');
              // $pdf->SetY($y1-1);
              // $pdf->SetX($x1-2);
              // $pdf->Cell(50,0,chr(115),0,1);

            }
          }
        
         // arrow
         $pdf->SetLeftMargin(25);
         $pdf->SetY(112);
         $i = 1;
         $prs = 1;
         $pss = 1;
         $cts = 1;
         $wid = 0;
         foreach ($satker as $key => $vals) {
            switch ($vals['jenis_audit']) {
              case 'Post':
                $pdf->SetFillColor(102,178,255);
                break;
              case 'Current':
                $pdf->SetFillColor(0,204,0);
                break;
              case 'Pre':
                $pdf->SetFillColor(255,102,102);
                break;

              default:
               $pdf->SetFillColor(0,204,0);
                break;
            }


              $pdf->SetDrawColor(0,80,180);
              $pdf->SetTextColor(255,255,255); 
              $pdf->SetLineWidth(0.2);
              $pdf->SetFont('Arial','BI',9);
              if($pss++ == $post){
                $pdf->SetFillColor(102,178,255);
                $pdf->Cell($post*20,6, ''.'POST AUDIT','TB',0,'C',true); 

                if($prs++ == $pre){
                  $pdf->SetFillColor(255,102,102);
                  $pdf->Cell($pre*20,6, 'PRE AUDIT','TB',0,'C',true); 

                  
                }


              }

              if($cts++ == $current){
                $pdf->SetFillColor(0,204,0);
                $pdf->Cell($current*20,6, 'CURRENT AUDIT','TB',0,'C',true); 
              }
              
              

            
            
            
         }

		$pdf->SetLeftMargin(25);
        $pdf->SetY(172);
        $pdf->SetDrawColor(0,80,180);
        $pdf->SetTextColor(96,96,96); 
        $pdf->SetFillColor(102,178,255);
        $pdf->SetLineWidth(0.2);
        $pdf->SetFont('Arial','I',9);
        $pdf->Cell(5,5, '',1,0,'C',true); $pdf->Cell(30,5, 'Post Audit ',0,0,'L',false); 
        $pdf->Ln();

        $pdf->SetLeftMargin(25);
        $pdf->SetY(178);
        $pdf->SetDrawColor(0,80,180);
        $pdf->SetTextColor(96,96,96);  
        $pdf->SetFillColor(0,204,0);
        $pdf->SetLineWidth(0.2);
        $pdf->SetFont('Arial','I',9);
        $pdf->Cell(5,5, '',1,0,'C',true); $pdf->Cell(30,5, 'Current Audit',0,0,'L',false); 

        $pdf->SetLeftMargin(25);
        $pdf->SetY(184);
        $pdf->SetDrawColor(0,80,180);
        $pdf->SetTextColor(96,96,96);  
        $pdf->SetFillColor(255,102,102);
        $pdf->SetLineWidth(0.2);
        $pdf->SetFont('Arial','I',9);
        $pdf->Cell(5,5, '',1,0,'C',true); $pdf->Cell(30,5, 'Pre Audit',0,0,'L',false); 

		$pdf->Output();
	}


}

