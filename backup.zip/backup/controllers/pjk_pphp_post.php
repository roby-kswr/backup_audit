<?php

class Pjk_pphp_post extends Controller {

	private $table      = "bast_post";
	private $tableSat   = "vt_upload_bast_post";
	private $primaryKey = "autono";
	private $primaryKey2 = "autocode";
	private $model      = "Pjk_pphp_post_model"; # please write with no space
	private $menu       = "PERTANGGUNG JAWABAN KEUANGAN";
	private $title      = "PPHP/BAST VS KONTRAK - Post ";
	private $curl       = BASE_URL."pjk_pphp_post/";
	private $curl2      = BASE_URL."pjk_pphp_post";
	

	public function __construct()
    {
        $session = $this->loadHelper('Session_helper');
        if(!$session->get('username')){
        	$this->redirect('auth/login');
        }
    }

	function index()
	{
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['curl']		 = $this->curl;
		$data['curl2']		 = $this->curl2;
		$template            = $this->loadView('pjk_pphp_post_view');
		$template->set('data', $data);
		$template->render();
	}

	function get($x = null)
	{
		$request = $_REQUEST;
		$columns = array(
			array( 'db' => 'autono',      'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'id_kontrak',      'dt' => 1 ),
			array( 'db' => 'no_bast',       'dt' => 2 ),
			array( 'db' => 'nm_satminkal',   'dt' => 3 ),
			array( 'db' => 'sumbast',   'dt' => 4 ),
			array( 'db' => 'sumkontrak',    'dt' => 5 )			
			// array( 'db' => 'nm_satminkal','dt' => 6 )
			
			
		);

		// $join = "a
		// 		 LEFT JOIN (SELECT nm_satminkal,kd_satminkal AS kode_satminkal FROM tsatminkal ) AS b ON a.satminkal = b.kode_satminkal";

		$model   = $this->loadModel($this->model);
		if($x){
			$result  = $model->mget_detail($request, $this->table, $this->primaryKey, $columns,$join, $id);
		} else {
			$result  = $model->mget($request, $this->table, $this->primaryKey, $columns);
		}

		return json_encode($result);
	}

	// public function add()
	// {
	// 	$model               = $this->loadModel($this->model);
	// 	$data                = array();
	// 	$data['breadcrumb1'] = $this->menu;
	// 	$data['title']       = $this->title;
	// 	$data['action']      = 'Add';
	// 	$data['curl']		 = $this->curl;

 //        $data['satminkal']	 = $model->get_satmin();
 //        $data['program']	 = $model->get_program();
 //        $data['giat']		 = $model->get_kegiatan();
 //        $data['output']		 = $model->output();
 //        $data['suboutput']   = $model->suboutput();
 //        $data['komponen']    = $model->get_komponen();
 //        $data['subkomponen'] = $model->get_subkomponen();
 //        $data['akun'] 		 = $model->get_akun();

	// 	$template            = $this->loadView('pphp_post_add');
	// 	$template->set('data', $data);
	// 	$template->render();
	// }

	// public function edit($x)
	// {
	// 	$id                  = $this->base64url_decode($x);
	// 	$model               = $this->loadModel($this->model);
	// 	$data                = array();
	// 	$data['breadcrumb1'] = $this->menu;
	// 	$data['title']       = $this->title;
	// 	$data['action']      = 'Edit';
	// 	$data['encode']      = $x;
	// 	$data['curl']		 = $this->curl;
	// 	$data['aadata']      = $model->get($this->table, $this->primaryKey, $id);

	// 	$data['satminkal']	 = $model->get_satmin();
 //        $data['program']	 = $model->get_program();
 //        $data['giat']		 = $model->get_kegiatan();
 //        $data['output']		 = $model->output();
 //        $data['suboutput']   = $model->suboutput();
 //        $data['komponen']    = $model->get_komponen();
 //        $data['subkomponen'] = $model->get_subkomponen();
 //        $data['akun'] 		 = $model->get_akun();

	// 	$template            = $this->loadView('pphp_post_edit');
	// 	$template->set('data', $data);
	// 	$template->render();
	// }

	// public function save()

	// {


	// 	$data                 = array();

	// 	$model                = $this->loadModel($this->model);
	// 	$data['parent_id']    = $this->base64url_decode($x) ;

	// 	$data['satminkal']    = htmlspecialchars($_REQUEST['satminkal']) ;
	// 	$data['program']      = htmlspecialchars($_REQUEST['program']) ;
	// 	$data['giat']         = htmlspecialchars($_REQUEST['giat']) ;
	// 	$data['output']       = htmlspecialchars($_REQUEST['output']) ;
	// 	$data['suboutput']    = htmlspecialchars($_REQUEST['suboutput']) ;
	// 	$data['komponen']     = htmlspecialchars($_REQUEST['komponen']) ;
	// 	$data['subkomponen']  = htmlspecialchars($_REQUEST['subkomponen']) ;
	// 	$data['akun']         = htmlspecialchars($_REQUEST['akun']) ;

	// 	$data['no_pphp']       = htmlspecialchars($_REQUEST['no_pphp']) ;
	// 	$data['tahun']        = htmlspecialchars($_REQUEST['tahun']) ;
	// 	$data['file_name']    = $_FILES['file_name']['name'] ;
	// 	$data['autocode']     = $model->autocode($this->table, "ekpphp_");
	// 	// $s	  				  = $model->aut();
		
	// 	$result               = $model->msave($this->table, $data, $this->title);
	// 	$last_id            = $result['id'];

	// 	$uploadDyn			  = $model->uploadpphppos($_FILES['file_name'],$data['satminkal'],$data['tahun'],$data['autocode']);

	// 	$import_pphp		      = $model->import_pphp_post($data['satminkal'],$data['tahun'], $s, $data['autocode'], $last_id);
        
 //        $this->redirect('pphp_post_detail/detail/'.$data['satminkal'].'/'.$data['autocode']);
 //        // $this->redirect('ekstrakpphp');
	// }

	// public function update($x)
	// {
	// 	$data           	= array();
	// 	$id             	= $this->base64url_decode($x);
	// 	$model          	= $this->loadModel($this->model);
	// 	$data['satker']     = htmlspecialchars($_REQUEST['satker']) ;
	// 	$data['tahun']      = htmlspecialchars($_REQUEST['tahun']) ;
	// 	$data['file_name']	= htmlspecialchars($_REQUEST['file_name']) ;
	// 	$result         	= $model->mupdate($this->table, $data, $this->primaryKey, $id, $this->title);
	// 	$this->redirect('pphp_post');
	// }

	// public function delete($x)
	// {
	// 	$id        = $this->base64url_decode($x);
	// 	$model     = $this->loadModel($this->model);
	// 	$resultSat = $model->mdelete($this->tableSat,'parent_id', $id, $this->title);
	// 	$result    = $model->mdelete($this->table, $this->primaryKey,$id, $this->title);
		
		
	// 	return $result;
	// }

}