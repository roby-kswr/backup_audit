<?php

class Pka_anev extends Controller {

	private $table       = "tpka";
	private $tableManage = "tpkamanage";
	private $primaryKey  = "autono";
	private $model       = "Pka_anev_model"; # please write with no space
	private $menu        = "Transaksi";
	private $title       = "PKA View";
	private $curl        = BASE_URL."pka_anev/";
	

	public function __construct()
    {
        $session = $this->loadHelper('Session_helper');
        if(!$session->get('username')){
        	$this->redirect('auth/login');
        }
    }
	
	function index()
	{
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['curl']        = $this->curl;
		$template            = $this->loadView('pka_anev_view');
		$template->set('data', $data);
		$template->render();
	}

	function get()
	{
		$request = $_REQUEST;
		$columns = array(
			array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'no_pka',  'dt' => 1 ),
			array( 'db' => 'tgl_pka',  'dt' => 2 ),
			array( 'db' => 'nm_kotama',  'dt' => 3 ),
			array( 'db' => 'nm_sasaran_audit',  'dt' => 4 ),
			array( 'db' => 'keterangan',   'dt' => 5 )
		);
		
		$join   = "a LEFT JOIN (SELECT autono AS kd_kotama, nm_kotama FROM tkotama) AS b ON a.id_kotama = b.kd_kotama
				   LEFT JOIN (SELECT autono AS kd_sasaran_audit, nm_sasaran_audit FROM tsasaran_audit) AS c ON a.id_sasaran_audit = c.kd_sasaran_audit";
		$model  = $this->loadModel($this->model);
		$result = $model->mget($request, $this->table, $this->primaryKey, $columns, $join);

		return json_encode($result);
	}

	function getManage()
	{
		$request    = $_REQUEST;
		$columns = array(
			array( 'db' => 'autono',   'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'user_id',     'dt' => 1 ),
			array( 'db' => 'user_fullname',  'dt' => 2 ),
			array( 'db' => 'jabatanVal',        'dt' => 3 ),
			array( 'db' => 'user_grupVal',         'dt' => 4 )
		);

		$model   = $this->loadModel($this->model);
		$result  = $model->mgetManage($request, $this->tableManage, $this->primaryKey, $columns);

		return json_encode($result);
	}

	public function treemenu($id)
	{
		global $config;

		$model  = $this->loadModel($this->model);

		$group_id = $this->base64url_decode($id);
		
		$result = $model->show_menu_admin($group_id);

	    while ($row = $model->fetch_object($result)) {
	        $data[$row->parent_id][] = $row;
	    }
	       
	    $menu = $this->get_menutree($data);
	    echo (json_encode($menu));
	}

	public function get_menutree($data, $parent = 0) 
    {
      static $i = 1;
      $datas = array();
      if (isset($data[$parent])) {
        foreach ($data[$parent] as $v) {
			$child               = $this->get_groups($data, $v->id);
			$row['key']          = $this->base64url_encode($v->id);
			$row['title']        = $v->title;
			$row['parent_id']    = (int) $v->parent_id;
			$row['expanded']     = false;
			$row['selected']     = boolval( $v->permission_a );
			$row['folder']       = false;
			$row['extraClasses'] = "";
			$row['tooltip']      = $v->description;
			$row['children']     = array();
          if ($child) {          
            $row['children']     =  $child;
          }
          array_push($datas,$row);
        }
        return $datas;
      } else {
        return false;
      }
    }

	public function tree($id)
	{
		global $config;

		$idx    = $this->base64url_decode($id);

		$model  = $this->loadModel($this->model);
		
		$result = $model->show_groups($idx);

	    while ($row = $model->fetch_object($result)) {
	        $data[$row->parent_id][] = $row;
	    }
	       
	    $groups = $this->get_groups($data);
	    echo (json_encode($groups));
	}

	public function get_groups($data, $parent = 0) 
    {
      static $i = 1;
      $datas = array();
      if (isset($data[$parent])) {
        foreach ($data[$parent] as $v) {
			$child               = $this->get_groups($data, $v->id);
			$row['key']          = $this->base64url_encode($v->id);
			$row['title']        = $v->title;
			$row['parent_id']    = (int) $v->parent_id;
			$row['selected']     = boolval( $v->permission_a );
			$row['expanded']     = true;
			$row['folder']       = false;
			$row['extraClasses'] = "";
			$row['tooltip']      = $v->description;
			$row['children']     = array();
          if ($child) {          
            $row['children']     =  $child;
          }
          array_push($datas,$row);
        }
        return $datas;
      } else {
        return false;
      }
    }

    function gets_kotama()
    {
		$id    = $_REQUEST['id_sprin'];
		$model = $this->loadModel($this->model);
		$data  = $model->mget_kotama($id);
        echo json_encode($data);
    }

    function gets_satker()
    {
		$id    = $_REQUEST['id_kotama'];
		$model = $this->loadModel($this->model);
		$data  = $model->mget_satker($id);
        echo json_encode($data);
    }

    function insert_tree()
    {
		$lastid    = $_REQUEST['last_id'];
		$id_pka    = $_REQUEST['id_pka'];
		$id_satker = $_REQUEST['id_satker'];
		$nm_satker = $_REQUEST['nm_satker'];
		$model     = $this->loadModel($this->model);
		$data      = $model->insertTree($lastid,$id_pka,$id_satker,$nm_satker);
        echo json_encode($data);
    }

    function delete_tree()
    {
		$id_pka    = $_REQUEST['id_pka'];
		$id_satker = $_REQUEST['id_satker'];
		$model     = $this->loadModel($this->model);
		$data      = $model->deleteTree($id_pka,$id_satker);
        echo json_encode($data);
    }

    function load_Fpdf($x)
	{
		$model = $this->loadModel('pka_model');
		$pdf   = $this->loadLibrary('fpdf');
		$id    = $this->base64url_decode($x);
		
		// Get Data Sprin
		$dtPka      = $model->load_pka($this->table, $id);
		// Get Data Jenis Audit
		$dtJnsAudit = $model->load_jnsAudit($id);
		// Get Data Personel
		$dtDisusun  = $model->load_personel($this->table, $this->primaryKey, $id);
		// Get Data Detil Parent
		$sWhere     = "AND parent_id = '0'";
		$dtManage   = $model->load_manage($this->tableManage, $id, $sWhere);
		
		// ** PKA **
			$pdf->SetMargins(42,10); // Format A4
			$pdf->AddPage('P', 'A4');

			// Kop Surat
			$pdf->SetFont('Arial', '', 10);
			$pdf->Cell(80, 5, 'INSPEKTORAT JENDERAL ANGKATAN DARAT', 0, 1, 'C');
			$pdf->Cell(79, 2, 'TIM '.ucwords(strtoupper($dtJnsAudit['nm_jns_audit'])).' AUDIT', 0, 1, 'C');
			$pdf->Line(44, 25, 120, 25);
			$pdf->Ln(10);

			// Entitas
			$pdf->Cell(28, 5, 'Entitas', 0, 'LTR', 'L');
			$pdf->Cell(-10, 5, ':', 0, 'LTR','C');
			$pdf->SetX(67);$pdf->MultiCell(110, 5, strip_tags(preg_replace('/<p[^>]*>/', '        ', ucwords(strtolower($dtPka['nm_kotama']))) ), 'J');
			// Sasaran
			$pdf->Cell(28, 5, 'Sasaran', 0, 'LTR', 'L');
			$pdf->Cell(-10, 5, ':', 0, 'LTR','C');
			$pdf->SetX(67); $pdf->MultiCell(110, 5, strip_tags(preg_replace('/<p[^>]*>/', '        ', $dtPka['nm_sasaran_audit']) ), 'J');	
			// Bidang
			$pdf->Cell(28, 5, 'Bidang', 0, 'LTR', 'L');
			$pdf->Cell(-10, 5, ':', 0, 'LTR','C');
			$pdf->SetX(67); $pdf->MultiCell(110, 5, strip_tags(preg_replace('/<p[^>]*>/', '        ', $dtPka['bidang']) ), 'J');
			// Tahun
			$pdf->Cell(28, 5, 'Tahun', 0, 'LTR', 'L');
			$pdf->Cell(-10, 5, ':', 0, 'LTR','C');
			$pdf->SetX(67); $pdf->MultiCell(110, 5, strip_tags(preg_replace('/<p[^>]*>/', '        ', $dtPka['tahun']) ), 'J');
			// Nomor PKA
			$pdf->Cell(28, 5, 'Nomor PKA', 0, 'LTR', 'L');
			$pdf->Cell(-10, 5, ':', 0, 'LTR','C');
			$pdf->SetX(67); $pdf->MultiCell(110, 5, strip_tags(preg_replace('/<p[^>]*>/', '        ', $dtPka['no_pka']) ), 0, 'J');
			$pdf->ln(8);

			// Title
			$pdf->SetFont('Arial', 'B', 10);
			$pdf->Cell(140, 5, 'PROGRAM KERJA AUDIT (PKA)', 0, 1, 'C');	
			$pdf->Ln(3);

			//Table	
			// * Baris Pertama
			$pdf->SetFont('Arial', '', 10);
			$pdf->Cell(10, 10, 'NO', 'LRTB', 0, 'C');
			$pdf->Cell(60, 10, 'URAIAN', 'LRTB', 0, 'C');
			$pdf->Cell(50, 5, 'DILAKSANAKAN', 'LRTB', 0, 'C');
			$pdf->Cell(15, 5, 'NO', 'LRT', 0, 'C');
			// Total Max 135 Kertas A4
			$pdf->Ln();

			// * Baris Kedua
			$pdf->Cell(70, 0, '', 0, 0);
			$pdf->Cell(30, 5, 'OLEH', 'LRB', 0, 'C');
			$pdf->Cell(20, 5, 'WAKTU', 'LRB', 0, 'C');
			$pdf->Cell(15, 5, 'KKA', 'LRB', 0, 'C');
			$pdf->Ln();

			// * Baris Ketiga
			$pdf->Cell(10, 5, '1', 'LRB', 0, 'C');
			$pdf->Cell(60, 5, '2', 'LRB', 0, 'C');
			$pdf->Cell(30, 5, '3', 'LRB', 0, 'C');
			$pdf->Cell(20, 5, '4', 'LRB', 0, 'C');
			$pdf->Cell(15, 5, '5', 'LRB', 0, 'C');
			$pdf->Ln();
						
			// * Kolom Data
			$pdf->SetWidths(array(10,60,30,20,15,''));
			$pdf->SetAligns(array('C','L','L','C','C',''));
			$pdf->RowBLess(array('','','','','',''));

			$x = 'A'; 
			foreach ($dtManage as $key => $valueManage)
			{
				$pdf->SetFont('Arial', 'B', 10);
				$no = 1;
				$pdf->RowBLess(
					array($x++.'.',
					$valueManage['group_name'],	
					$valueManage['oleh'],
					$valueManage['waktu'],
					$valueManage['no_kka'],
					''
				));

				$parent_id = $valueManage['autono'];
				$sWhere    = "AND parent_id = '$parent_id'";
				// Get Data Detil Child
				$dtManage  = $model->load_manage($this->tableManage, $id, $sWhere);
				foreach ($dtManage as $key => $valueManage)	
				{		  
					$pdf->SetFont('Arial', '', 10);
					$pdf->RowBLess(
						array($no++.'.',
						$valueManage['group_name'],	
						$valueManage['oleh'],
						$valueManage['waktu'],
						$valueManage['no_kka'],
						''
					));
				}

				$pdf->RowBLess(array('','','','','',''));
			}

			if("{nb}"){			
				$pdf->RowLineB(array('','','','','',''));
			}

			$pdf->SetFont('Arial', '', 10);
			$pdf->ln(0);
			$pdf->Cell(190, 10, 'Jakarta,          '.$pdf->getMonth($dtPka['month']).' '.$dtPka['year'], 0, 1, 'C');
			$pdf->ln(0);
			$pdf->Cell(190, 5, 'Disusun Oleh', 0, 1, 'C');
			$pdf->ln(0);
			$pdf->Cell(190, 5, 'Parik Bidang,', 0, 1, 'C');
			$pdf->ln(10);	
			$pdf->Cell(190, 5, ucwords(strtolower($dtDisusun['nama'])), 0, 1, 'C');
			$pdf->Cell(190, 5, ucwords(strtolower($dtDisusun['nm_pangkat'])).' '.ucwords(strtolower($dtDisusun['nm_korps'])).' NRP '.$dtDisusun['nrp'], 0, 1, 'C');

			//Footer
			global $totalPageForFooter;
			if($pdf->PageNo() != $totalPageForFooter){
				if($pdf->PageNo() > 2){
					$pdf->SetY(35);
					$pdf->Ln(10);					
					$pdf->SetFont('Arial', '', 10);
					$pdf->SetY(39);
					$pdf->Cell(12, 5, '1', 'LRTB',0,'C');
					$pdf->Cell(10, 5, '2', 'LRTB', 0, 'C');
					$pdf->Cell(50, 5, '3', 'LRTB', 0, 'C');
					$pdf->Cell(35, 5, '4', 'LRTB', 0, 'C');
					$pdf->Cell(35, 5, '5', 'LRTB', 0, 'C');
					$pdf->Cell(37, 5, '6', 'LRTB', 0, 'C');
					$pdf->Cell(30, 5, '7', 'LRTB', 0, 'C');
					$pdf->Cell(29, 5, '8', 'LRTB', 0, 'C');
					$pdf->Ln(0);
				}
			}

		$pdf->Output();
		
	}
    
}