<?php

class Kegiatan extends Controller {

	private $table      = "tkegiatan";
	private $primaryKey = "autono";
	private $model      = "Kegiatan_model"; # please write with no space
	private $menu       = "Reference";
	private $title      = "Kegiatan";
	private $curl       = BASE_URL."kegiatan/";
	

	public function __construct()
    {
        $session = $this->loadHelper('Session_helper');
        if(!$session->get('username')){
        	$this->redirect('auth/login');
        }
    }
	
	function index()
	{
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['curl']        = $this->curl;
		$template            = $this->loadView('kegiatan_view');
		$template->set('data', $data);
		$template->render();
	}

	function get()
	{
		$request = $_REQUEST;
		$columns = array(
			array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'KDGIAT',  'dt' => 1 ),
			array( 'db' => 'NMGIAT',  'dt' => 2 ),
			array( 'db' => 'keterangan',   'dt' => 3 )
		);

		$join   = "a LEFT JOIN (SELECT KDPROGRAM, NMPROGRAM FROM tprogram ) AS b ON a.KDPROGRAM = b.KDPROGRAM";
		$model  = $this->loadModel($this->model);
		$result = $model->mget($request, $this->table, $this->primaryKey, $columns, $join);

		return json_encode($result);
	}

	public function add()
	{
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Add';
		$data['curl']        = $this->curl;
		$data['KDPROGRAM']   = $model->get_program();
		$data['KDFUNGSI']    = $model->get_fungsi();
		$data['KDSFUNG']     = $model->get_subFungsi();
		$template            = $this->loadView('kegiatan_add');
		$template->set('data', $data);
		$template->render();
	}

	public function edit($x)
	{
		$id                  = $this->base64url_decode($x);
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Edit';
		$data['encode']      = $x;
		$data['curl']        = $this->curl;
		$data['aadata']      = $model->get($this->table, $this->primaryKey, $id);
		$data['KDPROGRAM']   = $model->get_program();
		$data['KDFUNGSI']    = $model->get_fungsi();
		$data['KDSFUNG']     = $model->get_subFungsi();
		$template            = $this->loadView('kegiatan_edit');
		$template->set('data', $data);
		$template->render();
	}

	public function save()
	{
		$data               = array();
		$model              = $this->loadModel($this->model);
		$data['KDUNIT']     = 22 ;
		$data['KDPROGRAM']  = htmlspecialchars($_REQUEST['KDPROGRAM']) ;
		$data['KDFUNGSI']   = htmlspecialchars($_REQUEST['KDFUNGSI']) ;
		$data['KDSFUNG']    = htmlspecialchars($_REQUEST['KDSFUNG']) ;
		$data['KDES2']      = 01 ;
		$data['KDPROGOUT']  = 01 ;
		$data['KDGIAT']     = ucwords(htmlspecialchars($_REQUEST['KDGIAT'])) ;
		$data['NMGIAT']     = ucwords(htmlspecialchars($_REQUEST['NMGIAT'])) ;
		$data['keterangan'] = ucwords(htmlspecialchars($_REQUEST['keterangan'])) ;
		$data['autocode']   = $model->autocode($this->table, "KGTN_");	
		$result             = $model->msave($this->table, $data, $this->title);
		$this->redirect('kegiatan');
	}

	public function update($x)
	{
		$data               = array();
		$id                 = $this->base64url_decode($x);
		$model              = $this->loadModel($this->model);
		$data['KDUNIT']     = 22 ;
		$data['KDPROGRAM']  = htmlspecialchars($_REQUEST['KDPROGRAM']) ;
		$data['KDFUNGSI']   = htmlspecialchars($_REQUEST['KDFUNGSI']) ;
		$data['KDSFUNG']    = htmlspecialchars($_REQUEST['KDSFUNG']) ;
		$data['KDES2']      = 01 ;
		$data['KDPROGOUT']  = 01 ;
		$data['KDGIAT']     = ucwords(htmlspecialchars($_REQUEST['KDGIAT'])) ;
		$data['NMGIAT']     = ucwords(htmlspecialchars($_REQUEST['NMGIAT'])) ;
		$data['keterangan'] = ucwords(htmlspecialchars($_REQUEST['keterangan'])) ;
		$result             = $model->mupdate($this->table, $data, $this->primaryKey, $id, $this->title);
		$this->redirect('kegiatan');
	}

	public function delete($x)
	{
		$id     = $this->base64url_decode($x);
		$model  = $this->loadModel($this->model);
		$result = $model->mdelete($this->table, $this->primaryKey, $id, $this->title);
		return $result;
	}
    
}