                <?php

                class Laporan_hasil_temuan_wasrik_intel extends Controller {

                  private $table       = "tkotama"; 
                  private $primaryKey  = "autono";
                  private $model       = "laporan_hasil_temuan_wasrik_intel_model"; # please write with no space
                  private $menu        = "Laporan";
                  private $title       = "Laporan Hasil Temuan Wasrik";
                  private $curl        = BASE_URL."laporan_hasil_temuan_wasrik_intel";
                  

                  public function __construct()
                    {
                        $session = $this->loadHelper('Session_helper');
                        if(!$session->get('username')){
                          $this->redirect('auth/login');
                        }
                    }

                 function index()
                  {
                    $data                = array();
                    $data['breadcrumb1'] = $this->menu;
                    $data['title']       = $this->title;
                    $data['curl']        = $this->curl;
                    $data['curl2']       = $this->curl2;
                    $template            = $this->loadView('laporan_hasil_temuan_wasrik_intel_view');
                    $template->set('data', $data);
                    $template->render();
                  }

                  function get($audit)
                  {
                    $request = $_REQUEST;
                    $columns = array(
                      array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
                      array( 'db' => 'nm_kotama',  'dt' => 2 ),
                      array( 'db' => 'jml_fakta',  'dt' => 3 ),
                      array( 'db' => 'tgl_mulai',   'dt' => 4 ),
                      array( 'db' => 'tgl_selesai',   'dt' => 5 ),
                       array( 'db' => 'au',   'dt' => 6 ),

                      
                      
                    );

                    $model   = $this->loadModel($this->model);               
                    $result  = $model->mget($request, $this->table, $this->primaryKey, $audit , $columns);
                    

                    return json_encode($result);
                  }


                  function print()
               {
                  $pdf = $this->loadLibrary('fpdf');

                 
                  $audit = $_REQUEST['filteraudit'];

                  $exp = explode('-', $tahun);
                  $ss = $exp[1];
                  // membuat halaman baru
                  $pdf->AddPage('P','A4');
                  // setting jenis font yang akan digunakan
                  $pdf->setX(23);

                  $pdf->Image(ROOT_DIR.'static/images/mabesad.png',18,10,18);
                  
                  // Arial bold 12
                 $pdf->Ln(1);
                 $pdf->SetFont('Arial','B',18);
                  
                  // Geser Ke Kanan 35mm
                 $pdf->Cell(95);
                  
                  // Judul

                 $pdf->Cell(10,7,'E-AUDIT TNI AD',0,1,'C');
                 $pdf->Cell(95);
                 $pdf->SetFont('Arial','B',13);
                 $pdf->Cell(10,10,'INSPEKTORAT JENDRAL ANGKATAN DARAT',0,1,'C');
                  // Garis Bawah Double
                 $pdf->Ln(5);
                 // $pdf->Cell(1);
                 $pdf->Cell(190,0,'','B',1,'L');
                 // $pdf->Cell();
                 $pdf->Cell(190,1,'','B',1,'L');
                 // $pdf->Cell(260,1,'','B',0,'L');
                  
                  // Line break 5mm
                  $pdf->Ln(3);
                  $pdf->SetFont('Arial','B',12);
                  $pdf->Cell(40); 
                  $pdf->Cell(115,7,'LAPORAN HASIL TEMUAN '.strtoupper($audit).' WASRIK '.$ss,0,1,'C');
                  $pdf->SetFont('Arial','B',12);
                  $pdf->Ln(2);
                  
                  //header
                $pdf->Cell(10, 15, 'NO', 'LRT', 0, 'C');

                $pdf->Cell(50, 15, 'NAMA KOTAMA', 'LRT', 0, 'C');
                
                $pdf->Cell(92, 5, 'WAKTU PELAKSANAAN', 'LRTB', 0, 'C');

                $pdf->Cell(40, 7, 'JUMLAH FAKTA', 'LRT', 0, 'C');          
               
                $pdf->Cell(30, 5, '', 0, 0);

                $pdf->Ln();

                // * Baris Kedua
                $pdf->Cell(30, 0, '', 0, 0);

                $pdf->Cell(30, 0, '', 0, 0);
                
                $pdf->Cell(45, 7, 'TANGGAL MULAI', 'R', 0, 'C');

                $pdf->Cell(47, 7, 'TANGGAL SELESAI', 'L', 0, 'C');

                $pdf->Cell(40, 8, 'TEMUAN', 'LR', 0,'C');

                $pdf->Ln();


                $pdf->SetY(35);
                $pdf->Ln(10);         
                $pdf->SetFont('Arial', '', 10);
                $pdf->SetY(65);

                $pdf->Cell(10, 5, '1', 'LRTB',0,'C');

                $pdf->Cell(50, 5, '2', 'LRTB', 0, 'C');
                
                $pdf->Cell(45, 5, '3', 'LRTB', 0, 'C');

                $pdf->Cell(47, 5, '4', 'LRTB', 0, 'C');

                $pdf->Cell(40, 5, '5', 'LRTB', 0, 'C');

                $pdf->Cell(30, 7, '', 0, 0);

                $pdf->Ln(5);


                  //body

                  $pdf->SetFont('Arial', '', 10);
                  $pdf->SetWidths(array(10, 50, 45,47,40,30));
                  $pdf->SetAligns(array('C', 'C', 'C', 'C','C','C'));

                  $model = $this->loadModel($this->model);

                  

                 $query = $model->query("SELECT DISTINCT  nm_kotama, tgl_mulai, tgl_selesai, jml_fakta FROM tkotama AS a 
                                        LEFT JOIN (SELECT id_kotama, id_sprin FROM tsprinpers) b ON a.autono = b.id_kotama 
                                        LEFT JOIN (SELECT autono, DATE_FORMAT(tgl_mulai,'%d-%m-%Y') AS tgl_mulai, DATE_FORMAT(tgl_selesai,'%d-%m-%Y') AS tgl_selesai, id_pkpt_detil FROM tsprin) AS c ON b.id_sprin = c.autono
                                        LEFT JOIN (SELECT autono, id_sprin FROM tpka) AS d ON d.id_sprin = c.autono
                                        LEFT JOIN (SELECT id_pka, nm_audit, jml_fakta FROM tkka) AS e ON e.id_pka = d. autono
                                        LEFT JOIN (SELECT autono,id_jns_audit FROM tpkpt_detil) AS f ON c.id_pkpt_detil = f.autono
                                        WHERE id_jns_audit = '$audit' AND IF(b.id_kotama IS NULL, '', 'selected') != ''
                                        GROUP BY nm_audit ORDER BY jml_fakta DESC ");

                  $no = 1;
                  foreach ($query as $row){
                    // $pdf->setX(20);
                     $pdf->Row(
                      array($no++,
                      $row['nm_kotama'],                      
                      $row['tgl_mulai'],
                      $row['tgl_selesai'],
                      $row['jml_fakta']            
                  ));

                  }
                //   global $totalPageForFooter;
                // if($pdf->PageNo() != $totalPageForFooter){
                //   if($pdf->PageNo() > 1){
                //     $pdf->SetY(35);
                //     $pdf->Ln(10);         
                //     $pdf->SetFont('Arial', '', 10);
                //     $pdf->SetY(39);
                //     $pdf->Cell(20, 5, '1', 'LRTB',0,'C');
                //     $pdf->Cell(70, 5, '2', 'LRTB', 0, 'C');
                //     $pdf->Cell(35, 5, '3', 'LRTB', 0, 'C');
                //     $pdf->Cell(40, 5, '4', 'LRTB', 0, 'C');
                //     $pdf->Cell(42, 5, '5', 'LRTB', 0, 'C');
                //     $pdf->Cell(60, 5, '6', 'LRTB', 0, 'C');
                //     $pdf->Ln(0);
                //   }
                // }


                  $pdf->Output();
              }

    }