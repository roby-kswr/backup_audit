<?php

class Kategori extends Controller {

	private $table      = "tkategori";
	private $primaryKey = "autono";
	private $model      = "Kategori_model"; # please write with no space
	private $menu       = "Reference";
	private $title      = "Kategori";
	private $curl       = BASE_URL."kategori/";
	

	public function __construct()
    {
        $session = $this->loadHelper('Session_helper');
        if(!$session->get('username')){
        	$this->redirect('auth/login');
        }
    }
	
	function index()
	{
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['curl']        = $this->curl;
		$template            = $this->loadView('kategori_view');
		$template->set('data', $data);
		$template->render();
	}

	function get()
	{
		$request = $_REQUEST;
		$columns = array(
			array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'nm_bidang',  'dt' => 1 ),
			array( 'db' => 'nm_kategori',  'dt' => 2 ),
			array( 'db' => 'keterangan',   'dt' => 3 )
		);

		$join   = "a LEFT JOIN (SELECT autono AS kd_bidang, nm_bidang FROM tbidang ) AS b ON a.id_bidang = b.kd_bidang";
		$model  = $this->loadModel($this->model);
		$result = $model->mget($request, $this->table, $this->primaryKey, $columns, $join);

		return json_encode($result);
	}

	public function add()
		{
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Add';
		$data['curl']        = $this->curl;
		$template            = $this->loadView('kategori_add');
		$data['bidang']      = $model->get_bidang();
		$template->set('data', $data);
		$template->render();
	}

	public function edit($x)
	{
		$id                  = $this->base64url_decode($x);
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Edit';
		$data['encode']      = $x;
		$data['curl']        = $this->curl;
		$data['aadata']      = $model->get($this->table, $this->primaryKey, $id);
		$data['bidang']      = $model->get_bidangEdit($this->table, $this->primaryKey, $id);
		$template            = $this->loadView('kategori_edit');
		$template->set('data', $data);
		$template->render();
	}

	public function save()
	{
		$data                = array();
		$model               = $this->loadModel($this->model);
		$data['id_bidang']   = htmlspecialchars($_REQUEST['id_bidang']) ;
		$data['nm_kategori'] = ucwords(htmlspecialchars($_REQUEST['nm_kategori'])) ;
		$data['keterangan']  = ucwords(htmlspecialchars($_REQUEST['keterangan'])) ;
		$data['autocode']    = $model->autocode($this->table, "KTGR_");	
		$result              = $model->msave($this->table, $data, $this->title);
		$this->redirect('kategori');
	}

	public function update($x)
	{
		$data                = array();
		$id                  = $this->base64url_decode($x);
		$model               = $this->loadModel($this->model);
		$data['id_bidang']   = htmlspecialchars($_REQUEST['id_bidang']) ;
		$data['nm_kategori'] = ucwords(htmlspecialchars($_REQUEST['nm_kategori'])) ;
		$data['keterangan']  = ucwords(htmlspecialchars($_REQUEST['keterangan'])) ;
		$result              = $model->mupdate($this->table, $data, $this->primaryKey, $id, $this->title);
		$this->redirect('kategori');
	}

	public function delete($x)
	{
		$id     = $this->base64url_decode($x);
		$model  = $this->loadModel($this->model);
		$result = $model->mdelete($this->table, $this->primaryKey, $id, $this->title);
		return $result;
	}
    
}