<?php

class Bast_post_detail extends Controller {

	private $table       = "vt_upload_bast_post";
	private $primaryKey  = "autono";
	private $primaryKey2 = "satminkal";
	private $primaryKey3 = "autocode";
	private $model       = "Bast_post_detail_model";
	private $menu        = "Transaksi";
	private $title       = "Ekstrak BAST Detail";
	private $curl        = BASE_URL."bast_post_detail";
	

	public function __construct()
    {
        $session = $this->loadHelper('Session_helper');
        if(!$session->get('username')){
        	$this->redirect('auth/login');
        }
    }
	
	function index()
	{
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['curl']	     = $this->curl;
		$template            = $this->loadView('bast_post_detail_view');
		$template->set('data', $data);
		$template->render();
	}

	public function detail($x,$y)
	{
		$uri = $this->loadHelper('Url_helper');
		$data                    = array();
		$data['satminkal']		 = $uri->segment(2);
		$data['autocode']		 = $uri->segment(3);
		$data['breadcrumb1']     = $this->menu;
		$data['title']           = $this->title;
		$data['curl']	         = $this->curl;
		$data['encode']          = $x;
		$data['satminkal']       = $x;
		$data['autocode']        = $y;
		$template                = $this->loadView('bast_post_detail_view');
		$template->set('data', $data);
		$template->render();
	}

	function get($x = null, $y = null)
	{
		$request      = $_REQUEST;
		//$id         = $this->base64url_decode($x);
		$columns = array(
			array( 'db' => 'autono',      'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'satminkal',   'dt' => 1 ),
			array( 'db' => 'tahun',       'dt' => 2 ),
			array( 'db' => 'no_urut',     'dt' => 3 ),
			array( 'db' => 'keterangan',  'dt' => 4 ),
			array( 'db' => 'vol',         'dt' => 5 ),
			array( 'db' => 'satuan',      'dt' => 6 ),
			array( 'db' => 'harga',       'dt' => 7 ),			
			array( 'db' => 'jumlah',      'dt' => 8 ),
			array( 'db' => 'ppn',         'dt' => 9 ),
			array( 'db' => 'totalbast',    'dt' => 10 )


		);

		$model   = $this->loadModel($this->model);
		if($x){
			$result  = $model->mget_detail($request, $this->table,$x,$y, $columns, $x);
		} else {
			$result  = $model->mget($request, $this->table, $this->primaryKey, $columns);
		}

		return json_encode($result);
	}

	// public function add($x = null)
	// {
	// 	$model               = $this->loadModel($this->model);
	// 	$data                = array();
	// 	$data['breadcrumb1'] = $this->menu;
	// 	$data['title']       = $this->title;
	// 	$data['action']      = 'Add';
	// 	$data['curl']	     = $this->curl;
	// 	$data['encode']	     = $x;
	// 	$template            = $this->loadView('ku17_post_detail_add');
	// 	$template->set('data', $data);
	// 	$template->render();
	// }

	// public function edit($x)
	// {
	// 	$id                  = $this->base64url_decode($x);
	// 	$model               = $this->loadModel($this->model);
	// 	$uri                 = $this->loadHelper('Url_helper');
	// 	$data                = array();
	// 	$data['breadcrumb1'] = $this->menu;
	// 	$data['title']       = $this->title;
	// 	$data['action']      = 'Edit';
	// 	$data['encode']      = $x;
	// 	$data['curl']	     = $this->curl;
	// 	$data['child']       = $uri->segment(5);
	// 	$data['aadata']      = $model->get($this->table, $this->primaryKey, $id);
	// 	$template            = $this->loadView('ku17_post_detail_edit');
	// 	$template->set('data', $data);
	// 	$template->render();
	// }

	// public function save($x = null)
	// {
	// 	$data                 = array();
	// 	$model                = $this->loadModel($this->model);
	// 	$data['parent_id']    = $this->base64url_decode($x) ;
	// 	$data['uraian']       = htmlspecialchars($_REQUEST['uraian']) ;
	// 	$data['jumlah']       = htmlspecialchars($_REQUEST['jumlah']) ;
	// 	$data['satuan']       = htmlspecialchars($_REQUEST['satuan']) ;
	// 	$data['harga']        = htmlspecialchars($_REQUEST['harga']) ;
	// 	$data['autocode']     = $model->autocode($this->table, "#autocode#");	
	// 	$result               = $model->msave($this->table, $data, $this->title);
	// 	if($x){
	// 		$this->redirect('ku17_post_detail/detail/'.$x);
	// 	} else {
	// 		$this->redirect('ku17_post_detail');
	// 	}
	// }

	// public function update($x)
	// {
	// 	$data               = array();
	// 	$id                 = $this->base64url_decode($x);
	// 	$model              = $this->loadModel($this->model);
	// 	$uri                = $this->loadHelper('Url_helper');
	// 	$child              = $uri->segment(5);
	// 	$data['uraian']     = htmlspecialchars($_REQUEST['uraian']) ;
	// 	$data['jumlah']     = htmlspecialchars($_REQUEST['jumlah']) ;
	// 	$data['satuan']     = htmlspecialchars($_REQUEST['satuan']) ;
	// 	$data['harga']      = htmlspecialchars($_REQUEST['harga']) ;	
	// 	$result             = $model->mupdate($this->table, $data, $this->primaryKey, $id, $this->title);
	// 	if($child){
	// 		$this->redirect('ku17_post_detail/detail/'.$child);
	// 	} else {
	// 		$this->redirect('ku17_post_detail');
	// 	}
	// }

	// public function delete($x)
	// {
	// 	$id                 = $this->base64url_decode($x);
	// 	$model              = $this->loadModel($this->model);
	// 	$result             = $model->mdelete($this->table, $this->primaryKey, $id, $this->title);
	// 	return $result;
	// }
    
}