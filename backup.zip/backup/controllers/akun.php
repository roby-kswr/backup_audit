<?php

class Akun extends Controller {

	private $table      = "takun";
	private $primaryKey = "autono";
	private $model      = "Akun_model"; # please write with no space
	private $menu       = "Reference";
	private $title      = "Akun";
	private $curl       = BASE_URL."akun/";
	

	public function __construct()
    {
        $session = $this->loadHelper('Session_helper');
        if(!$session->get('username')){
        	$this->redirect('auth/login');
        }
    }
	
	function index()
	{
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['curl']        = $this->curl;
		$template            = $this->loadView('akun_view');
		$template->set('data', $data);
		$template->render();
	}

	function get()
	{
		$request    = $_REQUEST;
		$columns    = array(
			array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'nm_jenbel',  'dt' => 1 ),
			array( 'db' => 'kd_akun',  'dt' => 2 ),
			array( 'db' => 'nm_akun',  'dt' => 3 ),
			array( 'db' => 'keterangan',   'dt' => 4 )
		);
		
		$join   = "a LEFT JOIN (SELECT autono AS kd_jenbel, nm_jenbel FROM tjenbel) AS b ON a.id_jenbel = b.kd_jenbel";
		$model  = $this->loadModel($this->model);
		$result = $model->mget($request, $this->table, $this->primaryKey, $columns, $join);

		return json_encode($result);
	}

	public function add()
	{
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Add';
		$data['curl']        = $this->curl;
		$data['id_jenbel']   = $model->get_jenBel();
		$template            = $this->loadView('akun_add');
		$template->set('data', $data);
		$template->render();
	}

	public function edit($x)
	{
		$id                  = $this->base64url_decode($x);
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Edit';
		$data['encode']      = $x;
		$data['curl']        = $this->curl;
		$data['id_jenbel']   = $model->get_jenBel();
		$data['aadata']      = $model->get($this->table, $this->primaryKey, $id);
		$template            = $this->loadView('akun_edit');
		$template->set('data', $data);
		$template->render();
	}

	public function save()
	{
		$data               = array();
		$model              = $this->loadModel($this->model);
		$data['id_jenbel']  = ucwords(htmlspecialchars($_REQUEST['id_jenbel'])) ;
		$data['kd_akun']    = ucwords(htmlspecialchars($_REQUEST['kd_akun'])) ;
		$data['nm_akun']    = ucwords(htmlspecialchars($_REQUEST['nm_akun'])) ;
		$data['keterangan'] = ucwords(htmlspecialchars($_REQUEST['keterangan'])) ;
		$data['autocode']   = $model->autocode($this->table, "AKN_");	
		$result             = $model->msave($this->table, $data, $this->title);
		$this->redirect('akun');
	}

	public function update($x)
	{
		$data               = array();
		$id                 = $this->base64url_decode($x);
		$model              = $this->loadModel($this->model);
		$data['id_jenbel']  = ucwords(htmlspecialchars($_REQUEST['id_jenbel'])) ;
		$data['kd_akun']    = ucwords(htmlspecialchars($_REQUEST['kd_akun'])) ;
		$data['nm_akun']    = ucwords(htmlspecialchars($_REQUEST['nm_akun'])) ;
		$data['keterangan'] = ucwords(htmlspecialchars($_REQUEST['keterangan'])) ;
		$result             = $model->mupdate($this->table, $data, $this->primaryKey, $id, $this->title);
		$this->redirect('akun');
	}

	public function delete($x)
	{
		$id     = $this->base64url_decode($x);
		$model  = $this->loadModel($this->model);
		$result = $model->mdelete($this->table, $this->primaryKey, $id, $this->title);
		return $result;
	}
    
}