<?php

class Grafik_irada extends Controller {

	private $table      = "ttakwal";
	private $tableTemb  = "ttakwaltemb";
	private $tableProgja= "dja_pagu";
	private $tableFiles = "vt_files";
	private $primaryKey = "wasgiat";
	private $model      = "Grafik_irada_model"; # please write with no space
	private $menu       = "Graphics View";
	private $title      = "Grafik Pelaksanaan Progja Irada";
	private $curl       = BASE_URL."grafik_irada/";
	

	public function __construct()
	{
		$session = $this->loadHelper('Session_helper');
		if(!$session->get('username')){
			$this->redirect('auth/login');
		}
	}
	
	function index()
	{
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$model                    = $this->loadModel($this->model);	
		$data['curl']        = $this->curl;
		$data['id_bidang']   = $model->get_bidang();
		$template            = $this->loadView('grafik_intel_view');
		$template->set('data', $data);
		$template->render();
	}

	function loadProgja()
	{
		$request = $_REQUEST;
		$model   = $this->loadModel($this->model);
		$columns = array(
			// array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'urskmpnen',  'dt' => 1 ),
			array( 'db' => 'progja',   'dt' => 2 ),
			// array( 'db' => 'wasgiat',   'dt' => 3 ),
		);
		$join   = "";
		$sWhere = "";
		$result  = $model->load_progja($request, $this->tableProgja, $this->primaryKey, $columns, $join, $sWhere);

		return json_encode($result);
	}

	function load_Pagu()
	{
		$request = $_REQUEST;
		$model   = $this->loadModel($this->model);
		$columns = array(
			// array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'urskmpnen',  'dt' => 1 ),
			array( 'db' => 'progja',   'dt' => 2 ),
			// array( 'db' => 'wasgiat',   'dt' => 3 ),
		);
		$join   = "";
		$sWhere = "";
		$result  = $model->load_pagu($request, $this->tableProgja, $this->primaryKey, $columns, $join, $sWhere);

		return json_encode($result);
	}

	
	function survey_framework() {    
		$model = $this->loadModel($this->model);
		$data  = $model->hasil_survey();
		return json_encode($data);  
	}

	function loadPagu() {    
		$model = $this->loadModel($this->model);
		$data  = $model->hasil_pagu();
		return json_encode($data);  
	}
}