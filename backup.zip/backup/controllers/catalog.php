<?php

class Catalog extends Controller {

	private $table      = "tbl_catalog";
	private $tableSat   = "vt_upload_catalog";
	private $primaryKey = "autono";
	private $primaryKey2 = "autocode";
	private $model      = "Catalog_model"; # please write with no space
	private $menu       = "Ekstrak Data";
	private $title      = "Master Data Catalog ";
	private $curl       = BASE_URL."catalog/";
	private $curl2      = BASE_URL."catalog";
	

	public function __construct()
    {
        $session = $this->loadHelper('Session_helper');
        if(!$session->get('username')){
        	$this->redirect('auth/login');
        }
    }

	function index()
	{
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['curl']		 = $this->curl;
		$data['curl2']		 = $this->curl2;
		$template            = $this->loadView('catalog_view');
		$template->set('data', $data);
		$template->render();
	}

	function get($x = null)
	{
		$request = $_REQUEST;
		$columns = array(
			array( 'db' => 'autono',      'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'tahun', 'dt' => 1 ),
			array( 'db' => 'file_name','dt' => 2 ),
			array( 'db' => 'autocode','dt' => 3 )			
			
		);

		// $join = "a
		// 		 LEFT JOIN (SELECT nm_satminkal,kd_satminkal AS kode_satminkal FROM tsatminkal ) AS b ON a.satminkal = b.kode_satminkal";

		$model   = $this->loadModel($this->model);
		if($x){
			$result  = $model->mget_detail($request, $this->table, $this->primaryKey, $columns,$join, $id);
		} else {
			$result  = $model->mget($request, $this->table, $this->primaryKey, $columns);
		}

		return json_encode($result);
	}

	public function add()
	{
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Add';
		$data['curl']		 = $this->curl;

        // $data['satminkal']	 = $model->get_satmin();
        // $data['program']	 = $model->get_program();
        // $data['giat']		 = $model->get_kegiatan();
        // $data['output']		 = $model->output();
        // $data['suboutput']   = $model->suboutput();
        // $data['komponen']    = $model->get_komponen();
        // $data['subkomponen'] = $model->get_subkomponen();
        // $data['akun'] 		 = $model->get_akun();

		$template            = $this->loadView('catalog_add');
		$template->set('data', $data);
		$template->render();
	}

	public function edit($x)
	{
		$id                  = $this->base64url_decode($x);
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Edit';
		$data['encode']      = $x;
		$data['curl']		 = $this->curl;
		$data['aadata']      = $model->get($this->table, $this->primaryKey, $id);

		// $data['satminkal']	 = $model->get_satmin();
  //       $data['program']	 = $model->get_program();
  //       $data['giat']		 = $model->get_kegiatan();
  //       $data['output']		 = $model->output();
  //       $data['suboutput']   = $model->suboutput();
  //       $data['komponen']    = $model->get_komponen();
  //       $data['subkomponen'] = $model->get_subkomponen();
  //       $data['akun'] 		 = $model->get_akun();

		$template            = $this->loadView('hps_cur_edit');
		$template->set('data', $data);
		$template->render();
	}

	public function save()

	{


		$data                 = array();

		$model                = $this->loadModel($this->model);
		$data['parent_id']    = $this->base64url_decode($x) ;

		$data['tahun']        = htmlspecialchars($_REQUEST['tahun']) ;
		$data['file_name']    = $_FILES['file_name']['name'] ;
		$data['autocode']     = $model->autocode($this->table, "ctlg_");
		// $s	  				  = $model->aut();
		
		$result               = $model->msave($this->table, $data, $this->title);
		$last_id              = $result['id'];

		$uploadDyn			  = $model->uploadCatalog($_FILES['file_name'],$data['tahun'],$data['autocode']);

		$import_hps		      = $model->import_catalog($data['tahun'], $s,$data['autocode'], $last_id);
        
        $this->redirect('catalog_detail/detail/'.$data['tahun'].'/'.$data['autocode']);
        // $this->redirect('ekstrakhps');
	}

	public function update($x)
	{
		$data           	= array();
		$id             	= $this->base64url_decode($x);
		$model          	= $this->loadModel($this->model);
		$data['satker']     = htmlspecialchars($_REQUEST['satker']) ;
		$data['tahun']      = htmlspecialchars($_REQUEST['tahun']) ;
		$data['file_name']	= htmlspecialchars($_REQUEST['file_name']) ;
		$result         	= $model->mupdate($this->table, $data, $this->primaryKey, $id, $this->title);
		$this->redirect('hps_cur');
	}

	public function delete($x)
	{
		$id        = $this->base64url_decode($x);
		$model     = $this->loadModel($this->model);
		$resultSat = $model->mdelete($this->tableSat,'parent_id', $id, $this->title);
		$result    = $model->mdelete($this->table, $this->primaryKey,$id, $this->title);
		
		
		return $result;
	}

}