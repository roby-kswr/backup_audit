<?php
use XBase\Table;

class Ekstrakdipa extends Controller {

	private $table      = "teksrka";
	private $primaryKey = "autono";
	private $model      = "Ekstrakdipa_model"; # please write with no space
	private $menu       = "Ekstrak Data";
	private $title      = "DIPA";
	private $curl       = BASE_URL."ekstrakdipa/";
	

	public function __construct()
    {
        $session = $this->loadHelper('Session_helper');
        if(!$session->get('username')){
        	$this->redirect('auth/login');
        }
    }

	function index()
	{
		
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['curl']		 = $this->curl;
		$template            = $this->loadView('ekstrakdipa_view');
		$template->set('data', $data);
		$template->render();
	}

	function get()
	{
		$request = $_REQUEST;
		$columns = array(
			array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'nm_satker',  'dt' => 1 ),
			array( 'db' => 'tahun',  'dt' => 2 ),
			array( 'db' => 'file_name',   'dt' => 3 )
		);

		$model   = $this->loadModel($this->model);
		$result  = $model->mget($request, $this->table, $this->primaryKey, $columns);

		return json_encode($result);
	}

	public function add()
	{
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Add';
		$data['curl']		 = $this->curl;
        $data['satker']		 = $model->satker();
		$template            = $this->loadView('ekstrakrka_add');
		$template->set('data', $data);
		$template->render();
	}

	public function edit($x)
	{
		$id                  = $this->base64url_decode($x);
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Edit';
		$data['encode']      = $x;
		$data['curl']		 = $this->curl;
		$data['aadata']      = $model->get($this->table, $this->primaryKey, $id);
		$data['satker']   	 = $model->satker();
		$template            = $this->loadView('ekstrakrka_edit');
		$template->set('data', $data);
		$template->render();
	}

	public function save()

	{

		$model          	     = $this->loadModel($this->model);
		# Insert files
		$files1					 = array();
		$files1['dir'] 			 = "zip";
		$files1['kode_parent'] 	= "DIPA01";
		$files1['subdir'] 		 = "";
		if(!empty($_FILES['file_dipa']['name'][0])) {
		    $file_ary1 = $model->reArrayFiles($_FILES['file_dipa']);
		    foreach ($file_ary1 as $file1) {
				$files1['kode_parent'] = $data['autocode'];
				$files1['parent_id']   = $lastid;
				$files1['nama_file']   = $this->randName($file1['name']);
				$files1['tipe_file']   = $file1['type'];
				$files1['ukuran']      = $file1['size'];
				$files1['ftable']      = $this->table;

				if(!empty($file1['name'])){ $model->savefile($files1); } 
		    }
		}
		# Upload file
		if(isset($_FILES['file_dipa'])){ $model->uploads($files1['dir'], $_FILES['file_dipa'], $files1['kode_parent'], $files1['subdir']); }

		$zip         = new ZipArchive;
		$dir         = ROOT_DIR.'static/files/'.$files1['dir'].'/'.$files1['kode_parent'].'/';
		$filename    = $files1['nama_file'];
		$storagname  = $dir.$filename;
		if ($zip->open($dir.$filename) === TRUE) {
		    $zip->extractTo($dir);
		    $zip->close();
		    $this->redirect('ekstrakdipa');
		} else {
		    echo 'failed';
		}
	}

	public function update($x)
	{
		$data           	= array();
		$id             	= $this->base64url_decode($x);
		$model          	= $this->loadModel($this->model);
		$data['satker']     = htmlspecialchars($_REQUEST['satker']);
		$data['tahun']      = htmlspecialchars($_REQUEST['tahun']) ;
		$data['file_name']	= htmlspecialchars($_REQUEST['file_name']) ;
		$result         	= $model->mupdate($this->table, $data, $this->primaryKey, $id, $this->title);
		$this->redirect('ekstrakrka');
	}

	public function delete($x)
	{
		$id     = $this->base64url_decode($x);
		$model  = $this->loadModel($this->model);
		$result = $model->mdelete($this->table, $this->primaryKey, $id, $this->title);
		return $result;
	}

}