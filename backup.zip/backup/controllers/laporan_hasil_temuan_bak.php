<?php
/**
 * 
 */
class Laporan_hasil_temuan extends Controller
{
	
	function __construct()
	{
		$session = $this->loadHelper('Session_helper');

        if(!$session->get('username')){

        	$this->redirect('auth/login');
        }
	}

	 function index()
    {
         $pdf = $this->loadLibrary('fpdf');
        
         $pdf->setAutoPageBreak(true,27);   
         $pdf->SetMargins(25.4,20.3,15.2,12.7); // Format A4
         $pdf->AddPage('P','A4');
        
         // Kop Surat
         $pdf->SetFont('Arial', '', 10);    
         $pdf->header();
         $pdf->Cell(65, -6, 'MARKAS BESAR ANGKATAN DARAT', 0, 1, 'C');
         $pdf->Cell(64, 15, 'INSPEKTORAT JENDERAL', 0, 1, 'C');
         $pdf->Cell(2);
         $pdf->Cell(62,-5,'','B',1);
         $pdf->Cell(253, 10, 'Bandung,          Mei 2019', 0, 1, 'C');
         $pdf->Ln(5);

         // Content
         $pdf->Cell(25, 5, 'Nomor', 0, 'LTR', 'L');
         $pdf->Cell(-2, 5, ':', 0, 'LTR','C');
         $pdf->Cell(2);
         $pdf->MultiCell(110, 5, 'B/            /           /NHV-Verku.IV2020', 'J');
         $pdf->Cell(28, 5, 'Klasifikasi', 0, 'LTR', 'L');
         $pdf->Cell(-8, 5, ':', 0, 'LTR','C');
         $pdf->Cell(5);
         $pdf->MultiCell(110, 5, 'Biasa', 'J');
         $pdf->Cell(28, 5, 'Lampiran', 0, 'LTR', 'L');
         $pdf->Cell(-8, 5, ':', 0, 'LTR','C');
         $pdf->Cell(5);
         $pdf->MultiCell(110, 5,'', 'J');
         $pdf->Cell(28, 5, 'Perihal', 0, 'LTR', 'L');
         $pdf->Cell(-8, 5, ':', 0, 'LTR','C');
         $pdf->Cell(5);
         $pdf->MultiCell(60, 5, 'Nota Hasil Verifikasi Wabku Bulan Januari 2020', 'J');
         $pdf->Cell(26);
         $pdf->Cell(58,0,'','B',1);
         // $pdf->Line(127, 73, 68, 73);
         $pdf->Ln(5);

         $pdf->Cell(240, 5, 'Kepada', 0, 1, 'C');
         $pdf->Cell(103);
         $pdf->Cell(10, 7, 'Yth.', 0, 0);
         $pdf->MultiCell(220, 7, 'Dirtopad', 0,'J');
         $pdf->Cell(232, 7, 'di', 0, 1, 'C');
         $pdf->Cell(243, 7, 'Bandung', 0, 1, 'C');
         $pdf->Ln(5);

         $pdf->Cell(25, 5, 'U.p.Sekertaris', 0, 'LTR', 'L');
         $pdf->Ln(5);
         $pdf->Cell(10,5,'1.',0,0);
         $pdf->MultiCell(25,5,'Dasar :',0,'J');
         // $pdf->Ln(3);
         $pdf->Cell(15);

         $pdf->Cell(10,5,'a.',0,0);
         $pdf->MultiCell(125,5,'Peraturan kasad Nomor 26 Tahun 2019 tentang Organisasi dan Tugas Inspektorat Jendral TNI Angkatan Darat Lampiran III Organisasi dan Tugas Inspektorat Jendral TNI Angkatan Darat (Orgas Itjenad) uji coba; ',0,'J');
         $pdf->Ln(2);
         $pdf->Cell(15);

         $pdf->Cell(10,5,'b.',0,0);
         $pdf->MultiCell(125,5,'Keputusan Kasad Nomor Skep/574/VIII/2015 tanggal 20 Agustus 2015 Petunjuk teknis tentang  Verifikasi Bidang Keuangan',0,'J');
         $pdf->Ln(2);
         $pdf->Cell(15);

         $pdf->Cell(10,5,'c.',0,0);
         $pdf->MultiCell(125,5,'Surat Keputusan Kasad Nomor Skep/500/IX/1989 tanggal 25 September 1989 tentang Kewajiban dan Wewenang Penertiban Umum dan Pengurusan Pebendaharaan dalam rangka Pengawasan dan Pemeriksaan di Linggkungan TNI AD;dan',0,'J');
         $pdf->Ln(2);
         $pdf->Cell(15);

         $pdf->Cell(10,5,'d.',0,0);
         $pdf->MultiCell(125,5,'Keputusan Irjenad Nomor Skep/01/I/2020 tanggal 2 Januari 2020 tentang Program dan Anggaran Itjenad TA 2020.',0,'J');
         $pdf->Ln(4);
         // $pdf->Cell(20);


         $pdf->Cell(10,1,'',0,1);
         // $pdf->Cell(5);
         $pdf->Cell(10,5,'2. ',0,0);
         $pdf->MultiCell(140,5,'Sesuai dasar tersebut diatas, disampaikan Nota Hasil Verifikasi (NHV) pertanggungjawaban keuangan Dittopad bulan Januari 2020 sebagai berikut : ',0,'J');
         $pdf->Ln(4);

         $pdf->Cell(15);

         $pdf->Cell(10,5,'a. ',0,0);
         $pdf->Cell(110,5,'Pertanggungjawaban keuangan yang sesuai perutukannya  ',0,1);
         $pdf->Ln(5);

         $pdf->Cell(25);
         $pdf->Cell(10,5,'1) ',0,0);
         $pdf->Cell(40,5,'Belanja Perosonel Nihil',0,1);
         $pdf->Cell(25);
         $pdf->Cell(10,5,'2) ',0,0);
         $pdf->Cell(40,5,'Belanja Barang Nihil',0,1);
         $pdf->Cell(25);
         $pdf->Cell(10,5,'3) ',0,0);
         $pdf->Cell(40,5,'Belanja Modal Nihil',0,1);
         $pdf->Ln(4);

         $pdf->Cell(15);
         $pdf->Cell(110,5,'b.   Pertanggungjawaban keuangan yang diragukan kebenarannya  ',0,1);
         $pdf->Ln(5);

         $pdf->Cell(25);
         $pdf->Cell(10,5,'1) ',0,0);
         $pdf->Cell(40,5,'Belanja Perosonel Nihil',0,1);
         $pdf->Cell(25);
         $pdf->Cell(10,5,'2) ',0,0);
         $pdf->Cell(40,5,'Belanja Barang Nihil',0,1);
         $pdf->Cell(25);
         $pdf->Cell(10,5,'3) ',0,0);
         $pdf->Cell(40,5,'Belanja Modal Nihil',0,1);
         $pdf->Ln(4);

         $pdf->Cell(15);
         $pdf->Cell(10,5,'c.',0,0);
         $pdf->MultiCell(130,5,'Pertanggungjawaban keuangan yang tidak dapat dipertanggung jawaban  ',0,1);
         $pdf->Ln(5);

         $pdf->Cell(25);
         $pdf->Cell(10,5,'1) ',0,0);
         $pdf->Cell(40,5,'Belanja Perosonel Nihil',0,1);
         $pdf->Cell(25);
         $pdf->Cell(10,5,'2) ',0,0);
         $pdf->Cell(40,5,'Belanja Barang Nihil',0,1);
         $pdf->Ln(5);

         $pdf->Cell(35);
         $pdf->Cell(10,5,'a) ',0,0);
         $pdf->MultiCell(108,5,'BK 02/l-2020 Pembayaran Tunjangan Kinerja anggota PNS Dittopad bulan Januari 2020 ditemukan pembayaran Tunjangan Kinerja tidak dapat dipertanggung jawab kan sebesar Rp.4.986.000, atas nama :',0,'J');
         $pdf->Ln(4);

         $pdf->Cell(45);
         $pdf->Cell(10,5,'(1)',0,0);
         $pdf->MultiCell(99,5,'PNS Siti Syafani III/b Nip. 1962110619940320001 Jabatan Operator KomInfolahta Dittopad kelahiran 06-11-1962 dengan di bayarkan Tunjangan Kinerja Grade 5 sebesar Rp. 2.493.000 Anggota tersebut sesuai data kelahiran seharusnya MPP Tmt 01-12-2019, surat  perintah tidak bebas tugas dari PDW(Dam/Ka Satminkal) tidak terlampir tetapi tunjangan Kinerja bulan Januari 2020 masih di bayarkan sesuai ketentuan anggota MPP tidak berhak Tunjangan Kinerja',0,'J');   
         $pdf->Ln(3);
         
         $pdf->Cell(45);
         $pdf->Cell(10,5,'(2)',0,0);
         $pdf->MultiCell(99,5,'PNS Rozak III/b Nip. 1962110619940320001 Jabatan Operator Turhitsituasibaggesi subditlahdatatop kelahiran 25-12-1962 dengan bayaran Tunjangan Kinerja Grade 5 sebesar Rp.2.493.000 Anggota tersebut sesuai dengan data kelahiran seharusnya MPP Tmt 01-01-2020, Surat Perintah tidak bebas tugas dari PDW (Dam/ka Satminkal) tidak terlampir tetapi Tunjangan kinerja bulan Januari 2020 masih dibayarkan sesuai ketentuan anggota yang MPP tidak berhak Tunjangan Kinerja ',0,'J');   
         $pdf->Ln(3);

         $pdf->Cell(10,1,'',0,1);
         $pdf->Cell(35);
         $pdf->Cell(10,5,'b) ',0,0);
         $pdf->MultiCell(110,5,'BK 02/l-2020 Pembayaran Tunjangan Kinerja anggota PNS Dittopad bulan Januari 2020 ditemukan pembayaran Tunjangan Kinerja tidak dapat dipertanggung jawab kan sebesar Rp.4.986.000, atas nama :',0,'J');
         $pdf->Ln(2);

         $pdf->Cell(35);
         $pdf->Cell(10,5,'c) ',0,0);
         $pdf->MultiCell(110,5,'BK 02/l-2020 Pembayaran Tunjangan Kinerja anggota PNS Dittopad bulan Januari 2020 ditemukan pembayaran Tunjangan Kinerja tidak dapat dipertanggung jawab kan sebesar Rp.4.986.000, atas nama :',0,'J');
         $pdf->Ln(2); 

         $pdf->Cell(25);
         $pdf->Cell(10,5,'3) ',0,0);
         $pdf->Cell(40,5,'Belanja Modal Nihil',0,1);
         $pdf->Ln(3); 

         $pdf->Cell(10,1,'',0,1);
         // $pdf->Cell(5);
         $pdf->Cell(10,5,'3.',0,0);
         $pdf->MultiCell(145,5,'Jawaban Nota Hasil Verifikasi (NHV) beserta kelengkapan admnistrasi dikirim ke verku itsus Itjenad Jl. Manado No. 8 Bandung Jawa Barat ,Kode Pos 4013 Telpon/Fak 022-4204248 Email Verkubdg@gmail.com. paling lambat 15 hari setelah NHV ini diterima',0,'J');
         $pdf->Ln(3);
         
         $var = "Demikian untuk dimaklumi.";
         if ($var == "Demikian untuk dimaklumi.") {
            $pdf->AddPage('P','A4');
         }
         // $pdf->Cell(5);
         $pdf->Cell(10,5,'4.',0,0);
         $pdf->MultiCell(145,5,$var,0,'J');
         $pdf->Ln(3);
          

         $pdf->Cell(140,5,"a.n Inspektur Jendral Angkatan Darat",0,1,'R');
         $pdf->Cell(126,5,"Inspektur Khusus",0,1,'R');
         $pdf->Cell(116,5,"u.b",0,1,'R');
         $pdf->Cell(120,5,"Kaverku",0,1,'R');
         $pdf->Cell(100 ,10,'',0,1);//end of line
         $pdf->Ln(5);

         $pdf->Cell(115,5,'Tembusan :',0,0);
         $pdf->Cell(8,5,"Drs. Damru",0,1,'R');
         $pdf->Cell(1);
         $pdf->Cell(140,5,"Kolonel Cku NRP 1910002720862",0,1,'R');
         $pdf->Ln(1);

         $pdf->Cell(10,5,'1.',0,0);
         $pdf->Cell(40,5,'Irjenad sebagai laporan',0,1);
         $pdf->Cell(10,5,'2.',0,0);
         $pdf->Cell(40,5,'Irsus Itjenad',0,1);
         $pdf->Cell(10,5,'3.',0,0);
         $pdf->Cell(40,5,'Sekertaris Itjenad',0,1);
         $pdf->Cell(10,5,'4.',0,0);
         $pdf->Cell(40,5,'Irdittopad',0,1);
         $pdf->Cell(10,5,'5.',0,0);
         $pdf->Cell(40,5,'Kakupus I/Ditkuad',0,1);
         $pdf->Cell(10,5,'6.',0,0);
         $pdf->MultiCell(45,5,'Paku Dittopad N.A 2.01.12',0,1);
         $pdf->Cell(53,0,'','B',1);
         // $pdf->Line(95, 105, 43,105);//end of lin
         // $pdf->Ln(2);
         // $pdf->PageNo();
         $pdf->Output();

    } 

   function verku_4()
    {
       $pdf = $this->loadLibrary('fpdf');
         
         // $pdf->setAutoPageBreak(auto,27); 
         
         $pdf->SetMargins(25.4,20.3); // Format A4
         $pdf->AddPage('P','A4');
        
         // Kop Surat
         $pdf->SetFont('Arial', '', 10);    
         $pdf->header();
         $pdf->Cell(65, -6, 'MARKAS BESAR ANGKATAN DARAT', 0, 1, 'C');
         $pdf->Cell(64, 15, 'INSPEKTORAT JENDERAL', 0, 1, 'C');
         $pdf->Cell(2);
         $pdf->Cell(62,-5,'','B',1);
         $pdf->Cell(253, 10, 'Bandung,          Mei 2019', 0, 1, 'C');
         $pdf->Ln(5);

         // Content
         $pdf->Cell(25, 5, 'Nomor', 0, 'LTR', 'L');
         $pdf->Cell(-2, 5, ':', 0, 'LTR','C');
         $pdf->Cell(2);
         $pdf->MultiCell(110, 5, 'B/            /           /NHV-Verku.IV/P/2019', 'J');
         $pdf->Cell(28, 5, 'Klasifikasi', 0, 'LTR', 'L');
         $pdf->Cell(-8, 5, ':', 0, 'LTR','C');
         $pdf->Cell(5);
         $pdf->MultiCell(110, 5, 'Biasa', 'J');
         $pdf->Cell(28, 5, 'Lampiran', 0, 'LTR', 'L');
         $pdf->Cell(-8, 5, ':', 0, 'LTR','C');
         $pdf->Cell(5);
         $pdf->MultiCell(110, 5,'', 'J');
         $pdf->Cell(28, 5, 'Perihal', 0, 'LTR', 'L');
         $pdf->Cell(-8, 5, ':', 0, 'LTR','C');
         $pdf->Cell(5);
         $pdf->MultiCell(60, 5, 'NHV Penutup wabku bulan Januari 2020', 'J');
         $pdf->Cell(26);
         $pdf->Cell(58,0,'','B',1);
         // $pdf->Line(127, 73, 68, 73);
         $pdf->Ln(5);

         $pdf->Cell(240, 5, 'Kepada', 0, 1, 'C');
         $pdf->Cell(103);
         $pdf->Cell(10, 7, 'Yth.', 0, 0);
         $pdf->MultiCell(36, 7, 'Danpussenarmed', 0,'J');
         $pdf->Cell(232, 7, 'di', 0, 1, 'C');
         $pdf->Cell(243, 7, 'Cimahi', 0, 1, 'C');
         $pdf->Ln(5);

         $pdf->Cell(25, 5, 'U.p.Dirum', 0, 'LTR', 'L');
         $pdf->Ln(5);
         $pdf->Cell(10,5,'1.',0,0);
         $pdf->MultiCell(140,5,'Dasar :',0,'J');
         // $pdf->Ln(3);
         $pdf->Cell(15);

        $pdf->Cell(10,5,'a.',0,0);
         $pdf->MultiCell(125,5,'Keputusan Kasad Nomor Skep/574/VIII/2015 tanggal 20 Agustus 2015 Petunjuk teknis tentang  Verifikasi Bidang Keuangan;',0,'J');
         $pdf->Ln(2);
         $pdf->Cell(15);

         $pdf->Cell(10,5,'b.',0,0);
         $pdf->MultiCell(125,5,'Peraturan kasad Nomor 26 Tahun 2019 tentang Organisasi dan Tugas Markas Besar TNI AD Lampiran III Organisasi dan Tugas Inspektorat Jendral TNI Angkatan Darat Lampiran III Organisasi dan Tugas Inspektorat Jendral TNI Angkatan Darat (Orgas Itjenad) uji coba;',0,'J');
         $pdf->Ln(2);
         $pdf->Cell(15);

         $pdf->Cell(10,5,'c.',0,0);
         $pdf->MultiCell(125,5,'Keputusan Irjenad Nomor B/644/V/NHV-Verku.IV/2020 tanggal 20-5-2020 tentang Nota Hasil Verifikasi pada wabku bulan Januari 2020;dan',0,'J');
         $pdf->Ln(2);
         $pdf->Cell(15);

         $pdf->Cell(10,5,'d.',0,0);
         $pdf->MultiCell(125,5,'Surat Danpussenarmed Nomor B/834/V/2020 tanggal 29-5-2020 tentang Jawaban NHV Itjenad',0,'J');
         $pdf->Ln(2);
         $pdf->Cell(20);

         $pdf->Cell(10,1,'',0,1);
         // $pdf->Cell(5);
         $pdf->Cell(10,5,'2. ',0,0);
         $pdf->MultiCell(140,5,'Setelah mempelajari jawaban/tanggapan yang tertuang dalam Surat tersebut 1.d diatas dengan ini disampaikan bahwa permaasalahan yang dinotakan telah terjawab dan dapat diterima;',0,'J');
         $pdf->Ln(4);
         $pdf->Cell(15);

         $pdf->Cell(10,1,'',0,1);
         $pdf->Cell(10,5,'3.',0,0);
         $pdf->MultiCell(140,5,'Dengan demikian maka NHV Irjenad yang tertuang dalam surat tersebut 1.c diatas dinyatakan ditutup dan selesai;dan',0,'J');
         $pdf->Ln(5);
         
         $pdf->CheckPageBreak(73.7);
         // if ($s < 27 ) {
         //     $v = $pdf->Ln(5);
         // }else if($s == 27){
         //    $v =$pdf->AddPage();
         // }   
         // $pdf->Cell(5);
         $pdf->Cell(10,5,'4.',0,0);
         $pdf->MultiCell(145,5,'Demikian untuk dimaklumi. ',0,'J');
         $pdf->Ln(3);
         // $pdf->Cell(80); 

         $pdf->Cell(140,5,"a.n Inspektur Jendral Angkatan Darat",0,1,'R');
         $pdf->Cell(126,5,"Inspektur Khusus",0,1,'R');
         $pdf->Cell(116,5,"u.b",0,1,'R');
         $pdf->Cell(120,5,"Kaverku",0,1,'R');
         $pdf->Cell(100 ,10,'',0,1);//end of line
         $pdf->Ln(5);

         $pdf->Cell(125,5,'Tembusan :',0,0);
         $pdf->Cell(8,5,"Drs.E. Bambang Widoyoko",0,1,'R');
         $pdf->Cell(1);
         $pdf->Cell(130,5,"Kolonel Cku NRP 33754",0,1,'R');
         $pdf->Ln(1);

          $pdf->Cell(10,5,'1.',0,0);
         $pdf->Cell(40,5,'Irjenad sebagai laporan',0,1);
         $pdf->Cell(10,5,'2.',0,0);
         $pdf->Cell(40,5,'Irsus Itjenad',0,1);
         $pdf->Cell(10,5,'3.',0,0);
         $pdf->Cell(40,5,'Sekertaris Itjenad',0,1);
         $pdf->Cell(10,5,'4.',0,0);
         $pdf->Cell(40,5,'Irkodiklat',0,1);
         $pdf->Cell(10,5,'5.',0,0);
         $pdf->Cell(40,5,'Kakupus II/Ditkuad',0,1);
         $pdf->Cell(10,5,'6.',0,0);
         $pdf->Cell(40,5,'Paku Pussenarmed N.A 2.02.04',0,1);
         $pdf->Cell(62,0,'','B',1);

         
         // $pdf->Line(95, 105, 43,105);//end of lin
         // $pdf->Ln(2);
         // $pdf->PageNo();
         $pdf->Output();
    }

}