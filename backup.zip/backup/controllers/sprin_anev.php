<?php

class Sprin_anev extends Controller {

	private $table      = "tsprin";
	private $tableTemb  = "tsprintemb";
	private $tablePers  = "tsprinpers";
	private $primaryKey = "autono";
	private $model      = "Sprin_model"; # please write with no space
	private $menu       = "Transaksi";
	private $title      = "Sprin View";
	private $curl       = BASE_URL."sprin_anev/";
	
	public function __construct()
    {
        $session = $this->loadHelper('Session_helper');
        if(!$session->get('username')){
        	$this->redirect('auth/login');
        }
    }
	
	function index()
	{
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['curl']        = $this->curl;
		$template            = $this->loadView('sprin_anev_view');
		$template->set('data', $data);
		$template->render();
	}

	function get()
	{
		$request = $_REQUEST;
		$columns = array(
			array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'no_pkpt',  'dt' => 1 ),
			array( 'db' => 'no_sprin',   'dt' => 2 ),
			array( 'db' => 'tgl_sprin',   'dt' => 3 ),
			array( 'db' => 'file_name',   'dt' => 4 ),
		);

		$join   = "a LEFT JOIN (SELECT autono AS kd_pkpt, nomor_pkpt AS no_pkpt FROM tpkpt) AS b ON a.id_pkpt=b.kd_pkpt";
		$model  = $this->loadModel($this->model);
		$result = $model->mget($request, $this->table, $this->primaryKey, $columns, $join);

		return json_encode($result);
	}


	function loadPers($id)
	{
		$request = $_REQUEST;
		$model   = $this->loadModel($this->model);
		$id      = $this->base64url_decode($id);
		$last_id = $model->get_maxId($this->table);
		$columns = array(
			array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'nama',  'dt' => 1 ),
			array( 'db' => 'nm_pangkat',   'dt' => 2 ),
			array( 'db' => 'nm_korps',   'dt' => 3 ),
			array( 'db' => 'nrp',   'dt' => 4 ),
			array( 'db' => 'jabatan',   'dt' => 5 ),
			array( 'db' => 'nm_jabatan_wasrik',   'dt' => 6 ),
			array( 'db' => 'nm_kotama',   'dt' => 7 )
		);
		$join   = "LEFT JOIN (SELECT autono AS kd_pers, nrp, nama, id_korps, id_pangkat, jabatan FROM tpers) b ON a.id_personel = b.kd_pers
				   LEFT JOIN (SELECT autono as kd_pangkat, nm_pangkat FROM tpangkat) c ON b.id_pangkat = c.kd_pangkat
				   LEFT JOIN (SELECT autono as kd_korps, nm_korps FROM tkorps) d ON b.id_korps = d.kd_korps
				   LEFT JOIN (SELECT autono as kd_jabwas, nm_jabatan_wasrik FROM tjabatanwasrik) e ON a.id_jabatanwasrik = e.kd_jabwas
				   LEFT JOIN (SELECT autono as kd_kotama, nm_kotama FROM tkotama) f ON FIND_IN_SET (f.kd_kotama, a.id_kotama)";
		if($id)
		{
			$sWhere = "id_sprin = $id";
		} 
		else 
		{
			$sWhere = "id_sprin = $last_id";
		}
	
		$result  = $model->mgetdetail($request, $this->tablePers, $this->primaryKey, $columns, $join, $sWhere);

		return json_encode($result);
	}

	function load_Fpdf($x)
	{
		$model   = $this->loadModel('sprin_model');
		$pdf     = $this->loadLibrary('fpdf');
		$id      = $this->base64url_decode($x);
		$val     = $model->getvalue("SELECT * FROM tsprin WHERE autono = $id");
		$valTemb = $model->query("SELECT nm_tembusan FROM tsprintemb a LEFT JOIN (SELECT autono AS kd_tembusan, nm_tembusan FROM ttembusan) AS b ON a.id_tembusan=b.kd_tembusan WHERE id_sprin = $id");
		$expldD  = explode('<li>', $val['dasar']);
		$expldU  = explode('<li>', $val['untuk']);		
		
		// ** Surat Dinas **
			$pdf->SetMargins(42,10); // Format A4
			$pdf->AddPage('P', 'A4');

			// Kop Surat
			$pdf->SetFont('Arial', '', 10);
			$pdf->Cell(65, 5, 'MARKAS BESAR ANGKATAN DARAT', 0, 1, 'C');
			$pdf->Cell(64, 2, 'INSPEKTORAT JENDERAL', 0, 1, 'C');
			$pdf->Line(44, 25, 105, 25);
			$pdf->Ln(5);

			// Title
			$pdf->Cell(153, 5, 'SURAT PERINTAH', 0, 1, 'C');
			$pdf->Cell(152, 5, 'Nomor Sprin/                /VII/2019', 0, 1, 'C');
			$pdf->Ln(5);

			// Content
			$pdf->Cell(28, 5, 'Menimbang', 0, 'LTR', 'L');
			$pdf->Cell(10, 5, ':', 0, 'LTR','C');
			$pdf->MultiCell(110, 5, strip_tags(preg_replace('/<p[^>]*>/', '        ', $val['menimbang'])), 'J');
			// Dasar
			$pdf->Cell(28, 5, 'Dasar', 0, 'LTR', 'L');
			$pdf->Cell(10, 5, ':', 0, 'LTR','C');
			for ($i=1; $i < count($expldD); $i++){
		   		$pdf->MultiCell(110, 5, $i.'.     '.str_replace(array('</li>','</ol>'), "\r\n", $expldD[$i]), 'J');
		   		$pdf->Cell(28, 5, '', 0, 'LTR', 'L');
		   		$pdf->Cell(10, 5, '', 0, 'LTR','C');	
			}				
			$pdf->ln(-5);
			$pdf->Cell(153, 12, 'DIPERINTAHKAN', 0, 1, 'C');
			// Kepada
			$pdf->Cell(28, 5, 'Kepada', 0, 'LTR', 'L');
			$pdf->Cell(10, 5, ':', 0, 'LTR','C');
			$pdf->MultiCell(110, 5, strip_tags(preg_replace('/<p[^>]*>/', '        ', $val['kepada'])), 'J');
			// Untuk
			$pdf->Cell(28, 5, 'Untuk', 0, 'LTR', 'L');
			$pdf->Cell(10, 5, ':', 0, 'LTR','C');
			for ($i=1; $i < count($expldU); $i++){
		   		$pdf->MultiCell(110, 5, $i.'.     '.str_replace(array('</li>','</ol>'), "\r\n", $expldU[$i]), 'J');
		   		$pdf->Cell(28, 5, '', 0, 'LTR', 'L');
		   		$pdf->Cell(10, 5, '', 0, 'LTR','C');	
			}
			$pdf->ln(0);
			$pdf->Cell(0, 0, 'Selesai.', 0, 1, 'L');
			$pdf->Cell(217, 5, 'Dikeluarkan di Jakarta', 0, 1, 'C');
			$pdf->Cell(237, 3, 'pada tanggal                     Juli 2019', 0, 1, 'C');
			$pdf->Cell(237, 10, 'Inspektur Jenderal Angkatan Darat,', 0, 1, 'C');
			$pdf->Cell(237, 25, 'Suko Pranoto', 0, 1, 'C');
			$pdf->Cell(237, -17, 'Mayor Jenderal TNI', 0, 1, 'C');
			$pdf->Cell(65, 16, 'Tembusan:', 0, 1, 'L');
			$no = 'a';
			foreach ($valTemb as $key => $valueTemb)
			{		  
				if(count($valTemb) > 1){
					$pdf->Cell(65, 4, $no++.'.      '.$valueTemb['nm_tembusan'], 0, 1, 'L');
				}else{
					$pdf->Cell(65, 4, $valueTemb['nm_tembusan'], 0, 1, 'L');
				}
			}

		// ** Daftar Susunan Tim Pengawasan **
			$pdf->SetMargins(33,23); // Format A4 Landscape
			$pdf->AddPage('L', 'A4');

			// Kop Surat
			$pdf->SetFont('Arial', '', 10);
			$pdf->Cell(65, 5, 'MARKAS BESAR ANGKATAN DARAT', 0, 1, 'C');
			$pdf->Cell(64, 2, 'INSPEKTORAT JENDERAL', 0, 1, 'C');
			$pdf->Line(35, 52, 95, 52);
			$pdf->Ln(10);

			// Title
			$pdf->Cell(250, 5, 'DAFTAR SUSUNAN TIM PENGAWASAN CURRENT AUDIT TA 2019', 0, 1, 'C');
			$pdf->Cell(249, 3, 'DI KODAM XII/MDK DAN KODAM IM', 0, 1, 'C');
			$pdf->Ln(5);

			//Table	
			// * Baris Pertama
			$pdf->Cell(22, 5, 'NOMOR', 'LRTB', 0, 'C');
			$pdf->Cell(50, 10, 'NAMA', 'LRT', 0, 'C');
			$pdf->Cell(35, 5, 'PANGKAT,', 'LRT', 0, 'C');
			$pdf->Cell(35, 5, 'JABATAN', 'LRT', 0, 'C');
			$pdf->Cell(37, 5, 'JABATAN DALAM', 'LRT', 0, 'C');
			$pdf->Cell(30, 10, 'SAS SATUAN', 'LRT', 0, 'C');
			$pdf->Cell(29, 5, 'WAKTU', 'LRT', 0, 'C');
			// Total Max 880 Kertas A4
			$pdf->Cell(30, 5, '', 0, 0);
			$pdf->Ln();

			// * Baris Kedua
			$pdf->Cell(12, 5, 'URUT', 'LR', 0, 'C');
			$pdf->Cell(10, 5, 'BAG', 'LR', 0, 'C');
			$pdf->Cell(50, 0, '', 0, 0);
			$pdf->Cell(35, 5, 'KORPS, NRP', 'LR', 0, 'C');
			$pdf->Cell(35, 5, 'KESATUAN', 'LR', 0, 'C');
			$pdf->Cell(37, 5, 'TIM', 'LR', 0, 'C');
			$pdf->Cell(30, 0, '', 'LR', 0, 'C');
			$pdf->Cell(29, 5, 'PELAKSANAAN', 'LR', 0, 'C');
			$pdf->Ln();
						
			// * Kolom Data
			$pdf->SetWidths(array(12,10,50,35,35,37,30,29));
			$pdf->SetAligns(array('C','C','L','L','L','L','C','C'));

			$no = 1;
			$valPers = $model->query("SELECT nama, nm_pangkat, nm_korps, nrp, jabatan, nm_jabatan_wasrik, GROUP_CONCAT(nm_kotama) AS nm_kotama FROM tsprinpers a 
										LEFT JOIN (SELECT autono AS kd_pers, nrp, nama, id_korps, id_pangkat, jabatan FROM tpers) b ON a.id_personel = b.kd_pers
				   						LEFT JOIN (SELECT autono as kd_pangkat, nm_pangkat FROM tpangkat) c ON b.id_pangkat = c.kd_pangkat
				   						LEFT JOIN (SELECT autono as kd_korps, nm_korps FROM tkorps) d ON b.id_korps = d.kd_korps
				  						LEFT JOIN (SELECT autono as kd_jabwas, nm_jabatan_wasrik FROM tjabatanwasrik) e ON a.id_jabatanwasrik = e.kd_jabwas
				   						LEFT JOIN (SELECT autono as kd_kotama, nm_kotama FROM tkotama) f ON FIND_IN_SET (f.kd_kotama, a.id_kotama)
				   					  WHERE id_sprin = $id GROUP BY autono");
			foreach ($valPers as $key => $valuePers)	
			{		  
				$no1 = 1;
				$pdf->Row(
					array($no++,
					$no1++, 
					ucwords(strtolower($valuePers['nama'])),
					// $valuePers['nm_pangkat']." ".$valuePers['nm_korps']."\n".$valuePers['nrp'],
					ucwords(strtolower($valuePers['nm_pangkat'])).' '.$valuePers['nm_korps'],
					ucwords(strtolower($valuePers['jabatan'])),
					ucwords(strtolower($valuePers['nm_jabatan_wasrik'])),
					$valuePers['nm_kotama'],
					$valuePers['terima']
				));
			}

			// if("{nb}"){
			// 	$pdf->Cell(0,-10,'Page '.$pdf->PageNo(),0,0,'C');
			// }

			// Footer
				// global $totalPageForFooter;
				// if($pdf->PageNo() != $totalPageForFooter){
				// 	if($pdf->PageNo() != 1){
				// 		$pdf->SetY(15);
				// 		$pdf->SetFont('Arial', '', 12);
				// 		$pdf->Cell(0, 10,''.$pdf->PageNo(),0,0,'C');
				// 		$pdf->Ln(10);
						
				// 		$pdf->SetFont('Arial', '', 12);
				// 		$pdf->SetY(100);
				// 		$pdf->Cell(12, 5, '1', 'LRT',0,'C');
				// 		$pdf->Cell(10, 5, '2', 'LRT', 0, 'C');
				// 		$pdf->Cell(55, 5, '3', 'LRT', 0, 'C');
				// 		$pdf->Cell(30, 5, '4', 'LRT', 0, 'C');
				// 		$pdf->Cell(35, 5, '5', 'LRT', 0, 'C');
				// 		$pdf->Cell(37, 5, '6', 'LRT', 0, 'C');
				// 		$pdf->Cell(30, 5, '7', 'LRT', 0, 'C');
				// 		$pdf->Cell(29, 5, '8', 'LRT', 0, 'C');
				// 		$pdf->Ln(0);
				// 	}
				// }

		$pdf->Output();
		
	}

	function gets_bulan()
    {
		$id    = $_REQUEST['id_pkpt'];
		$model = $this->loadModel($this->model);
		$data  = $model->mget_bulan($id);
        echo json_encode($data);
    } 

    function gets_kotama()
    {
		$id    = $_REQUEST['parent_id'];
		$model = $this->loadModel($this->model);
		$data  = $model->mget_kotama($id);
        echo json_encode($data);
    } 
}