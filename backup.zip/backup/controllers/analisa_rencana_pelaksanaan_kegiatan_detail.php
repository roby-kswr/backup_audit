<?php



class Analisa_rencana_pelaksanaan_kegiatan_detail extends Controller {



	private $table      = "vt_verku_renlak_detail";

	private $primaryKey = "autono";

	private $model      = "Analisa_rencana_pelaksanaan_kegiatan_detail_model";

	private $menu       = "Analisa";

	private $title      = "Rencana Pelaksanaan Kegiatan Detail";

	private $curl       = BASE_URL."analisa_rencana_pelaksanaan_kegiatan_detail";

	



	public function __construct()

    {

        $session = $this->loadHelper('Session_helper');

        if(!$session->get('username')){

        	$this->redirect('auth/login');

        }

    }

	

	function index()

	{

		$data                = array();

		$data['breadcrumb1'] = $this->menu;

		$data['title']       = $this->title;

		$data['curl']	     = $this->curl;

		$template            = $this->loadView('analisa_rencana_pelaksanaan_kegiatan_detail_view');

		$template->set('data', $data);

		$template->render();

	}



	public function detail($x,$y,$z,$za,$zb)

	{

		$uri = $this->loadHelper('Url_helper');

		$data                = array();

		$data['tahun']		 = $uri->segment(3);

		$data['bulan']		 = $uri->segment(4);

		// $data['kotama']		 = $uri->segment(5);

		// $data['satminkal']		 = $uri->segment(6);

		$data['breadcrumb1'] = $this->menu;

		$data['title']       = $this->title;

		$data['curl']	     = $this->curl;

		$data['encode']      = $x;

		$data['tahun']      = $y;

		$data['bulan'] 		 = $z;

		$data['kotama']      = $za;

		$data['satminkal'] 	 = $zb;

		$template            = $this->loadView('analisa_rencana_pelaksanaan_kegiatan_detail_view');

		$template->set('data', $data);

		$template->render();

	}



	function get($x = null, $y = null, $z = null, $za = null, $zb = null)

	{

		$request    = $_REQUEST;

		$id         = $this->base64url_decode($x);

		$columns = array(

			array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),

			array( 'db' => 'upload',  'dt' => 1 ),array( 'db' => 'keterangan',  'dt' => 2 ),array( 'db' => 'nm_renlak',  'dt' => 3 ),

		);



		$model   = $this->loadModel($this->model);
		$join   = "a LEFT JOIN (SELECT autono AS kd_renlak, nm_renlak FROM trenlak ) AS b ON a.kategori = b.kd_renlak";
		if($x){

			$result  = $model->mget_detail($request, $this->table, $this->primaryKey, $columns, $id,$y,$z,$za,$zb,$join);

		} else {

			$result  = $model->mget($request, $this->table, $this->primaryKey, $columns);

		}



		return json_encode($result);

	}



	public function add($x = null,$y = null,$z = null, $za = null, $zb = null)

	{
		$uri = $this->loadHelper('Url_helper');

		$model               = $this->loadModel($this->model);

		$data                = array();

		$data['tahun']		 = $uri->segment(3);

		$data['bulan']		 = $uri->segment(4);

		$data['breadcrumb1'] = $this->menu;

		$data['title']       = $this->title;

		$data['action']      = 'Add';

		$data['curl']	     = $this->curl;

		$data['encode']      = $x;

		$data['tahun']      = $y;

		$data['bulan'] 		 = $z;

		$data['kotama']      = $za;

		$data['satminkal'] 	 = $zb;

		$template            = $this->loadView('analisa_rencana_pelaksanaan_kegiatan_detail_add');

		$data['kategori']   = $model->get_verku_ren($data['kotama'],$data['satminkal'],$data['tahun'],$data['bulan']);

		$template->set('data', $data);

		$template->render();

	}



	public function edit($x,$y = null,$z = null,$zz = null, $za = null, $zb = null)

	{

		$id                  = $this->base64url_decode($x);

		$model               = $this->loadModel($this->model);

		$uri                 = $this->loadHelper('Url_helper');

		$data                = array();

		// $data['tahun']		 = $uri->segment(7);

		// $data['bulan']		 = $uri->segment(8);

		$data['breadcrumb1'] = $this->menu;

		$data['title']       = $this->title;

		$data['action']      = 'Edit';

		$data['encode']      = $x;

		$data['keyy']      = $y;

		$data['tahun']      = $z;

		$data['bulan'] 		 = $zz;

		$data['kotama']      = $za;

		$data['satminkal'] 	 = $zb;

		$data['curl']	     = $this->curl;

		$data['child']       = $uri->segment(5);

		$data['aadata']      = $model->get($this->table, $this->primaryKey, $id);

		$template            = $this->loadView('analisa_rencana_pelaksanaan_kegiatan_detail_edit');

		$data['kategori']   = $model->get_verku_ren2();

		$template->set('data', $data);

		$template->render();

	}



	public function save($x = null,$y = null,$z = null, $za = null, $zb = null)

	{
		$uri = $this->loadHelper('Url_helper');

		

		$data                 = array();

		

		$model                = $this->loadModel($this->model);

		$data['parent_id']    = $this->base64url_decode($x) ;

		$data['tahun']		 = $uri->segment(5);

		$data['bulan']		 = $uri->segment(6);

		$data['kotama']		 = $uri->segment(7);

		$data['satminkal']		 = $uri->segment(8);

		$data['kategori']     = htmlspecialchars($_REQUEST['kategori']) ;
		$data['upload']        = $_FILES['upload']['name'] ;
		$data['keterangan'] = htmlspecialchars($_REQUEST['keterangan']) ;


		$data['autocode']     = $model->autocode($this->table, "#autocode#");	



		$uploadDyn			 = $model->uploadRenlak($_FILES['upload'],$data['kotama'],$data['satminkal'],$data['tahun'],$data['bulan'],'renlak_verku');

		$result               = $model->msave($this->table, $data, $this->title);

		if($x){

			$this->redirect('analisa_rencana_pelaksanaan_kegiatan_detail/detail/'.$x.'/'.$data['tahun'].'/'.$data['bulan'].'/'.$data['kotama'].'/'.$data['satminkal']);

		} else {

			$this->redirect('analisa_rencana_pelaksanaan_kegiatan_detail');

		}

	}



	public function update($x,$y = null,$z = null,$zz = null, $za = null, $zb = null)

	{

		$data               = array();

		$id                 = $this->base64url_decode($x);

		$model              = $this->loadModel($this->model);

		$uri                = $this->loadHelper('Url_helper');

		$child              = $uri->segment(5);

		$parent_id = $this->base64url_decode($uri->segment(5));

		// $data['keyy']      = $y;

		$tahun      = $uri->segment(6);

		$bulan 		 = $uri->segment(7);

		$kotama      = $uri->segment(8);

		$satminkal 		 = $uri->segment(9);

		$data['kategori']  = htmlspecialchars($_REQUEST['kategori']) ;

		if ($_FILES['upload']['name']!='')
		{ $data['upload']        = $_FILES['upload']['name'] ; 
		 $uploadDyn			 = $model->uploadRenlak_update($_FILES['upload'],$data['kotama'],$data['satminkal'],$tahun,$bulan,'renlak_verku');
			}

		$data['keterangan'] = htmlspecialchars($_REQUEST['keterangan']) ;
	

		$result             = $model->mupdate($this->table, $data, $this->primaryKey, $id, $this->title);

		if($child){

			$this->redirect('analisa_rencana_pelaksanaan_kegiatan_detail/detail/'.$child.'/'.$tahun.'/'.$bulan.'/'.$kotama.'/'.$satminkal);

		} else {

			$this->redirect('analisa_rencana_pelaksanaan_kegiatan_detail');

		}

	}



	public function delete($x)

	{

		$id                 = $this->base64url_decode($x);

		$model              = $this->loadModel($this->model);

		$result             = $model->mdelete($this->table, $this->primaryKey, $id, $this->title);

		return $result;

	}

    

}