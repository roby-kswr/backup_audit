<?php



class Dasar_tup_verku extends Controller {



	private $table      = "vt_verku_tup_dasar";

	private $table2      = "vt_verku_temuan";

	private $primaryKey = "autono";

	private $primaryKey2 = "kategori";

	private $primaryKey3 = "tahun";

	private $primaryKey4 = "bulan";

	private $primaryKey5 = "kotama";

	private $primaryKey6 = "satminkal";

	private $model      = "Dasar_tup_verku_model";

	private $menu       = "Analisa";

	private $title      = "Dasar TUP Verifikasi Keuangan";

	private $curl       = BASE_URL."dasar_tup_verku";

	private $curl2       = BASE_URL."analisa_tup_verku";

	

	public function __construct()

    {

        $session = $this->loadHelper('Session_helper');

        if(!$session->get('username')){

        	$this->redirect('auth/login');

        }

    }

	

	function index()

	{

		$data                = array();

		$data['breadcrumb1'] = $this->menu;

		$data['title']       = $this->title;

		$data['curl']	     = $this->curl;

		$template            = $this->loadView('dasar_tup_verku_view');

		$template->set('data', $data);

		$template->render();

	}



	public function detail($x,$y,$z,$za)

	{

		$uri = $this->loadHelper('Url_helper');

		$data                = array();

		$data['tahun']		 = $uri->segment(4);

		$data['bulan']		 = $uri->segment(5);

		$data['kotama']		 = $uri->segment(6);

		$data['satminkal']		 = $uri->segment(7);

		// $data['satker']		 = $uri->segment(5);

		$data['breadcrumb1'] = $this->menu;

		$data['title']       = $this->title;

		$data['curl']	     = $this->curl;

		$data['curl2']	     = $this->curl2;

		// $data['encode']      = $x;

		$data['tahun']      = $x;

		$data['bulan']      = $y;

		$data['kotama'] 		 = $z;

		$data['satminkal'] 	 = $za;

		// echo $data['satminkal'];exit;


		

		$template            = $this->loadView('dasar_tup_verku_view');

		$template->set('data', $data);

		$template->render();

	}



	function get($x = null, $y = null, $z = null, $za = null)

	{
		
		$request    = $_REQUEST;

		$id         = $this->base64url_decode($x);

		$columns = array(

			array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),

			array( 'db' => 'order',  'dt' => 1 ),array( 'db' => 'keterangan',  'dt' => 2 ),array('db'=>'ket2','dt'=>3),array('db'=>'parent_id','dt'=>4),
		);


		$model   = $this->loadModel($this->model);

		
		if($x){

			$result  = $model->mget_detail($request, $this->table, $this->primaryKey, $columns,$x,$y,$z,$za);

		} else {

			$result  = $model->mget($request, $this->table, $this->primaryKey, $columns);

		}



		return json_encode($result);

	}



	public function add($x = null,$y = null,$z = null)

	{

		$uri = $this->loadHelper('Url_helper');

		$model               = $this->loadModel($this->model);

		$data                = array();

		$data['tahun']		 = $uri->segment(4);

		$data['bulan']		 = $uri->segment(5);

		$data['kotama']		 = $uri->segment(6);

		$data['satminkal']		 = $uri->segment(7);

		$data['breadcrumb1'] = $this->menu;

		$data['title']       = $this->title;

		$data['action']      = 'Add';

		$data['curl']	     = $this->curl;

		$data['encode']      = $x;

		// $data['tahun']      = $y;

		// $data['bulan'] 		 = $z;

		$template            = $this->loadView('dasar_tup_verku_add');

		$data['kat']   = $model->get_dasar_tup_verku($data['tahun'],$data['bulan'],$data['kotama'],$data['satminkal']);

		$template->set('data', $data);

		$template->render();

	}


	public function edit($x,$y = null)

	{

		$id                  = $this->base64url_decode($x);

		$model               = $this->loadModel($this->model);

		$uri                 = $this->loadHelper('Url_helper');

		$data                = array();

		// $data['tahun']		 = $uri->segment(7);

		// $data['bulan']		 = $uri->segment(8);

		// $parent_id = $this->base64url_decode($x);

		$data['breadcrumb1'] = $this->menu;

		$data['title']       = $this->title;

		$data['action']      = 'Edit';

		$data['encode']      = $x;

		$data['keyy']      = $y;

		$data['tahun']		 = $uri->segment(5);

		$data['bulan']		 = $uri->segment(6);

		$data['kotama']		 = $uri->segment(7);

		$data['satminkal']		 = $uri->segment(8);

		$data['curl']	     = $this->curl;	

		$data['child']       = $uri->segment(5);

		$data['aadata'] 	 = $model->get($this->table, $this->primaryKey, $id); 

		// $data['aadata']      = $model->getvalue("SELECT * FROM vt_verku_temuan WHERE kotama = '$data[kotama]' AND satminkal = '$data[satminkal]' AND kategori = '$data[kategori]' AND tahun = '$data[tahun]' AND bulan = '$data[bulan]'");

		$template            = $this->loadView('dasar_tup_verku_edit');

		$data['kat']   = $model->get_dasar_tup_verku($data['tahun'],$data['bulan'],$data['kotama'],$data['satminkal'],$data['satminkal']);

		$template->set('data', $data);

		$template->render();

	}



	public function save($x = null, $y = null)

	{
		$uri = $this->loadHelper('Url_helper');

		 $data                 = array();	


		$model                = $this->loadModel($this->model);

		// $data['parent_id']    = $this->base64url_decode($x) ;

		$data['tahun']		 = $uri->segment(4);

		$data['bulan']		 = $uri->segment(5);
// echo $data['bulan'];exit;
		$data['kotama']		 = $uri->segment(6);

		$data['satminkal']		 = $uri->segment(7);


	     $data['parent_id']   = htmlspecialchars($_REQUEST['temuan']) ;
		
		$data['keterangan'] = htmlspecialchars_decode($_REQUEST['keterangan']) ;

		$data['order']   = htmlspecialchars($_REQUEST['order']) ;


	    // $data['autocode']     = $model->autocode($this->table, "#autocode#");	



	  // $uploadDyn			 = $model->uploadRenlak($_FILES['upload'],$data['parent_id'],$data['tahun'],$data['bulan'],'renlak_verku');

		$result               = $model->msave($this->table, $data, $this->title);

		if($x){

			$this->redirect('dasar_tup_verku/detail/'.$data['tahun'].'/'.$data['bulan'].'/'.$data['kotama'].'/'.$data['satminkal']);

		} else {

			$this->redirect('dasar_tup_verku');

		}

	}


	



	public function update($x,$y = null,$z = null,$zz = null)

	{

		$data               = array();

		$id                 = $this->base64url_decode($x);

		$model              = $this->loadModel($this->model);

		$uri                = $this->loadHelper('Url_helper');

		$child              = $uri->segment(4);

		$parent_id          = $this->base64url_decode($y);

		$key               = $y;

		$tahun      	     = $uri->segment(5);

		$bulan 		 	     = $uri->segment(6);

		$kotama 		     = $uri->segment(7);

		$satminkal 		     = $uri->segment(8);	

		$data['tahun']       = $uri->segment(5);

		// echo $data['tahun'];exit;

		$data['bulan']       = $uri->segment(6);

		$data['kotama']		 = $uri->segment(7);

				// echo $data['kotama'];exit;

		$data['satminkal']	 = $uri->segment(8);


		// echo $data['kotama'];exit;
		$data['parent_id']  = htmlspecialchars($_REQUEST['temuan']);

		$data['order']  = htmlspecialchars($_REQUEST['order']) ;

		$data['keterangan'] = htmlspecialchars($_REQUEST['keterangan']) ;

		 $result             = $model->mupdate($this->table, $data, $this->primaryKey,$id,$this->menu);

		if($child){

			$this->redirect('dasar_tup_verku/detail/'.$tahun.'/'.$bulan.'/'.$data['kotama'].'/'.$data['satminkal']);

		} else {

			$this->redirect('dasar_tup_verku');

		}

	}



	public function delete($x)

	{

		$id                 = $this->base64url_decode($x);

		$model              = $this->loadModel($this->model);

		$result             = $model->mdelete($this->table, $this->primaryKey, $id, $this->title);

		return $result;

	}

    

}