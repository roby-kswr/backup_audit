<?php

class Renlak extends Controller {

	private $table      = "trenlak";
	private $primaryKey = "autono";
	private $model      = "Renlak_model"; # please write with no space
	private $menu       = "Reference";
	private $title      = "Renlak";
	private $curl       = BASE_URL."renlak/";
	

	public function __construct()
    {
        $session = $this->loadHelper('Session_helper');
        if(!$session->get('username')){
        	$this->redirect('auth/login');
        }
    }
	
	function index()
	{
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['curl']        = $this->curl;
		$template            = $this->loadView('renlak_view');
		$template->set('data', $data);
		$template->render();
	}

	function get()
	{
		$request = $_REQUEST;
		$columns = array(
			array( 'db' => 'autono', 'dt' => 0, 'formatter' => function( $d, $row ) { return $this->base64url_encode($d); } ),
			array( 'db' => 'nm_ren',  'dt' => 1 ),
			array( 'db' => 'nm_renlak',  'dt' => 2 ),
			array( 'db' => 'keterangan',   'dt' => 3 )
		);

		$join   = "a LEFT JOIN (SELECT autono AS kd_ren, nm_ren FROM tren ) AS b ON a.id_renlak = b.kd_ren";
		$model  = $this->loadModel($this->model);
		$result = $model->mget($request, $this->table, $this->primaryKey, $columns, $join);

		return json_encode($result);
	}

	public function add()
	{
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Add';
		$data['curl']        = $this->curl;
		$template            = $this->loadView('renlak_add');
		$data['id_renlak']   = $model->get_ren();
		$template->set('data', $data);
		$template->render();
	}

	public function edit($x)
	{
		$id                  = $this->base64url_decode($x);
		$model               = $this->loadModel($this->model);
		$data                = array();
		$data['breadcrumb1'] = $this->menu;
		$data['title']       = $this->title;
		$data['action']      = 'Edit';
		$data['encode']      = $x;
		$data['curl']        = $this->curl;
		$data['aadata']      = $model->get($this->table, $this->primaryKey, $id);
		$data['id_renlak']   = $model->get_ren();
		$template            = $this->loadView('renlak_edit');
		$template->set('data', $data);
		$template->render();
	}

	public function save()
	{
		$data                = array();
		$model               = $this->loadModel($this->model);
		$data['id_renlak']   = htmlspecialchars($_REQUEST['id_renlak']) ;
		$data['nm_renlak'] = ucwords(htmlspecialchars($_REQUEST['nm_renlak'])) ;
		$data['keterangan']  = ucwords(htmlspecialchars($_REQUEST['keterangan'])) ;
		$data['autocode']    = $model->autocode($this->table, "REN_");	
		$result              = $model->msave($this->table, $data, $this->title);
		$this->redirect('renlak');
	}

	public function update($x)
	{
		$data                = array();
		$id                  = $this->base64url_decode($x);
		$model               = $this->loadModel($this->model);
		$data['id_renlak']   = htmlspecialchars($_REQUEST['id_renlak']) ;
		$data['nm_renlak'] = ucwords(htmlspecialchars($_REQUEST['nm_renlak'])) ;
		$data['keterangan']  = ucwords(htmlspecialchars($_REQUEST['keterangan'])) ;
		$result              = $model->mupdate($this->table, $data, $this->primaryKey, $id, $this->title);
		$this->redirect('renlak');
	}

	public function delete($x)
	{
		$id     = $this->base64url_decode($x);
		$model  = $this->loadModel($this->model);
		$result = $model->mdelete($this->table, $this->primaryKey, $id, $this->title);
		return $result;
	}
    
}