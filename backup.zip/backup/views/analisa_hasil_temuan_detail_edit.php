<?php include('header.php'); ?>
              <!-- Page header -->
              <div class="page-header">
                <div class="page-header-content">
                  <div class="page-title">
                    <h4><i class="icon-arrow-left52 position-left"></i> <span class="text-semibold"><?php echo $data['breadcrumb1']; ?></span> - <?php echo $data['title'] ?></h4>
                  </div>
                </div>

                <div class="breadcrumb-line">
                  <ul class="breadcrumb">
                    <li><a href="<?php echo BASE_URL ?>"><i class="icon-home2 position-left"></i> Home</a></li>
                    <li><a href="<?php echo $data['curl'] ?>"><?php echo $data['breadcrumb1'] ?></a></li>
                    <li><a href="<?php echo $data['curl'] ?>"><?php echo $data['title'] ?></a></li>
                    <li class="active"><?php echo $data['action'] ?></li>
                  </ul>
                </div>
              </div>
              <!-- /page header -->

              <!-- Content area -->
              <div class="content">
                <div class="panel panel-flat">
                    <div class="panel-heading">
                      <h5 class="panel-title"><strong><?php echo $data['action'] ?></strong> <?php echo $data['title'] ?></h5>
                      <div class="heading-elements">
                        <ul class="icons-list">
                          <li><a data-action="collapse"></a></li>
                          <li><a data-action="reload"></a></li>
                          <li><a data-action="close"></a></li>
                        </ul>
                      </div>
                    </div>
                    <div class="panel-body">
                      <form class="form-horizontal" action="<?php echo $data['curl']."update/".$data['tahun']."/".$data['bulan'].'/'.$data['kotama'].'/'.$data['satminkal'].'/'.$data['child']; ?>" method="post" enctype="multipart/form-data">
                        <fieldset class="content-group">

                          <?// echo $data['aadata']['nomor_nhv']?>
                         <div class="form-group">
                            <label class="control-label col-lg-2">Klasifikasi</label>
                            <div class="col-lg-10" style="width: 500px;">
                             <input type="text" class="form-control" name="klasifikasi" value="<?php echo $data['aadata']['klasifikasi'] ?>">
                            </div>
                          </div>
                        <div class="form-group">
                            <label class="control-label col-lg-2">Lampiran</label>
                            <div class="col-lg-10" style="width: 500px;">
                             <input type="text" class="form-control" name="lampiran" value="<?php echo $data['aadata']['lampiran'] ?>">
                            </div>
                          </div>

                          <div class="form-group">
                            <label class="control-label col-lg-2">Perihal</label>
                            <div class="col-lg-10" style="width: 500px;">
                             <input type="text" class="form-control" name="perihal" value="<?php echo $data['aadata']['perihal'] ?>">
                            </div>
                          </div>

                        <div class="form-group">
                        <label class="control-label col-lg-2">Tanda Tangan<span class="text-danger">*</span></label>
                        <div class="input-group" style="width: 590px; padding-left: 10px;">
                          <div class="input-group-addon"><i class="icon-list-unordered"></i></div>
                          <select data-placeholder="Pilih Tolak Ukur NHV" class="select-search required" id="tanda_tangan" name="tanda_tangan">
                            <option></option>
                              <?php 
                              foreach ($data['tanda_tangan'] as $key => $tanda_tangan) { 
                                if($data['aadata']['tanda_tangan'] == $tanda_tangan[0])
                                {
                                  echo "<option value=\"".$tanda_tangan[0]."\" selected>".$tanda_tangan[0].$tanda_tangan[1]."</option>"."\n";
                                } 
                                else
                                {
                                  echo "<option value=\"".$tanda_tangan[0]."\">".$tanda_tangan[0].'-'.$tanda_tangan[1]."</option>"."\n";
                                }
                              } 
                              ?>
                          </select>
                        </div>
                      </div>


                      <div class="form-group">
                  <label class="control-label text-bold col-lg-2">Tembusan <span class="text-danger">*</span></label>
                  <div class="multi-select-full col-lg-6">
                    <select class="multiselect-select-all-filtering" multiple="multiple" id="temb" name="temb[]">
                      <?php foreach ($data['id_tembusan'] as $key => $value) { echo "<option value=\"".$value[0]."\" ".$value[2].">".$value[1]."</option>"."\n";} ?>
                    </select>
                  </div>
                  <span>&nbsp;</span>
                </div>   
                             
                        </fieldset>
                        <div class="text-right">
                           <a href="<?php echo $data['curl']."detail"."/".$data['child']."/".$data['tahun']."/".$data['bulan']."/".$data['kotama']."/".$data['satminkal']; ?>" class="btn btn-danger btn-sx"><i class="icon-circle-left2 position-left"></i> Cancel</a> 
                          <button type="submit" class="btn btn-primary">Submit <i class="icon-circle-right2 position-right"></i></button>
                        </div>
                      </form>
                    </div>

       
          
<?php include('footer.php'); ?>