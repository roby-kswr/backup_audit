<?php include('header.php'); ?>
<!-- Page header -->
<div class="page-header">
	<div class="page-header-content">
		<div class="page-title">
			<h4><i class="icon-arrow-left52 position-left"></i> <span class="text-semibold"><?php echo $data['breadcrumb1']; ?></span> - <?php echo $data['title']; ?></h4>
		</div>
	</div>
	<div class="breadcrumb-line">
		<ul class="breadcrumb">
			<li><a href="<?php echo BASE_URL ?>"><i class="icon-home2 position-left"></i> Home</a></li>
			<li><a href="<?php echo $data['curl'] ?>"><?php echo $data['breadcrumb1']; ?></a></li>
			<li class="active"><?php echo $data['title']; ?></li>
		</ul>
	</div>
</div>
<!-- /page header -->

<!-- Content area -->
<div class="content">
	<!-- Basic datatable -->
	<div class="panel panel-flat">
		<div class="panel-heading">
			<h5 class="panel-title"><strong>Table</strong> <?php echo $data['title'] ?></h5>
			<div class="heading-elements">
				<ul class="icons-list">
					<li><a data-action="collapse"></a></li>
					<li><a data-action="reload"></a></li>
					<li><a data-action="close"></a></li>
				</ul>
			</div>
		</div>
		<!-- <div class="panel-body">
			<a href="<?php //echo $data['curl'] ?>add" class="btn btn-success btn-ladda btn-ladda-progress btn-sx" data-style="zoom-out"><span class="ladda-label"><i class="icon-spinner9 position-left"></i></span> Syncronise</a>
		</div> -->
		<table class="table datatable table-bordered table-striped">
			<thead>
				<tr>
					<th class="text-center text-grey-400">TAHUN</th>
					<th class="text-center text-grey-400">SATKER</th>
					<th class="text-center text-grey-400">SPH</th>
					<th class="text-center text-grey-400">TOTAL KONTRAK</th>
					<th class="text-center text-grey-400">TOTAL BAST</th>
					<th class="text-center text-grey-400">TOTAL KU17</th>
					<th class="text-center text-grey-400">TOTAL SP2d</th>
					<th class="text-center text-grey-400">NILAI</th>
					<th class="text-center text-grey-400">DETAIL</th>
				</tr>
			</thead>
		</table>
	</div>
<!-- /basic datatable --> 

<!-- Info modal -->
<div id="modal_form" class="modal fade">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header bg-info">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h6 class="modal-title"><i class="icon-windows8" title="Dokumen"></i>&nbsp; Dokumen Media</h6>
			</div>

			<div class="modal-body">
				<table class="table table-bordered table-striped" id="datafile1">
					<thead>
						<tr>
							<th>Kode Akun</th>
							<th>Nama Akun</th>
							<th>Pagu</th>
						</tr>
					</thead>
				</table>
			</div>
		</div>
	</div>
</div>
<!-- /info modal -->     

<script type="text/javascript">
  	var url = '<?php echo $data['curl'] ?>';
  	$(function() {
	 	$('.datatable').DataTable({
	        "processing": true,
	        "serverSide": true, 
	        "order": [0],
	        "ajax": {
	            "url": url+'getProgja',
	            "type": "POST"
	        },
	        "columns": [
				{"data": 1,width:'auto', className:'text-center text-nowrap', orderable: false},
	            {
	                "data": 8,
	                "width": 'auto',
	                "sortable": false,
	                "className": "left text-nowrap",
	                "render": function ( data, type, row, meta ) {
	                     return '<a href="'+url+'detail/'+row[0]+'/'+row[2]+'/'+row[9]+'" class="btn-sx" data-popup="tooltip" title="Detail '+row[8]+'">'+row[8]+'</i></a>   ';
	                 }
	            },
	             {
	                "data": 8,
	                "width": 'auto',
	                "sortable": false,
	                "className": "center text-nowrap",
	                "render": function ( data, type, row, meta ) {
	                      if(row[10] != null){                  
	                     var bp = row[10];
	                   }
	                   else {
	                    var bp = '<p class="label label-danger">Belum di Upload</p>';
                   }
                   return ''+bp+'';
	                 }
	            },
	            
	             {
	                "data": 8,
	                "width": 'auto',
	                "sortable": false,
	                "className": "center text-nowrap",
	                "render": function ( data, type, row, meta ) {
	                      if(row[11] != null){                  
	                     var ba = row[11];
	                   }
	                   else {
	                    var ba = '<p class="label label-danger">Belum di Upload</p>';
                   }
                   return ''+ba+'';
	                 }
	             },
	             {
	                "data": 8,
	                "width": 'auto',
	                "sortable": false,
	                "className": "center text-nowrap",
	                "render": function ( data, type, row, meta ) {
	                      if(row[12] != null){                  
	                     var bb = row[12];
	                   }
	                   else {
	                    var bb = '<p class="label label-danger">Belum di Upload</p>';
                   }
                   return ''+bb+'';
	                 }
	            },
	             {
	                "data": 8,
	                "width": 'auto',
	                "sortable": false,
	                "className": "center text-nowrap",
	                "render": function ( data, type, row, meta ) {
	                      if(row[13] != null){                  
	                     var bc = row[13];
	                   }
	                   else {
	                    var bc = '<p class="label label-danger">Belum di Upload</p>';
                   }
                   return ''+bc+'';
	                 }
	             },
	             {
	                "data": 8,
	                "width": 'auto',
	                "sortable": false,
	                "className": "center text-nowrap",
	                "render": function ( data, type, row, meta ) {
	                      if(row[14] != null){                  
	                     var bd = row[14];
	                   }
	                   else {
	                    var bd = '<p class="label label-danger">Belum di Upload</p>';
                   }
                   return ''+bd+'';
	                 }
	            },
	            {"data": 7,width:'auto', className:'text-right', searchable:false},
	            {
	                "data": null,
	                "width": 50,
	                "sortable": false,
	                "className": "center",
	                "render": function ( data, type, row, meta ) {
	                     return '<a href="'+url+'detail/'+row[0]+'/'+row[2]+'/'+row[9]+'" class="btn-sx" data-popup="tooltip" title="Detail Progja"><i class="icon-list"></i></a>   ';
	                 }
	            }
	        ]
    	});
  	});
  	function myShowfiles(a, b, c){
     	// Show file
	    $('#datafile'+a).DataTable({
          	"destroy": true,
          	"processing": true,
          	"serverSide": true, 
          	"paging": false,
          	"searching": false,
          	"info": false,
          	"order": [0],
          	"ajax": {
	              "url": url+'getAkun/'+'3'+'/'+'4',
	              "type": "POST"
	        },
	        "columns": [
              	{"data": 1,width:'20%'},
              	{"data": 2,width:'20%'},
              	{"data": 3,width:'20%'},
          	]
     	});
	}
</script>