<?php include('header.php'); ?>

              <!-- Page header -->

              <div class="page-header">

                <div class="page-header-content">

                  <div class="page-title">

                    <h4><i class="icon-arrow-left52 position-left"></i> <span class="text-semibold"><?php echo $data['breadcrumb1']; ?></span> - <?php echo $data['title']; ?></h4>

                  </div>

                </div>

                <div class="breadcrumb-line">

                  <ul class="breadcrumb">

                    <li><a href="<?php echo BASE_URL ?>/"><i class="icon-home2 position-left"></i> Home</a></li>

                    <li><a href="<?php echo $data['curl'] ?>/"><?php echo $data['breadcrumb1']; ?></a></li>

                    <li class="active"><?php echo $data['title']; ?></li>

                  </ul>



                </div>

              </div>

              <!-- /page header -->



              <!-- Content area -->

              <div class="content">

                <!-- Basic datatable -->

                  <div class="panel panel-flat">

                    <div class="panel-heading">

                      <h5 class="panel-title"><strong>Table</strong> <?php echo $data['title'] ?></h5>

                      <div class="heading-elements">

                        <ul class="icons-list">

                          <li><a data-action="collapse"></a></li>

                          <li><a data-action="reload"></a></li>

                          <li><a data-action="close"></a></li>

                        </ul>

                      </div>

                    </div>

                    <div class="panel-body">
                      <!-- <p><a href="<?php echo $data['curl'] ?>/add/<?php echo $data['encode']; ?>" class="btn btn-info btn-sx"><i class="icon-plus-circle2 position-left"></i> Add</a></p> -->

                        <div class="form-group log-lg-2">
                          <div class="input-group col-lg-2" style="width: 250px;" >
                            <div class="input-group-addon bg-primary" >FILTER TAHUN</div>      
                            <select data-placeholder="Pilih Tahun" class="select-search" id="filtertahun" name="filtertahun" >
                              <option value="2020">2020</option>
                              <option value="2019">2019</option>
                              <!-- <option value="3">2020</option> -->
                              <option value="2021">2021</option>
                              <option value="2022">2022</option>
                              <option value="2023">2023</option>
                              <option value="2024">2024</option>
                              <option value="2025">2025</option>
                              <?php //foreach ($data['id_jns_audit'] as $key => $value) { echo "<option value=\"".$value[0]."\">".$value[1]."</option>"."\n";} ?>
                            </select>
                          </div>                  
                        </div>


                          <div class="form-group log-lg-2">
                          <div class="input-group col-lg-2" style="width: 250px;" >
                            <div class="input-group-addon bg-green-800" >FILTER BULAN</div>      
                            <select data-placeholder="Pilih Bulan" class="select-search" id="filterbulan" name="filterbulan"  >
                              <option value="1">Januari</option>
                              <option value="2">Februari</option>
                              <option value="3">Maret</option>
                              <option value="4">April</option>
                              <option value="5">Mei</option>
                              <option value="6">Juni</option>
                              <option value="7">Juli</option>
                              <option value="8">Agustus</option>
                              <option value="9">September</option>
                              <option value="10">Oktober</option>
                              <option value="11">November</option>
                              <option value="12">Desember</option>
                              <?php //foreach ($data['id_jns_audit'] as $key => $value) { echo "<option value=\"".$value[0]."\">".$value[1]."</option>"."\n";} ?>
                            </select>
                          </div>                  
                        </div>


                    </div>

                    

                    <table class="table datatable">

                      <thead>

                        <tr>

									<th class="text-center">Tahun</th>
                  <th class="text-center">Bulan</th>
                  <th class="text-center">Satker</th>
									<th class="text-center">Status</th>

									
									<th class="text-center">Details</th>


                        </tr>

                      </thead>

                    </table>

                  </div>

                  <!-- /basic datatable -->      

<?php include('footer.php'); ?>



<script type="text/javascript">

// FUNCTION UNTUK AMBIL TAHUN DARI COMBOBOX //
 $("#filtertahun").on('change', function(result){
    var tahun = $(this).val();    
    var bulan = $("#filterbulan").val();  
    var table = $('.datatable').DataTable();
    table.ajax.url( url+'get/<?php echo $data['encode'] ?>/'+tahun+'/'+bulan ).load(); 
});

  $("#filterbulan").on('change', function(result){
    var bulan = $(this).val();    
    var tahun = $("#filtertahun").val();
    var table = $('.datatable').DataTable();
    table.ajax.url( url+'get/<?php echo $data['encode'] ?>/'+tahun+'/'+bulan ).load(); 
});


  var url = '<?php echo $data['curl'] ?>/';

  $(function() {
  var tahun = $("#filtertahun").val();
  var bulan = $("#filterbulan").val();  

  $('.datatable').DataTable({

        "processing": true,

        "serverSide": true, 

        "order": [0],

        "ajax": {

            "url": url+'get/<?php echo $data['encode'] ?>/'+tahun+'/'+bulan,

            "type": "POST"

        },

        "columns": [

						 {
                "data": 1,

                "width": 300,

                "sortable": false,

                "className": "center",

                "render": function ( data, type, row, meta ) {
                   var tt = $("#filtertahun").val();               
                     return '<p >'+tt+'</p>';
                   

                 }

            },
             {
                "data": null,

                "width": 300,

                "sortable": false,

                "className": "center",

                "render": function ( data, type, row, meta ) {
                   var tb = $("#filterbulan option:selected").text();               
                     return '<p >'+tb+'</p>';
                   

                 }

            },
             

            {"data": 2,"className": "left",width:'auto'},

						 {
                "data": null,

                "width": 500,

                "sortable": false,

                "className": "center",

                "render": function ( data, type, row, meta ) {
                  if(row[3] != null){                  
                     var bp = '<p class="label label-success">Belanja Barang : Sudah di Upload</p>';
                   }
                   else {
                    var bp = '<p class="label label-danger">Belanja Barang : Belum di Upload</p>';
                   }

                    if(row[4] != null){                  
                     var bb = '<p class="label label-success">Belanja Modal : Sudah di Upload</p>';
                   }
                   else {
                    var bb = '<p class="label label-danger">Belanja Modal : Belum di Upload</p>';
                   }

                    

                   return ''+bp+'<br>'+bb+'';

                 }

            },
           

                        {
			                "data": null,
			                "width": 50,
			                "sortable": false,
			                "className": "center",
			                "render": function ( data, type, row, meta ) {
                         var tt = $("#filtertahun").val();
                         var tb = $("#filterbulan").val();          
			                     return '<a href="<?php echo $data['curl']  ?>_detail/detail/'+row[0]+'/'+tt+'/'+tb+'/'+row[1]+'/'+row[5]+'" class="btn-sx cyan" data-popup="tooltip" data-original-title="Top tooltip"><i class="icon-folder5"></i></a>  ';
			                 }
			            }

        ]

    });

  });

 

</script>