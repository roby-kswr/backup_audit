<?php include('header.php'); ?>
<!-- Page header -->
<div class="page-header">
	<div class="page-header-content">
		<div class="page-title">
			<h4><i class="icon-arrow-left52 position-left"></i> <span class="text-semibold"><?php echo $data['breadcrumb1']; ?></span> - <?php echo $data['title']; ?></h4>
		</div>
	</div>
	<div class="breadcrumb-line">
		<ul class="breadcrumb">
			<li><a href="<?php echo BASE_URL ?>"><i class="icon-home2 position-left"></i> Home</a></li>
			<li><a href="<?php echo $data['curl'] ?>"><?php echo $data['breadcrumb1']; ?></a></li>
			<li class="active"><?php echo $data['title']; ?> Detail</li>
		</ul>
	</div>
</div>
<!-- /page header -->

<!-- Content area -->
<div class="content">

	<div class="panel panel-flat">
		<div class="panel-heading">
			<h5 class="panel-title"><i class="icon-display4 position-left"></i><span class="text-bold">SATKER</span>  <span class="text-teal"> &nbsp; <?php echo $data['nmsatker'] ?></span></h5>
			<div class="heading-elements">
				<ul class="icons-list">
					<li><a data-action="collapse"></a></li>
					<li><a data-action="reload"></a></li>
					<li><a data-action="close"></a></li>
				</ul>
			</div>
		</div>
		<div class="panel-body">
			<a href="<?php echo $data['curl2'] ?>" class="btn btn-danger btn-ladda btn-ladda-progress btn-sx" data-style="zoom-out"><span class="ladda-label"><i class="icon-arrow-left52 position-left"></i></span> Back</a>
			<a href="" onclick="gettemuan()" class="btn btn-info btn-sx" data-toggle="modal" data-target="#modal_temuan" title="Temuan"><i class="icon-plus-circle2 position-left"></i>Add Temuan</a> 
			<a href="<?php echo $data['curl'] ?>edit/<?php echo $data['tahun']; ?>/<?php echo $data['bulan'];?>/<?php echo $data['kotama']?>/<?php echo $data['satminkal']?>/<?php echo $data['encode']; ?>" class="btn btn-info btn-sx"><i class="icon-plus-circle2 position-left"></i>Keterangan NHV</a> 
			 <a href="<?php echo $data['curl3'] ?>detail/<?php echo $data['tahun']; ?>/<?php echo $data['bulan'];?>/<?php echo $data['kotama']?>/<?php echo $data['satminkal']?>/<?php echo $data['encode']; ?>" class="btn btn-info btn-sx"><i class="icon-plus-circle2 position-left"></i> Dasar NHV</a> 
		</div>
		<table class="table datatable table-striped table-bordered">
			<thead>
				<tr>
					<th class="text-center">URAIAN</th>
					<th class="text-center">WASGIAT</th>
					<th class="text-center text-grey-400">HPS</th>
					<th class="text-center text-grey-400">TOR</th>
					<th class="text-center text-grey-400">RAB</th>
					<th class="text-center text-grey-400">SPH</th>
					<th class="text-center text-grey-400">KONTRAK</th>
					<th class="text-center text-grey-400">BAST</th>
					<th class="text-center text-grey-400">KU17</th>
					<th class="text-center text-grey-400">SP2D</th>
					<th class="text-center">NILAI</th>
					<th class="text-center">DATA</th>
					<th class="text-center">AKUN</th>
		<!-- 			<th class="text-center">TOR</th>
					<th class="text-center">RAB</th>
					<th class="text-center">SPH</th>
					<th class="text-center">KONTRAK</th>
					<th class="text-center">BAST</th>
					<th class="text-center">SP2D</th>
					<th class="text-center">KU17</th> -->
					
				</tr>
			</thead>
		</table>
	</div>
<!-- /basic datatable --> 

			<!-- TEMUAN MODAL -->
			<div id="modal_temuan" class="modal fade">
				<div class="modal-dialog modal-lg">
					<div class="modal-content">
						<div class="modal-header bg-info">
							<button type="button" class="close" data-dismiss="modal">&times;</button>
							<h6 class="modal-title"><i class="icon-windows8" title="Temuan"></i>&nbsp;Temuan</h6>
						</div>

			<div class="modal-body">

				<div class="tabbable"> <!-- tab -->
					<ul class="nav nav-tabs nav-tabs-highlight nav-justified">
						<li class="active"><a href="#highlighted-tabb1" class="text-bold text-grey-300" onclick="gettemuan(false)" data-toggle="tab">TEMUAN</a></li>
						<!-- <li><a href="#highlighted-tabb2" class="text-bold text-grey-300" onclick="getdasar(false)" data-toggle="tab">DASAR NHV</a></li> -->
<!-- 						<li><a href="#highlighted-tabb6" class="text-bold text-grey-300" onclick="getbast(false)" data-toggle="tab">BAST</a></li>
						<li><a href="#highlighted-tabb7" class="text-bold text-grey-300" onclick="getku17(false)" data-toggle="tab">KU17</a></li>
						<li><a href="#highlighted-tabb8" class="text-bold text-grey-300" onclick="getsp2d(false)" data-toggle="tab">SP2D</a></li> -->
					</ul>

					  <div class="tab-content">
						<div class="tab-pane active" id="highlighted-tabb1"> <!-- TAB TEMUAN -->
							<div class="row">
							<form id="temuan-form" class="form-horizontal form-validate-jquery" action="#"  method="post" enctype="multipart/form-data">

                     <fieldset class="content-group"> 
                          <div class="form-group">
                            <label class="control-label col-lg-2">Kategori Dokumen <span class="text-danger">*</span></label>
                            <div class="input-group" style="width: 590px; padding-left: 10px;">
                              <div class="input-group-addon"><i class="icon-list-unordered"></i></div>
                              <select data-placeholder="Pilih Kategori" class="select-search required" id="kategori" name="kategori" >
                                <option></option>
                                  <?php foreach ($data['kategori'] as $key => $value) { echo "<option value=\"".$value[0]."\">".$value[1]."</option>"."\n";} ?>
                              </select>
                            </div>
                        </div>
                         
                      <div class="form-group" style="margin-top: 15px;">
                        <label class="control-label col-lg-2">Keterangan</label>
                        <div class="col-lg-10" style="width: 600px;">
                        <textarea style="width: 580px; height: 150px;" class="textarea" name="keterangan"></textarea>
                         <input type="hidden" class="form-control" name="sphval" id="sphval" readonly="true">

                        </div>
                      </div>

                      <div class="form-group">
		              <label class="control-label col-lg-2">Tolak Ukur NHV <span class="text-danger">*</span></label>
		              <div class="input-group" style="width: 590px; padding-left: 10px;">
		                <div class="input-group-addon"><i class="icon-list-unordered"></i></div>
		                <select data-placeholder="Pilih Tolak Ukur NHV" class="select-search required" id="status_temuan" name="status_temuan">
		                  <option></option>
		                    <?php 
		                    foreach ($data['nm_tunhv'] as $key => $status_temuan) { 
		                      if($data['aadata']['status_temuan'] == $status_temuan[0])
		                      {
		                        echo "<option value=\"".$status_temuan[0]."\" selected>".$status_temuan[1]."</option>"."\n";
		                      } 
		                      else
		                      {
		                        echo "<option value=\"".$status_temuan[0]."\">".$status_temuan[1]."</option>"."\n";
		                      }
		                    } 
		                    ?>
		                </select>
		              </div>
		            </div>
  </fieldset>
                <div class="text-right">		  
								  <button type="submit" id="post-temuan" class="btn btn-success">Submit <i class="icon-circle-right2 position-right"></i></button>
								</div>
								<div class="form-group">
								    <label class="control-label col-lg-2"></label>
								    <div class="col-lg-10"></div>
								  </div>
                </form>
               </div>
               <fieldset class="content-group">
								<table class="table table-striped table-bordered" id="datatable-temuan">
						          <thead>
						            <tr>
						              <th class="text-center bg-slate-600">Tahun</th>
						              <th class="text-center bg-slate-600">Bulan</th>
						              <th class="text-center bg-slate-600">Kategori</th>
						              <th class="text-center bg-slate-600">Status Temuan</th>
						               <th class="text-center bg-slate-600">Isi Detail Temuan</th>
						            </tr>
						          </thead>
						        </table>
							</fieldset>
                  </div>    <!-- TAB TEMUAN -->


                  <div class="tab-pane" id="highlighted-tabb2"> <!-- TAB DASAR -->
							<div class="row">
							<form class="form-horizontal" id="dasar-form" action="#" method="post" enctype="multipart/form-data">
						 
						 <fieldset class="content-group">
                          <div class="form-group">
                            <label class="control-label col-lg-2">Parent <span class="text-danger">*</span></label>
                            <div class="input-group" style="width: 590px; padding-left: 10px;">
                              <div class="input-group-addon"><i class="icon-list-unordered"></i></div>
                              <select data-placeholder="Pilih Parent" class="select-search required" id="temuan" name="temuan">
                                <option></option>
                                  <?php foreach ($data['kat'] as $key => $value) { echo "<option value=\"".$value[0]."\">".$value[1]."</option>"."\n";} ?>
                              </select>
                            </div>
                         </div>


                         
                          <div class="form-group">
                            <label class="control-label col-lg-2">No Urut</label>
                            <div class="col-lg-10" style="width: 600px;">
                             <input type="number" class="form-control" name="order">
                            </div>
                          </div>

                          <div class="form-group">
                            <label class="control-label col-lg-2">Keterangan</label>
                            <div class="col-lg-10" style="width: 600px;">
                              <textarea style="width: 580px; height: 150px;" class="textarea" name="keterangan"></textarea>
                            </div>
                          </div>
                        </fieldset>

								<div class="text-right">		  
								  <button type="button" id="post-dasar" class="btn btn-success">Submit <i class="icon-circle-right2 position-right"></i></button>
								</div>
								<div class="form-group">
								    <label class="control-label col-lg-2"></label>
								    <div class="col-lg-10"></div>
								  </div>
							</form>
							</div>
							<fieldset class="content-group">
								<table class="table table-striped table-bordered" id="datatable-dasar">
						          <thead>
						            <tr>
						              <th class="text-center bg-slate-600">Induk</th>
						              <th class="text-center bg-slate-600">No Urut</th>
						              <th class="text-center bg-slate-600">Keterangan</th>
						            </tr>
						          </thead>
						        </table>
							</fieldset>
						</div> <!-- TAB DASAR -->


			</div>
		</div>
	</div>
</div>
</div>
</div>
<!-- TEMUAN MODAL -->  






<!-- AKUN modal -->
<div id="modal_form" class="modal fade">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header bg-info">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h6 class="modal-title"><i class="icon-windows8" title="Dokumen"></i>&nbsp; Dokumen Media</h6>
			</div>

			<div class="modal-body">
				<table class="table" id="datafile1">
					<thead>
						<tr>
							<th class="text-center">Kode Akun</th>
							<th class="text-center">Nama Akun</th>
							<th class="text-center">Pagu</th>
						</tr>
					</thead>
				</table>
			</div>
		</div>
	</div>
</div>
<!-- /AKUN modal -->  

<!-- HPS modal -->
<div id="modal_akun" class="modal fade">
<div class="modal-dialog modal-lg">
  <div class="modal-content">
	    <div class="modal-header bg-teal">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h6 class="modal-title"><i class="icon-file-spreadsheet2" title="Dokumen"></i>&nbsp; Akun</h6>
	    </div>

	    <div class="modal-body">
	      <table class="table table-striped table-bordered" id="dthps">
	          <thead>
	            <tr>
	              <th class="text-center">KDAKUN</th>
	              <th class="text-center">NAMA AKUN</th>
	              <th class="text-center">NILAI</th><!-- 
	              <th class="text-center">DOKUMEN</th>
	              <th class="text-center">HPS</th>
	              <th class="text-center">Actions</th> -->
	            </tr>
	          </thead>
	        </table>
	  </div>
	</div>
</div>
</div>
<!-- /HPS modal -->   

<!-- Info modal -->
<div id="modal_datas" class="modal fade">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header bg-teal">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h6 class="modal-title"><i class="icon-file-text2" title="Dokumen"></i>&nbsp; Dokumen</h6>
			</div>

			<div class="modal-body">

				<div class="tabbable"> <!-- tab -->
					<ul class="nav nav-tabs nav-tabs-highlight nav-justified">
						<li class="active"><a href="#highlighted-tab1" class="text-bold text-grey-300" data-toggle="tab">HPS</a></li>
						<li><a href="#highlighted-tab2" class="text-bold text-grey-300" onclick="gettor(false)" data-toggle="tab">TOR</a></li>
						<li><a href="#highlighted-tab3" class="text-bold text-grey-300" onclick="getrab(false)" data-toggle="tab">RAB</a></li>
						<li><a href="#highlighted-tab4" class="text-bold text-grey-300" onclick="getsph(false)" data-toggle="tab">SPH</a></li>
						<li><a href="#highlighted-tab5" class="text-bold text-grey-300" onclick="getkontrak(false)" data-toggle="tab">KONTRAK</a></li>
						<li><a href="#highlighted-tab6" class="text-bold text-grey-300" onclick="getbast(false)" data-toggle="tab">BAST</a></li>
						<li><a href="#highlighted-tab7" class="text-bold text-grey-300" onclick="getku17(false)" data-toggle="tab">KU17</a></li>
						<li><a href="#highlighted-tab8" class="text-bold text-grey-300" onclick="getsp2d(false)" data-toggle="tab">SP2D</a></li>
					</ul>

					<div class="tab-content">
						<div class="tab-pane active" id="highlighted-tab1">
							<div class="row">
							<form class="form-horizontal hidden" id="hps-form" action="<?php echo $data['curl']."/savehps/".$data['encode']; ?>" method="post" enctype="multipart/form-data">
								<fieldset class="content-group">
								  <div class="form-group">
								    <label class="control-label col-lg-2">Tanggal HPS</label>
								    <div class="col-lg-6">
								      <div class="input-group">
								        <span class="input-group-addon"><i class="icon-calendar"></i></span>
								        <input type="date" class="form-control" name="tanggal_hps" value="" >
								        <!-- <input type="hidden" class="form-control" name="hpsval" id="hpsval" readonly="true"> -->
								         <!-- <input type="hidden" class="form-control" name="sphval" id="sphval" readonly="true"> -->
								      </div>
								    </div>
								  </div>
								  <div class="form-group">
								    <label class="control-label col-lg-2">Nilai HPS</label>
								    <div class="col-lg-6">		      
								        <input type="number" class="form-control" name="nilai_hps">
								    </div>
								  </div>
								  <div class="form-group">
								    <label class="control-label col-lg-2">Dok. HPS</label>
								    <div class="col-lg-10">
								      <input type="file" class="file-input" multiple="multiple" name="file_hps[]" data-show-upload="false" data-show-caption="true" data-show-preview="false" accept="application/pdf">
								      <span class="text-size-mini text-danger">* Hanya menerima file <code>.pdf</code></span>
								    </div>
								  </div>
								  <div class="form-group">
								    <label class="control-label col-lg-2">File HPS</label>
								    <div class="col-lg-10">
								      <input type="file" class="file-input" multiple="multiple" name="file_excelhps[]" data-show-upload="false" data-show-caption="true" data-show-preview="false" accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel">
								      <span class="text-size-mini text-danger">* Hanya menerima file <code>.xls, .xlsx</code></span>
								    </div>
								  </div>
								</fieldset>
								<div class="text-right">		  
								  <button type="button" id="post-hps" class="btn btn-success">Submit <i class="icon-circle-right2 position-right"></i></button>
								</div>
								<div class="form-group">
								    <label class="control-label col-lg-2"></label>
								    <div class="col-lg-10"></div>
								  </div>
							</form>
							</div>
							<fieldset class="content-group">
								<table class="table table-striped table-bordered" id="datatable-hps">
						          <thead>
						            <tr>
						              <th class="text-center bg-slate-600">Tanggal HPS</th>
						              <th class="text-center bg-slate-600">Nilai HPS</th>
						              <th class="text-center bg-slate-600">Dok.</th>
						              <th class="text-center bg-slate-600">HPS</th>
						            </tr>
						          </thead>
						        </table>
							</fieldset>
						</div> <!-- tab hps -->

						<div class="tab-pane" id="highlighted-tab2"> <!-- tab tor -->
							<div class="row">
							<form class="form-horizontal hidden" id="tor-form" action="<?php echo $data['curl']."/savertor/".$data['encode']; ?>" method="post" enctype="multipart/form-data">
								<fieldset class="content-group">
								  <div class="form-group">
								    <label class="control-label col-lg-2">Tanggal TOR</label>
								    <div class="col-lg-6">
								      <div class="input-group">
								        <span class="input-group-addon"><i class="icon-calendar"></i></span>
								        <input type="date" class="form-control" name="tanggal_tor" value="" >
								        <input type="hidden" class="form-control" name="torval" id="torval" readonly="true">
								      </div>
								    </div>
								  </div>
								  <div class="form-group">
								    <label class="control-label col-lg-2">Dok. TOR</label>
								    <div class="col-lg-10">
								      <input type="file" class="file-input" multiple="multiple" name="file_tor[]" data-show-upload="false" data-show-caption="true" data-show-preview="false" accept="application/pdf">
								      <span class="text-size-mini text-danger">* Hanya menerima file <code>.pdf</code></span>
								    </div>
								  </div>
								  <div class="form-group">
								    <label class="control-label col-lg-2">File TOR</label>
								    <div class="col-lg-10">
								      <input type="file" class="file-input" multiple="multiple" name="file_exceltor[]" data-show-upload="false" data-show-caption="true" data-show-preview="false" accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel">
								      <span class="text-size-mini text-danger">* Hanya menerima file <code>.xls, .xlsx</code></span>
								    </div>
								  </div>
								</fieldset>
								<div class="text-right">		  
								  <button type="button" id="post-tor" class="btn btn-success">Submit <i class="icon-circle-right2 position-right"></i></button>
								</div>
								<div class="form-group">
								    <label class="control-label col-lg-2"></label>
								    <div class="col-lg-10"></div>
								  </div>
							</form>
							</div>
							<fieldset class="content-group">
								<table class="table table-striped table-bordered" id="datatable-tor">
						          <thead>
						            <tr>
						              <th class="text-center bg-slate-600">Tanggal TOR</th>
						              <th class="text-center bg-slate-600">Dok.</th>
						              <th class="text-center bg-slate-600">TOR</th>
						            </tr>
						          </thead>
						        </table>
							</fieldset>
						</div> <!-- tab tor -->

						<div class="tab-pane" id="highlighted-tab3">
							<div class="row">
							<form class="form-horizontal hidden" id="rab-form" action="<?php echo $data['curl']."/savehrab/".$data['encode']; ?>" method="post" enctype="multipart/form-data">
								<fieldset class="content-group">
								  <div class="form-group">
								    <label class="control-label col-lg-2">Tanggal RAB</label>
								    <div class="col-lg-6">
								      <div class="input-group">
								        <span class="input-group-addon"><i class="icon-calendar"></i></span>
								        <input type="date" class="form-control" name="tanggal_rab" value="" >
								        <input type="hidden" class="form-control" name="rabval" id="rabval" readonly="true">
								      </div>
								    </div>
								  </div>
								  <div class="form-group">
								    <label class="control-label col-lg-2">Nilai RAB</label>
								    <div class="col-lg-6">		      
								        <input type="number" class="form-control" name="nilai_rab">
								    </div>
								  </div>
								  <div class="form-group">
								    <label class="control-label col-lg-2">Dok. RAB</label>
								    <div class="col-lg-10">
								      <input type="file" class="file-input" multiple="multiple" name="file_rab[]" data-show-upload="false" data-show-caption="true" data-show-preview="false" accept="application/pdf">
								      <span class="text-size-mini text-danger">* Hanya menerima file <code>.pdf</code></span>
								    </div>
								  </div>
								  <div class="form-group">
								    <label class="control-label col-lg-2">File RAB</label>
								    <div class="col-lg-10">
								      <input type="file" class="file-input" multiple="multiple" name="file_excelrab[]" data-show-upload="false" data-show-caption="true" data-show-preview="false" accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel">
								      <span class="text-size-mini text-danger">* Hanya menerima file <code>.xls, .xlsx</code></span>
								    </div>
								  </div>
								</fieldset>
								<div class="text-right">		  
								  <button type="button" id="post-rab" class="btn btn-success">Submit <i class="icon-circle-right2 position-right"></i></button>
								</div>
								<div class="form-group">
								    <label class="control-label col-lg-2"></label>
								    <div class="col-lg-10"></div>
								  </div>
							</form>
							</div>
							<fieldset class="content-group">
								<table class="table table-striped table-bordered" id="datatable-rab">
						          <thead>
						            <tr>
						              <th class="text-center bg-slate-600">Tanggal RAB</th>
						              <th class="text-center bg-slate-600">Nilai RAB</th>
						              <th class="text-center bg-slate-600">Dok.</th>
						              <th class="text-center bg-slate-600">RAB</th>
						            </tr>
						          </thead>
						        </table>
							</fieldset>
						</div> <!-- tab rab -->

						<div class="tab-pane" id="highlighted-tab4"><!-- tab sph -->
							<div class="row">
							<form class="form-horizontal hidden" id="sph-form" action="<?php echo $data['curl']."/savehsph/".$data['encode']; ?>" method="post" enctype="multipart/form-data">
								<fieldset class="content-group">
								  <div class="form-group">
								    <label class="control-label col-lg-2">Tanggal SPH</label>
								    <div class="col-lg-6">
								      <div class="input-group">
								        <span class="input-group-addon"><i class="icon-calendar"></i></span>
								        <input type="date" class="form-control" name="tanggal_sph" value="" >
								       
								      </div>
								    </div>
								  </div>
								  <div class="form-group">
								    <label class="control-label col-lg-2">Nilai SPH</label>
								    <div class="col-lg-6">		      
								        <input type="number" class="form-control" name="nilai_sph">
								    </div>
								  </div>
								  <div class="form-group">
								    <label class="control-label col-lg-2">Dok. SPH</label>
								    <div class="col-lg-10">
								      <input type="file" class="file-input" multiple="multiple" name="file_sph[]" data-show-upload="false" data-show-caption="true" data-show-preview="false" accept="application/pdf">
								      <span class="text-size-mini text-danger">* Hanya menerima file <code>.pdf</code></span>
								    </div>
								  </div>
								  <div class="form-group">
								    <label class="control-label col-lg-2">File SPH</label>
								    <div class="col-lg-10">
								      <input type="file" class="file-input" multiple="multiple" name="file_excelsph[]" data-show-upload="false" data-show-caption="true" data-show-preview="false" accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel">
								      <span class="text-size-mini text-danger">* Hanya menerima file <code>.xls, .xlsx</code></span>
								    </div>
								  </div>
								</fieldset>
								<div class="text-right">		  
								  <button type="button" id="post-sph" class="btn btn-success">Submit <i class="icon-circle-right2 position-right"></i></button>
								</div>
								<div class="form-group">
								    <label class="control-label col-lg-2"></label>
								    <div class="col-lg-10"></div>
								  </div>
							</form>
							</div>
							<fieldset class="content-group">
								<table class="table table-striped table-bordered" id="datatable-sph">
						          <thead>
						            <tr>
						              <th class="text-center bg-slate-600">Tanggal SPH</th>
						              <th class="text-center bg-slate-600">Nilai SPH</th>
						              <th class="text-center bg-slate-600">Dok.</th>
						              <th class="text-center bg-slate-600">SPH</th>
						            </tr>
						          </thead>
						        </table>
							</fieldset>
						</div> <!-- tab sph -->

						<div class="tab-pane" id="highlighted-tab5"><!-- tab kontrak -->
							<div class="row">
							<form class="form-horizontal hidden" id="kontrak-form" action="<?php echo $data['curl']."/savehkontrak/".$data['encode']; ?>" method="post" enctype="multipart/form-data">
								<fieldset class="content-group">
								  <div class="form-group">
								    <label class="control-label col-lg-2">Tanggal Kontrak</label>
								    <div class="col-lg-6">
								      <div class="input-group">
								        <span class="input-group-addon"><i class="icon-calendar"></i></span>
								        <input type="date" class="form-control" name="tanggal_kontrak" value="" >
								        <input type="hidden" class="form-control" name="kontrakval" id="kontrakval" readonly="true">
								      </div>
								    </div>
								  </div>
								  <div class="form-group">
								    <label class="control-label col-lg-2">Termin Pembayaran</label>
								    <div class="col-lg-6">		      
								        <input type="number" class="form-control" name="termin" min="1" max="5">
								    </div>
								  </div>
								  <div class="form-group">
								    <label class="control-label col-lg-2">Nilai Kontrak</label>
								    <div class="col-lg-6">		      
								        <input type="number" class="form-control" name="nilai_kontrak">
								    </div>
								  </div>
								  <div class="form-group">
								    <label class="control-label col-lg-2">Dok. Kontrak</label>
								    <div class="col-lg-10">
								      <input type="file" class="file-input" multiple="multiple" name="file_kontrak[]" data-show-upload="false" data-show-caption="true" data-show-preview="false" accept="application/pdf">
								      <span class="text-size-mini text-danger">* Hanya menerima file <code>.pdf</code></span>
								    </div>
								  </div>
								  <div class="form-group">
								    <label class="control-label col-lg-2">File Kontrak</label>
								    <div class="col-lg-10">
								      <input type="file" class="file-input" multiple="multiple" name="file_excelkontrak[]" data-show-upload="false" data-show-caption="true" data-show-preview="false" accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel">
								      <span class="text-size-mini text-danger">* Hanya menerima file <code>.xls, .xlsx</code></span>
								    </div>
								  </div>
								</fieldset>
								<div class="text-right">		  
								  <button type="button" id="post-kontrak" class="btn btn-success">Submit <i class="icon-circle-right2 position-right"></i></button>
								</div>
								<div class="form-group">
								    <label class="control-label col-lg-2"></label>
								    <div class="col-lg-10"></div>
								  </div>
							</form>
							</div>
							<fieldset class="content-group">
								<table class="table table-striped table-bordered" id="datatable-kontrak">
						          <thead>
						            <tr>
						              <th class="text-center bg-slate-600">Tanggal Kontrak</th>
						              <th class="text-center bg-slate-600">Nilai Kontrak</th>
						              <th class="text-center bg-slate-600">Termin Ke</th>
						              <th class="text-center bg-slate-600">Dok.</th>
						              <th class="text-center bg-slate-600">Kontrak</th>
						            </tr>
						          </thead>
						        </table>
							</fieldset>
						</div> <!-- tab kontrak -->

						<div class="tab-pane" id="highlighted-tab6"><!-- tab bast -->
							<div class="row">
							<form class="form-horizontal hidden" id="bast-form" action="<?php echo $data['curl']."/savehbast/".$data['encode']; ?>" method="post" enctype="multipart/form-data">
								<fieldset class="content-group">
								  <div class="form-group">
								    <label class="control-label col-lg-2">Tanggal BAST</label>
								    <div class="col-lg-6">
								      <div class="input-group">
								        <span class="input-group-addon"><i class="icon-calendar"></i></span>
								        <input type="date" class="form-control" name="tanggal_bast" value="" >
								        <input type="hidden" class="form-control" name="bastval" id="bastval" readonly="true">
								      </div>
								    </div>
								  </div>
								  <div class="form-group">
								    <label class="control-label col-lg-2">Nilai BAST</label>
								    <div class="col-lg-6">		      
								        <input type="number" class="form-control" name="nilai_bast">
								    </div>
								  </div>
								  <div class="form-group">
								    <label class="control-label col-lg-2">Dok. BAST</label>
								    <div class="col-lg-10">
								      <input type="file" class="file-input" multiple="multiple" name="file_bast[]" data-show-upload="false" data-show-caption="true" data-show-preview="false" accept="application/pdf">
								      <span class="text-size-mini text-danger">* Hanya menerima file <code>.pdf</code></span>
								    </div>
								  </div>
								  <div class="form-group">
								    <label class="control-label col-lg-2">File BAST</label>
								    <div class="col-lg-10">
								      <input type="file" class="file-input" multiple="multiple" name="file_excelbast[]" data-show-upload="false" data-show-caption="true" data-show-preview="false" accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel">
								      <span class="text-size-mini text-danger">* Hanya menerima file <code>.xls, .xlsx</code></span>
								    </div>
								  </div>
								</fieldset>
								<div class="text-right">		  
								  <button type="button" id="post-bast" class="btn btn-success">Submit <i class="icon-circle-right2 position-right"></i></button>
								</div>
								<div class="form-group">
								    <label class="control-label col-lg-2"></label>
								    <div class="col-lg-10"></div>
								  </div>
							</form>
							</div>
							<fieldset class="content-group">
								<table class="table table-striped table-bordered" id="datatable-bast">
						          <thead>
						            <tr>
						              <th class="text-center bg-slate-600">Tanggal BAST</th>
						              <th class="text-center bg-slate-600">Nilai BAST</th>
						              <th class="text-center bg-slate-600">Dok.</th>
						              <th class="text-center bg-slate-600">BAST</th>
						            </tr>
						          </thead>
						        </table>
							</fieldset>
						</div> <!-- tab bast -->

						<div class="tab-pane" id="highlighted-tab7"><!-- tab ku17 -->
							<div class="row">
							<form class="form-horizontal hidden" id="ku17-form" action="<?php echo $data['curl']."/savehku17/".$data['encode']; ?>" method="post" enctype="multipart/form-data">
								<fieldset class="content-group">
								  <div class="form-group">
								    <label class="control-label col-lg-2">Tanggal KU17</label>
								    <div class="col-lg-6">
								      <div class="input-group">
								        <span class="input-group-addon"><i class="icon-calendar"></i></span>
								        <input type="date" class="form-control" name="tanggal_ku17" value="" >
								        <input type="hidden" class="form-control" name="ku17val" id="ku17val" readonly="true">
								      </div>
								    </div>
								  </div>
								  <div class="form-group">
								    <label class="control-label col-lg-2">Nilai KU17</label>
								    <div class="col-lg-6">		      
								        <input type="number" class="form-control" name="nilai_ku17">
								    </div>
								  </div>
								  <div class="form-group">
								    <label class="control-label col-lg-2">Dok. KU17</label>
								    <div class="col-lg-10">
								      <input type="file" class="file-input" multiple="multiple" name="file_ku17[]" data-show-upload="false" data-show-caption="true" data-show-preview="false" accept="application/pdf">
								      <span class="text-size-mini text-danger">* Hanya menerima file <code>.pdf</code></span>
								    </div>
								  </div>
								  <div class="form-group">
								    <label class="control-label col-lg-2">File KU17</label>
								    <div class="col-lg-10">
								      <input type="file" class="file-input" multiple="multiple" name="file_excelku17[]" data-show-upload="false" data-show-caption="true" data-show-preview="false" accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel">
								      <span class="text-size-mini text-danger">* Hanya menerima file <code>.xls, .xlsx</code></span>
								    </div>
								  </div>
								</fieldset>
								<div class="text-right">		  
								  <button type="button" id="post-ku17" class="btn btn-success">Submit <i class="icon-circle-right2 position-right"></i></button>
								</div>
								<div class="form-group">
								    <label class="control-label col-lg-2"></label>
								    <div class="col-lg-10"></div>
								  </div>
							</form>
							</div>
							<fieldset class="content-group">
								<table class="table table-striped table-bordered" id="datatable-ku17">
						          <thead>
						            <tr>
						              <th class="text-center bg-slate-600">Tanggal KU17</th>
						              <th class="text-center bg-slate-600">Nilai KU17</th>
						              <th class="text-center bg-slate-600">Dok.</th>
						              <th class="text-center bg-slate-600">KU17</th>
						            </tr>
						          </thead>
						        </table>
							</fieldset>
						</div> <!-- tab ku17 -->

						<div class="tab-pane" id="highlighted-tab8"><!-- tab sp2d -->
							<div class="row">
							<form class="form-horizontal hidden" id="sp2d-form" action="<?php echo $data['curl']."/savehsp2d/".$data['encode']; ?>" method="post" enctype="multipart/form-data">
								<fieldset class="content-group">
								  <div class="form-group">
								    <label class="control-label col-lg-2">Tanggal SP2D</label>
								    <div class="col-lg-6">
								      <div class="input-group">
								        <span class="input-group-addon"><i class="icon-calendar"></i></span>
								        <input type="date" class="form-control" name="tanggal_sp2d" value="" >
								        <input type="hidden" class="form-control" name="sp2dval" id="sp2dval" readonly="true">
								      </div>
								    </div>
								  </div>
								  <div class="form-group">
								    <label class="control-label col-lg-2">Nilai SP2D</label>
								    <div class="col-lg-6">		      
								        <input type="number" class="form-control" name="nilai_sp2d">
								    </div>
								  </div>
								  <div class="form-group">
								    <label class="control-label col-lg-2">Dok. SP2D</label>
								    <div class="col-lg-10">
								      <input type="file" class="file-input" multiple="multiple" name="file_sp2d[]" data-show-upload="false" data-show-caption="true" data-show-preview="false" accept="application/pdf">
								      <span class="text-size-mini text-danger">* Hanya menerima file <code>.pdf</code></span>
								    </div>
								  </div>
								  <div class="form-group">
								    <label class="control-label col-lg-2">File SP2D</label>
								    <div class="col-lg-10">
								      <input type="file" class="file-input" multiple="multiple" name="file_excelsp2d[]" data-show-upload="false" data-show-caption="true" data-show-preview="false" accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel">
								      <span class="text-size-mini text-danger">* Hanya menerima file <code>.xls, .xlsx</code></span>
								    </div>
								  </div>
								</fieldset>
								<div class="text-right">		  
								  <button type="button" id="post-sp2d" class="btn btn-success">Submit <i class="icon-circle-right2 position-right"></i></button>
								</div>
								<div class="form-group">
								    <label class="control-label col-lg-2"></label>
								    <div class="col-lg-10"></div>
								  </div>
							</form>
							</div>
							<fieldset class="content-group">
								<table class="table table-striped table-bordered" id="datatable-sp2d">
						          <thead>
						            <tr>
						              <th class="text-center bg-slate-600">Tanggal SP2D</th>
						              <th class="text-center bg-slate-600">Nilai SP2D</th>
						              <th class="text-center bg-slate-600">Dok.</th>
						              <th class="text-center bg-slate-600">SP2D</th>
						            </tr>
						          </thead>
						        </table>
							</fieldset>
						</div> <!-- tab sp2d -->
					</div>
				</div> <!-- tab -->


			</div>
		</div>
	</div>
</div>
<!-- /info modal -->

   

<script type="text/javascript">
  	var url = '<?php echo $data['curl'] ?>';
  	var url2 = '<?php echo $data['curl4'] ?>';
  	

  	// #HPS
	$('#post-hps').on('click', function() {
	  let data = new FormData($("#hps-form")[0]);
	  var hps = $("#sphval").val();
	  $.ajax({
	    url: url+'savehps/'+hps,
	    type: 'POST',
	    data: data,
	    processData: false,
	    contentType: false,
	    success: function(r) {
	      gethps(hps);
	      $('#hps-form')[0].reset();
			new PNotify({
	            title: 'sukses',
	            text: 'Data HPS berhasil disimpan.',
	            addclass: 'bg-primary alert-styled-left'
	        });

         
	    },
	    error: function(r) {
	      console.log('error', r);
	    }
	  });
	});

	function gethps(a){
     	$('#sphval').val(a);
     	if(!a){
			var a = $("#sphval").val();
		}
	    $('#datatable-hps').DataTable({
          	"destroy": true,
          	"processing": true,
          	"serverSide": true, 
          	"paging": false,
          	"searching": false,
          	"info": false,
          	"order": [0],
          	"ajax": {
	              "url": url+'getdatahps/'+a,
	              "type": "POST"
	        },
	        "columns": [
              	{"data": 1,width:'auto', orderable: false, searchable:true, className:'text-center'},
              	{"data": 2,width:'auto', orderable: false, searchable:true, className: 'text-right text-bold'},
              	{
	                "data": null,
	                "width": 50,
	                "sortable": false,
	                "className": "center",
	                "render": function ( data, type, row, meta ) {
	                     return "<a href=\""+url+'downloadpdf/'+row[0]+"\"  class=\"btn-sx text-danger\" data-toggle=\"modal\" data-target=\"#modal_hps_dokumen\" title=\"Dokumen HPS\"><i class=\"icon-file-pdf\"></i></a> ";
	                 }
	            },
              	{
	                "data": null,
	                "width": 50,
	                "sortable": false,
	                "className": "center",
	                "render": function ( data, type, row, meta ) {
	                     return "<a href=\""+url+'downloadexcel/'+row[0]+"\"  class=\"btn-sx text-teal\" data-toggle=\"modal\" data-target=\"#modal_hps_dokumen\" title=\"File HPS\"><i class=\"icon-file-excel\"></i></a> ";
	                 }
	            }
          	]
     	});
	}

	// #TOR
	$('#post-tor').on('click', function() {
	  let data = new FormData($("#tor-form")[0]);
	  //var tor = $("#torval").val();
	  var tor = $("#sphval").val();
	  $.ajax({
	    url: url+'savetor/'+tor,
	    type: 'POST',
	    data: data,
	    processData: false,
	    contentType: false,
	    success: function(r) {
	      gettor(tor);
	      $('#tor-form')[0].reset();
			new PNotify({
	            title: 'sukses',
	            text: 'Data berhasil disimpan.',
	            addclass: 'bg-primary alert-styled-left'
	        });

         
	    },
	    error: function(r) {
	      console.log('error', r);
	    }
	  });
	});

	function gettor(b){
		if(!b){
			var b = $("#sphval").val();
		}
     	$('#torval').val(b);
     	
	    $('#datatable-tor').DataTable({
          	"destroy": true,
          	"processing": true,
          	"serverSide": true, 
          	"paging": false,
          	"searching": false,
          	"info": false,
          	"order": [0],
          	"ajax": {
	              "url": url+'getdatator/'+b,
	              "type": "POST"
	        },
	        "columns": [
              	{"data": 1,width:'auto', orderable: false, searchable:true, className:'text-center'},
              	{
	                "data": null,
	                "width": 50,
	                "sortable": false,
	                "className": "center",
	                "render": function ( data, type, row, meta ) {
	                     return "<a href=\""+url+'downloadpdf/'+row[0]+"\"  class=\"btn-sx text-danger\" data-toggle=\"modal\" data-target=\"#modal_tor_dokumen\" title=\"Dokumen TOR\"><i class=\"icon-file-pdf\"></i></a> ";
	                 }
	            },
              	{
	                "data": null,
	                "width": 50,
	                "sortable": false,
	                "className": "center",
	                "render": function ( data, type, row, meta ) {
	                     return "<a href=\""+url+'downloadexcel/'+row[0]+"\"  class=\"btn-sx text-teal\" data-toggle=\"modal\" data-target=\"#modal_tor_dokumen\" title=\"File TOR\"><i class=\"icon-file-excel\"></i></a> ";
	                 }
	            }
          	]
     	});
	}

	// #RAB
	$('#post-rab').on('click', function() {
	  let data = new FormData($("#rab-form")[0]);
	  var rab = $("#sphval").val();
	  //var rab = $("#rabval").val();
	  $.ajax({
	    url: url+'saverab/'+rab,
	    type: 'POST',
	    data: data,
	    processData: false,
	    contentType: false,
	    success: function(r) {
	      getrab(rab);
	      $('#rab-form')[0].reset();
			new PNotify({
	            title: 'sukses',
	            text: 'Data berhasil disimpan.',
	            addclass: 'bg-primary alert-styled-left'
	        });

         
	    },
	    error: function(r) {
	      console.log('error', r);
	    }
	  });
	});

	function getrab(c){
		if(!c){
			var c = $("#sphval").val();
		}
     	$('#rabval').val(c);
	    $('#datatable-rab').DataTable({
          	"destroy": true,
          	"processing": true,
          	"serverSide": true, 
          	"paging": false,
          	"searching": false,
          	"info": false,
          	"order": [0],
          	"ajax": {
	              "url": url+'getdatarab/'+c,
	              "type": "POST"
	        },
	        "columns": [
              	{"data": 1,width:'auto', orderable: false, searchable:true, className:'text-center'},
              	{"data": 2,width:'auto', orderable: false, searchable:true, className: 'text-right text-bold'},
              	{
	                "data": null,
	                "width": 50,
	                "sortable": false,
	                "className": "center",
	                "render": function ( data, type, row, meta ) {
	                     return "<a href=\""+url+'downloadpdf/'+row[0]+"\"  class=\"btn-sx text-danger\" data-toggle=\"modal\" data-target=\"#modal_rab_dokumen\" title=\"Dokumen TOR\"><i class=\"icon-file-pdf\"></i></a> ";
	                 }
	            },
              	{
	                "data": null,
	                "width": 50,
	                "sortable": false,
	                "className": "center",
	                "render": function ( data, type, row, meta ) {
	                     return "<a href=\""+url+'downloadexcel/'+row[0]+"\"  class=\"btn-sx text-teal\" data-toggle=\"modal\" data-target=\"#modal_rab_dokumen\" title=\"File TOR\"><i class=\"icon-file-excel\"></i></a> ";
	                 }
	            }
          	]
     	});
	}


	// #SPH
	$('#post-sph').on('click', function() {
	  let data = new FormData($("#sph-form")[0]);
	  var sph = $("#sphval").val();
	  // var sph = $("#sphval").val();
	  $.ajax({
	    url: url+'savesph/'+sph,
	    type: 'POST',
	    data: data,
	    processData: false,
	    contentType: false,
	    success: function(r) {
	      getsph(sph);
	      $('#sph-form')[0].reset();
			new PNotify({
	            title: 'sukses',
	            text: 'Data berhasil disimpan.',
	            addclass: 'bg-primary alert-styled-left'
	        });

         
	    },
	    error: function(r) {
	      console.log('error', r);
	    }
	  });
	});

	function getsph(d){
		if(!d){
			var d = $("#sphval").val();
		}
     	$('#sphval').val(d);
	    $('#datatable-sph').DataTable({
          	"destroy": true,
          	"processing": true,
          	"serverSide": true, 
          	"paging": false,
          	"searching": false,
          	"info": false,
          	"order": [0],
          	"ajax": {
	              "url": url+'getdatasph/'+d,
	              "type": "POST"
	        },
	        "columns": [
              	{"data": 1,width:'auto', orderable: false, searchable:true, className:'text-center'},
              	{"data": 2,width:'auto', orderable: false, searchable:true, className: 'text-right text-bold'},
              	{
	                "data": null,
	                "width": 50,
	                "sortable": false,
	                "className": "center",
	                "render": function ( data, type, row, meta ) {
	                     return "<a href=\""+url+'downloadpdf/'+row[0]+"\"  class=\"btn-sx text-danger\" data-toggle=\"modal\" data-target=\"#modal_sph_dokumen\" title=\"Dokumen TOR\"><i class=\"icon-file-pdf\"></i></a> ";
	                 }
	            },
              	{
	                "data": null,
	                "width": 50,
	                "sortable": false,
	                "className": "center",
	                "render": function ( data, type, row, meta ) {
	                     return "<a href=\""+url+'downloadexcel/'+row[0]+"\"  class=\"btn-sx text-teal\" data-toggle=\"modal\" data-target=\"#modal_sph_dokumen\" title=\"File TOR\"><i class=\"icon-file-excel\"></i></a> ";
	                 }
	            }
          	]
     	});
	}


	// #KONTRAK
	$('#post-kontrak').on('click', function() {
	  let data = new FormData($("#kontrak-form")[0]);
	  var kontrak = $("#sphval").val();
	  //var kontrak = $("#kontrakval").val();
	  $.ajax({
	    url: url+'savekontrak/'+kontrak,
	    type: 'POST',
	    data: data,
	    processData: false,
	    contentType: false,
	    success: function(r) {
	      getkontrak(kontrak);
	      $('#kontrak-form')[0].reset();
			new PNotify({
	            title: 'sukses',
	            text: 'Data berhasil disimpan.',
	            addclass: 'bg-primary alert-styled-left'
	        });

         
	    },
	    error: function(r) {
	      console.log('error', r);
	    }
	  });
	});

	function getkontrak(e){
		if(!e){
			var e = $("#sphval").val();
		}
     	$('#kontrakval').val(e);
	    $('#datatable-kontrak').DataTable({
          	"destroy": true,
          	"processing": true,
          	"serverSide": true, 
          	"paging": false,
          	"searching": false,
          	"info": false,
          	"order": [0],
          	"ajax": {
	              "url": url+'getdatakontrak/'+e,
	              "type": "POST"
	        },
	        "columns": [
              	{"data": 1,width:'auto', orderable: false, searchable:true, className:'text-center'},
              	{"data": 2,width:'auto', orderable: false, searchable:true, className: 'text-right text-bold'},
              	{"data": 3,width:'auto', orderable: false, searchable:true, className: 'text-center text-bold'},
              	{
	                "data": null,
	                "width": 50,
	                "sortable": false,
	                "className": "center",
	                "render": function ( data, type, row, meta ) {
	                     return "<a href=\""+url+'downloadpdf/'+row[0]+"\"  class=\"btn-sx text-danger\" data-toggle=\"modal\" data-target=\"#modal_kontrak_dokumen\" title=\"Dokumen TOR\"><i class=\"icon-file-pdf\"></i></a> ";
	                 }
	            },
              	{
	                "data": null,
	                "width": 50,
	                "sortable": false,
	                "className": "center",
	                "render": function ( data, type, row, meta ) {
	                     return "<a href=\""+url+'downloadexcel/'+row[0]+"\"  class=\"btn-sx text-teal\" data-toggle=\"modal\" data-target=\"#modal_kontrak_dokumen\" title=\"File TOR\"><i class=\"icon-file-excel\"></i></a> ";
	                 }
	            }
          	]
     	});
	}

	// #BAST
	$('#post-bast').on('click', function() {
	  let data = new FormData($("#bast-form")[0]);
	  var bast = $("#sphval").val();
	  //var bast = $("#bastval").val();
	  $.ajax({
	    url: url+'savebast/'+bast,
	    type: 'POST',
	    data: data,
	    processData: false,
	    contentType: false,
	    success: function(r) {
	      getbast(bast);
	      $('#bast-form')[0].reset();
			new PNotify({
	            title: 'sukses',
	            text: 'Data berhasil disimpan.',
	            addclass: 'bg-primary alert-styled-left'
	        });

         
	    },
	    error: function(r) {
	      console.log('error', r);
	    }
	  });
	});

	function getbast(f){
		if(!f){
			var f = $("#sphval").val();
		}
     	$('#bastval').val(f);
	    $('#datatable-bast').DataTable({
          	"destroy": true,
          	"processing": true,
          	"serverSide": true, 
          	"paging": false,
          	"searching": false,
          	"info": false,
          	"order": [0],
          	"ajax": {
	              "url": url+'getdatabast/'+f,
	              "type": "POST"
	        },
	        "columns": [
              	{"data": 1,width:'auto', orderable: false, searchable:true, className:'text-center'},
              	{"data": 2,width:'auto', orderable: false, searchable:true, className: 'text-right text-bold'},
              	{
	                "data": null,
	                "width": 50,
	                "sortable": false,
	                "className": "center",
	                "render": function ( data, type, row, meta ) {
	                     return "<a href=\""+url+'downloadpdf/'+row[0]+"\"  class=\"btn-sx text-danger\" data-toggle=\"modal\" data-target=\"#modal_bast_dokumen\" title=\"Dokumen TOR\"><i class=\"icon-file-pdf\"></i></a> ";
	                 }
	            },
              	{
	                "data": null,
	                "width": 50,
	                "sortable": false,
	                "className": "center",
	                "render": function ( data, type, row, meta ) {
	                     return "<a href=\""+url+'downloadexcel/'+row[0]+"\"  class=\"btn-sx text-teal\" data-toggle=\"modal\" data-target=\"#modal_bast_dokumen\" title=\"File TOR\"><i class=\"icon-file-excel\"></i></a> ";
	                 }
	            }
          	]
     	});
	}

	// #KU17
	$('#post-ku17').on('click', function() {
	  let data = new FormData($("#ku17-form")[0]);
	  var ku17 = $("#sphval").val();
	  //var ku17 = $("#ku17val").val();
	  $.ajax({
	    url: url+'saveku17/'+ku17,
	    type: 'POST',
	    data: data,
	    processData: false,
	    contentType: false,
	    success: function(r) {
	      getku17(ku17);
	      $('#ku17-form')[0].reset();
			new PNotify({
	            title: 'sukses',
	            text: 'Data berhasil disimpan.',
	            addclass: 'bg-primary alert-styled-left'
	        });

         
	    },
	    error: function(r) {
	      console.log('error', r);
	    }
	  });
	});

	function getku17(g){
		if(!g){
			var g = $("#sphval").val();
		}
     	$('#ku17val').val(g);
	    $('#datatable-ku17').DataTable({
          	"destroy": true,
          	"processing": true,
          	"serverSide": true, 
          	"paging": false,
          	"searching": false,
          	"info": false,
          	"order": [0],
          	"ajax": {
	              "url": url+'getdataku17/'+g,
	              "type": "POST"
	        },
	        "columns": [
              	{"data": 1,width:'auto', orderable: false, searchable:true, className:'text-center'},
              	{"data": 2,width:'auto', orderable: false, searchable:true, className: 'text-right text-bold'},
              	{
	                "data": null,
	                "width": 50,
	                "sortable": false,
	                "className": "center",
	                "render": function ( data, type, row, meta ) {
	                     return "<a href=\""+url+'downloadpdf/'+row[0]+"\"  class=\"btn-sx text-danger\" data-toggle=\"modal\" data-target=\"#modal_ku17_dokumen\" title=\"Dokumen TOR\"><i class=\"icon-file-pdf\"></i></a> ";
	                 }
	            },
              	{
	                "data": null,
	                "width": 50,
	                "sortable": false,
	                "className": "center",
	                "render": function ( data, type, row, meta ) {
	                     return "<a href=\""+url+'downloadexcel/'+row[0]+"\"  class=\"btn-sx text-teal\" data-toggle=\"modal\" data-target=\"#modal_ku17_dokumen\" title=\"File TOR\"><i class=\"icon-file-excel\"></i></a> ";
	                 }
	            }
          	]
     	});
	}


	// #SP2D
	$('#post-sp2d').on('click', function() {
	  let data = new FormData($("#sp2d-form")[0]);
	  var sp2d = $("#sphval").val();
	  //var sp2d = $("#sp2dval").val();
	  $.ajax({
	    url: url+'savesp2d/'+sp2d,
	    type: 'POST',
	    data: data,
	    processData: false,
	    contentType: false,
	    success: function(r) {
	      getsp2d(sp2d);
	      $('#sp2d-form')[0].reset();
			new PNotify({
	            title: 'sukses',
	            text: 'Data berhasil disimpan.',
	            addclass: 'bg-primary alert-styled-left'
	        });

         
	    },
	    error: function(r) {
	      console.log('error', r);
	    }
	  });
	});

	function getsp2d(h){
		if(!h){
			var h = $("#sphval").val();
		}
     	$('#sp2dval').val(h);
	    $('#datatable-sp2d').DataTable({
          	"destroy": true,
          	"processing": true,
          	"serverSide": true, 
          	"paging": false,
          	"searching": false,
          	"info": false,
          	"order": [0],
          	"ajax": {
	              "url": url+'getdatasp2d/'+h,
	              "type": "POST"
	        },
	        "columns": [
              	{"data": 1,width:'auto', orderable: false, searchable:true, className:'text-center'},
              	{"data": 2,width:'auto', orderable: false, searchable:true, className: 'text-right text-bold'},
              	{
	                "data": null,
	                "width": 50,
	                "sortable": false,
	                "className": "center",
	                "render": function ( data, type, row, meta ) {
	                     return "<a href=\""+url+'downloadpdf/'+row[0]+"\"  class=\"btn-sx text-danger\" data-toggle=\"modal\" data-target=\"#modal_sp2d_dokumen\" title=\"Dokumen TOR\"><i class=\"icon-file-pdf\"></i></a> ";
	                 }
	            },
              	{
	                "data": null,
	                "width": 50,
	                "sortable": false,
	                "className": "center",
	                "render": function ( data, type, row, meta ) {
	                     return "<a href=\""+url+'downloadexcel/'+row[0]+"\"  class=\"btn-sx text-teal\" data-toggle=\"modal\" data-target=\"#modal_sp2d_dokumen\" title=\"File TOR\"><i class=\"icon-file-excel\"></i></a> ";
	                 }
	            }
          	]
     	});
	}


  // MODAL 2  #Temuan
	$('#post-temuan').on('click', function() {
	  let data = new FormData($("#temuan-form")[0]);
	  //var tor = $("#torval").val();
	  var sphval = $("#sphval").val();
	   var x = document.forms["temuan-form"]["kategori"].value;
	   //VALIDASI FUNCTION TEMUAN //
	   if (x == "") {
	   alert("Field Kategori harus di isi !");
       return false;}
       else {
	  $.ajax({
	    url: url+'savetemuan/<?php echo $data['tahun'] ?>/<?php echo $data['bulan'] ?>/<?php echo $data['kotama'] ?>/<?php echo $data['satminkal'] ?>',
	    type: 'POST',
	    data: data,
	    processData: false,
	    contentType: false,
	    success: function(r) {
	      gettemuan(sphval);
	      $('#temuan-form')[0].reset();
	         $('#kategori').val('').trigger("change");
			new PNotify({
	            title: 'sukses',
	            text: 'Data berhasil disimpan.',
	            addclass: 'bg-primary alert-styled-left'
	        });

         
	    },
	    error: function(r) {
	      console.log('error', r);
	    }
	  });
	}}); 
	// END VALIDASI FUNCTION TEMUAN //

	function gettemuan(b){
		if(!b){
			var b = $("#sphval").val();
		}
     	$('#sphval').val(b);
     	
	    $('#datatable-temuan').DataTable({
          	"destroy": true,
          	"processing": true,
          	"serverSide": true, 
          	"paging": false,
          	"searching": false,
          	"info": false,
          	"order": [0],
          	"ajax": {
	              "url": url+'getdatatemuan/<?php echo $data['tahun'] ?>/<?php echo $data['bulan'] ?>/<?php echo $data['kotama'] ?>/<?php echo $data['satminkal'] ?>',
	              "type": "POST"
	        },
	        "columns": [
              	{"data": 1,width:'auto', orderable: false, searchable:true, className:'text-center'},
              	{"data": 2,width:'auto', orderable: false, searchable:true, className:'text-center'},
              	{"data": 7,width:'auto', orderable: false, searchable:true, className:'text-center'},
              	{"data": 6,width:'auto', orderable: false, searchable:true, className:'text-center'},

             {
                "data": null,

                "width": 250,

                "sortable": false,

                "className": "center",

                "render": function ( data, type, row, meta ) {
                 if(row[8] == 4)
                   {
                   return '<p class="text-success">Selesai</p>';
                 }
                 else if (row[8] == null) {
                    return 'Belum di Analisa';
                 }
                 else {
                    return '<a href="'+url2+'detail/<?php echo $data['encode']; ?>/<?php echo $data['tahun']; ?>/<?php echo $data['bulan']; ?>/'+row[5]+'/<?php echo $data['kotama'] ?>/<?php echo $data['satminkal'] ?>" class="btn-sx" data-popup="tooltip" data-original-title="Top tooltip"><b style="padding-right:10px;">Detail Temuan</b><i class="glyphicon glyphicon-circle-arrow-right"></i></a> <a href="#" onClick="deletes_temuan('+"'"+row[0]+"'"+')" class="btn-sx red" title="Delete"><i class="icon-cancel-square2"></i></a>';
                 }
                 }

            } //detail
          	]
     	});
	}   // #Temuan

	 // MODAL 2  #DASAR
	$('#post-dasar').on('click', function() {
	  let data = new FormData($("#dasar-form")[0]);
	  //var tor = $("#torval").val();
	  var sphval = $("#sphval").val();
	  $.ajax({
	    url: url+'savedasar/<?php echo $data['tahun'] ?>/<?php echo $data['bulan'] ?>/<?php echo $data['kotama'] ?>/<?php echo $data['satminkal'] ?>',
	    type: 'POST',
	    data: data,
	    processData: false,
	    contentType: false,
	    success: function(r) {
	      getdasar(sphval);
	      $('#temuan').val('').trigger("change");
		  // $('#temuan').data('select-search','refresh');
	      $('#dasar-form')[0].reset();
	      
			new PNotify({
	            title: 'sukses',
	            text: 'Data berhasil disimpan.',
	            addclass: 'bg-primary alert-styled-left'
	        });

         
	    },


	    error: function(r) {
	      console.log('error', r);
	    }
	  });
	});

	function getdasar(b){
		if(!b){
			var b = $("#sphval").val();
		}
     	$('#sphval').val(b);
     	
	    $('#datatable-dasar').DataTable({
          	"destroy": true,
          	"processing": true,
          	"serverSide": true, 
          	"paging": false,
          	"searching": false,
          	"info": false,
          	"order": [0],
          	"ajax": {
	              "url": url+'getdatadasar/<?php echo $data['tahun'] ?>/<?php echo $data['bulan'] ?>/<?php echo $data['kotama'] ?>/<?php echo $data['satminkal'] ?>',
	              "type": "POST"
	        },
	        "columns": [
              	{"data": 4,width:'auto', orderable: false, searchable:true, className:'text-center'},
              	{"data": 2,width:'auto', orderable: false, searchable:true, className:'text-center'},
              	{"data": 3,width:'auto', orderable: false, searchable:true, className:'text-center'}
          	]
     	});
	}   
	// $('form').validate().resetform();
	// #DASAR







  	$(function() {
	 	$('.datatable').DataTable({
	        "processing": true,
	        "serverSide": true, 
	        "order": [0],
	        "ajax": {
	            "url": url+'getdetail/<?php echo $data['encode'] ?>',
	            "type": "POST"
	        },
	        "columns": [
				{"data": 1,width:'auto', className:'text-left text-nowrap', orderable: false, searchable:true},
	            {"data": 8,width:'auto', className:'text-left  text-nowrap', orderable: false, searchable:true},
	             {
	                "data": 8,
	                "width": 'auto',
	                "sortable": false,
	                "className": "center text-nowrap",
	                "render": function ( data, type, row, meta ) {
	                      if(row[14] != null){                  
	                     var be = '<p class="label label-success">Sudah di Upload</p>';
	                   }
	                   else {
	                    var be = '<p class="label label-danger">Belum di Upload</p>';
                   }
                   return ''+be+'';
	                 }
	            },
	            {
	                "data": 8,
	                "width": 'auto',
	                "sortable": false,
	                "className": "center text-nowrap",
	                "render": function ( data, type, row, meta ) {
	                      if(row[15] != null){                  
	                     var bf = '<p class="label label-success">Sudah di Upload</p>';
	                   }
	                   else {
	                    var bf = '<p class="label label-danger">Belum di Upload</p>';
                   }
                   return ''+bf+'';
	                 }
	             },
	             {
	                "data": 8,
	                "width": 'auto',
	                "sortable": false,
	                "className": "center text-nowrap",
	                "render": function ( data, type, row, meta ) {
	                      if(row[16] != null){                  
	                     var bg = '<p class="label label-success">Sudah di Upload</p>';
	                   }
	                   else {
	                    var bg = '<p class="label label-danger">Belum di Upload</p>';
                   }
                   return ''+bg+'';
	                 }
	            },
	            {
	                "data": 8,
	                "width": 'auto',
	                "sortable": false,
	                "className": "center text-nowrap",
	                "render": function ( data, type, row, meta ) {
	                      if(row[9] != null){                  
	                     var bp = '<p class="label label-success">Sudah di Upload</p>';
	                   }
	                   else {
	                    var bp = '<p class="label label-danger">Belum di Upload</p>';
                   }
                   return ''+bp+'';
	                 }
	            },
	            {
	                "data": 8,
	                "width": 'auto',
	                "sortable": false,
	                "className": "center text-nowrap",
	                "render": function ( data, type, row, meta ) {
	                      if(row[10] != null){                  
	                     var ba = '<p class="label label-success">Sudah di Upload</p>';
	                   }
	                   else {
	                    var ba = '<p class="label label-danger">Belum di Upload</p>';
                   }
                   return ''+ba+'';
	                 }
	             },
	             {
	                "data": 8,
	                "width": 'auto',
	                "sortable": false,
	                "className": "center text-nowrap",
	                "render": function ( data, type, row, meta ) {
	                      if(row[11] != null){                  
	                     var bb = '<p class="label label-success">Sudah di Upload</p>';
	                   }
	                   else {
	                    var bb = '<p class="label label-danger">Belum di Upload</p>';
                   }
                   return ''+bb+'';
	                 }
	            },
	             {
	                "data": 8,
	                "width": 'auto',
	                "sortable": false,
	                "className": "center text-nowrap",
	                "render": function ( data, type, row, meta ) {
	                      if(row[12] != null){                  
	                     var bc = '<p class="label label-success">Sudah di Upload</p>';
	                   }
	                   else {
	                    var bc = '<p class="label label-danger">Belum di Upload</p>';
                   }
                   return ''+bc+'';
	                 }
	             },
	             {
	                "data": 8,
	                "width": 'auto',
	                "sortable": false,
	                "className": "center text-nowrap",
	                "render": function ( data, type, row, meta ) {
	                      if(row[13] != null){                  
	                     var bd = '<p class="label label-success">Sudah di Upload</p>';
	                   }
	                   else {
	                    var bd = '<p class="label label-danger">Belum di Upload</p>';
                   }
                   return ''+bd+'';
	                 }
	            },
	            {"data": 7,width:'auto', className:'text-right', searchable:false},

	            {
	                "data": null,
	                "width": 50,
	                "sortable": false,
	                "className": "center",
	                "render": function ( data, type, row, meta ) {
	                     return "<a href=\"#\" onclick=\"gethps('"+row[0]+"')\"   class=\"btn-sx\" data-toggle=\"modal\" data-target=\"#modal_datas\" title=\"Lihat data dokumen\"><i class=\"icon-zoomin3 text-slate-300\"></i></a> ";
	                 }
	            },
	            {
	                "data": null,
	                "width": 50,
	                "sortable": false,
	                "className": "center",
	                "render": function ( data, type, row, meta ) {
	                     return "<a href=\"#\" onclick=\"showakun('"+row[0]+"')\"  class=\"btn-sx\" data-toggle=\"modal\" data-target=\"#modal_akun\" title=\"Lihat Akun\"><i class=\"icon-file-spreadsheet2 text-teal-600\"></i></a> ";
	                 }
	            },
	            
	         




	        ]
    	});
  	});
  	function showakun(a){
     	// Show file
	    $('#dthps').DataTable({
          	"destroy": true,
          	"processing": true,
          	"serverSide": true, 
          	"paging": false,
          	"searching": true,
          	"info": false,
          	"order": [0],
          	"ajax": {
	              "url": url+'getrab/'+a,
	              "type": "POST"
	        },
	        "columns": [
              	{"data": 1,width:'auto', orderable: false, searchable:true},
              	{"data": 2,width:'auto', orderable: false, searchable:true},
              	{"data": 3,width:'auto', orderable: false, searchable:false, className:'text-right'}

          	]
     	});
	}

function deletes_temuan(i) {
  swal({
      title:"Are you sure?",
      text: "You will not be able to recover this data!",
      type: "warning",
      showCancelButton: true,
      confirmButtonColor: "#EF5350",
      confirmButtonText: "Yes, delete it!",
      cancelButtonText: "No, cancel!",
      closeOnConfirm: false,
      closeOnCancel: true
  },
  function(isConfirm){
      if (isConfirm) {
        $.post(url+'delete_temuan/'+i, function(data, status){
          $('#datatable-temuan').DataTable().ajax.reload();
          var table = $('.datatable').DataTable();
          table.ajax.reload(null, false);
            if(status == 'success'){
               swal({
                  title:"Deleted!",
                  text: "Your data has been deleted.",
                  confirmButtonColor: "#66BB6A",
                  type: "success",
                  timer: 2000
              });
            }
        });
      }
  });
}

</script>