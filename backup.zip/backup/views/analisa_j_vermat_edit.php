<?php include('header.php'); ?>
              <!-- Page header -->
              <div class="page-header">
                <div class="page-header-content">
                  <div class="page-title">
                    <h4><i class="icon-arrow-left52 position-left"></i> <span class="text-semibold"><?php echo $data['breadcrumb1']; ?></span> - <?php echo $data['title'] ?></h4>
                  </div>
                </div>

                <div class="breadcrumb-line">
                  <ul class="breadcrumb">
                    <li><a href="<?php echo BASE_URL ?>"><i class="icon-home2 position-left"></i> Home</a></li>
                    <li><a href="<?php echo $data['curl'] ?>"><?php echo $data['breadcrumb1'] ?></a></li>
                    <li><a href="<?php echo $data['curl'] ?>"><?php echo $data['title'] ?></a></li>
                    <li class="active"><?php echo $data['action'] ?></li>
                  </ul>
                </div>
              </div>
              <!-- /page header -->

              <!-- Content area -->
              <div class="content">
                <div class="panel panel-flat">
                    <div class="panel-heading">
                      <h5 class="panel-title"><strong><?php echo $data['action'] ?></strong> <?php echo $data['title'] ?></h5>
                      <div class="heading-elements">
                        <ul class="icons-list">
                          <li><a data-action="collapse"></a></li>
                          <li><a data-action="reload"></a></li>
                          <li><a data-action="close"></a></li>
                        </ul>
                      </div>
                    </div>
                    <div class="panel-body">
                      <form class="form-horizontal" action="<?php echo $data['curl']."/update/".$data['autono']."/".$data['tahun']."/".$data['bulan'].'/'.$data['kotama'].'/'.$data['satminkal']; ?>" method="post" enctype="multipart/form-data">
                        <fieldset class="content-group">
                        


                          <div class="form-group">
                            <label class="control-label col-lg-2">Jawaban</label>
                            <div class="col-lg-10" style="width: 600px;">
                              <textarea class="summernote" name="jawaban" id="jawaban"><?php echo $data['aadata']['jawaban']?></textarea>
                            </div>
                          </div>
                                         <div class="col-md-6">
                          <div class="form-group">
                            <label><b>Data Pendukung<b></label>
                              <input type="file" id="file-input-extension" multiple="multiple" name="upload[]" data-show-upload="false" data-show-caption="true" data-show-preview="true">
                              <span class="help-block">Allow only <code>.pdf </code>file types to be uploaded.</span>
                            </div>

                            <div class="row">
                              <?php foreach ($data['attch'] as $key => $attch) { ?>
                                <div class="col-lg-3 col-sm-6" style="height: 150px">
                                  <div class="thumbnail">
                                    <div class="thumb">
                                      <?php $tipe = explode('/', $attch['tipe_file']);  
                                      if($tipe['1'] == 'pdf')
                                      {                                     
                                        echo "<img src=\"".BASE_URL."static/images/pdf-logo.jpg"."\" >";
                                        echo $attch['nama_file'];
                                      }  
                                      else 
                                      { 
                                        echo '<img src="'.BASE_URL."static/files/".$attch['dir']."/".$attch['kode_parent']."/".$attch['nama_file'].'" class=\"col-lg-2 col-sm-6\" alt="">';  
                                      } 
                                      ?>
                                      <div class="caption-overflow">
                                        <span>
                                          <?php 
                                          if($tipe['1'] == 'pdf')
                                          {
                                            echo '<a href="'.BASE_URL."static/files/".$attch['dir']."/".$attch['kode_parent']."/".$attch['nama_file'].'" data-popup="lightbox" rel="gallery" target="_blank" class="btn border-white text-white btn-flat btn-icon btn-rounded"><i class="icon-eye"></i></a>';  
                                          } 
                                          else
                                          { 
                                            echo '<a href="'.BASE_URL."static/files/".$attch['dir']."/".$attch['kode_parent']."/".$attch['nama_file'].'" data-popup="lightbox" rel="gallery" target="_blank" class="btn border-white text-white btn-flat btn-icon btn-rounded"><i class="icon-eye"></i></a>';  
                                          }  
                                          ?>
                                          <a href="#" onClick="delete_files(1, '<?php echo $attch['autono'] ?>')" class="btn border-white text-white btn-flat btn-icon btn-rounded ml-5 red" title="Delete file"><i class="icon-trash"></i></a>
                                        </span>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              <?php } ?>
                            </div>
                          </div>

                           <input type="hidden" name="status" value="5">
                             
                        </fieldset>
                        <div class="text-right">
                           <a href="<?php echo $data['curl'] ?>" class="btn btn-danger btn-sx"><i class="icon-circle-left2 position-left"></i> Cancel</a> 
                          <button type="submit" class="btn btn-primary">Submit <i class="icon-circle-right2 position-right"></i></button>
                        </div>
                      </form>
                    </div>

 <script type="text/javascript">


// FUNCTION UNTUK AMBIL TAHUN DARI COMBOBOX //
 $("#nm_tunhv").on('change', function(result){

   var keterangan = $(this).val();   
    if(keterangan == 5)
    {
      $("#jawaban").attr('disabled', true);
      document.getElementById("keterangan").value = "";
    }
    else
    {

      $("#keterangan").attr('disabled', false);
    }
    // alert (tahun);
    
});

$(function() {
    // // Custom file extensions
    $("#file-input-extension").fileinput({
      browseLabel: 'Browse',
      browseClass: 'btn btn-primary',
      uploadClass: 'btn btn-default',
      browseIcon: '<i class="icon-file-plus"></i>',
      uploadIcon: '<i class="icon-file-upload2"></i>',
      removeIcon: '<i class="icon-cross3"></i>',
      layoutTemplates: {
        icon: '<i class="icon-file-check"></i>'
      },
      maxFilesNum: 10,
      allowedFileExtensions: ["pdf"]
    });
  }); 

$('.summernote').summernote(
{
    toolbar: [
      // [groupName, [list of button]]
      ['style', ['bold', 'italic', 'underline', 'clear']],
      ['para', ['paragraph']],
      ['table', ['table']]
    ]
  });

</script>                    
          
<?php include('footer.php'); ?>