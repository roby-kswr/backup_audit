<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?php global $config; echo $config['app_name']?></title>
 <!--  <link href="https://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900" rel="stylesheet" type="text/css"> -->
  <link rel="icon" type="image/png" sizes="16x16" href="<?php echo BASE_URL ?>static/images/vitechasia.png">
  <link href="<?php echo BASE_URL ?>static/css/icons/icomoon/styles.css" rel="stylesheet" type="text/css">
  <link href="<?php echo BASE_URL ?>static/css/bootstrap.css" rel="stylesheet" type="text/css">
  <link href="<?php echo BASE_URL ?>static/css/core.css" rel="stylesheet" type="text/css">
  <link href="<?php echo BASE_URL ?>static/css/components.css" rel="stylesheet" type="text/css">
  <link href="<?php echo BASE_URL ?>static/css/colors.css" rel="stylesheet" type="text/css">
  <!-- /global stylesheets -->

  <!-- Core JS files -->
  <script type="text/javascript" src="<?php echo BASE_URL ?>static/js/plugins/loaders/pace.min.js"></script>
  <script type="text/javascript" src="<?php echo BASE_URL ?>static/js/core/libraries/jquery.min.js"></script>
  <script type="text/javascript" src="<?php echo BASE_URL ?>static/js/core/libraries/bootstrap.min.js"></script>
  <script type="text/javascript" src="<?php echo BASE_URL ?>static/js/plugins/loaders/blockui.min.js"></script>
  <!-- /core JS files -->

  <!-- Theme JS files -->
  <script type="text/javascript" src="<?php echo BASE_URL ?>static/js/plugins/tables/datatables/datatables.min.js"></script>
  <script type="text/javascript" src="<?php echo BASE_URL ?>static/js/plugins/forms/selects/select2.min.js"></script>
  <script type="text/javascript" src="<?php echo BASE_URL ?>static/js/plugins/tables/datatables/extensions/buttons.min.js"></script>
  <script type="text/javascript" src="<?php echo BASE_URL ?>static/js/plugins/tables/datatables/extensions/jszip/jszip.min.js"></script>
  <script type="text/javascript" src="<?php echo BASE_URL ?>static/js/plugins/tables/datatables/extensions/pdfmake/pdfmake.min.js"></script>
  <script type="text/javascript" src="<?php echo BASE_URL ?>static/js/plugins/tables/datatables/extensions/pdfmake/vfs_fonts.min.js"></script>


  <script type="text/javascript" src="<?php echo BASE_URL ?>static/js/plugins/extensions/session_timeout.min.js"></script>

  <script type="text/javascript" src="<?php echo BASE_URL ?>static/js/core/app.js"></script>
  <script type="text/javascript" src="<?php echo BASE_URL ?>static/js/pages/datatables_extension_buttons_html5.js"></script>
  <script type="text/javascript">var url_session = '<?php echo BASE_URL ?>auth/logout';</script>

</head>

<body class="navbar-top">
  <!-- Main navbar -->
  <div class="navbar navbar-inverse navbar-fixed-top">
    <div class="navbar-header">
      <a class="navbar-brand" href="<?php echo BASE_URL ?>"><i class="icon-circle-code position-left text-teal"></i><span>Aplikasi E-Audit</span></a>

      <ul class="nav navbar-nav pull-right visible-xs-block">
        <li><a data-toggle="collapse" data-target="#navbar-mobile"><i class="icon-tree5"></i></a></li>
        <li><a class="sidebar-mobile-main-toggle"><i class="icon-paragraph-justify3"></i></a></li>
      </ul>
    </div>

    <div class="navbar-collapse collapse" id="navbar-mobile">
      <ul class="nav navbar-nav">
        <li><a class="sidebar-control sidebar-main-toggle hidden-xs"><i class="icon-paragraph-justify3"></i></a></li>
      </ul>

      <ul class="nav navbar-nav navbar-right">
        <li class="dropdown dropdown-user">
          <a class="dropdown-toggle" data-toggle="dropdown">
            <i class="icon-user"></i><span><?php echo $_SESSION['username']." " ?></span>  <i class="caret"> </i>
          </a>

          <ul class="dropdown-menu dropdown-menu-right">
            <li><a href="#"><i class="icon-user-plus"></i> My profile</a></li>
            <li><a href="#"><span class="badge badge-warning pull-right">0</span> <i class="icon-comment-discussion"></i> Messages</a></li>
            <li class="divider"></li>
            <li><a href="#"><i class="icon-cog5"></i> Account settings</a></li>
            <li><a href="<?php echo BASE_URL ?>auth/logout"><i class="icon-switch2"></i> Logout</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
  <!-- /main navbar -->
  <!-- Page container -->
  <div class="page-container">
    <!-- Page content -->
    <div class="page-content">
      <!-- Main sidebar -->
      <div class="sidebar sidebar-main sidebar-fixed">
        <div class="sidebar-content">

          <div class="sidebar-user">
            <div class="category-content">
              <div class="media">
                <a href="#" class="media-left"><img src="<?php echo BASE_URL ?>static/images/mabes_ad1.png" class="img-ad img-thumbnail" alt=""></a>
                <div class="media-body">
                  <span class="media-heading text-semibold text-warning-400 text-size-mini">INSPEKTORAT JENDERAL</span>
                  <div class="text-size-mini text-muted">ANGKATAN DARAT</div>
                </div>
              </div>
            </div>
          </div>


          <!-- Main navigation -->
          <div class="sidebar-category sidebar-category-visible">
            <div class="category-content no-padding">
              <ul class="navigation navigation-main navigation-accordion">
                <li class="navigation-header"><span>Main menu</span> <i class="icon-menu" title="" data-original-title="Main pages"></i></li>
                <!-- Main menu -->
                <?php 
                
                    $mn = new Model();

                    $result = $mn->show_menu($_SESSION['groupid']);
                    
                    while ($row = $mn->fetch_object($result)) {

                    $data[$row->parent_id][] = $row;
                    
                    }
                    
                    $menu = $mn->get_menu($data);
                    
                    echo $menu;

                 ?>

                <!-- /main menu-->
              </ul>
            </div>
          </div>
          <!-- /main navigation -->
        </div>
      </div>
      <!-- /main sidebar -->

      <!-- Main content -->
      <div class="content-wrapper">
        <div class="content">
          <div class="container-fluid text-center">
            <code><h1 class="text-danger">Under maintenance</h1></code>
            <h3 class="text-bold"></h3>
            <h6 class="text-muted">The page under maintenance, please contact your web apps developer.</h6>
            <div class="row">
              <div class="col-lg-4 col-lg-offset-4 col-sm-6 col-sm-offset-3">
                <form action="#" class="main-search">
                  <div class="row">
                    <div class="col-sm-12">
                      <!-- <a href="<?php echo BASE_URL; ?>" class="btn btn-info btn-block content-group"><i class="icon-circle-left2 position-left"></i> Go to dashboard</a> -->
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
          <div class="footer text-muted">
            <small>Copyright &copy;2020 - <a href="https://vitech.asia" title="Go to https://vitech.asia/" target="_blank">Vitech Asia</a></small>
          </div>
        </div>
      </div>
        <!-- /content area -->
      </div>
      <!-- /main content -->
    </div>
    <!-- /page content -->
  </div>
  <!-- /page container -->
</body>
</html>
